﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace Parse.Internal
{
	// Token: 0x02000007 RID: 7
	internal class FacebookAuthenticationProvider : IParseAuthenticationProvider
	{
		// Token: 0x17000008 RID: 8
		// (set) Token: 0x0600001C RID: 28 RVA: 0x00002640 File Offset: 0x00000840
		public string AccessToken
		{
			[CompilerGenerated]
			set
			{
				this.<AccessToken>k__BackingField = value;
			}
		}

		// Token: 0x0600001D RID: 29 RVA: 0x0000264C File Offset: 0x0000084C
		public void Deauthenticate()
		{
			this.AccessToken = null;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002658 File Offset: 0x00000858
		public bool RestoreAuthentication(IDictionary<string, object> authData)
		{
			if (authData == null)
			{
				this.Deauthenticate();
			}
			else
			{
				this.AccessToken = authData["access_token"] as string;
			}
			return true;
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600001F RID: 31 RVA: 0x0000267C File Offset: 0x0000087C
		public string AuthType
		{
			get
			{
				return "facebook";
			}
		}

		// Token: 0x0400000C RID: 12
		internal static readonly Uri LoginDialogUrl = new Uri("https://www.facebook.com/dialog/oauth", UriKind.Absolute);

		// Token: 0x0400000D RID: 13
		private static readonly Uri TokenExtensionUrl = new Uri("https://graph.facebook.com/oauth/access_token", UriKind.Absolute);

		// Token: 0x0400000E RID: 14
		internal static readonly Uri ResponseUrl = new Uri("https://www.facebook.com/connect/login_success.html", UriKind.Absolute);

		// Token: 0x0400000F RID: 15
		private static readonly Uri MeUrl = new Uri("https://graph.facebook.com/me", UriKind.Absolute);

		// Token: 0x04000010 RID: 16
		private TaskCompletionSource<IDictionary<string, object>> pendingTask;

		// Token: 0x04000011 RID: 17
		private CancellationToken pendingCancellationToken;

		// Token: 0x04000012 RID: 18
		private Action<Uri> Navigate;
	}
}
