﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Parse.Internal
{
	// Token: 0x02000008 RID: 8
	internal class FlexibleDictionaryWrapper<TOut, TIn> : IDictionary<string, TOut>, ICollection<KeyValuePair<string, TOut>>, IEnumerable<KeyValuePair<string, TOut>>, IEnumerable
	{
		// Token: 0x06000020 RID: 32 RVA: 0x00002684 File Offset: 0x00000884
		public void Add(string key, TOut value)
		{
			this.toWrap.Add(key, (TIn)((object)ParseClient.ConvertTo<TIn>(value)));
		}

		// Token: 0x06000021 RID: 33 RVA: 0x000026A4 File Offset: 0x000008A4
		public bool ContainsKey(string key)
		{
			return this.toWrap.ContainsKey(key);
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000022 RID: 34 RVA: 0x000026B4 File Offset: 0x000008B4
		public ICollection<string> Keys
		{
			get
			{
				return this.toWrap.Keys;
			}
		}

		// Token: 0x06000023 RID: 35 RVA: 0x000026C4 File Offset: 0x000008C4
		public bool Remove(string key)
		{
			return this.toWrap.Remove(key);
		}

		// Token: 0x06000024 RID: 36 RVA: 0x000026D4 File Offset: 0x000008D4
		public bool TryGetValue(string key, out TOut value)
		{
			TIn tin;
			bool flag = this.toWrap.TryGetValue(key, out tin);
			value = (TOut)((object)ParseClient.ConvertTo<TOut>(tin));
			return flag;
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000025 RID: 37 RVA: 0x00002708 File Offset: 0x00000908
		public ICollection<TOut> Values
		{
			get
			{
				return this.toWrap.Values.Select<TIn, TOut>((TIn item) => (TOut)((object)ParseClient.ConvertTo<TOut>(item))).ToList<TOut>();
			}
		}

		// Token: 0x1700000C RID: 12
		public TOut this[string key]
		{
			get
			{
				return (TOut)((object)ParseClient.ConvertTo<TOut>(this.toWrap[key]));
			}
			set
			{
				this.toWrap[key] = (TIn)((object)ParseClient.ConvertTo<TIn>(value));
			}
		}

		// Token: 0x06000028 RID: 40 RVA: 0x0000277C File Offset: 0x0000097C
		public void Add(KeyValuePair<string, TOut> item)
		{
			this.toWrap.Add(new KeyValuePair<string, TIn>(item.Key, (TIn)((object)ParseClient.ConvertTo<TIn>(item.Value))));
		}

		// Token: 0x06000029 RID: 41 RVA: 0x000027AC File Offset: 0x000009AC
		public void Clear()
		{
			this.toWrap.Clear();
		}

		// Token: 0x0600002A RID: 42 RVA: 0x000027BC File Offset: 0x000009BC
		public bool Contains(KeyValuePair<string, TOut> item)
		{
			return this.toWrap.Contains(new KeyValuePair<string, TIn>(item.Key, (TIn)((object)ParseClient.ConvertTo<TIn>(item.Value))));
		}

		// Token: 0x0600002B RID: 43 RVA: 0x000027EC File Offset: 0x000009EC
		public void CopyTo(KeyValuePair<string, TOut>[] array, int arrayIndex)
		{
			IEnumerable<KeyValuePair<string, TOut>> enumerable = this.toWrap.Select<KeyValuePair<string, TIn>, KeyValuePair<string, TOut>>((KeyValuePair<string, TIn> pair) => new KeyValuePair<string, TOut>(pair.Key, (TOut)((object)ParseClient.ConvertTo<TOut>(pair.Value))));
			enumerable.ToList<KeyValuePair<string, TOut>>().CopyTo(array, arrayIndex);
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600002C RID: 44 RVA: 0x00002830 File Offset: 0x00000A30
		public int Count
		{
			get
			{
				return this.toWrap.Count;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600002D RID: 45 RVA: 0x00002840 File Offset: 0x00000A40
		public bool IsReadOnly
		{
			get
			{
				return this.toWrap.IsReadOnly;
			}
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00002850 File Offset: 0x00000A50
		public bool Remove(KeyValuePair<string, TOut> item)
		{
			return this.toWrap.Remove(new KeyValuePair<string, TIn>(item.Key, (TIn)((object)ParseClient.ConvertTo<TIn>(item.Value))));
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00002880 File Offset: 0x00000A80
		public IEnumerator<KeyValuePair<string, TOut>> GetEnumerator()
		{
			foreach (KeyValuePair<string, TIn> pair in this.toWrap)
			{
				KeyValuePair<string, TIn> keyValuePair = pair;
				string key = keyValuePair.Key;
				KeyValuePair<string, TIn> keyValuePair2 = pair;
				yield return new KeyValuePair<string, TOut>(key, (TOut)((object)ParseClient.ConvertTo<TOut>(keyValuePair2.Value)));
			}
			yield break;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x0000289C File Offset: 0x00000A9C
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x04000018 RID: 24
		private readonly IDictionary<string, TIn> toWrap;
	}
}
