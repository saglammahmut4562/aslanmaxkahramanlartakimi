﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Parse.Internal
{
	// Token: 0x0200000A RID: 10
	internal class FlexibleListWrapper<TOut, TIn> : IList<TOut>, ICollection<TOut>, IEnumerable<TOut>, IEnumerable
	{
		// Token: 0x0600003A RID: 58 RVA: 0x00002A44 File Offset: 0x00000C44
		public int IndexOf(TOut item)
		{
			return this.toWrap.IndexOf((TIn)((object)ParseClient.ConvertTo<TIn>(item)));
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00002A64 File Offset: 0x00000C64
		public void Insert(int index, TOut item)
		{
			this.toWrap.Insert(index, (TIn)((object)ParseClient.ConvertTo<TIn>(item)));
		}

		// Token: 0x0600003C RID: 60 RVA: 0x00002A84 File Offset: 0x00000C84
		public void RemoveAt(int index)
		{
			this.toWrap.RemoveAt(index);
		}

		// Token: 0x17000011 RID: 17
		public TOut this[int index]
		{
			get
			{
				return (TOut)((object)ParseClient.ConvertTo<TOut>(this.toWrap[index]));
			}
			set
			{
				this.toWrap[index] = (TIn)((object)ParseClient.ConvertTo<TIn>(value));
			}
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00002AD4 File Offset: 0x00000CD4
		public void Add(TOut item)
		{
			this.toWrap.Add((TIn)((object)ParseClient.ConvertTo<TIn>(item)));
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00002AF4 File Offset: 0x00000CF4
		public void Clear()
		{
			this.toWrap.Clear();
		}

		// Token: 0x06000041 RID: 65 RVA: 0x00002B04 File Offset: 0x00000D04
		public bool Contains(TOut item)
		{
			return this.toWrap.Contains((TIn)((object)ParseClient.ConvertTo<TIn>(item)));
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00002B24 File Offset: 0x00000D24
		public void CopyTo(TOut[] array, int arrayIndex)
		{
			this.toWrap.Select<TIn, TOut>((TIn item) => (TOut)((object)ParseClient.ConvertTo<TOut>(item))).ToList<TOut>().CopyTo(array, arrayIndex);
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00002B5C File Offset: 0x00000D5C
		public int Count
		{
			get
			{
				return this.toWrap.Count;
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000044 RID: 68 RVA: 0x00002B6C File Offset: 0x00000D6C
		public bool IsReadOnly
		{
			get
			{
				return this.toWrap.IsReadOnly;
			}
		}

		// Token: 0x06000045 RID: 69 RVA: 0x00002B7C File Offset: 0x00000D7C
		public bool Remove(TOut item)
		{
			return this.toWrap.Remove((TIn)((object)ParseClient.ConvertTo<TIn>(item)));
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00002B9C File Offset: 0x00000D9C
		public IEnumerator<TOut> GetEnumerator()
		{
			foreach (object item in this.toWrap)
			{
				yield return (TOut)((object)ParseClient.ConvertTo<TOut>(item));
			}
			yield break;
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00002BB8 File Offset: 0x00000DB8
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x04000020 RID: 32
		private IList<TIn> toWrap;
	}
}
