﻿using System;
using System.Collections.Generic;

namespace Parse.Internal
{
	// Token: 0x02000013 RID: 19
	internal interface IParseAuthenticationProvider
	{
		// Token: 0x06000064 RID: 100
		void Deauthenticate();

		// Token: 0x06000065 RID: 101
		bool RestoreAuthentication(IDictionary<string, object> authData);

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000066 RID: 102
		string AuthType { get; }
	}
}
