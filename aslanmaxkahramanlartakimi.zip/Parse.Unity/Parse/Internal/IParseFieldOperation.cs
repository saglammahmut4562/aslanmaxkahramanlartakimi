﻿using System;

namespace Parse.Internal
{
	// Token: 0x02000014 RID: 20
	internal interface IParseFieldOperation
	{
		// Token: 0x06000067 RID: 103
		object Encode();

		// Token: 0x06000068 RID: 104
		IParseFieldOperation MergeWithPrevious(IParseFieldOperation previous);

		// Token: 0x06000069 RID: 105
		object Apply(object oldValue, ParseObject obj, string key);
	}
}
