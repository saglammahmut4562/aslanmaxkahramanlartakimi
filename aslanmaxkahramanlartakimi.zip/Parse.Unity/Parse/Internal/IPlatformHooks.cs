﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Parse.Internal
{
	// Token: 0x02000015 RID: 21
	internal interface IPlatformHooks
	{
		// Token: 0x17000017 RID: 23
		// (get) Token: 0x0600006A RID: 106
		IDictionary<string, object> ApplicationSettings { get; }

		// Token: 0x0600006B RID: 107
		Task<Tuple<HttpStatusCode, string>> UploadAsync(Uri uri, IList<KeyValuePair<string, string>> headers, Stream data, IProgress<ParseUploadProgressEventArgs> progress, CancellationToken cancellationToken);

		// Token: 0x0600006C RID: 108
		Task<Tuple<HttpStatusCode, string>> RequestAsync(Uri uri, string method, IList<KeyValuePair<string, string>> headers, Stream data, string contentType, CancellationToken cancellationToken);

		// Token: 0x0600006D RID: 109
		void Initialize();

		// Token: 0x0600006E RID: 110
		void ClearInMemoryInstallation();

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x0600006F RID: 111
		string SDKName { get; }
	}
}
