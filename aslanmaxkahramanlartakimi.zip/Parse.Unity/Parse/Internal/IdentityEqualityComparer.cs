﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Parse.Internal
{
	// Token: 0x0200000C RID: 12
	internal class IdentityEqualityComparer<T> : IEqualityComparer<T>
	{
		// Token: 0x06000051 RID: 81 RVA: 0x00002D34 File Offset: 0x00000F34
		public bool Equals(T x, T y)
		{
			return object.ReferenceEquals(x, y);
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00002D48 File Offset: 0x00000F48
		public int GetHashCode(T obj)
		{
			return RuntimeHelpers.GetHashCode(obj);
		}
	}
}
