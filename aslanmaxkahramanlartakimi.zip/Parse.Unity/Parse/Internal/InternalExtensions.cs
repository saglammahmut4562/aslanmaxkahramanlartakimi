﻿using System;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;

namespace Parse.Internal
{
	// Token: 0x0200000D RID: 13
	internal static class InternalExtensions
	{
		// Token: 0x06000053 RID: 83 RVA: 0x00002D58 File Offset: 0x00000F58
		internal static Task<TResult> OnSuccess<TIn, TResult>(this Task<TIn> task, Func<Task<TIn>, TResult> continuation)
		{
			return task.OnSuccess<TResult>((Task t) => continuation((Task<TIn>)t));
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00002D84 File Offset: 0x00000F84
		internal static Task OnSuccess<TIn>(this Task<TIn> task, Action<Task<TIn>> continuation)
		{
			return task.OnSuccess<TIn, object>(delegate(Task<TIn> t)
			{
				continuation(t);
				return null;
			});
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00002DB0 File Offset: 0x00000FB0
		internal static Task<TResult> OnSuccess<TResult>(this Task task, Func<Task, TResult> continuation)
		{
			return task.ContinueWith<Task<TResult>>(delegate(Task t)
			{
				if (t.IsFaulted)
				{
					AggregateException ex = t.Exception.Flatten();
					if (ex.InnerExceptions.Count == 1)
					{
						ExceptionDispatchInfo.Capture(ex.InnerExceptions[0]).Throw();
					}
					else
					{
						ExceptionDispatchInfo.Capture(ex).Throw();
					}
					return Task.FromResult<TResult>(default(TResult));
				}
				if (t.IsCanceled)
				{
					TaskCompletionSource<TResult> taskCompletionSource = new TaskCompletionSource<TResult>();
					taskCompletionSource.SetCanceled();
					return taskCompletionSource.Task;
				}
				return Task.FromResult<TResult>(continuation(t));
			}).Unwrap<TResult>();
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00002DE4 File Offset: 0x00000FE4
		internal static Task OnSuccess(this Task task, Action<Task> continuation)
		{
			return task.OnSuccess<object>(delegate(Task t)
			{
				continuation(t);
				return null;
			});
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00002E10 File Offset: 0x00001010
		internal static Task WhileAsync(Func<Task<bool>> predicate, Func<Task> body)
		{
			Func<Task> iterate = null;
			iterate = () => predicate().OnSuccess<bool, Task>(delegate(Task<bool> t)
			{
				if (!t.Result)
				{
					return Task.FromResult<int>(0);
				}
				return body().OnSuccess<Task>((Task _) => iterate()).Unwrap();
			}).Unwrap();
			return iterate();
		}
	}
}
