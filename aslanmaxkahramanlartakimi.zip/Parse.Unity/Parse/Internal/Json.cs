﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace Parse.Internal
{
	// Token: 0x02000016 RID: 22
	internal class Json
	{
		// Token: 0x06000071 RID: 113 RVA: 0x0000312C File Offset: 0x0000132C
		public static object Parse(string input)
		{
			int num;
			object obj;
			if ((Json.ParseObject(input, 0, out num, out obj) || Json.ParseArray(input, 0, out num, out obj)) && num == input.Length)
			{
				return obj;
			}
			throw new ArgumentException("Input JSON was invalid.");
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00003168 File Offset: 0x00001368
		public static string Encode(IDictionary<string, object> dict)
		{
			if (dict == null)
			{
				throw new ArgumentNullException();
			}
			if (dict.Count == 0)
			{
				return "{}";
			}
			StringBuilder stringBuilder = new StringBuilder("{");
			foreach (KeyValuePair<string, object> keyValuePair in dict)
			{
				stringBuilder.Append(Json.Encode(keyValuePair.Key));
				stringBuilder.Append(":");
				stringBuilder.Append(Json.Encode(keyValuePair.Value));
				stringBuilder.Append(",");
			}
			stringBuilder[stringBuilder.Length - 1] = '}';
			return stringBuilder.ToString();
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00003220 File Offset: 0x00001420
		public static string Encode(IList<object> list)
		{
			if (list == null)
			{
				throw new ArgumentNullException();
			}
			if (list.Count == 0)
			{
				return "[]";
			}
			StringBuilder stringBuilder = new StringBuilder("[");
			foreach (object obj in list)
			{
				stringBuilder.Append(Json.Encode(obj));
				stringBuilder.Append(",");
			}
			stringBuilder[stringBuilder.Length - 1] = ']';
			return stringBuilder.ToString();
		}

		// Token: 0x06000074 RID: 116 RVA: 0x000032B4 File Offset: 0x000014B4
		public static string Encode(object obj)
		{
			IDictionary<string, object> dictionary = obj as IDictionary<string, object>;
			if (dictionary != null)
			{
				return Json.Encode(dictionary);
			}
			IList<object> list = obj as IList<object>;
			if (list != null)
			{
				return Json.Encode(list);
			}
			string text = obj as string;
			if (text != null)
			{
				text = Json.escapePattern.Replace(text, delegate(Match m)
				{
					char c = m.Value[0];
					switch (c)
					{
					case '\b':
						return "\\b";
					case '\t':
						return "\\t";
					case '\n':
						return "\\n";
					case '\v':
						break;
					case '\f':
						return "\\f";
					case '\r':
						return "\\r";
					default:
						if (c == '"')
						{
							return "\\\"";
						}
						if (c == '\\')
						{
							return "\\\\";
						}
						break;
					}
					return "\\u" + ((ushort)m.Value[0]).ToString("x4");
				});
				return "\"" + text + "\"";
			}
			if (obj == null)
			{
				return "null";
			}
			if (obj is bool)
			{
				if ((bool)obj)
				{
					return "true";
				}
				return "false";
			}
			else
			{
				if (!obj.GetType().IsPrimitive())
				{
					throw new ArgumentException("Unable to encode objects of type " + obj.GetType());
				}
				return Convert.ToString(obj, CultureInfo.InvariantCulture);
			}
		}

		// Token: 0x06000075 RID: 117 RVA: 0x0000337C File Offset: 0x0000157C
		private static bool ParseObject(string input, int start, out int consumed, out object output)
		{
			output = null;
			consumed = 0;
			int num;
			Match match;
			if (!Json.Accept(input, start, Json.beginObject, out num, out match))
			{
				return false;
			}
			consumed += num;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			object obj;
			while (Json.ParseMember(input, start + consumed, out num, out obj))
			{
				Tuple<string, object> tuple = obj as Tuple<string, object>;
				dictionary[tuple.Item1] = tuple.Item2;
				consumed += num;
				if (!Json.Accept(input, start + consumed, Json.valueSeparator, out num, out match))
				{
					break;
				}
				consumed += num;
			}
			if (!Json.Accept(input, start + consumed, Json.endObject, out num, out match))
			{
				return false;
			}
			consumed += num;
			output = dictionary;
			return true;
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00003420 File Offset: 0x00001620
		private static bool ParseMember(string input, int start, out int consumed, out object output)
		{
			output = null;
			consumed = 0;
			int num;
			object obj;
			if (!Json.ParseString(input, start, out num, out obj))
			{
				return false;
			}
			consumed += num;
			Match match;
			if (!Json.Accept(input, start + consumed, Json.nameSeparator, out num, out match))
			{
				return false;
			}
			consumed += num;
			object obj2;
			if (!Json.ParseValue(input, start + consumed, out num, out obj2))
			{
				return false;
			}
			consumed += num;
			output = new Tuple<string, object>((string)obj, obj2);
			return true;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x0000348C File Offset: 0x0000168C
		private static bool ParseArray(string input, int start, out int consumed, out object output)
		{
			output = null;
			consumed = 0;
			int num;
			Match match;
			if (!Json.Accept(input, start, Json.beginArray, out num, out match))
			{
				return false;
			}
			consumed += num;
			List<object> list = new List<object>();
			object obj;
			while (Json.ParseValue(input, start + consumed, out num, out obj))
			{
				list.Add(obj);
				consumed += num;
				if (!Json.Accept(input, start + consumed, Json.valueSeparator, out num, out match))
				{
					break;
				}
				consumed += num;
			}
			if (!Json.Accept(input, start + consumed, Json.endArray, out num, out match))
			{
				return false;
			}
			consumed += num;
			output = list;
			return true;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x0000351C File Offset: 0x0000171C
		private static bool ParseValue(string input, int start, out int consumed, out object output)
		{
			Match match;
			if (Json.Accept(input, start, Json.falseValue, out consumed, out match))
			{
				output = false;
				return true;
			}
			if (Json.Accept(input, start, Json.nullValue, out consumed, out match))
			{
				output = null;
				return true;
			}
			if (Json.Accept(input, start, Json.trueValue, out consumed, out match))
			{
				output = true;
				return true;
			}
			return Json.ParseObject(input, start, out consumed, out output) || Json.ParseArray(input, start, out consumed, out output) || Json.ParseNumber(input, start, out consumed, out output) || Json.ParseString(input, start, out consumed, out output);
		}

		// Token: 0x06000079 RID: 121 RVA: 0x000035A4 File Offset: 0x000017A4
		private static bool ParseString(string input, int start, out int consumed, out object output)
		{
			output = null;
			Match match;
			if (!Json.Accept(input, start, Json.stringValue, out consumed, out match))
			{
				return false;
			}
			int num = 0;
			Group group = match.Groups["content"];
			StringBuilder stringBuilder = new StringBuilder(group.Value);
			foreach (object obj in match.Groups["escape"].Captures)
			{
				Capture capture = (Capture)obj;
				int num2 = capture.Index - group.Index - num;
				num += capture.Length - 1;
				stringBuilder.Remove(num2 + 1, capture.Length - 1);
				char c = capture.Value[1];
				if (c <= '\\')
				{
					if (c == '"')
					{
						stringBuilder[num2] = '"';
						continue;
					}
					if (c == '/')
					{
						stringBuilder[num2] = '/';
						continue;
					}
					if (c == '\\')
					{
						stringBuilder[num2] = '\\';
						continue;
					}
				}
				else if (c <= 'f')
				{
					if (c == 'b')
					{
						stringBuilder[num2] = '\b';
						continue;
					}
					if (c == 'f')
					{
						stringBuilder[num2] = '\f';
						continue;
					}
				}
				else
				{
					if (c == 'n')
					{
						stringBuilder[num2] = '\n';
						continue;
					}
					switch (c)
					{
					case 'r':
						stringBuilder[num2] = '\r';
						continue;
					case 't':
						stringBuilder[num2] = '\t';
						continue;
					case 'u':
						stringBuilder[num2] = (char)ushort.Parse(capture.Value.Substring(2), NumberStyles.AllowHexSpecifier);
						continue;
					}
				}
				throw new ArgumentException("Unexpected escape character in string: " + capture.Value);
			}
			output = stringBuilder.ToString();
			return true;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00003794 File Offset: 0x00001994
		private static bool ParseNumber(string input, int start, out int consumed, out object output)
		{
			output = null;
			Match match;
			if (!Json.Accept(input, start, Json.numberValue, out consumed, out match))
			{
				return false;
			}
			if (match.Groups["frac"].Length > 0 || match.Groups["exp"].Length > 0)
			{
				output = double.Parse(match.Value, CultureInfo.InvariantCulture);
				return true;
			}
			output = long.Parse(match.Value, CultureInfo.InvariantCulture);
			return true;
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00003818 File Offset: 0x00001A18
		private static bool Accept(string input, int start, Regex matcher, out int consumed, out Match match)
		{
			match = matcher.Match(input, start);
			consumed = match.Length;
			return match.Success;
		}

		// Token: 0x0400002F RID: 47
		private static readonly string startOfString = "\\G";

		// Token: 0x04000030 RID: 48
		private static readonly string whitespace = "[ \t\r\n]*";

		// Token: 0x04000031 RID: 49
		private static readonly Regex beginArray = new Regex(Json.startOfString + Json.whitespace + "\\[" + Json.whitespace);

		// Token: 0x04000032 RID: 50
		private static readonly Regex beginObject = new Regex(Json.startOfString + Json.whitespace + "\\{" + Json.whitespace);

		// Token: 0x04000033 RID: 51
		private static readonly Regex endArray = new Regex(Json.startOfString + Json.whitespace + "\\]" + Json.whitespace);

		// Token: 0x04000034 RID: 52
		private static readonly Regex endObject = new Regex(Json.startOfString + Json.whitespace + "\\}" + Json.whitespace);

		// Token: 0x04000035 RID: 53
		private static readonly Regex nameSeparator = new Regex(Json.startOfString + Json.whitespace + ":" + Json.whitespace);

		// Token: 0x04000036 RID: 54
		private static readonly Regex valueSeparator = new Regex(Json.startOfString + Json.whitespace + "," + Json.whitespace);

		// Token: 0x04000037 RID: 55
		private static readonly Regex falseValue = new Regex(Json.startOfString + "false");

		// Token: 0x04000038 RID: 56
		private static readonly Regex trueValue = new Regex(Json.startOfString + "true");

		// Token: 0x04000039 RID: 57
		private static readonly Regex nullValue = new Regex(Json.startOfString + "null");

		// Token: 0x0400003A RID: 58
		private static readonly Regex numberValue = new Regex(Json.startOfString + "-?(?:0|[1-9]\\d*)(?<frac>\\.\\d+)?(?<exp>(?:e|E)(?:-|\\+)?\\d+)?");

		// Token: 0x0400003B RID: 59
		private static readonly Regex stringValue = new Regex(Json.startOfString + "\"(?<content>(?:[^\\\\\"]|(?<escape>\\\\(?:[\\\\\"/bfnrt]|u[0-9a-fA-F]{4})))*)\"", RegexOptions.Multiline);

		// Token: 0x0400003C RID: 60
		private static readonly Regex escapePattern = new Regex("\\\\|\"|[\0-\u001f]");
	}
}
