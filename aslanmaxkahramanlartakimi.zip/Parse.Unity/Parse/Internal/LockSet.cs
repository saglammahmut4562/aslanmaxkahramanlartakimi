﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;

namespace Parse.Internal
{
	// Token: 0x02000017 RID: 23
	internal class LockSet
	{
		// Token: 0x0600007D RID: 125 RVA: 0x000038CC File Offset: 0x00001ACC
		public LockSet(IEnumerable<object> mutexes)
		{
			this.mutexes = mutexes.OrderBy<object, IComparable>((object mutex) => LockSet.GetStableId(mutex)).ToList<object>();
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00003918 File Offset: 0x00001B18
		public void Enter()
		{
			foreach (object obj in this.mutexes)
			{
				Monitor.Enter(obj);
			}
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00003964 File Offset: 0x00001B64
		public void Exit()
		{
			foreach (object obj in this.mutexes)
			{
				Monitor.Exit(obj);
			}
		}

		// Token: 0x06000081 RID: 129 RVA: 0x000039B0 File Offset: 0x00001BB0
		private static IComparable GetStableId(object mutex)
		{
			IComparable value;
			lock (LockSet.stableIds)
			{
				value = LockSet.stableIds.GetValue(mutex, delegate(object k)
				{
					long num = LockSet.nextStableId;
					LockSet.nextStableId = num + 1L;
					return num;
				});
			}
			return value;
		}

		// Token: 0x0400003E RID: 62
		private static readonly ConditionalWeakTable<object, IComparable> stableIds = new ConditionalWeakTable<object, IComparable>();

		// Token: 0x0400003F RID: 63
		private static long nextStableId = 0L;

		// Token: 0x04000040 RID: 64
		private readonly IEnumerable<object> mutexes;
	}
}
