﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace Parse.Internal
{
	// Token: 0x02000018 RID: 24
	internal static class MissingExtensions
	{
		// Token: 0x06000084 RID: 132 RVA: 0x00003A2C File Offset: 0x00001C2C
		public static Type GetTypeInfo(this Type t)
		{
			return t;
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00003A30 File Offset: 0x00001C30
		internal static T GetCustomAttribute<T>(this PropertyInfo prop, bool inherit) where T : Attribute
		{
			return (T)((object)prop.GetCustomAttributes(typeof(T), inherit).FirstOrDefault<object>());
		}

		// Token: 0x06000086 RID: 134 RVA: 0x00003A50 File Offset: 0x00001C50
		internal static T GetCustomAttribute<T>(this Type type, bool inherit) where T : Attribute
		{
			return (T)((object)type.GetCustomAttributes(typeof(T), inherit).FirstOrDefault<object>());
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00003A70 File Offset: 0x00001C70
		internal static T GetCustomAttribute<T>(this Type type) where T : Attribute
		{
			return type.GetCustomAttribute<T>(true);
		}

		// Token: 0x06000088 RID: 136 RVA: 0x00003A7C File Offset: 0x00001C7C
		internal static Task<string> ReadToEndAsync(this StreamReader reader)
		{
			return Task.Run<string>(() => reader.ReadToEnd());
		}

		// Token: 0x06000089 RID: 137 RVA: 0x00003AA8 File Offset: 0x00001CA8
		internal static Task CopyToAsync(this Stream stream, Stream destination)
		{
			return stream.CopyToAsync(destination, 2048, CancellationToken.None);
		}

		// Token: 0x0600008A RID: 138 RVA: 0x00003ABC File Offset: 0x00001CBC
		internal static Task CopyToAsync(this Stream stream, Stream destination, int bufferSize, CancellationToken cancellationToken)
		{
			byte[] buffer = new byte[bufferSize];
			int bytesRead = 0;
			return InternalExtensions.WhileAsync(() => stream.ReadAsync(buffer, 0, bufferSize, cancellationToken).OnSuccess<int, bool>(delegate(Task<int> readTask)
			{
				bytesRead = readTask.Result;
				return bytesRead > 0;
			}), delegate
			{
				cancellationToken.ThrowIfCancellationRequested();
				return destination.WriteAsync(buffer, 0, bytesRead, cancellationToken).OnSuccess(delegate(Task _)
				{
					cancellationToken.ThrowIfCancellationRequested();
				});
			});
		}

		// Token: 0x0600008B RID: 139 RVA: 0x00003B20 File Offset: 0x00001D20
		internal static Task<int> ReadAsync(this Stream stream, byte[] buffer, int offset, int count, CancellationToken cancellationToken)
		{
			if (cancellationToken.IsCancellationRequested)
			{
				TaskCompletionSource<int> taskCompletionSource = new TaskCompletionSource<int>();
				taskCompletionSource.SetCanceled();
				return taskCompletionSource.Task;
			}
			return Task.Factory.FromAsync<byte[], int, int, int>(new Func<byte[], int, int, AsyncCallback, object, IAsyncResult>(stream.BeginRead), new Func<IAsyncResult, int>(stream.EndRead), buffer, offset, count, null);
		}

		// Token: 0x0600008C RID: 140 RVA: 0x00003B74 File Offset: 0x00001D74
		internal static Task WriteAsync(this Stream stream, byte[] buffer, int offset, int count, CancellationToken cancellationToken)
		{
			if (cancellationToken.IsCancellationRequested)
			{
				TaskCompletionSource<object> taskCompletionSource = new TaskCompletionSource<object>();
				taskCompletionSource.SetCanceled();
				return taskCompletionSource.Task;
			}
			return Task.Factory.FromAsync<byte[], int, int>(new Func<byte[], int, int, AsyncCallback, object, IAsyncResult>(stream.BeginWrite), new Action<IAsyncResult>(stream.EndWrite), buffer, offset, count, null);
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00003BC8 File Offset: 0x00001DC8
		internal static IEnumerable<TResult> Zip<T1, T2, TResult>(this IEnumerable<T1> list1, IEnumerable<T2> list2, Func<T1, T2, TResult> zipper)
		{
			IEnumerator<T1> e = list1.GetEnumerator();
			IEnumerator<T2> e2 = list2.GetEnumerator();
			while (e.MoveNext() && e2.MoveNext())
			{
				yield return zipper(e.Current, e2.Current);
			}
			yield break;
		}
	}
}
