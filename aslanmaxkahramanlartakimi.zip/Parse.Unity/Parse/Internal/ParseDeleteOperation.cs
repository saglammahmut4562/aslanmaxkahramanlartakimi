﻿using System;
using System.Collections.Generic;

namespace Parse.Internal
{
	// Token: 0x0200001C RID: 28
	internal class ParseDeleteOperation : IParseFieldOperation
	{
		// Token: 0x0600009D RID: 157 RVA: 0x00003DFC File Offset: 0x00001FFC
		private ParseDeleteOperation()
		{
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00003E1C File Offset: 0x0000201C
		public object Encode()
		{
			return new Dictionary<string, object> { { "__op", "Delete" } };
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00003E40 File Offset: 0x00002040
		public IParseFieldOperation MergeWithPrevious(IParseFieldOperation previous)
		{
			return this;
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00003E44 File Offset: 0x00002044
		public object Apply(object oldValue, ParseObject obj, string key)
		{
			return ParseDeleteOperation.DeleteToken;
		}

		// Token: 0x04000055 RID: 85
		internal static readonly object DeleteToken = new object();

		// Token: 0x04000056 RID: 86
		private static ParseDeleteOperation _Instance = new ParseDeleteOperation();
	}
}
