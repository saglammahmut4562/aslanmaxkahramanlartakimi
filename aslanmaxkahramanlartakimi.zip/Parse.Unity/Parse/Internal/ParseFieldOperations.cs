﻿using System;
using System.Collections.Generic;

namespace Parse.Internal
{
	// Token: 0x0200001D RID: 29
	internal static class ParseFieldOperations
	{
		// Token: 0x060000A2 RID: 162 RVA: 0x00003E4C File Offset: 0x0000204C
		public static IParseFieldOperation Decode(IDictionary<string, object> json)
		{
			throw new NotImplementedException();
		}

		// Token: 0x04000057 RID: 87
		private static ParseObjectIdComparer comparer;
	}
}
