﻿using System;

namespace Parse.Internal
{
	// Token: 0x0200001E RID: 30
	internal class ParseJSONCacheItem
	{
		// Token: 0x060000A3 RID: 163 RVA: 0x00003E54 File Offset: 0x00002054
		public ParseJSONCacheItem(object obj)
		{
			try
			{
				this.comparisonString = Json.Encode(ParseClient.MaybeEncodeJSONObject(obj, true));
			}
			catch
			{
				this.comparisonString = "";
			}
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00003E9C File Offset: 0x0000209C
		public override bool Equals(object obj)
		{
			ParseJSONCacheItem parseJSONCacheItem = (ParseJSONCacheItem)obj;
			return this.comparisonString.Equals(parseJSONCacheItem.comparisonString);
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00003EC4 File Offset: 0x000020C4
		public override int GetHashCode()
		{
			return this.comparisonString.GetHashCode();
		}

		// Token: 0x04000058 RID: 88
		private readonly string comparisonString;
	}
}
