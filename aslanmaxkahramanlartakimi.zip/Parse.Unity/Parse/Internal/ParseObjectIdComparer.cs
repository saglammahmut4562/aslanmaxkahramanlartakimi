﻿using System;
using System.Collections.Generic;

namespace Parse.Internal
{
	// Token: 0x0200001F RID: 31
	internal class ParseObjectIdComparer : IEqualityComparer<object>
	{
		// Token: 0x060000A6 RID: 166 RVA: 0x00003ED4 File Offset: 0x000020D4
		bool IEqualityComparer<object>.Equals(object p1, object p2)
		{
			ParseObject parseObject = p1 as ParseObject;
			ParseObject parseObject2 = p2 as ParseObject;
			if (parseObject != null && parseObject2 != null)
			{
				return object.Equals(parseObject.ObjectId, parseObject2.ObjectId);
			}
			return object.Equals(p1, p2);
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00003F10 File Offset: 0x00002110
		public int GetHashCode(object p)
		{
			ParseObject parseObject = p as ParseObject;
			if (parseObject != null)
			{
				return parseObject.ObjectId.GetHashCode();
			}
			return p.GetHashCode();
		}
	}
}
