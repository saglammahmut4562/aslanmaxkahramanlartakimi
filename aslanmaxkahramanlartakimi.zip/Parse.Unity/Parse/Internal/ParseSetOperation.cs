﻿using System;

namespace Parse.Internal
{
	// Token: 0x02000020 RID: 32
	internal class ParseSetOperation : IParseFieldOperation
	{
		// Token: 0x060000A8 RID: 168 RVA: 0x00003F3C File Offset: 0x0000213C
		public ParseSetOperation(object value)
		{
			this.Value = value;
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x00003F4C File Offset: 0x0000214C
		public object Encode()
		{
			return ParseClient.MaybeEncodeJSONObject(this.Value, true);
		}

		// Token: 0x060000AA RID: 170 RVA: 0x00003F5C File Offset: 0x0000215C
		public IParseFieldOperation MergeWithPrevious(IParseFieldOperation previous)
		{
			return this;
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00003F60 File Offset: 0x00002160
		public object Apply(object oldValue, ParseObject obj, string key)
		{
			return this.Value;
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000AC RID: 172 RVA: 0x00003F68 File Offset: 0x00002168
		// (set) Token: 0x060000AD RID: 173 RVA: 0x00003F70 File Offset: 0x00002170
		public object Value { get; private set; }
	}
}
