﻿using System;

namespace Parse.Internal
{
	// Token: 0x02000021 RID: 33
	internal static class ReflectionHelpers
	{
		// Token: 0x060000AE RID: 174 RVA: 0x00003F7C File Offset: 0x0000217C
		internal static bool IsPrimitive(this Type type)
		{
			return type.GetTypeInfo().IsPrimitive;
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00003F8C File Offset: 0x0000218C
		internal static bool IsConstructedGenericType(this Type type)
		{
			return type.IsGenericType && !type.IsGenericTypeDefinition;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00003FA4 File Offset: 0x000021A4
		internal static Type[] GetGenericTypeArguments(this Type type)
		{
			return type.GetGenericArguments();
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00003FAC File Offset: 0x000021AC
		internal static bool IsNullable(this Type t)
		{
			bool flag = t.IsGenericType && !t.IsGenericTypeDefinition;
			return flag && t.GetGenericTypeDefinition().Equals(typeof(Nullable<>));
		}
	}
}
