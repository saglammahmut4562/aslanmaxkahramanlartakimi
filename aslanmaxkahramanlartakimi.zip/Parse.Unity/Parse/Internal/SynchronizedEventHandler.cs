﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Parse.Internal
{
	// Token: 0x02000022 RID: 34
	internal class SynchronizedEventHandler<T>
	{
		// Token: 0x060000B3 RID: 179 RVA: 0x00003FFC File Offset: 0x000021FC
		public void Add(Delegate del)
		{
			lock (this.delegates)
			{
				TaskFactory taskFactory;
				if (SynchronizationContext.Current != null)
				{
					taskFactory = new TaskFactory(CancellationToken.None, TaskCreationOptions.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.FromCurrentSynchronizationContext());
				}
				else
				{
					taskFactory = Task.Factory;
				}
				foreach (Delegate @delegate in del.GetInvocationList())
				{
					this.delegates.AddLast(new Tuple<Delegate, TaskFactory>(@delegate, taskFactory));
				}
			}
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00004088 File Offset: 0x00002288
		public void Remove(Delegate del)
		{
			lock (this.delegates)
			{
				if (this.delegates.Count != 0)
				{
					foreach (Delegate @delegate in del.GetInvocationList())
					{
						for (LinkedListNode<Tuple<Delegate, TaskFactory>> linkedListNode = this.delegates.First; linkedListNode != null; linkedListNode = linkedListNode.Next)
						{
							if (linkedListNode.Value.Item1 == @delegate)
							{
								this.delegates.Remove(linkedListNode);
								break;
							}
						}
					}
				}
			}
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00004124 File Offset: 0x00002324
		public Task Invoke(object sender, T args)
		{
			Task<int>[] toContinue = new Task<int>[] { Task.FromResult<int>(0) };
			IEnumerable<Tuple<Delegate, TaskFactory>> enumerable;
			lock (this.delegates)
			{
				enumerable = this.delegates.ToList<Tuple<Delegate, TaskFactory>>();
			}
			List<Task> list = enumerable.Select<Tuple<Delegate, TaskFactory>, Task>((Tuple<Delegate, TaskFactory> p) => p.Item2.ContinueWhenAll(toContinue, delegate(Task[] _)
			{
				p.Item1.DynamicInvoke(new object[] { sender, args });
			})).ToList<Task>();
			return Task.WhenAll(list);
		}

		// Token: 0x0400005E RID: 94
		private LinkedList<Tuple<Delegate, TaskFactory>> delegates = new LinkedList<Tuple<Delegate, TaskFactory>>();
	}
}
