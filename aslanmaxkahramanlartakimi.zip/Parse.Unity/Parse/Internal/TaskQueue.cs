﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Parse.Internal
{
	// Token: 0x02000025 RID: 37
	internal class TaskQueue
	{
		// Token: 0x060000BB RID: 187 RVA: 0x00004260 File Offset: 0x00002460
		private Task GetTaskToAwait(CancellationToken cancellationToken)
		{
			Task task2;
			lock (this.mutex)
			{
				Task task3 = this.tail ?? Task.FromResult<bool>(true);
				task2 = task3.ContinueWith(delegate(Task task)
				{
				}, cancellationToken);
			}
			return task2;
		}

		// Token: 0x060000BC RID: 188 RVA: 0x000042CC File Offset: 0x000024CC
		public T Enqueue<T>(Func<Task, T> taskStart, CancellationToken cancellationToken) where T : Task
		{
			T t;
			lock (this.mutex)
			{
				Task task = this.tail ?? Task.FromResult<bool>(true);
				t = taskStart(this.GetTaskToAwait(cancellationToken));
				this.tail = Task.WhenAll(new Task[] { task, t });
			}
			return t;
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000BD RID: 189 RVA: 0x00004340 File Offset: 0x00002540
		public object Mutex
		{
			get
			{
				return this.mutex;
			}
		}

		// Token: 0x04000064 RID: 100
		private Task tail;

		// Token: 0x04000065 RID: 101
		private readonly object mutex = new object();
	}
}
