﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Parse
{
	// Token: 0x02000026 RID: 38
	public class ParseACL
	{
		// Token: 0x060000BF RID: 191 RVA: 0x0000434C File Offset: 0x0000254C
		internal ParseACL(IDictionary<string, object> jsonObject)
		{
			this.readers = new HashSet<string>(from pair in jsonObject
				where ((IDictionary<string, object>)pair.Value).ContainsKey("read")
				select pair.Key);
			this.writers = new HashSet<string>(from pair in jsonObject
				where ((IDictionary<string, object>)pair.Value).ContainsKey("write")
				select pair.Key);
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00004418 File Offset: 0x00002618
		internal IDictionary<string, object> ToJSON()
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			foreach (string text in this.readers.Union<string>(this.writers))
			{
				Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
				if (this.readers.Contains(text))
				{
					dictionary2["read"] = true;
				}
				if (this.writers.Contains(text))
				{
					dictionary2["write"] = true;
				}
				dictionary[text] = dictionary2;
			}
			return dictionary;
		}

		// Token: 0x04000067 RID: 103
		private const string publicName = "*";

		// Token: 0x04000068 RID: 104
		private readonly ICollection<string> readers = new HashSet<string>();

		// Token: 0x04000069 RID: 105
		private readonly ICollection<string> writers = new HashSet<string>();
	}
}
