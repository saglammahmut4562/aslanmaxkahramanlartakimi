﻿using System;

namespace Parse
{
	// Token: 0x02000027 RID: 39
	[AttributeUsage(AttributeTargets.Class, Inherited = true, AllowMultiple = false)]
	public sealed class ParseClassNameAttribute : Attribute
	{
		// Token: 0x060000C5 RID: 197 RVA: 0x00004504 File Offset: 0x00002704
		public ParseClassNameAttribute(string className)
		{
			this.ClassName = className;
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000C6 RID: 198 RVA: 0x00004514 File Offset: 0x00002714
		// (set) Token: 0x060000C7 RID: 199 RVA: 0x0000451C File Offset: 0x0000271C
		public string ClassName { get; private set; }
	}
}
