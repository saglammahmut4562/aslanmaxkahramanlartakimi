﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Parse.Internal;

namespace Parse
{
	// Token: 0x02000028 RID: 40
	public static class ParseClient
	{
		// Token: 0x060000C8 RID: 200 RVA: 0x00004528 File Offset: 0x00002728
		static ParseClient()
		{
			Type parseType = ParseClient.GetParseType("PlatformHooks");
			if (parseType == null)
			{
				throw new InvalidOperationException("You must include a reference to a platform-specific Parse library.");
			}
			ParseClient.platformHooks = Activator.CreateInstance(parseType) as IPlatformHooks;
			ParseClient.versionString = "net-" + ParseClient.platformHooks.SDKName + ParseClient.Version;
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000C9 RID: 201 RVA: 0x000045D8 File Offset: 0x000027D8
		// (set) Token: 0x060000CA RID: 202 RVA: 0x000045E0 File Offset: 0x000027E0
		internal static Uri HostName { get; set; }

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000CB RID: 203 RVA: 0x000045E8 File Offset: 0x000027E8
		// (set) Token: 0x060000CC RID: 204 RVA: 0x000045F0 File Offset: 0x000027F0
		private static string ApplicationId { get; set; }

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000CD RID: 205 RVA: 0x000045F8 File Offset: 0x000027F8
		// (set) Token: 0x060000CE RID: 206 RVA: 0x00004600 File Offset: 0x00002800
		private static string WindowsKey { get; set; }

		// Token: 0x060000CF RID: 207 RVA: 0x00004608 File Offset: 0x00002808
		private static Type GetParseType(string name)
		{
			foreach (string text in ParseClient.assemblyNames)
			{
				Type type = Type.GetType(string.Format("Parse.{0}, {1}", name, text));
				if (type != null)
				{
					return type;
				}
			}
			return null;
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000D0 RID: 208 RVA: 0x00004650 File Offset: 0x00002850
		internal static Version Version
		{
			get
			{
				AssemblyName assemblyName = new AssemblyName(typeof(ParseClient).GetTypeInfo().Assembly.FullName);
				return assemblyName.Version;
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x00004684 File Offset: 0x00002884
		public static void Initialize(string applicationId, string dotnetKey)
		{
			lock (ParseClient.mutex)
			{
				ParseClient.HostName = ParseClient.HostName ?? new Uri("https://api.parse.com/");
				ParseClient.ApplicationId = applicationId;
				ParseClient.WindowsKey = dotnetKey;
				ParseObject.RegisterSubclass<ParseUser>();
				ParseObject.RegisterSubclass<ParseRole>();
				ParseClient.platformHooks.Initialize();
				if (ParseClient.InstallationId == null)
				{
					ParseClient.InstallationId = new Guid?(Guid.NewGuid());
				}
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000D2 RID: 210 RVA: 0x0000470C File Offset: 0x0000290C
		// (set) Token: 0x060000D3 RID: 211 RVA: 0x0000479C File Offset: 0x0000299C
		internal static Guid? InstallationId
		{
			get
			{
				Guid? guid;
				lock (ParseClient.mutex)
				{
					if (ParseClient.installationId != null)
					{
						guid = ParseClient.installationId;
					}
					else
					{
						object obj2;
						ParseClient.ApplicationSettings.TryGetValue("InstallationId", out obj2);
						try
						{
							ParseClient.installationId = new Guid?(new Guid((string)obj2));
						}
						catch (Exception)
						{
							ParseClient.installationId = null;
						}
						guid = ParseClient.installationId;
					}
				}
				return guid;
			}
			set
			{
				lock (ParseClient.mutex)
				{
					ParseClient.ApplicationSettings["InstallationId"] = ((value != null) ? value.ToString() : null);
					ParseClient.installationId = value;
				}
			}
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x000047FC File Offset: 0x000029FC
		internal static object Decode(object data)
		{
			if (data == null)
			{
				return null;
			}
			IDictionary<string, object> dictionary = data as IDictionary<string, object>;
			if (dictionary != null)
			{
				if (dictionary.ContainsKey("__op"))
				{
					return ParseFieldOperations.Decode(dictionary);
				}
				object obj;
				dictionary.TryGetValue("__type", out obj);
				string text = obj as string;
				if (text == null)
				{
					Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
					foreach (KeyValuePair<string, object> keyValuePair in dictionary)
					{
						dictionary2[keyValuePair.Key] = ParseClient.Decode(keyValuePair.Value);
					}
					return dictionary2;
				}
				if (text == "Date")
				{
					return ParseClient.ParseDate(dictionary["iso"] as string);
				}
				if (text == "Bytes")
				{
					return Convert.FromBase64String(dictionary["base64"] as string);
				}
				if (text == "Pointer")
				{
					return ParseObject.CreateWithoutData(dictionary["className"] as string, dictionary["objectId"] as string);
				}
				if (text == "File")
				{
					return new ParseFile(dictionary["name"] as string, new Uri(dictionary["url"] as string));
				}
				if (text == "GeoPoint")
				{
					return new ParseGeoPoint((double)ParseClient.ConvertTo<double>(dictionary["latitude"]), (double)ParseClient.ConvertTo<double>(dictionary["longitude"]));
				}
				if (text == "Object")
				{
					ParseObject parseObject = ParseObject.CreateWithoutData(dictionary["className"] as string, null);
					parseObject.MergeAfterFetch(dictionary);
					return parseObject;
				}
				if (text == "Relation")
				{
					return ParseRelationBase.CreateRelation(null, null, dictionary["className"] as string);
				}
				Dictionary<string, object> dictionary3 = new Dictionary<string, object>();
				foreach (KeyValuePair<string, object> keyValuePair2 in dictionary)
				{
					dictionary3[keyValuePair2.Key] = ParseClient.Decode(keyValuePair2.Value);
				}
				return dictionary3;
			}
			else
			{
				IList<object> list = data as IList<object>;
				if (list != null)
				{
					return list.Select<object, object>((object item) => ParseClient.Decode(item)).ToList<object>();
				}
				return data;
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00004A80 File Offset: 0x00002C80
		internal static DateTime ParseDate(string input)
		{
			return DateTime.ParseExact(input, ParseClient.dateFormatString, CultureInfo.InvariantCulture);
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00004A94 File Offset: 0x00002C94
		internal static bool IsContainerObject(object value)
		{
			return value is ParseACL || value is ParseGeoPoint || ParseClient.ConvertTo<IDictionary<string, object>>(value) is IDictionary<string, object> || ParseClient.ConvertTo<IList<object>>(value) is IList<object>;
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00004AC4 File Offset: 0x00002CC4
		internal static object MaybeEncodeJSONObject(object value, bool allowParseObjects)
		{
			IDictionary<string, object> dictionary = ParseClient.EncodeJSONObject(value, allowParseObjects);
			if (dictionary != null)
			{
				return dictionary;
			}
			IList<object> list = ParseClient.ConvertTo<IList<object>>(value) as IList<object>;
			if (list != null)
			{
				return ParseClient.EncodeJSONArray(list, allowParseObjects);
			}
			IParseFieldOperation parseFieldOperation = value as IParseFieldOperation;
			if (parseFieldOperation != null)
			{
				return parseFieldOperation.Encode();
			}
			return value;
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00004B08 File Offset: 0x00002D08
		private static IDictionary<string, object> EncodeJSONObject(object value, bool allowParseObjects)
		{
			if (value is DateTime)
			{
				return new Dictionary<string, object>
				{
					{
						"iso",
						((DateTime)value).ToString(ParseClient.dateFormatString)
					},
					{ "__type", "Date" }
				};
			}
			byte[] array = value as byte[];
			if (array != null)
			{
				return new Dictionary<string, object>
				{
					{ "__type", "Bytes" },
					{
						"base64",
						Convert.ToBase64String(array)
					}
				};
			}
			ParseObject parseObject = value as ParseObject;
			if (parseObject != null)
			{
				if (!allowParseObjects)
				{
					throw new ArgumentException("ParseObjects not allowed here.");
				}
				if (parseObject.ObjectId == null)
				{
					throw new ArgumentException("Cannot create a pointer to an object without an objectId");
				}
				return new Dictionary<string, object>
				{
					{ "__type", "Pointer" },
					{ "className", parseObject.ClassName },
					{ "objectId", parseObject.ObjectId }
				};
			}
			else
			{
				ParseFile parseFile = value as ParseFile;
				if (parseFile != null)
				{
					return parseFile.ToJSON();
				}
				if (value is ParseGeoPoint)
				{
					return ((ParseGeoPoint)value).ToJSON();
				}
				ParseACL parseACL = value as ParseACL;
				if (parseACL != null)
				{
					return parseACL.ToJSON();
				}
				IDictionary<string, object> dictionary = ParseClient.ConvertTo<IDictionary<string, object>>(value) as IDictionary<string, object>;
				if (dictionary != null)
				{
					Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
					foreach (KeyValuePair<string, object> keyValuePair in dictionary)
					{
						dictionary2[keyValuePair.Key] = ParseClient.MaybeEncodeJSONObject(keyValuePair.Value, allowParseObjects);
					}
					return dictionary2;
				}
				ParseRelationBase parseRelationBase = value as ParseRelationBase;
				if (parseRelationBase != null)
				{
					return parseRelationBase.ToJSON();
				}
				return null;
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00004CB8 File Offset: 0x00002EB8
		private static object EncodeJSONArray(IList<object> list, bool allowParseObjects)
		{
			List<object> list2 = new List<object>();
			foreach (object obj in list)
			{
				if (!ParseClient.IsValidType(obj))
				{
					throw new ArgumentException("Invalid type for value in an array");
				}
				list2.Add(ParseClient.MaybeEncodeJSONObject(obj, allowParseObjects));
			}
			return list2;
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00004D20 File Offset: 0x00002F20
		internal static Task<Tuple<HttpStatusCode, string>> RequestAsync(Uri uri, string method = null, IList<KeyValuePair<string, string>> headers = null, Stream data = null, string contentType = null, CancellationToken cancellationToken = default(CancellationToken))
		{
			if (method == null)
			{
				if (data == null)
				{
					method = "GET";
				}
				else
				{
					method = "POST";
				}
			}
			return ParseClient.platformHooks.RequestAsync(uri, method, headers, data, contentType, cancellationToken);
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00004D4C File Offset: 0x00002F4C
		internal static Task<Tuple<HttpStatusCode, IDictionary<string, object>>> RequestAsync(string method, string relativeUri, string sessionToken, IDictionary<string, object> data = null, CancellationToken cancellationToken = default(CancellationToken))
		{
			return ParseClient.RequestAsync(method, new Uri(relativeUri, UriKind.Relative), sessionToken, data, cancellationToken);
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00004D60 File Offset: 0x00002F60
		internal static Task<Tuple<HttpStatusCode, IDictionary<string, object>>> RequestAsync(string method, Uri relativeUri, string sessionToken, IDictionary<string, object> data = null, CancellationToken cancellationToken = default(CancellationToken))
		{
			if (ParseClient.ApplicationId == null)
			{
				throw new InvalidOperationException("You must call ParseClient.Initialize() before making any requests.");
			}
			List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>
			{
				new KeyValuePair<string, string>("X-Parse-Application-Id", ParseClient.ApplicationId),
				new KeyValuePair<string, string>("X-Parse-Windows-Key", ParseClient.WindowsKey),
				new KeyValuePair<string, string>("X-Parse-Client-Version", ParseClient.versionString),
				new KeyValuePair<string, string>("X-Parse-Installation-Id", ParseClient.InstallationId.ToString())
			};
			if (sessionToken != null)
			{
				list.Add(new KeyValuePair<string, string>("X-Parse-Session-Token", sessionToken));
			}
			Stream stream = null;
			string text = null;
			if (data != null)
			{
				stream = new MemoryStream(Encoding.UTF8.GetBytes(ParseClient.SerializeJsonString(data)));
				text = "application/json";
			}
			return ParseClient.RequestAsync(new Uri(ParseClient.HostName, relativeUri), method, list, stream, text, cancellationToken).OnSuccess<Tuple<HttpStatusCode, string>, Tuple<HttpStatusCode, IDictionary<string, object>>>(delegate(Task<Tuple<HttpStatusCode, string>> t)
			{
				Tuple<HttpStatusCode, string> result = t.Result;
				string item = result.Item2;
				if (item == null)
				{
					cancellationToken.ThrowIfCancellationRequested();
					return new Tuple<HttpStatusCode, IDictionary<string, object>>(result.Item1, null);
				}
				IDictionary<string, object> dictionary = null;
				try
				{
					if (item.StartsWith("["))
					{
						object obj = Json.Parse(item);
						dictionary = new Dictionary<string, object> { { "results", obj } };
					}
					else
					{
						dictionary = ParseClient.DeserializeJsonString(item);
					}
				}
				catch (Exception ex)
				{
					throw new ParseException(ParseException.ErrorCode.OtherCause, "Invalid response from server", ex);
				}
				if (result.Item1 < HttpStatusCode.OK || result.Item1 > (HttpStatusCode)299)
				{
					int num = (int)(dictionary.ContainsKey("code") ? ((long)dictionary["code"]) : (-1L));
					string text2 = (dictionary.ContainsKey("error") ? (dictionary["error"] as string) : item);
					throw new ParseException((ParseException.ErrorCode)num, text2, null);
				}
				cancellationToken.ThrowIfCancellationRequested();
				return new Tuple<HttpStatusCode, IDictionary<string, object>>(result.Item1, dictionary);
			});
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00004E60 File Offset: 0x00003060
		internal static Task<Tuple<HttpStatusCode, IDictionary<string, object>>> UploadAsync(Uri relativeUri, string sessionToken, string contentType, Stream data, IProgress<ParseUploadProgressEventArgs> progress, CancellationToken cancellationToken)
		{
			List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>
			{
				new KeyValuePair<string, string>("X-Parse-Application-Id", ParseClient.ApplicationId),
				new KeyValuePair<string, string>("X-Parse-Windows-Key", ParseClient.WindowsKey),
				new KeyValuePair<string, string>("X-Parse-Client-Version", ParseClient.versionString),
				new KeyValuePair<string, string>("X-Parse-Installation-Id", ParseClient.InstallationId.ToString())
			};
			if (sessionToken != null)
			{
				list.Add(new KeyValuePair<string, string>("X-Parse-Session-Token", sessionToken));
			}
			list.Add(new KeyValuePair<string, string>("Content-Type", contentType));
			Uri uri = new Uri(ParseClient.HostName, relativeUri);
			return ParseClient.platformHooks.UploadAsync(uri, list, data, progress, cancellationToken).OnSuccess<Tuple<HttpStatusCode, string>, Tuple<HttpStatusCode, IDictionary<string, object>>>(delegate(Task<Tuple<HttpStatusCode, string>> t)
			{
				string item = t.Result.Item2;
				IDictionary<string, object> dictionary = null;
				try
				{
					dictionary = ParseClient.DeserializeJsonString(item);
				}
				catch (Exception ex)
				{
					throw new ParseException(ParseException.ErrorCode.OtherCause, "Invalid response from server", ex);
				}
				if (t.Result.Item1 != HttpStatusCode.Created)
				{
					int num = (int)(dictionary.ContainsKey("code") ? ((long)dictionary["code"]) : (-1L));
					string text = dictionary["error"] as string;
					throw new ParseException((ParseException.ErrorCode)num, text, null);
				}
				cancellationToken.ThrowIfCancellationRequested();
				return new Tuple<HttpStatusCode, IDictionary<string, object>>(t.Result.Item1, dictionary);
			});
		}

		// Token: 0x060000DE RID: 222 RVA: 0x00004F40 File Offset: 0x00003140
		internal static T As<T>(object value) where T : class
		{
			return ParseClient.ConvertTo<T>(value) as T;
		}

		// Token: 0x060000DF RID: 223 RVA: 0x00004F54 File Offset: 0x00003154
		internal static object ConvertTo<T>(object value)
		{
			if (value is T || value == null)
			{
				return value;
			}
			if (typeof(T).IsPrimitive())
			{
				return (T)((object)Convert.ChangeType(value, typeof(T)));
			}
			if (typeof(T).IsConstructedGenericType())
			{
				if (typeof(T).IsNullable())
				{
					Type type = typeof(T).GetGenericTypeArguments()[0];
					if (type.IsPrimitive())
					{
						return (T)((object)Convert.ChangeType(value, type));
					}
				}
				Type interfaceType = ParseClient.GetInterfaceType(value.GetType(), typeof(IList<>));
				if (interfaceType != null && typeof(T).GetGenericTypeDefinition() == typeof(IList<>))
				{
					Type type2 = typeof(FlexibleListWrapper<, >).MakeGenericType(new Type[]
					{
						typeof(T).GetGenericTypeArguments()[0],
						interfaceType.GetGenericTypeArguments()[0]
					});
					return Activator.CreateInstance(type2, new object[] { value });
				}
				Type interfaceType2 = ParseClient.GetInterfaceType(value.GetType(), typeof(IDictionary<, >));
				if (interfaceType2 != null && typeof(T).GetGenericTypeDefinition() == typeof(IDictionary<, >))
				{
					Type type3 = typeof(FlexibleDictionaryWrapper<, >).MakeGenericType(new Type[]
					{
						typeof(T).GetGenericTypeArguments()[1],
						interfaceType2.GetGenericTypeArguments()[1]
					});
					return Activator.CreateInstance(type3, new object[] { value });
				}
			}
			return value;
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x000050F8 File Offset: 0x000032F8
		private static Type GetInterfaceType(Type objType, Type genericInterfaceType)
		{
			if (genericInterfaceType.IsConstructedGenericType())
			{
				genericInterfaceType = genericInterfaceType.GetGenericTypeDefinition();
			}
			Tuple<Type, Type> tuple = new Tuple<Type, Type>(objType, genericInterfaceType);
			if (ParseClient.interfaceLookupCache.ContainsKey(tuple))
			{
				return ParseClient.interfaceLookupCache[tuple];
			}
			foreach (Type type in objType.GetInterfaces())
			{
				if (type.IsConstructedGenericType() && type.GetGenericTypeDefinition() == genericInterfaceType)
				{
					return ParseClient.interfaceLookupCache[tuple] = type;
				}
			}
			return null;
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x0000517C File Offset: 0x0000337C
		internal static string BuildQueryString(IDictionary<string, object> parameters)
		{
			return string.Join("&", (from pair in parameters
				let valueString = pair.Value as string
				select string.Format("{0}={1}", Uri.EscapeDataString(pair.Key), Uri.EscapeDataString(string.IsNullOrEmpty(valueString) ? Json.Encode(pair.Value) : valueString))).ToArray<string>());
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x000051E0 File Offset: 0x000033E0
		internal static bool IsValidType(object value)
		{
			return value == null || value.GetType().IsPrimitive() || value is string || value is ParseObject || value is ParseACL || value is ParseFile || value is ParseGeoPoint || value is ParseRelationBase || value is DateTime || value is byte[] || ParseClient.ConvertTo<IDictionary<string, object>>(value) is IDictionary<string, object> || ParseClient.ConvertTo<IList<object>>(value) is IList<object>;
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x0000525C File Offset: 0x0000345C
		internal static IDictionary<string, object> DeserializeJsonString(string jsonData)
		{
			return Json.Parse(jsonData) as IDictionary<string, object>;
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0000526C File Offset: 0x0000346C
		internal static string SerializeJsonString(IDictionary<string, object> jsonData)
		{
			return Json.Encode(jsonData);
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000E5 RID: 229 RVA: 0x00005274 File Offset: 0x00003474
		internal static IDictionary<string, object> ApplicationSettings
		{
			get
			{
				return ParseClient.platformHooks.ApplicationSettings;
			}
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x00005280 File Offset: 0x00003480
		internal static void ClearInMemoryInstallation()
		{
			ParseClient.platformHooks.ClearInMemoryInstallation();
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0000528C File Offset: 0x0000348C
		internal static IEnumerable<object> DeepTraversal(object root, bool traverseParseObjects = false, bool yieldRoot = false)
		{
			IEnumerable<object> enumerable = ParseClient.DeepTraversalInternal(root, traverseParseObjects, new HashSet<object>(new IdentityEqualityComparer<object>()));
			if (yieldRoot)
			{
				return new object[] { root }.Concat<object>(enumerable);
			}
			return enumerable;
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x000052C4 File Offset: 0x000034C4
		private static IEnumerable<object> DeepTraversalInternal(object root, bool traverseParseObjects, ICollection<object> seen)
		{
			seen.Add(root);
			IEnumerable<object> itemsToVisit = null;
			IDictionary<string, object> dict = ParseClient.As<IDictionary<string, object>>(root);
			if (dict != null)
			{
				itemsToVisit = dict.Values;
			}
			else
			{
				IList<object> list = ParseClient.As<IList<object>>(root);
				if (list != null)
				{
					itemsToVisit = list;
				}
				else if (traverseParseObjects)
				{
					ParseObject obj = root as ParseObject;
					if (obj != null)
					{
						itemsToVisit = from k in obj.Keys.ToList<string>()
							select obj[k];
					}
				}
			}
			if (itemsToVisit != null)
			{
				foreach (object i in itemsToVisit)
				{
					if (!seen.Contains(i))
					{
						yield return i;
						IEnumerable<object> children = ParseClient.DeepTraversalInternal(i, traverseParseObjects, seen);
						foreach (object child in children)
						{
							yield return child;
						}
					}
				}
			}
			yield break;
		}

		// Token: 0x0400006F RID: 111
		private static object mutex = new object();

		// Token: 0x04000070 RID: 112
		private static readonly string versionString;

		// Token: 0x04000071 RID: 113
		internal static readonly string dateFormatString = "yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'";

		// Token: 0x04000072 RID: 114
		private static string[] assemblyNames = new string[] { "Parse.Phone", "Parse.WinRT", "Parse.NetFx45", "Parse.iOS", "Parse.Android", "Parse.Unity" };

		// Token: 0x04000073 RID: 115
		private static readonly IPlatformHooks platformHooks;

		// Token: 0x04000074 RID: 116
		internal static Guid? installationId;

		// Token: 0x04000075 RID: 117
		private static readonly Dictionary<Tuple<Type, Type>, Type> interfaceLookupCache = new Dictionary<Tuple<Type, Type>, Type>();
	}
}
