﻿using System;
using System.Runtime.CompilerServices;

namespace Parse
{
	// Token: 0x0200002D RID: 45
	public class ParseException : Exception
	{
		// Token: 0x060000FC RID: 252 RVA: 0x000058B4 File Offset: 0x00003AB4
		internal ParseException(ParseException.ErrorCode code, string message, Exception cause = null)
			: base(message, cause)
		{
			this.Code = code;
		}

		// Token: 0x17000026 RID: 38
		// (set) Token: 0x060000FD RID: 253 RVA: 0x000058C8 File Offset: 0x00003AC8
		private ParseException.ErrorCode Code
		{
			[CompilerGenerated]
			set
			{
				this.<Code>k__BackingField = value;
			}
		}

		// Token: 0x0200002E RID: 46
		public enum ErrorCode
		{
			// Token: 0x04000091 RID: 145
			OtherCause = -1,
			// Token: 0x04000092 RID: 146
			InternalServerError = 1,
			// Token: 0x04000093 RID: 147
			ConnectionFailed = 100,
			// Token: 0x04000094 RID: 148
			ObjectNotFound,
			// Token: 0x04000095 RID: 149
			InvalidQuery,
			// Token: 0x04000096 RID: 150
			InvalidClassName,
			// Token: 0x04000097 RID: 151
			MissingObjectId,
			// Token: 0x04000098 RID: 152
			InvalidKeyName,
			// Token: 0x04000099 RID: 153
			InvalidPointer,
			// Token: 0x0400009A RID: 154
			InvalidJSON,
			// Token: 0x0400009B RID: 155
			CommandUnavailable,
			// Token: 0x0400009C RID: 156
			NotInitialized,
			// Token: 0x0400009D RID: 157
			IncorrectType = 111,
			// Token: 0x0400009E RID: 158
			InvalidChannelName,
			// Token: 0x0400009F RID: 159
			PushMisconfigured = 115,
			// Token: 0x040000A0 RID: 160
			ObjectTooLarge,
			// Token: 0x040000A1 RID: 161
			OperationForbidden = 119,
			// Token: 0x040000A2 RID: 162
			CacheMiss,
			// Token: 0x040000A3 RID: 163
			InvalidNestedKey,
			// Token: 0x040000A4 RID: 164
			InvalidFileName,
			// Token: 0x040000A5 RID: 165
			InvalidACL,
			// Token: 0x040000A6 RID: 166
			Timeout,
			// Token: 0x040000A7 RID: 167
			InvalidEmailAddress,
			// Token: 0x040000A8 RID: 168
			DuplicateValue = 137,
			// Token: 0x040000A9 RID: 169
			InvalidRoleName = 139,
			// Token: 0x040000AA RID: 170
			ExceededQuota,
			// Token: 0x040000AB RID: 171
			ScriptFailed,
			// Token: 0x040000AC RID: 172
			UsernameMissing = 200,
			// Token: 0x040000AD RID: 173
			PasswordMissing,
			// Token: 0x040000AE RID: 174
			UsernameTaken,
			// Token: 0x040000AF RID: 175
			EmailTaken,
			// Token: 0x040000B0 RID: 176
			EmailMissing,
			// Token: 0x040000B1 RID: 177
			EmailNotFound,
			// Token: 0x040000B2 RID: 178
			SessionMissing,
			// Token: 0x040000B3 RID: 179
			MustCreateUserThroughSignup,
			// Token: 0x040000B4 RID: 180
			AccountAlreadyLinked,
			// Token: 0x040000B5 RID: 181
			LinkedIdMissing = 250,
			// Token: 0x040000B6 RID: 182
			InvalidLinkedSession,
			// Token: 0x040000B7 RID: 183
			UnsupportedService
		}
	}
}
