﻿using System;
using Parse.Internal;

namespace Parse
{
	// Token: 0x0200002F RID: 47
	public static class ParseFacebookUtils
	{
		// Token: 0x060000FF RID: 255 RVA: 0x000058E0 File Offset: 0x00003AE0
		internal static void Initialize()
		{
			ParseUser.RegisterProvider(ParseFacebookUtils.authProvider);
		}

		// Token: 0x040000B8 RID: 184
		private static readonly FacebookAuthenticationProvider authProvider = new FacebookAuthenticationProvider();
	}
}
