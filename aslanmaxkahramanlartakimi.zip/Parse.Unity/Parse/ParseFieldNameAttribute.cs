﻿using System;

namespace Parse
{
	// Token: 0x02000030 RID: 48
	[AttributeUsage(AttributeTargets.Property, Inherited = true, AllowMultiple = false)]
	public sealed class ParseFieldNameAttribute : Attribute
	{
		// Token: 0x06000100 RID: 256 RVA: 0x000058EC File Offset: 0x00003AEC
		public ParseFieldNameAttribute(string fieldName)
		{
			this.FieldName = fieldName;
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000101 RID: 257 RVA: 0x000058FC File Offset: 0x00003AFC
		// (set) Token: 0x06000102 RID: 258 RVA: 0x00005904 File Offset: 0x00003B04
		public string FieldName { get; private set; }
	}
}
