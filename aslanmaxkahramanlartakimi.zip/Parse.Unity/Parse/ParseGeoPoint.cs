﻿using System;
using System.Collections.Generic;

namespace Parse
{
	// Token: 0x02000034 RID: 52
	public struct ParseGeoPoint
	{
		// Token: 0x06000114 RID: 276 RVA: 0x00006958 File Offset: 0x00004B58
		public ParseGeoPoint(double latitude, double longitude)
		{
			this = default(ParseGeoPoint);
			this.Latitude = latitude;
			this.Longitude = longitude;
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000115 RID: 277 RVA: 0x00006970 File Offset: 0x00004B70
		// (set) Token: 0x06000116 RID: 278 RVA: 0x00006978 File Offset: 0x00004B78
		public double Latitude
		{
			get
			{
				return this.latitude;
			}
			set
			{
				if (value > 90.0 || value < -90.0)
				{
					throw new ArgumentOutOfRangeException("value", "Latitude must be within the range [-90, 90]");
				}
				this.latitude = value;
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000117 RID: 279 RVA: 0x000069AC File Offset: 0x00004BAC
		// (set) Token: 0x06000118 RID: 280 RVA: 0x000069B4 File Offset: 0x00004BB4
		public double Longitude
		{
			get
			{
				return this.longitude;
			}
			set
			{
				if (value > 180.0 || value < -180.0)
				{
					throw new ArgumentOutOfRangeException("value", "Longitude must be within the range [-180, 180]");
				}
				this.longitude = value;
			}
		}

		// Token: 0x06000119 RID: 281 RVA: 0x000069E8 File Offset: 0x00004BE8
		internal IDictionary<string, object> ToJSON()
		{
			return new Dictionary<string, object>
			{
				{ "__type", "GeoPoint" },
				{ "latitude", this.Latitude },
				{ "longitude", this.Longitude }
			};
		}

		// Token: 0x040000C9 RID: 201
		private double latitude;

		// Token: 0x040000CA RID: 202
		private double longitude;
	}
}
