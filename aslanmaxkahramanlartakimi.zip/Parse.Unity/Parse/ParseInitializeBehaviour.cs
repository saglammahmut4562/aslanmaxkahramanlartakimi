﻿using System;
using UnityEngine;

namespace Parse
{
	// Token: 0x02000035 RID: 53
	public class ParseInitializeBehaviour : MonoBehaviour
	{
		// Token: 0x0600011C RID: 284 RVA: 0x00006A44 File Offset: 0x00004C44
		public virtual void Awake()
		{
			if (!ParseInitializeBehaviour.isInitialized)
			{
				ParseInitializeBehaviour.isInitialized = true;
				global::UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
				ParseClient.Initialize(this.applicationID, this.dotnetKey);
				base.StartCoroutine(PlatformHooks.RunDispatcher());
			}
		}

		// Token: 0x040000CB RID: 203
		private static bool isInitialized;

		// Token: 0x040000CC RID: 204
		[SerializeField]
		public string applicationID;

		// Token: 0x040000CD RID: 205
		[SerializeField]
		public string dotnetKey;
	}
}
