﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Parse.Internal;

namespace Parse
{
	// Token: 0x02000036 RID: 54
	public class ParseObject : IEnumerable<KeyValuePair<string, object>>, IEnumerable, INotifyPropertyChanged
	{
		// Token: 0x0600011D RID: 285 RVA: 0x00006A7C File Offset: 0x00004C7C
		protected ParseObject()
			: this(ParseObject.AutoClassName)
		{
		}

		// Token: 0x0600011E RID: 286 RVA: 0x00006A8C File Offset: 0x00004C8C
		public ParseObject(string className)
		{
			bool value = ParseObject.isCreatingPointer.Value;
			ParseObject.isCreatingPointer.Value = false;
			if (className == null)
			{
				throw new ArgumentException("You must specify a Parse class name when creating a new ParseObject.");
			}
			if (ParseObject.AutoClassName.Equals(className))
			{
				className = ParseObject.GetClassName(base.GetType());
			}
			if (base.GetType().Equals(typeof(ParseObject)) && ParseObject.objectFactories.ContainsKey(className))
			{
				throw new ArgumentException("You must create this type of ParseObject using ParseObject.Create() or the proper subclass.");
			}
			this.ClassName = className;
			this.operationSetQueue.AddLast(new Dictionary<string, IParseFieldOperation>());
			if (!value)
			{
				this.hasBeenFetched = true;
				this.IsDirty = true;
				this.SetDefaultValues();
				return;
			}
			this.IsDirty = false;
			this.hasBeenFetched = false;
		}

		// Token: 0x06000120 RID: 288 RVA: 0x00006C0C File Offset: 0x00004E0C
		internal virtual void SetDefaultValues()
		{
		}

		// Token: 0x06000121 RID: 289 RVA: 0x00006C10 File Offset: 0x00004E10
		internal static string GetClassName(Type t)
		{
			ParseClassNameAttribute customAttribute = t.GetTypeInfo().GetCustomAttribute<ParseClassNameAttribute>();
			if (customAttribute == null)
			{
				throw new ArgumentException("No ParseClassName attribute specified on the given subclass.");
			}
			return customAttribute.ClassName;
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00006C40 File Offset: 0x00004E40
		private static Func<ParseObject> GetFactory(string className)
		{
			Tuple<Func<ParseObject>, Type> tuple;
			if (!ParseObject.objectFactories.TryGetValue(className, out tuple))
			{
				return () => new ParseObject(className);
			}
			return tuple.Item1;
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00006C88 File Offset: 0x00004E88
		public static ParseObject CreateWithoutData(string className, string objectId)
		{
			ParseObject.isCreatingPointer.Value = true;
			ParseObject parseObject2;
			try
			{
				ParseObject parseObject = ParseObject.GetFactory(className)();
				parseObject.ObjectId = objectId;
				parseObject.IsDirty = false;
				if (parseObject.IsDirty)
				{
					throw new InvalidOperationException("A ParseObject subclass default constructor must not make changes to the object that cause it to be dirty.");
				}
				parseObject2 = parseObject;
			}
			finally
			{
				ParseObject.isCreatingPointer.Value = false;
			}
			return parseObject2;
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00006CF0 File Offset: 0x00004EF0
		public static T CreateWithoutData<T>(string objectId) where T : ParseObject
		{
			return (T)((object)ParseObject.CreateWithoutData(ParseObject.GetClassName(typeof(T)), objectId));
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00006D0C File Offset: 0x00004F0C
		public static void RegisterSubclass<T>() where T : ParseObject, new()
		{
			string text = ParseObject.GetClassName(typeof(T));
			if (text == null)
			{
				throw new ArgumentException("No ParseClassName attribute defined for " + typeof(T));
			}
			Tuple<Func<ParseObject>, Type> tuple;
			if (ParseObject.objectFactories.TryGetValue(text, out tuple))
			{
				if (typeof(T).GetTypeInfo().IsAssignableFrom(tuple.Item2.GetTypeInfo()))
				{
					return;
				}
				if (text.Equals(ParseObject.GetClassName(typeof(ParseUser))))
				{
					ParseUser.ClearInMemoryUser();
				}
				else if (text.Equals("_Installation"))
				{
					ParseClient.ClearInMemoryInstallation();
				}
			}
			ParseObject.objectFactories[text] = new Tuple<Func<ParseObject>, Type>(() => new T(), typeof(T));
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00006DD0 File Offset: 0x00004FD0
		internal static Type GetType(string className)
		{
			Tuple<Func<ParseObject>, Type> tuple;
			if (!ParseObject.objectFactories.TryGetValue(className, out tuple))
			{
				return typeof(ParseObject);
			}
			return tuple.Item2;
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00006E00 File Offset: 0x00005000
		internal virtual void MergeAfterFetch(IDictionary<string, object> result)
		{
			lock (this.mutex)
			{
				this.MergeFromServer(result);
				this.RebuildEstimatedData();
			}
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00006E40 File Offset: 0x00005040
		internal void MergeAfterFailedSave(IDictionary<string, IParseFieldOperation> operationsBeforeSave)
		{
			lock (this.mutex)
			{
				LinkedListNode<IDictionary<string, IParseFieldOperation>> linkedListNode = this.operationSetQueue.Find(operationsBeforeSave);
				IDictionary<string, IParseFieldOperation> value = linkedListNode.Next.Value;
				bool flag = value.Count > 0;
				this.operationSetQueue.Remove(linkedListNode);
				foreach (KeyValuePair<string, IParseFieldOperation> keyValuePair in operationsBeforeSave)
				{
					IParseFieldOperation value2 = keyValuePair.Value;
					IParseFieldOperation parseFieldOperation = null;
					value.TryGetValue(keyValuePair.Key, out parseFieldOperation);
					if (parseFieldOperation != null)
					{
						parseFieldOperation = parseFieldOperation.MergeWithPrevious(value2);
					}
					else
					{
						parseFieldOperation = value2;
					}
					value[keyValuePair.Key] = parseFieldOperation;
				}
				if (!flag && value == this.CurrentOperations && operationsBeforeSave.Count > 0)
				{
					this.OnPropertyChanged("IsDirty");
				}
			}
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00006F3C File Offset: 0x0000513C
		internal virtual void MergeAfterSave(IDictionary<string, object> result)
		{
			lock (this.mutex)
			{
				IDictionary<string, IParseFieldOperation> value = this.operationSetQueue.First.Value;
				this.operationSetQueue.RemoveFirst();
				this.ApplyOperations(value, this.serverData);
				this.MergeFromServer(result);
				this.RebuildEstimatedData();
			}
		}

		// Token: 0x0600012A RID: 298 RVA: 0x00006FA8 File Offset: 0x000051A8
		internal virtual void MergeMagicFields(IDictionary<string, object> data)
		{
			lock (this.mutex)
			{
				if (data.ContainsKey("objectId"))
				{
					this.SetObjectIdInternal(data["objectId"] as string);
					this.hasBeenFetched = true;
					this.OnPropertyChanged("IsDataAvailable");
					data.Remove("objectId");
				}
				if (data.ContainsKey("createdAt"))
				{
					this.CreatedAt = new DateTime?(ParseClient.ParseDate(data["createdAt"] as string));
					data.Remove("createdAt");
				}
				if (data.ContainsKey("updatedAt"))
				{
					this.UpdatedAt = new DateTime?(ParseClient.ParseDate(data["updatedAt"] as string));
					data.Remove("updatedAt");
				}
				if (data.ContainsKey("ACL"))
				{
					ParseACL parseACL = new ParseACL(data["ACL"] as IDictionary<string, object>);
					this.serverData["ACL"] = parseACL;
					this.AddToHashedObjects(parseACL);
					data.Remove("ACL");
				}
			}
		}

		// Token: 0x0600012B RID: 299 RVA: 0x000070D8 File Offset: 0x000052D8
		internal void MergeFromServer(IDictionary<string, object> data)
		{
			lock (this.mutex)
			{
				this.IsDirty = false;
				this.MergeMagicFields(data);
				foreach (KeyValuePair<string, object> keyValuePair in data)
				{
					if (!(keyValuePair.Key == "__type") && !(keyValuePair.Key == "className"))
					{
						object obj2 = keyValuePair.Value;
						object obj3 = ParseClient.Decode(obj2);
						if (ParseClient.IsContainerObject(obj2))
						{
							IDictionary<string, object> dictionary = obj3 as IDictionary<string, object>;
							if (dictionary != null)
							{
								object obj4;
								dictionary.TryGetValue("__type", out obj4);
								if ((string)obj4 == "Relation")
								{
									string text = dictionary["className"] as string;
									obj2 = ParseRelationBase.CreateRelation(this, keyValuePair.Key, text);
								}
							}
							IList<object> list = obj3 as IList<object>;
							this.AddToHashedObjects(obj3);
						}
						this.serverData[keyValuePair.Key] = obj3;
					}
				}
				if (this.UpdatedAt == null && this.CreatedAt != null)
				{
					this.UpdatedAt = this.CreatedAt;
				}
				this.IsDirty = false;
				this.RebuildEstimatedData();
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x0600012C RID: 300 RVA: 0x00007260 File Offset: 0x00005460
		private bool HasDirtyChildren
		{
			get
			{
				bool flag;
				lock (this.mutex)
				{
					flag = this.FindUnsavedChildren().FirstOrDefault<ParseObject>() != null;
				}
				return flag;
			}
		}

		// Token: 0x0600012D RID: 301 RVA: 0x000072A8 File Offset: 0x000054A8
		private void CheckpointMutableContainer(object obj)
		{
			lock (this.mutex)
			{
				if (ParseClient.IsContainerObject(obj))
				{
					this.hashedObjects[obj] = new ParseJSONCacheItem(obj);
				}
			}
		}

		// Token: 0x0600012E RID: 302 RVA: 0x000072F8 File Offset: 0x000054F8
		private void CheckForChangesToMutableContainer(string key, object obj)
		{
			lock (this.mutex)
			{
				if (ParseClient.IsContainerObject(obj))
				{
					ParseJSONCacheItem parseJSONCacheItem;
					this.hashedObjects.TryGetValue(obj, out parseJSONCacheItem);
					if (parseJSONCacheItem == null)
					{
						throw new ArgumentException("ParseObjects contains container item that isn't cached.");
					}
					ParseJSONCacheItem parseJSONCacheItem2 = new ParseJSONCacheItem(obj);
					if (!parseJSONCacheItem.Equals(parseJSONCacheItem2))
					{
						this.PerformOperation(key, new ParseSetOperation(obj));
					}
				}
				else if (obj != null)
				{
					this.hashedObjects.Remove(obj);
				}
			}
		}

		// Token: 0x0600012F RID: 303 RVA: 0x00007380 File Offset: 0x00005580
		internal void CheckForChangesToMutableContainers()
		{
			lock (this.mutex)
			{
				foreach (KeyValuePair<string, object> keyValuePair in new Dictionary<string, object>(this.estimatedData))
				{
					this.CheckForChangesToMutableContainer(keyValuePair.Key, keyValuePair.Value);
				}
				object[] array = this.hashedObjects.Keys.Except<object>(this.estimatedData.Values).ToArray<object>();
				foreach (object obj2 in array)
				{
					this.hashedObjects.Remove(obj2);
				}
			}
		}

		// Token: 0x06000130 RID: 304 RVA: 0x00007454 File Offset: 0x00005654
		private IEnumerable<ParseObject> FindUnsavedChildren()
		{
			return from o in ParseClient.DeepTraversal(this.estimatedData, false, false).OfType<ParseObject>()
				where o.IsDirty
				select o;
		}

		// Token: 0x06000131 RID: 305 RVA: 0x0000748C File Offset: 0x0000568C
		internal IDictionary<string, object> ToJSONObjectForSaving(IDictionary<string, IParseFieldOperation> operations)
		{
			IDictionary<string, object> dictionary2;
			lock (this.mutex)
			{
				Dictionary<string, object> dictionary = new Dictionary<string, object>();
				foreach (KeyValuePair<string, IParseFieldOperation> keyValuePair in operations)
				{
					IParseFieldOperation value = keyValuePair.Value;
					dictionary[keyValuePair.Key] = ParseClient.MaybeEncodeJSONObject(value, true);
				}
				dictionary2 = dictionary;
			}
			return dictionary2;
		}

		// Token: 0x06000132 RID: 306 RVA: 0x0000751C File Offset: 0x0000571C
		internal IDictionary<string, object> ServerDataToJSONObjectForSerialization()
		{
			IDictionary<string, object> dictionary;
			lock (this.mutex)
			{
				dictionary = ParseClient.MaybeEncodeJSONObject(this.serverData, true) as IDictionary<string, object>;
			}
			return dictionary;
		}

		// Token: 0x06000133 RID: 307 RVA: 0x00007564 File Offset: 0x00005764
		internal IDictionary<string, IParseFieldOperation> StartSave()
		{
			IDictionary<string, IParseFieldOperation> dictionary;
			lock (this.mutex)
			{
				IDictionary<string, IParseFieldOperation> currentOperations = this.CurrentOperations;
				this.operationSetQueue.AddLast(new Dictionary<string, IParseFieldOperation>());
				this.OnPropertyChanged("IsDirty");
				dictionary = currentOperations;
			}
			return dictionary;
		}

		// Token: 0x06000134 RID: 308 RVA: 0x000075C0 File Offset: 0x000057C0
		internal virtual Task SaveAsync(Task toAwait, CancellationToken cancellationToken)
		{
			Tuple<HttpStatusCode, IDictionary<string, object>> result = null;
			IDictionary<string, IParseFieldOperation> currentOperations = null;
			if (!this.IsDirty)
			{
				return Task.FromResult<int>(0);
			}
			string sessionToken;
			Task task;
			lock (this.mutex)
			{
				sessionToken = ParseUser.CurrentSessionToken;
				currentOperations = this.StartSave();
				task = ParseObject.DeepSaveAsync(this.estimatedData, sessionToken, cancellationToken);
			}
			IDictionary<string, object> objectJSON;
			return task.OnSuccess<Task>((Task _) => toAwait).Unwrap().OnSuccess<Task<Tuple<HttpStatusCode, IDictionary<string, object>>>>(delegate(Task _)
			{
				Task<Tuple<HttpStatusCode, IDictionary<string, object>>> task2;
				lock (this.mutex)
				{
					objectJSON = this.ToJSONObjectForSaving(currentOperations);
					if (this.ObjectId != null)
					{
						if (objectJSON.Count == 0)
						{
							task2 = Task.FromResult<Tuple<HttpStatusCode, IDictionary<string, object>>>(new Tuple<HttpStatusCode, IDictionary<string, object>>(HttpStatusCode.OK, new Dictionary<string, object>()));
						}
						else
						{
							task2 = ParseClient.RequestAsync("PUT", string.Format("/1/classes/{0}/{1}", Uri.EscapeDataString(this.ClassName), Uri.EscapeDataString(this.ObjectId)), sessionToken, objectJSON, cancellationToken);
						}
					}
					else
					{
						task2 = ParseClient.RequestAsync("POST", string.Format("/1/classes/{0}", Uri.EscapeDataString(this.ClassName)), sessionToken, objectJSON, cancellationToken);
					}
				}
				return task2;
			})
				.Unwrap<Tuple<HttpStatusCode, IDictionary<string, object>>>()
				.OnSuccess<Tuple<HttpStatusCode, IDictionary<string, object>>, Tuple<HttpStatusCode, IDictionary<string, object>>>((Task<Tuple<HttpStatusCode, IDictionary<string, object>>> t) => result = t.Result)
				.ContinueWith<Task<Tuple<HttpStatusCode, IDictionary<string, object>>>>(delegate(Task<Tuple<HttpStatusCode, IDictionary<string, object>>> t)
				{
					lock (this.mutex)
					{
						if (result != null)
						{
							this.IsNew = result.Item1 == HttpStatusCode.Created;
							this.MergeAfterSave(result.Item2);
						}
						else
						{
							this.MergeAfterFailedSave(currentOperations);
						}
					}
					return t;
				})
				.Unwrap<Tuple<HttpStatusCode, IDictionary<string, object>>>();
		}

		// Token: 0x06000135 RID: 309 RVA: 0x000076B0 File Offset: 0x000058B0
		public Task SaveAsync()
		{
			return this.SaveAsync(CancellationToken.None);
		}

		// Token: 0x06000136 RID: 310 RVA: 0x000076C0 File Offset: 0x000058C0
		public Task SaveAsync(CancellationToken cancellationToken)
		{
			return this.taskQueue.Enqueue<Task>((Task toAwait) => this.SaveAsync(toAwait, cancellationToken), cancellationToken);
		}

		// Token: 0x06000137 RID: 311 RVA: 0x00007700 File Offset: 0x00005900
		private static void CollectDirtyChildren(object node, IList<ParseObject> dirtyChildren, ICollection<ParseObject> seen, ICollection<ParseObject> seenNew)
		{
			foreach (ParseObject parseObject in ParseClient.DeepTraversal(node, false, false).OfType<ParseObject>())
			{
				ICollection<ParseObject> collection;
				if (parseObject.ObjectId != null)
				{
					collection = new HashSet<ParseObject>(new IdentityEqualityComparer<ParseObject>());
				}
				else
				{
					if (seenNew.Contains(parseObject))
					{
						throw new InvalidOperationException("Found a circular dependency while saving");
					}
					collection = new HashSet<ParseObject>(seenNew, new IdentityEqualityComparer<ParseObject>());
					collection.Add(parseObject);
				}
				if (seen.Contains(parseObject))
				{
					break;
				}
				seen.Add(parseObject);
				ParseObject.CollectDirtyChildren(parseObject.estimatedData, dirtyChildren, seen, collection);
				if (parseObject.CheckIsDirty(false))
				{
					dirtyChildren.Add(parseObject);
				}
			}
		}

		// Token: 0x06000138 RID: 312 RVA: 0x000077BC File Offset: 0x000059BC
		private static void CollectDirtyChildren(object node, IList<ParseObject> dirtyChildren)
		{
			ParseObject.CollectDirtyChildren(node, dirtyChildren, new HashSet<ParseObject>(new IdentityEqualityComparer<ParseObject>()), new HashSet<ParseObject>(new IdentityEqualityComparer<ParseObject>()));
		}

		// Token: 0x06000139 RID: 313 RVA: 0x000077DC File Offset: 0x000059DC
		private static bool CanBeSerializedAsValue(object value)
		{
			return ParseClient.DeepTraversal(value, false, true).OfType<ParseObject>().All<ParseObject>((ParseObject o) => o.ObjectId != null);
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x0600013A RID: 314 RVA: 0x00007810 File Offset: 0x00005A10
		private bool CanBeSerialized
		{
			get
			{
				bool flag;
				lock (this.mutex)
				{
					flag = ParseObject.CanBeSerializedAsValue(this.estimatedData);
				}
				return flag;
			}
		}

		// Token: 0x0600013B RID: 315 RVA: 0x00007850 File Offset: 0x00005A50
		private static Task<T> EnqueueForAll<T>(IEnumerable<ParseObject> objects, Func<Task, Task<T>> taskStart, CancellationToken cancellationToken)
		{
			TaskCompletionSource<object> readyToStart = new TaskCompletionSource<object>();
			LockSet lockSet = new LockSet(objects.Select<ParseObject, object>((ParseObject o) => o.taskQueue.Mutex));
			lockSet.Enter();
			Task<T> fullTask2;
			try
			{
				Task<T> fullTask = taskStart(readyToStart.Task);
				List<Task> childTasks = new List<Task>();
				foreach (ParseObject parseObject in objects)
				{
					parseObject.taskQueue.Enqueue<Task<T>>(delegate(Task task)
					{
						childTasks.Add(task);
						return fullTask;
					}, cancellationToken);
				}
				Task.WhenAll(childTasks.ToArray()).ContinueWith(delegate(Task task)
				{
					readyToStart.SetResult(null);
				});
				fullTask2 = fullTask;
			}
			finally
			{
				lockSet.Exit();
			}
			return fullTask2;
		}

		// Token: 0x0600013C RID: 316 RVA: 0x00007968 File Offset: 0x00005B68
		private static Task DeepSaveAsync(object obj, string sessionToken, CancellationToken cancellationToken)
		{
			List<ParseObject> list = new List<ParseObject>();
			ParseObject.CollectDirtyChildren(obj, list);
			HashSet<ParseObject> uniqueObjects = new HashSet<ParseObject>(list, new IdentityEqualityComparer<ParseObject>());
			List<Task> list2 = (from f in ParseClient.DeepTraversal(obj, true, false).OfType<ParseFile>()
				where f.IsDirty
				select f.SaveAsync(cancellationToken)).ToList<Task>();
			return Task.WhenAll(list2).OnSuccess<Task>(delegate(Task _)
			{
				IEnumerable<ParseObject> remaining = new List<ParseObject>(uniqueObjects);
				return InternalExtensions.WhileAsync(() => Task.FromResult<bool>(remaining.Any<ParseObject>()), delegate
				{
					List<ParseObject> current = remaining.Where<ParseObject>((ParseObject item) => item.CanBeSerialized).ToList<ParseObject>();
					List<ParseObject> list3 = remaining.Where<ParseObject>((ParseObject item) => !item.CanBeSerialized).ToList<ParseObject>();
					if (current.Count > 20)
					{
						list3.InsertRange(0, current.GetRange(20, current.Count - 20));
						current.RemoveRange(20, current.Count - 20);
					}
					remaining = list3;
					if (current.Count == 0)
					{
						throw new InvalidOperationException("Unable to save a ParseObject with a relation to a cycle.");
					}
					return ParseObject.EnqueueForAll<object>(current, delegate(Task toAwait)
					{
						List<IDictionary<string, IParseFieldOperation>> operations = current.Select<ParseObject, IDictionary<string, IParseFieldOperation>>((ParseObject item) => item.StartSave()).ToList<IDictionary<string, IParseFieldOperation>>();
						return toAwait.OnSuccess<Task<Tuple<HttpStatusCode, IDictionary<string, object>>>>(delegate(Task __)
						{
							List<object> list4 = current.Zip<ParseObject, IDictionary<string, IParseFieldOperation>, Dictionary<string, object>>(operations, (ParseObject item, IDictionary<string, IParseFieldOperation> ops) => new Dictionary<string, object>
							{
								{
									"method",
									(item.ObjectId == null) ? "POST" : "PUT"
								},
								{
									"path",
									(item.ObjectId == null) ? string.Format("/1/classes/{0}", Uri.EscapeDataString(item.ClassName)) : string.Format("/1/classes/{0}/{1}", Uri.EscapeDataString(item.ClassName), Uri.EscapeDataString(item.ObjectId))
								},
								{
									"body",
									item.ToJSONObjectForSaving(ops)
								}
							}).Cast<object>().ToList<object>();
							return ParseClient.RequestAsync("POST", "/1/batch", sessionToken, new Dictionary<string, object> { { "requests", list4 } }, cancellationToken);
						}).Unwrap<Tuple<HttpStatusCode, IDictionary<string, object>>>().ContinueWith<Task<Tuple<HttpStatusCode, IDictionary<string, object>>>>(delegate(Task<Tuple<HttpStatusCode, IDictionary<string, object>>> requestTask)
						{
							if (requestTask.IsCanceled || requestTask.IsFaulted)
							{
								foreach (var anon in current.Zip(operations, (ParseObject item, IDictionary<string, IParseFieldOperation> ops) => new { item, ops }))
								{
									anon.item.MergeAfterFailedSave(anon.ops);
								}
								return requestTask;
							}
							List<object> resultsArray = (List<object>)requestTask.Result.Item2["results"];
							var enumerable = from i in Enumerable.Range(0, current.Count)
								select new
								{
									Obj = current[i],
									Result = (Dictionary<string, object>)resultsArray.ElementAtOrDefault<object>(i),
									Operation = operations[i]
								};
							ParseException ex = null;
							foreach (var anon2 in enumerable)
							{
								if (anon2.Result != null && anon2.Result.ContainsKey("success"))
								{
									anon2.Obj.MergeAfterSave((Dictionary<string, object>)anon2.Result["success"]);
								}
								else
								{
									anon2.Obj.MergeAfterFailedSave(anon2.Operation);
									if (ex == null)
									{
										Dictionary<string, object> dictionary = (Dictionary<string, object>)anon2.Result["error"];
										int num = (int)(dictionary.ContainsKey("code") ? ((long)dictionary["code"]) : (-1L));
										string text = dictionary["error"] as string;
										ex = new ParseException((ParseException.ErrorCode)num, text, null);
									}
								}
							}
							if (ex != null)
							{
								throw ex;
							}
							return requestTask;
						})
							.Unwrap<Tuple<HttpStatusCode, IDictionary<string, object>>>()
							.OnSuccess<Tuple<HttpStatusCode, IDictionary<string, object>>, object>((Task<Tuple<HttpStatusCode, IDictionary<string, object>>> t) => t.Result);
					}, cancellationToken);
				});
			}).Unwrap();
		}

		// Token: 0x0600013D RID: 317 RVA: 0x00007A0C File Offset: 0x00005C0C
		private void ApplyOperations(IDictionary<string, IParseFieldOperation> operations, IDictionary<string, object> map)
		{
			lock (this.mutex)
			{
				foreach (KeyValuePair<string, IParseFieldOperation> keyValuePair in operations)
				{
					object obj2;
					map.TryGetValue(keyValuePair.Key, out obj2);
					object obj3 = keyValuePair.Value.Apply(obj2, this, keyValuePair.Key);
					if (obj3 != ParseDeleteOperation.DeleteToken)
					{
						map[keyValuePair.Key] = obj3;
					}
					else
					{
						map.Remove(keyValuePair.Key);
					}
				}
			}
		}

		// Token: 0x0600013E RID: 318 RVA: 0x00007AC0 File Offset: 0x00005CC0
		internal void RebuildEstimatedData()
		{
			lock (this.mutex)
			{
				this.estimatedData.Clear();
				foreach (KeyValuePair<string, object> keyValuePair in this.serverData)
				{
					this.estimatedData.Add(keyValuePair);
				}
				foreach (IDictionary<string, IParseFieldOperation> dictionary in this.operationSetQueue)
				{
					this.ApplyOperations(dictionary, this.estimatedData);
				}
				this.hashedObjects.Clear();
				foreach (KeyValuePair<string, object> keyValuePair2 in this.estimatedData)
				{
					this.CheckpointMutableContainer(keyValuePair2.Value);
				}
				this.OnFieldsChanged(null);
			}
		}

		// Token: 0x0600013F RID: 319 RVA: 0x00007BE8 File Offset: 0x00005DE8
		internal void PerformOperation(string key, IParseFieldOperation operation)
		{
			lock (this.mutex)
			{
				object obj2;
				this.estimatedData.TryGetValue(key, out obj2);
				object obj3 = operation.Apply(obj2, this, key);
				if (obj3 != ParseDeleteOperation.DeleteToken)
				{
					this.estimatedData[key] = obj3;
				}
				else
				{
					this.estimatedData.Remove(key);
				}
				bool flag = this.CurrentOperations.Count > 0;
				IParseFieldOperation parseFieldOperation;
				this.CurrentOperations.TryGetValue(key, out parseFieldOperation);
				IParseFieldOperation parseFieldOperation2 = operation.MergeWithPrevious(parseFieldOperation);
				this.CurrentOperations[key] = parseFieldOperation2;
				if (!flag)
				{
					this.OnPropertyChanged("IsDirty");
				}
				this.CheckpointMutableContainer(obj3);
				this.dataAvailability[key] = true;
				this.OnFieldsChanged(new string[] { key });
			}
		}

		// Token: 0x06000140 RID: 320 RVA: 0x00007CC8 File Offset: 0x00005EC8
		internal virtual void OnSettingValue(ref string key, ref object value)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
		}

		// Token: 0x1700002F RID: 47
		public virtual object this[string key]
		{
			get
			{
				object obj3;
				lock (this.mutex)
				{
					this.CheckGetAccess(key);
					object obj2 = this.estimatedData[key];
					ParseRelationBase parseRelationBase = obj2 as ParseRelationBase;
					if (parseRelationBase != null)
					{
						parseRelationBase.EnsureParentAndKey(this, key);
					}
					obj3 = obj2;
				}
				return obj3;
			}
			set
			{
				lock (this.mutex)
				{
					this.OnSettingValue(ref key, ref value);
					if (!ParseClient.IsValidType(value))
					{
						throw new ArgumentException("Invalid type for value: " + value.GetType().ToString());
					}
					this.PerformOperation(key, new ParseSetOperation(value));
					this.CheckpointMutableContainer(value);
				}
			}
		}

		// Token: 0x06000143 RID: 323 RVA: 0x00007DAC File Offset: 0x00005FAC
		public bool ContainsKey(string key)
		{
			bool flag;
			lock (this.mutex)
			{
				flag = this.estimatedData.ContainsKey(key);
			}
			return flag;
		}

		// Token: 0x06000144 RID: 324 RVA: 0x00007DF0 File Offset: 0x00005FF0
		public bool TryGetValue<T>(string key, out T result)
		{
			bool flag;
			lock (this.mutex)
			{
				if (this.ContainsKey(key))
				{
					object obj2 = ParseClient.ConvertTo<T>(this[key]);
					if (obj2 is T || (obj2 == null && (!typeof(T).GetTypeInfo().IsValueType || typeof(T).IsNullable())))
					{
						result = (T)((object)obj2);
						return true;
					}
				}
				result = default(T);
				flag = false;
			}
			return flag;
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000145 RID: 325 RVA: 0x00007E88 File Offset: 0x00006088
		public bool IsDataAvailable
		{
			get
			{
				bool flag;
				lock (this.mutex)
				{
					flag = this.hasBeenFetched;
				}
				return flag;
			}
		}

		// Token: 0x06000146 RID: 326 RVA: 0x00007EC4 File Offset: 0x000060C4
		private bool CheckIsDataAvailable(string key)
		{
			bool flag;
			lock (this.mutex)
			{
				flag = this.IsDataAvailable || (this.dataAvailability.ContainsKey(key) && this.dataAvailability[key]);
			}
			return flag;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x00007F24 File Offset: 0x00006124
		private void CheckGetAccess(string key)
		{
			lock (this.mutex)
			{
				if (!this.CheckIsDataAvailable(key))
				{
					throw new InvalidOperationException("ParseObject has no data for this key.  Call FetchIfNeededAsync() to get the data.");
				}
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000148 RID: 328 RVA: 0x00007F6C File Offset: 0x0000616C
		internal IDictionary<string, IParseFieldOperation> CurrentOperations
		{
			get
			{
				return this.operationSetQueue.Last.Value;
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000149 RID: 329 RVA: 0x00007F80 File Offset: 0x00006180
		public ICollection<string> Keys
		{
			get
			{
				ICollection<string> keys;
				lock (this.mutex)
				{
					keys = this.estimatedData.Keys;
				}
				return keys;
			}
		}

		// Token: 0x0600014A RID: 330 RVA: 0x00007FC0 File Offset: 0x000061C0
		internal void AddToHashedObjects(object obj)
		{
			lock (this.mutex)
			{
				this.hashedObjects[obj] = new ParseJSONCacheItem(obj);
			}
		}

		// Token: 0x17000033 RID: 51
		// (set) Token: 0x0600014B RID: 331 RVA: 0x00008008 File Offset: 0x00006208
		private bool IsNew
		{
			set
			{
				lock (this.mutex)
				{
					this.isNew = value;
					this.OnPropertyChanged("IsNew");
				}
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600014C RID: 332 RVA: 0x00008050 File Offset: 0x00006250
		// (set) Token: 0x0600014D RID: 333 RVA: 0x0000808C File Offset: 0x0000628C
		[ParseFieldName("updatedAt")]
		public DateTime? UpdatedAt
		{
			get
			{
				DateTime? dateTime;
				lock (this.mutex)
				{
					dateTime = this.updatedAt;
				}
				return dateTime;
			}
			private set
			{
				lock (this.mutex)
				{
					this.updatedAt = value;
					this.OnPropertyChanged("UpdatedAt");
				}
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600014E RID: 334 RVA: 0x000080D4 File Offset: 0x000062D4
		// (set) Token: 0x0600014F RID: 335 RVA: 0x00008110 File Offset: 0x00006310
		[ParseFieldName("createdAt")]
		public DateTime? CreatedAt
		{
			get
			{
				DateTime? dateTime;
				lock (this.mutex)
				{
					dateTime = this.createdAt;
				}
				return dateTime;
			}
			private set
			{
				lock (this.mutex)
				{
					this.createdAt = value;
					this.OnPropertyChanged("CreatedAt");
				}
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000150 RID: 336 RVA: 0x00008158 File Offset: 0x00006358
		// (set) Token: 0x06000151 RID: 337 RVA: 0x00008194 File Offset: 0x00006394
		public bool IsDirty
		{
			get
			{
				bool flag;
				lock (this.mutex)
				{
					flag = this.CheckIsDirty(true);
				}
				return flag;
			}
			internal set
			{
				lock (this.mutex)
				{
					this.dirty = value;
					this.OnPropertyChanged("IsDirty");
				}
			}
		}

		// Token: 0x06000152 RID: 338 RVA: 0x000081DC File Offset: 0x000063DC
		private bool CheckIsDirty(bool considerChildren)
		{
			this.CheckForChangesToMutableContainers();
			return this.dirty || this.CurrentOperations.Count > 0 || (considerChildren && this.HasDirtyChildren);
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000153 RID: 339 RVA: 0x00008208 File Offset: 0x00006408
		// (set) Token: 0x06000154 RID: 340 RVA: 0x00008244 File Offset: 0x00006444
		[ParseFieldName("objectId")]
		public string ObjectId
		{
			get
			{
				string text;
				lock (this.mutex)
				{
					text = this.objectId;
				}
				return text;
			}
			set
			{
				lock (this.mutex)
				{
					this.IsDirty = true;
					this.SetObjectIdInternal(value);
				}
			}
		}

		// Token: 0x06000155 RID: 341 RVA: 0x00008288 File Offset: 0x00006488
		private void SetObjectIdInternal(string objectId)
		{
			lock (this.mutex)
			{
				this.objectId = objectId;
				this.OnPropertyChanged("ObjectId");
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000156 RID: 342 RVA: 0x000082D0 File Offset: 0x000064D0
		// (set) Token: 0x06000157 RID: 343 RVA: 0x0000830C File Offset: 0x0000650C
		public string ClassName
		{
			get
			{
				string text;
				lock (this.mutex)
				{
					text = this.className;
				}
				return text;
			}
			private set
			{
				lock (this.mutex)
				{
					this.className = value;
					this.OnPropertyChanged("ClassName");
				}
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x00008354 File Offset: 0x00006554
		IEnumerator<KeyValuePair<string, object>> IEnumerable<KeyValuePair<string, object>>.GetEnumerator()
		{
			return this.estimatedData.GetEnumerator();
		}

		// Token: 0x06000159 RID: 345 RVA: 0x00008364 File Offset: 0x00006564
		IEnumerator IEnumerable.GetEnumerator()
		{
			return ((IEnumerable<KeyValuePair<string, object>>)this).GetEnumerator();
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0000836C File Offset: 0x0000656C
		public static ParseQuery<ParseObject> GetQuery(string className)
		{
			if (ParseObject.GetType(className) != typeof(ParseObject))
			{
				throw new ArgumentException("Use the class-specific query properties for class " + className, "className");
			}
			return new ParseQuery<ParseObject>(className);
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600015B RID: 347 RVA: 0x0000839C File Offset: 0x0000659C
		internal IDictionary<string, string> PropertyMappings
		{
			get
			{
				ParseObject.propertyMappingsLock.EnterReadLock();
				try
				{
					IDictionary<string, string> dictionary;
					if (ParseObject.propertyMappings.TryGetValue(base.GetType(), out dictionary))
					{
						return dictionary;
					}
				}
				finally
				{
					ParseObject.propertyMappingsLock.ExitReadLock();
				}
				ParseObject.propertyMappingsLock.EnterUpgradeableReadLock();
				IDictionary<string, string> dictionary2;
				try
				{
					IDictionary<string, string> dictionary;
					if (!ParseObject.propertyMappings.TryGetValue(base.GetType(), out dictionary))
					{
						dictionary = new Dictionary<string, string>();
						foreach (PropertyInfo propertyInfo in base.GetType().GetProperties())
						{
							ParseFieldNameAttribute customAttribute = propertyInfo.GetCustomAttribute<ParseFieldNameAttribute>(true);
							if (customAttribute != null)
							{
								dictionary[customAttribute.FieldName] = propertyInfo.Name;
							}
						}
						ParseObject.propertyMappingsLock.EnterWriteLock();
						try
						{
							ParseObject.propertyMappings[base.GetType()] = dictionary;
						}
						finally
						{
							ParseObject.propertyMappingsLock.ExitWriteLock();
						}
					}
					dictionary2 = dictionary;
				}
				finally
				{
					ParseObject.propertyMappingsLock.ExitUpgradeableReadLock();
				}
				return dictionary2;
			}
		}

		// Token: 0x0600015C RID: 348 RVA: 0x000084A4 File Offset: 0x000066A4
		protected void OnFieldsChanged(IEnumerable<string> fieldNames)
		{
			IDictionary<string, string> dictionary = this.PropertyMappings;
			fieldNames = fieldNames ?? dictionary.Keys;
			foreach (string text in fieldNames)
			{
				string text2;
				if (dictionary.TryGetValue(text, out text2))
				{
					this.OnPropertyChanged(text2);
				}
			}
			this.OnPropertyChanged("Item[]");
		}

		// Token: 0x0600015D RID: 349 RVA: 0x00008518 File Offset: 0x00006718
		protected void OnPropertyChanged(string propertyName)
		{
			this.propertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x0600015E RID: 350 RVA: 0x00008530 File Offset: 0x00006730
		// (remove) Token: 0x0600015F RID: 351 RVA: 0x00008540 File Offset: 0x00006740
		public event PropertyChangedEventHandler PropertyChanged
		{
			add
			{
				this.propertyChanged.Add(value);
			}
			remove
			{
				this.propertyChanged.Remove(value);
			}
		}

		// Token: 0x040000CE RID: 206
		private static readonly string AutoClassName = "_Automatic";

		// Token: 0x040000CF RID: 207
		private static readonly IDictionary<Tuple<Type, string>, string> propertyFieldNames = new Dictionary<Tuple<Type, string>, string>();

		// Token: 0x040000D0 RID: 208
		private static readonly IDictionary<string, Tuple<Func<ParseObject>, Type>> objectFactories = new Dictionary<string, Tuple<Func<ParseObject>, Type>>();

		// Token: 0x040000D1 RID: 209
		private static readonly IDictionary<Type, IDictionary<string, string>> propertyMappings = new Dictionary<Type, IDictionary<string, string>>();

		// Token: 0x040000D2 RID: 210
		private static readonly ReaderWriterLockSlim propertyMappingsLock = new ReaderWriterLockSlim();

		// Token: 0x040000D3 RID: 211
		internal readonly object mutex = new object();

		// Token: 0x040000D4 RID: 212
		internal readonly IDictionary<string, object> serverData = new Dictionary<string, object>();

		// Token: 0x040000D5 RID: 213
		private readonly LinkedList<IDictionary<string, IParseFieldOperation>> operationSetQueue = new LinkedList<IDictionary<string, IParseFieldOperation>>();

		// Token: 0x040000D6 RID: 214
		private readonly IDictionary<string, object> estimatedData = new Dictionary<string, object>();

		// Token: 0x040000D7 RID: 215
		private readonly IDictionary<string, bool> dataAvailability = new Dictionary<string, bool>();

		// Token: 0x040000D8 RID: 216
		private readonly IDictionary<object, ParseJSONCacheItem> hashedObjects = new Dictionary<object, ParseJSONCacheItem>();

		// Token: 0x040000D9 RID: 217
		private static readonly ThreadLocal<bool> isCreatingPointer = new ThreadLocal<bool>(() => false);

		// Token: 0x040000DA RID: 218
		private bool hasBeenFetched;

		// Token: 0x040000DB RID: 219
		private bool dirty;

		// Token: 0x040000DC RID: 220
		internal TaskQueue taskQueue = new TaskQueue();

		// Token: 0x040000DD RID: 221
		private bool isNew;

		// Token: 0x040000DE RID: 222
		private DateTime? updatedAt;

		// Token: 0x040000DF RID: 223
		private DateTime? createdAt;

		// Token: 0x040000E0 RID: 224
		private string objectId;

		// Token: 0x040000E1 RID: 225
		private string className;

		// Token: 0x040000E2 RID: 226
		private SynchronizedEventHandler<PropertyChangedEventArgs> propertyChanged = new SynchronizedEventHandler<PropertyChangedEventArgs>();
	}
}
