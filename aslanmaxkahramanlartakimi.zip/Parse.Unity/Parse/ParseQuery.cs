﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Parse.Internal;

namespace Parse
{
	// Token: 0x02000041 RID: 65
	public class ParseQuery<T> where T : ParseObject
	{
		// Token: 0x06000186 RID: 390 RVA: 0x00008D9C File Offset: 0x00006F9C
		private ParseQuery(ParseQuery<T> source, IDictionary<string, object> where = null, IEnumerable<string> replacementOrderBy = null, IEnumerable<string> thenBy = null, int? skip = null, int? limit = null, IEnumerable<string> includes = null)
		{
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			this.className = source.className;
			this.where = source.where;
			this.orderBy = source.orderBy;
			this.skip = source.skip;
			this.limit = source.limit;
			this.includes = source.includes;
			if (where != null)
			{
				IDictionary<string, object> dictionary = this.MergeWhereClauses(where);
				this.where = new Dictionary<string, object>(dictionary);
			}
			if (replacementOrderBy != null)
			{
				this.orderBy = new ReadOnlyCollection<string>(replacementOrderBy.ToList<string>());
			}
			if (thenBy != null)
			{
				if (this.orderBy == null)
				{
					throw new ArgumentException("You must call OrderBy before calling ThenBy.");
				}
				List<string> list = new List<string>(this.orderBy);
				list.AddRange(thenBy);
				this.orderBy = new ReadOnlyCollection<string>(list);
			}
			if (skip != null)
			{
				this.skip = (this.skip ?? 0) + skip;
			}
			if (limit != null)
			{
				this.limit = limit;
			}
			if (includes != null)
			{
				HashSet<string> hashSet = this.MergeIncludes(includes);
				this.includes = new ReadOnlyCollection<string>(hashSet.ToList<string>());
			}
		}

		// Token: 0x06000187 RID: 391 RVA: 0x00008EEC File Offset: 0x000070EC
		public ParseQuery(string className)
		{
			if (className == null)
			{
				throw new ArgumentNullException("className", "Must specify a ParseObject class name when creating a ParseQuery.");
			}
			this.className = className;
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00008F10 File Offset: 0x00007110
		private HashSet<string> MergeIncludes(IEnumerable<string> includes)
		{
			if (this.includes == null)
			{
				return new HashSet<string>(includes);
			}
			HashSet<string> hashSet = new HashSet<string>(this.includes);
			foreach (string text in includes)
			{
				hashSet.Add(text);
			}
			return hashSet;
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00008F78 File Offset: 0x00007178
		private IDictionary<string, object> MergeWhereClauses(IDictionary<string, object> where)
		{
			if (this.where == null)
			{
				return where;
			}
			Dictionary<string, object> dictionary = new Dictionary<string, object>(this.where);
			foreach (KeyValuePair<string, object> keyValuePair in where)
			{
				IDictionary<string, object> dictionary2 = keyValuePair.Value as IDictionary<string, object>;
				if (dictionary.ContainsKey(keyValuePair.Key))
				{
					IDictionary<string, object> dictionary3 = dictionary[keyValuePair.Key] as IDictionary<string, object>;
					if (dictionary3 == null || dictionary2 == null)
					{
						throw new ArgumentException("More than one where clause for the given key provided.");
					}
					Dictionary<string, object> dictionary4 = new Dictionary<string, object>(dictionary3);
					foreach (KeyValuePair<string, object> keyValuePair2 in dictionary2)
					{
						if (dictionary4.ContainsKey(keyValuePair2.Key))
						{
							throw new ArgumentException("More than one condition for the given key provided.");
						}
						dictionary4[keyValuePair2.Key] = keyValuePair2.Value;
					}
					dictionary[keyValuePair.Key] = dictionary4;
				}
				else
				{
					dictionary[keyValuePair.Key] = keyValuePair.Value;
				}
			}
			return dictionary;
		}

		// Token: 0x0600018A RID: 394 RVA: 0x000090B4 File Offset: 0x000072B4
		public ParseQuery<T> OrderBy(string key)
		{
			return new ParseQuery<T>(this, null, new List<string> { key }, null, null, null, null);
		}

		// Token: 0x0600018B RID: 395 RVA: 0x000090EC File Offset: 0x000072EC
		public ParseQuery<T> ThenByDescending(string key)
		{
			return new ParseQuery<T>(this, null, null, new List<string> { "-" + key }, null, null, null);
		}

		// Token: 0x0600018C RID: 396 RVA: 0x0000912C File Offset: 0x0000732C
		public ParseQuery<T> WhereEqualTo(string key, object value)
		{
			return new ParseQuery<T>(this, new Dictionary<string, object> { { key, value } }, null, null, null, null, null);
		}

		// Token: 0x0600018D RID: 397 RVA: 0x00009164 File Offset: 0x00007364
		public Task<IEnumerable<T>> FindAsync()
		{
			return this.FindAsync(CancellationToken.None);
		}

		// Token: 0x0600018E RID: 398 RVA: 0x00009174 File Offset: 0x00007374
		public Task<IEnumerable<T>> FindAsync(CancellationToken cancellationToken)
		{
			this.EnsureNotInstallationQuery();
			return ParseClient.RequestAsync("GET", string.Format("/1/classes/{0}?{1}", Uri.EscapeDataString(this.className), ParseClient.BuildQueryString(this.BuildParameters(false))), ParseUser.CurrentSessionToken, null, cancellationToken).OnSuccess<Tuple<HttpStatusCode, IDictionary<string, object>>, IEnumerable<T>>(delegate(Task<Tuple<HttpStatusCode, IDictionary<string, object>>> t)
			{
				IList<object> list = t.Result.Item2["results"] as IList<object>;
				return this.PrepareObjectsFromResults(list);
			});
		}

		// Token: 0x0600018F RID: 399 RVA: 0x000091CC File Offset: 0x000073CC
		private T CreateParseObjectFromQueryResult(IDictionary<string, object> data)
		{
			T t = (T)((object)ParseObject.CreateWithoutData(this.className, null));
			t.MergeAfterFetch(data);
			return t;
		}

		// Token: 0x06000190 RID: 400 RVA: 0x000091FC File Offset: 0x000073FC
		private IEnumerable<T> PrepareObjectsFromResults(IList<object> results)
		{
			IEnumerable<T> enumerable = results.Select<object, T>((object item) => this.CreateParseObjectFromQueryResult(item as IDictionary<string, object>));
			return new ReadOnlyCollection<T>(enumerable.ToList<T>());
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00009228 File Offset: 0x00007428
		internal IDictionary<string, object> BuildParameters(bool includeClassName = false)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			if (this.where != null)
			{
				dictionary["where"] = ParseClient.MaybeEncodeJSONObject(this.where, true);
			}
			if (this.orderBy != null)
			{
				dictionary["order"] = string.Join(",", this.orderBy.ToArray<string>());
			}
			if (this.skip != null)
			{
				dictionary["skip"] = this.skip.Value;
			}
			if (this.limit != null)
			{
				dictionary["limit"] = this.limit.Value;
			}
			if (this.includes != null)
			{
				dictionary["include"] = string.Join(",", this.includes.ToArray<string>());
			}
			if (includeClassName)
			{
				dictionary["className"] = this.className;
			}
			return dictionary;
		}

		// Token: 0x06000192 RID: 402 RVA: 0x0000931C File Offset: 0x0000751C
		private void EnsureNotInstallationQuery()
		{
			if (this.className.Equals("_Installation"))
			{
				throw new InvalidOperationException("Cannot directly query the Installation class.");
			}
		}

		// Token: 0x0400010C RID: 268
		private readonly string className;

		// Token: 0x0400010D RID: 269
		private readonly Dictionary<string, object> where;

		// Token: 0x0400010E RID: 270
		private readonly ReadOnlyCollection<string> orderBy;

		// Token: 0x0400010F RID: 271
		private readonly ReadOnlyCollection<string> includes;

		// Token: 0x04000110 RID: 272
		private readonly int? skip;

		// Token: 0x04000111 RID: 273
		private readonly int? limit;
	}
}
