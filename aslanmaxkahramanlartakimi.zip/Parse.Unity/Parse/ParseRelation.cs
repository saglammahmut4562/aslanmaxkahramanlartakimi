﻿using System;

namespace Parse
{
	// Token: 0x02000042 RID: 66
	public sealed class ParseRelation<T> : ParseRelationBase where T : ParseObject
	{
		// Token: 0x06000195 RID: 405 RVA: 0x0000937C File Offset: 0x0000757C
		internal ParseRelation(ParseObject parent, string key, string targetClassName)
			: base(parent, key, targetClassName)
		{
		}
	}
}
