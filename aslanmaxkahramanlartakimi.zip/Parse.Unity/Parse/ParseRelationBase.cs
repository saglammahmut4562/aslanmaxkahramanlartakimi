﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Reflection;

namespace Parse
{
	// Token: 0x02000043 RID: 67
	[EditorBrowsable(EditorBrowsableState.Never)]
	public abstract class ParseRelationBase
	{
		// Token: 0x06000196 RID: 406 RVA: 0x00009388 File Offset: 0x00007588
		internal ParseRelationBase(ParseObject parent, string key)
		{
			this.EnsureParentAndKey(parent, key);
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00009398 File Offset: 0x00007598
		internal ParseRelationBase(ParseObject parent, string key, string targetClassName)
			: this(parent, key)
		{
			this.targetClassName = targetClassName;
		}

		// Token: 0x06000198 RID: 408 RVA: 0x000093AC File Offset: 0x000075AC
		internal void EnsureParentAndKey(ParseObject parent, string key)
		{
			this.parent = this.parent ?? parent;
			this.key = this.key ?? key;
		}

		// Token: 0x06000199 RID: 409 RVA: 0x000093D0 File Offset: 0x000075D0
		internal IDictionary<string, object> ToJSON()
		{
			return new Dictionary<string, object>
			{
				{ "__type", "Relation" },
				{ "className", this.targetClassName }
			};
		}

		// Token: 0x0600019A RID: 410 RVA: 0x00009408 File Offset: 0x00007608
		internal static ParseRelationBase CreateRelation(ParseObject parent, string key, string targetClassName)
		{
			Type type = ParseObject.GetType(targetClassName);
			Expression<Func<ParseRelation<ParseObject>>> expression = () => ParseRelationBase.CreateRelation<ParseObject>(parent, key, targetClassName);
			MethodInfo methodInfo = ((MethodCallExpression)expression.Body).Method.GetGenericMethodDefinition().MakeGenericMethod(new Type[] { type });
			return (ParseRelationBase)methodInfo.Invoke(null, new object[] { parent, key, targetClassName });
		}

		// Token: 0x0600019B RID: 411 RVA: 0x00009510 File Offset: 0x00007710
		private static ParseRelation<T> CreateRelation<T>(ParseObject parent, string key, string targetClassName) where T : ParseObject
		{
			return new ParseRelation<T>(parent, key, targetClassName);
		}

		// Token: 0x04000115 RID: 277
		private ParseObject parent;

		// Token: 0x04000116 RID: 278
		private string key;

		// Token: 0x04000117 RID: 279
		private string targetClassName;
	}
}
