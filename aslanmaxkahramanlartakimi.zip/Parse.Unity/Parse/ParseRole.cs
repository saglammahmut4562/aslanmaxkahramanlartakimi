﻿using System;
using System.Text.RegularExpressions;

namespace Parse
{
	// Token: 0x02000045 RID: 69
	[ParseClassName("_Role")]
	public class ParseRole : ParseObject
	{
		// Token: 0x0600019F RID: 415 RVA: 0x00009540 File Offset: 0x00007740
		internal override void OnSettingValue(ref string key, ref object value)
		{
			base.OnSettingValue(ref key, ref value);
			if (key == "name")
			{
				if (base.ObjectId != null)
				{
					throw new InvalidOperationException("A role's name can only be set before it has been saved.");
				}
				if (!(value is string))
				{
					throw new ArgumentException("A role's name must be a string.", "value");
				}
				if (!ParseRole.namePattern.IsMatch((string)value))
				{
					throw new ArgumentException("A role's name can only contain alphanumeric characters, _, -, and spaces.", "value");
				}
			}
		}

		// Token: 0x0400011B RID: 283
		private static readonly Regex namePattern = new Regex("^[0-9a-zA-Z_\\- ]+$");
	}
}
