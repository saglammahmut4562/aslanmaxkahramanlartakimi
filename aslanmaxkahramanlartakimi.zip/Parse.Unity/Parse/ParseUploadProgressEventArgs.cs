﻿using System;
using System.Runtime.CompilerServices;

namespace Parse
{
	// Token: 0x02000046 RID: 70
	public class ParseUploadProgressEventArgs : EventArgs
	{
		// Token: 0x060001A0 RID: 416 RVA: 0x000095B4 File Offset: 0x000077B4
		internal ParseUploadProgressEventArgs()
		{
		}

		// Token: 0x1700003A RID: 58
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x000095BC File Offset: 0x000077BC
		internal double Progress
		{
			[CompilerGenerated]
			set
			{
				this.<Progress>k__BackingField = value;
			}
		}
	}
}
