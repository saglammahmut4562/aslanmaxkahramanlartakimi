﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Parse.Internal;

namespace Parse
{
	// Token: 0x02000047 RID: 71
	[ParseClassName("_User")]
	public class ParseUser : ParseObject
	{
		// Token: 0x060001A2 RID: 418 RVA: 0x000095C8 File Offset: 0x000077C8
		public ParseUser()
		{
			this.isCurrentUser = false;
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x000095F0 File Offset: 0x000077F0
		internal override void MergeMagicFields(IDictionary<string, object> data)
		{
			lock (this.mutex)
			{
				if (data.ContainsKey("sessionToken"))
				{
					this.sessionToken = data["sessionToken"] as string;
					data.Remove("sessionToken");
				}
				base.MergeMagicFields(data);
			}
		}

		// Token: 0x060001A5 RID: 421 RVA: 0x0000965C File Offset: 0x0000785C
		internal override void MergeAfterSave(IDictionary<string, object> result)
		{
			lock (this.mutex)
			{
				base.MergeAfterSave(result);
				this.SynchronizeAllAuthData();
				this.CleanupAuthData();
				this.serverData.Remove("password");
				base.RebuildEstimatedData();
			}
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x000096BC File Offset: 0x000078BC
		internal override void MergeAfterFetch(IDictionary<string, object> result)
		{
			lock (this.mutex)
			{
				base.MergeAfterFetch(result);
				this.SynchronizeAllAuthData();
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x000096FC File Offset: 0x000078FC
		internal string SessionToken
		{
			get
			{
				string text;
				lock (this.mutex)
				{
					text = this.sessionToken;
				}
				return text;
			}
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x00009738 File Offset: 0x00007938
		internal override Task SaveAsync(Task toAwait, CancellationToken cancellationToken)
		{
			Task task;
			lock (this.mutex)
			{
				if (base.ObjectId == null)
				{
					throw new InvalidOperationException("You must call SignUpAsync before calling SaveAsync.");
				}
				task = base.SaveAsync(toAwait, cancellationToken).OnSuccess(delegate(Task _)
				{
					if (ParseUser.CurrentUser == this)
					{
						ParseUser.SaveCurrentUser(this);
					}
				});
			}
			return task;
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x000097A0 File Offset: 0x000079A0
		internal static string CurrentSessionToken
		{
			get
			{
				string text;
				lock (ParseUser.currentUserMutex)
				{
					text = ((ParseUser.CurrentUser != null) ? ParseUser.CurrentUser.SessionToken : null);
				}
				return text;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060001AA RID: 426 RVA: 0x000097E8 File Offset: 0x000079E8
		public static ParseUser CurrentUser
		{
			get
			{
				ParseUser parseUser;
				lock (ParseUser.currentUserMutex)
				{
					if (ParseUser.currentUser != null)
					{
						parseUser = ParseUser.currentUser;
					}
					else if (ParseUser.currentUserMatchesDisk)
					{
						parseUser = ParseUser.currentUser;
					}
					else
					{
						object obj2;
						ParseClient.ApplicationSettings.TryGetValue("CurrentUser", out obj2);
						string text = obj2 as string;
						if (text != null)
						{
							IDictionary<string, object> dictionary = ParseClient.DeserializeJsonString(text);
							ParseUser parseUser2 = ParseObject.CreateWithoutData<ParseUser>(null);
							parseUser2.MergeAfterFetch(dictionary);
							ParseUser.currentUserMatchesDisk = true;
							ParseUser.SaveCurrentUser(parseUser2);
							parseUser = parseUser2;
						}
						else
						{
							ParseUser.SaveCurrentUser(null);
							parseUser = null;
						}
					}
				}
				return parseUser;
			}
		}

		// Token: 0x060001AB RID: 427 RVA: 0x0000988C File Offset: 0x00007A8C
		internal static void SaveCurrentUser(ParseUser user)
		{
			ParseUser parseUser = ParseUser.currentUser;
			if (parseUser != null)
			{
				Monitor.Enter(parseUser.mutex);
			}
			if (user != null)
			{
				Monitor.Enter(user.mutex);
			}
			try
			{
				lock (ParseUser.currentUserMutex)
				{
					if (ParseUser.currentUser != null && ParseUser.currentUser != user)
					{
						ParseUser.currentUser.isCurrentUser = false;
					}
					ParseUser.currentUser = user;
					if (ParseUser.currentUser != null)
					{
						ParseUser.currentUser.isCurrentUser = true;
						IDictionary<string, object> dictionary = ParseUser.currentUser.ServerDataToJSONObjectForSerialization();
						dictionary["sessionToken"] = ParseUser.currentUser.SessionToken;
						dictionary["objectId"] = ParseUser.currentUser.ObjectId;
						dictionary["createdAt"] = ParseUser.currentUser.CreatedAt.Value.ToString(ParseClient.dateFormatString);
						dictionary["updatedAt"] = ParseUser.currentUser.UpdatedAt.Value.ToString(ParseClient.dateFormatString);
						string text = ParseClient.SerializeJsonString(dictionary);
						ParseClient.ApplicationSettings["CurrentUser"] = text;
					}
					else
					{
						ParseClient.ApplicationSettings["CurrentUser"] = null;
					}
					ParseUser.currentUserMatchesDisk = true;
				}
			}
			finally
			{
				if (parseUser != null)
				{
					Monitor.Exit(parseUser.mutex);
				}
				if (user != null)
				{
					Monitor.Exit(user.mutex);
				}
			}
		}

		// Token: 0x060001AC RID: 428 RVA: 0x00009A14 File Offset: 0x00007C14
		internal static void ClearInMemoryUser()
		{
			lock (ParseUser.currentUserMutex)
			{
				ParseUser.currentUserMatchesDisk = false;
				ParseUser.currentUser = null;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060001AD RID: 429 RVA: 0x00009A54 File Offset: 0x00007C54
		internal bool IsCurrentUser
		{
			get
			{
				return this.isCurrentUser;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x060001AE RID: 430 RVA: 0x00009A5C File Offset: 0x00007C5C
		// (set) Token: 0x060001AF RID: 431 RVA: 0x00009A7C File Offset: 0x00007C7C
		internal IDictionary<string, IDictionary<string, object>> AuthData
		{
			get
			{
				IDictionary<string, IDictionary<string, object>> dictionary;
				if (base.TryGetValue<IDictionary<string, IDictionary<string, object>>>("authData", out dictionary))
				{
					return dictionary;
				}
				return null;
			}
			private set
			{
				this["authData"] = value;
			}
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x00009A8C File Offset: 0x00007C8C
		private static IParseAuthenticationProvider GetProvider(string providerName)
		{
			IParseAuthenticationProvider parseAuthenticationProvider;
			if (ParseUser.authProviders.TryGetValue(providerName, out parseAuthenticationProvider))
			{
				return parseAuthenticationProvider;
			}
			return null;
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x00009AAC File Offset: 0x00007CAC
		private void CleanupAuthData()
		{
			lock (this.mutex)
			{
				if (this.IsCurrentUser)
				{
					IDictionary<string, IDictionary<string, object>> authData = this.AuthData;
					if (authData != null)
					{
						foreach (KeyValuePair<string, IDictionary<string, object>> keyValuePair in new Dictionary<string, IDictionary<string, object>>(authData))
						{
							if (keyValuePair.Value == null)
							{
								authData.Remove(keyValuePair.Key);
							}
						}
					}
				}
			}
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x00009B48 File Offset: 0x00007D48
		private void SynchronizeAllAuthData()
		{
			lock (this.mutex)
			{
				IDictionary<string, IDictionary<string, object>> authData = this.AuthData;
				if (authData != null)
				{
					foreach (KeyValuePair<string, IDictionary<string, object>> keyValuePair in authData)
					{
						this.SynchronizeAuthData(ParseUser.GetProvider(keyValuePair.Key));
					}
				}
			}
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x00009BCC File Offset: 0x00007DCC
		private void SynchronizeAuthData(IParseAuthenticationProvider provider)
		{
			bool flag = false;
			lock (this.mutex)
			{
				IDictionary<string, IDictionary<string, object>> authData = this.AuthData;
				if (!this.IsCurrentUser || authData == null || provider == null)
				{
					return;
				}
				IDictionary<string, object> dictionary;
				if (authData.TryGetValue(provider.AuthType, out dictionary))
				{
					flag = provider.RestoreAuthentication(dictionary);
				}
			}
			if (!flag)
			{
				this.UnlinkFromAsync(provider.AuthType, CancellationToken.None);
			}
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x00009C48 File Offset: 0x00007E48
		internal Task LinkWithAsync(string authType, IDictionary<string, object> data, CancellationToken cancellationToken)
		{
			IDictionary<string, IDictionary<string, object>> dictionary = this.AuthData;
			if (dictionary == null)
			{
				dictionary = (this.AuthData = new Dictionary<string, IDictionary<string, object>>());
			}
			dictionary[authType] = data;
			return base.SaveAsync(cancellationToken);
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x00009C80 File Offset: 0x00007E80
		internal Task UnlinkFromAsync(string authType, CancellationToken cancellationToken)
		{
			return this.LinkWithAsync(authType, null, cancellationToken);
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x00009C8C File Offset: 0x00007E8C
		internal static void RegisterProvider(IParseAuthenticationProvider provider)
		{
			ParseUser.authProviders[provider.AuthType] = provider;
			ParseUser parseUser = ParseUser.CurrentUser;
			if (parseUser != null)
			{
				parseUser.SynchronizeAuthData(provider);
			}
		}

		// Token: 0x0400011D RID: 285
		private static readonly object currentUserMutex = new object();

		// Token: 0x0400011E RID: 286
		private static ParseUser currentUser;

		// Token: 0x0400011F RID: 287
		private static readonly IDictionary<string, IParseAuthenticationProvider> authProviders = new Dictionary<string, IParseAuthenticationProvider>();

		// Token: 0x04000120 RID: 288
		private static bool currentUserMatchesDisk;

		// Token: 0x04000121 RID: 289
		private string sessionToken;

		// Token: 0x04000122 RID: 290
		private bool isCurrentUser;
	}
}
