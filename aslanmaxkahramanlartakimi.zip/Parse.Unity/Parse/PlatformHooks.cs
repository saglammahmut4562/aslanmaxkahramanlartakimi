﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Parse.Internal;
using UnityEngine;

namespace Parse
{
	// Token: 0x02000048 RID: 72
	internal class PlatformHooks : IPlatformHooks
	{
		// Token: 0x17000040 RID: 64
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x00009CE4 File Offset: 0x00007EE4
		public string SDKName
		{
			get
			{
				return "unity";
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x060001BA RID: 442 RVA: 0x00009CEC File Offset: 0x00007EEC
		public IDictionary<string, object> ApplicationSettings
		{
			get
			{
				if (PlatformHooks.settings == null)
				{
					throw new InvalidOperationException("Parse must be initialized before making any calls.");
				}
				return PlatformHooks.settings;
			}
		}

		// Token: 0x060001BB RID: 443 RVA: 0x00009D08 File Offset: 0x00007F08
		private static WWW GenerateWWWInstance(string uri, byte[] bytes, Hashtable headerTable)
		{
			Type typeFromHandle = typeof(WWW);
			Type[] array = new Type[]
			{
				typeof(string),
				typeof(byte[]),
				typeof(Dictionary<string, string>)
			};
			ConstructorInfo constructorInfo = typeFromHandle.GetConstructor(array);
			if (constructorInfo != null)
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				foreach (object obj in headerTable)
				{
					DictionaryEntry dictionaryEntry = (DictionaryEntry)obj;
					dictionary[dictionaryEntry.Key as string] = dictionaryEntry.Value as string;
				}
				return (WWW)constructorInfo.Invoke(new object[] { uri, bytes, dictionary });
			}
			array = new Type[]
			{
				typeof(string),
				typeof(byte[]),
				typeof(Hashtable)
			};
			constructorInfo = typeFromHandle.GetConstructor(array);
			return (WWW)constructorInfo.Invoke(new object[] { uri, bytes, headerTable });
		}

		// Token: 0x060001BC RID: 444 RVA: 0x00009E58 File Offset: 0x00008058
		internal static void RegisterNetworkRequest(WWW www, Action<WWW> action)
		{
			PlatformHooks.RunOnMainThread(delegate
			{
				bool isDone = www.isDone;
				action(www);
				if (!isDone)
				{
					PlatformHooks.RegisterNetworkRequest(www, action);
				}
			});
		}

		// Token: 0x060001BD RID: 445 RVA: 0x00009E8C File Offset: 0x0000808C
		public Task<Tuple<HttpStatusCode, string>> RequestAsync(Uri uri, string method, IList<KeyValuePair<string, string>> headers, Stream data, string contentType, CancellationToken cancellationToken)
		{
			return this.RequestAsync(uri, method, headers, data, contentType, null, cancellationToken);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x00009EAC File Offset: 0x000080AC
		public Task<Tuple<HttpStatusCode, string>> UploadAsync(Uri uri, IList<KeyValuePair<string, string>> headers, Stream data, IProgress<ParseUploadProgressEventArgs> progress, CancellationToken cancellationToken)
		{
			return this.RequestAsync(uri, "POST", headers, data, null, progress, cancellationToken);
		}

		// Token: 0x060001BF RID: 447 RVA: 0x00009ECC File Offset: 0x000080CC
		public Task<Tuple<HttpStatusCode, string>> RequestAsync(Uri uri, string method, IList<KeyValuePair<string, string>> headers, Stream data, string contentType, IProgress<ParseUploadProgressEventArgs> progress, CancellationToken cancellationToken)
		{
			TaskCompletionSource<Tuple<HttpStatusCode, string>> tcs = new TaskCompletionSource<Tuple<HttpStatusCode, string>>();
			cancellationToken.Register(delegate
			{
				tcs.TrySetCanceled();
			});
			byte[] bytes = null;
			Hashtable headerTable = new Hashtable();
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in headers)
				{
					headerTable[keyValuePair.Key] = keyValuePair.Value;
				}
			}
			if (contentType == null && headerTable["Content-Type"] != null)
			{
				contentType = headerTable["Content-Type"].ToString();
			}
			IDisposable toDisposeAfterReading = null;
			Task task;
			if (!method.Equals("POST") || data == null)
			{
				bool noBody = data == null;
				data = data ?? new MemoryStream(Encoding.UTF8.GetBytes("{}"));
				StreamReader streamReader = new StreamReader(data);
				toDisposeAfterReading = streamReader;
				task = streamReader.ReadToEndAsync().OnSuccess<string>(delegate(Task<string> t)
				{
					IDictionary<string, object> dictionary = Json.Parse(t.Result) as IDictionary<string, object>;
					dictionary["_method"] = method;
					dictionary["_noBody"] = noBody;
					headerTable["Content-Type"] = "application/json";
					bytes = Encoding.UTF8.GetBytes(Json.Encode(dictionary));
				});
			}
			else
			{
				headerTable["Content-Type"] = contentType ?? "application/json";
				MemoryStream ms = new MemoryStream();
				toDisposeAfterReading = ms;
				task = data.CopyToAsync(ms).OnSuccess(delegate(Task _)
				{
					bytes = ms.ToArray();
				});
			}
			task.ContinueWith<Task>(delegate(Task t)
			{
				if (toDisposeAfterReading != null)
				{
					toDisposeAfterReading.Dispose();
				}
				return t;
			}).Unwrap().OnSuccess(delegate(Task _)
			{
				float oldProgress = 0f;
				PlatformHooks.RunOnMainThread(delegate
				{
					PlatformHooks.RegisterNetworkRequest(PlatformHooks.GenerateWWWInstance(uri.AbsoluteUri, bytes, headerTable), delegate(WWW www)
					{
						if (cancellationToken.IsCancellationRequested)
						{
							tcs.TrySetCanceled();
							return;
						}
						if (!www.isDone)
						{
							if (progress != null)
							{
								float progress2 = www.progress;
								if (oldProgress < progress2)
								{
									progress.Report(new ParseUploadProgressEventArgs
									{
										Progress = (double)progress2
									});
								}
								oldProgress = progress2;
							}
							return;
						}
						if (progress != null)
						{
							progress.Report(new ParseUploadProgressEventArgs
							{
								Progress = 1.0
							});
						}
						HttpStatusCode httpStatusCode = (string.IsNullOrEmpty(www.error) ? HttpStatusCode.Created : HttpStatusCode.BadRequest);
						if (!string.IsNullOrEmpty(www.error))
						{
							string text = string.Format("{{\"error\":\"{0}\"}}", www.error);
							tcs.TrySetResult(new Tuple<HttpStatusCode, string>(httpStatusCode, text));
							return;
						}
						tcs.TrySetResult(new Tuple<HttpStatusCode, string>(httpStatusCode, www.text));
					});
				});
			});
			return tcs.Task.ContinueWith<Task<object>>(delegate(Task<Tuple<HttpStatusCode, string>> t)
			{
				TaskCompletionSource<object> dispatchTcs = new TaskCompletionSource<object>();
				ThreadPool.QueueUserWorkItem(delegate(object _)
				{
					dispatchTcs.SetResult(null);
				});
				return dispatchTcs.Task;
			}).Unwrap<object>().ContinueWith<Task<Tuple<HttpStatusCode, string>>>((Task<object> _) => tcs.Task)
				.Unwrap<Tuple<HttpStatusCode, string>>();
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000A11C File Offset: 0x0000831C
		internal static void RunOnMainThread(Action action)
		{
			if (PlatformHooks.dispatchQueueLock.IsWriteLockHeld)
			{
				PlatformHooks.dispatchQueue.Enqueue(action);
				return;
			}
			PlatformHooks.dispatchQueueLock.EnterWriteLock();
			try
			{
				PlatformHooks.dispatchQueue.Enqueue(action);
			}
			finally
			{
				PlatformHooks.dispatchQueueLock.ExitWriteLock();
			}
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000A174 File Offset: 0x00008374
		internal static IEnumerator RunDispatcher()
		{
			for (;;)
			{
				PlatformHooks.dispatchQueueLock.EnterUpgradeableReadLock();
				try
				{
					int i = PlatformHooks.dispatchQueue.Count;
					if (i > 0)
					{
						PlatformHooks.dispatchQueueLock.EnterWriteLock();
						try
						{
							while (i > 0)
							{
								try
								{
									PlatformHooks.dispatchQueue.Dequeue()();
								}
								catch (Exception ex)
								{
									Debug.LogException(ex);
								}
								i--;
							}
						}
						finally
						{
							PlatformHooks.dispatchQueueLock.ExitWriteLock();
						}
					}
				}
				finally
				{
					PlatformHooks.dispatchQueueLock.ExitUpgradeableReadLock();
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0000A18C File Offset: 0x0000838C
		public void Initialize()
		{
			if (PlatformHooks.settingsPath == null)
			{
				PlatformHooks.settingsPath = Path.Combine(Application.persistentDataPath, "Parse.settings");
				PlatformHooks.isWebPlayer = Application.isWebPlayer;
				PlatformHooks.settings = PlatformHooks.SettingsWrapper.Wrapper;
				ParseFacebookUtils.Initialize();
			}
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x0000A1C4 File Offset: 0x000083C4
		public void ClearInMemoryInstallation()
		{
		}

		// Token: 0x04000123 RID: 291
		private static IDictionary<string, object> settings;

		// Token: 0x04000124 RID: 292
		private static string settingsPath;

		// Token: 0x04000125 RID: 293
		private static bool isWebPlayer;

		// Token: 0x04000126 RID: 294
		private static readonly ReaderWriterLockSlim dispatchQueueLock = new ReaderWriterLockSlim();

		// Token: 0x04000127 RID: 295
		private static readonly Queue<Action> dispatchQueue = new Queue<Action>();

		// Token: 0x02000050 RID: 80
		private class SettingsWrapper : IEnumerable<KeyValuePair<string, object>>, IDictionary<string, object>, ICollection<KeyValuePair<string, object>>, IEnumerable
		{
			// Token: 0x060001DB RID: 475 RVA: 0x0000A5F4 File Offset: 0x000087F4
			private SettingsWrapper()
			{
				string text = this.Load();
				if (string.IsNullOrEmpty(text))
				{
					this.data = new Dictionary<string, object>();
					this.Save();
					return;
				}
				this.data = ParseClient.DeserializeJsonString(text);
			}

			// Token: 0x17000044 RID: 68
			// (get) Token: 0x060001DC RID: 476 RVA: 0x0000A634 File Offset: 0x00008834
			public static PlatformHooks.SettingsWrapper Wrapper
			{
				get
				{
					PlatformHooks.SettingsWrapper.wrapper = PlatformHooks.SettingsWrapper.wrapper ?? new PlatformHooks.SettingsWrapper();
					return PlatformHooks.SettingsWrapper.wrapper;
				}
			}

			// Token: 0x060001DD RID: 477 RVA: 0x0000A650 File Offset: 0x00008850
			private string Load()
			{
				if (PlatformHooks.settingsPath == null)
				{
					throw new InvalidOperationException("Parse must be initialized before making any calls.");
				}
				string text;
				lock (this)
				{
					try
					{
						if (PlatformHooks.isWebPlayer)
						{
							text = PlayerPrefs.GetString("Parse.settings", null);
						}
						else
						{
							using (FileStream fileStream = new FileStream(PlatformHooks.settingsPath, FileMode.Open, FileAccess.Read))
							{
								StreamReader streamReader = new StreamReader(fileStream);
								text = streamReader.ReadToEnd();
							}
						}
					}
					catch (Exception)
					{
						text = null;
					}
				}
				return text;
			}

			// Token: 0x060001DE RID: 478 RVA: 0x0000A6E8 File Offset: 0x000088E8
			private void Save()
			{
				if (PlatformHooks.settingsPath == null)
				{
					throw new InvalidOperationException("Parse must be initialized before making any calls.");
				}
				lock (this)
				{
					if (PlatformHooks.isWebPlayer)
					{
						PlayerPrefs.SetString("Parse.settings", ParseClient.SerializeJsonString(this.data));
						PlayerPrefs.Save();
					}
					else
					{
						using (FileStream fileStream = new FileStream(PlatformHooks.settingsPath, FileMode.Create, FileAccess.Write))
						{
							using (StreamWriter streamWriter = new StreamWriter(fileStream))
							{
								streamWriter.Write(ParseClient.SerializeJsonString(this.data));
							}
						}
					}
				}
			}

			// Token: 0x060001DF RID: 479 RVA: 0x0000A7A0 File Offset: 0x000089A0
			public void Add(string key, object value)
			{
				this.data.Add(key, value);
				this.Save();
			}

			// Token: 0x060001E0 RID: 480 RVA: 0x0000A7B8 File Offset: 0x000089B8
			public bool ContainsKey(string key)
			{
				return this.data.ContainsKey(key);
			}

			// Token: 0x17000045 RID: 69
			// (get) Token: 0x060001E1 RID: 481 RVA: 0x0000A7C8 File Offset: 0x000089C8
			public ICollection<string> Keys
			{
				get
				{
					return this.data.Keys;
				}
			}

			// Token: 0x060001E2 RID: 482 RVA: 0x0000A7D8 File Offset: 0x000089D8
			public bool Remove(string key)
			{
				if (this.data.Remove(key))
				{
					this.Save();
					return true;
				}
				return false;
			}

			// Token: 0x060001E3 RID: 483 RVA: 0x0000A7F4 File Offset: 0x000089F4
			public bool TryGetValue(string key, out object value)
			{
				return this.data.TryGetValue(key, out value);
			}

			// Token: 0x17000046 RID: 70
			// (get) Token: 0x060001E4 RID: 484 RVA: 0x0000A804 File Offset: 0x00008A04
			public ICollection<object> Values
			{
				get
				{
					return this.data.Values;
				}
			}

			// Token: 0x17000047 RID: 71
			public object this[string key]
			{
				get
				{
					return this.data[key];
				}
				set
				{
					this.data[key] = value;
					this.Save();
				}
			}

			// Token: 0x060001E7 RID: 487 RVA: 0x0000A83C File Offset: 0x00008A3C
			public void Add(KeyValuePair<string, object> item)
			{
				this.data.Add(item);
				this.Save();
			}

			// Token: 0x060001E8 RID: 488 RVA: 0x0000A850 File Offset: 0x00008A50
			public void Clear()
			{
				this.data.Clear();
				this.Save();
			}

			// Token: 0x060001E9 RID: 489 RVA: 0x0000A864 File Offset: 0x00008A64
			public bool Contains(KeyValuePair<string, object> item)
			{
				return this.data.Contains(item);
			}

			// Token: 0x060001EA RID: 490 RVA: 0x0000A874 File Offset: 0x00008A74
			public void CopyTo(KeyValuePair<string, object>[] array, int arrayIndex)
			{
				this.data.CopyTo(array, arrayIndex);
			}

			// Token: 0x17000048 RID: 72
			// (get) Token: 0x060001EB RID: 491 RVA: 0x0000A884 File Offset: 0x00008A84
			public int Count
			{
				get
				{
					return this.data.Count;
				}
			}

			// Token: 0x17000049 RID: 73
			// (get) Token: 0x060001EC RID: 492 RVA: 0x0000A894 File Offset: 0x00008A94
			public bool IsReadOnly
			{
				get
				{
					return this.data.IsReadOnly;
				}
			}

			// Token: 0x060001ED RID: 493 RVA: 0x0000A8A4 File Offset: 0x00008AA4
			public bool Remove(KeyValuePair<string, object> item)
			{
				if (this.data.Remove(item))
				{
					this.Save();
					return true;
				}
				return false;
			}

			// Token: 0x060001EE RID: 494 RVA: 0x0000A8C0 File Offset: 0x00008AC0
			public IEnumerator<KeyValuePair<string, object>> GetEnumerator()
			{
				return this.data.GetEnumerator();
			}

			// Token: 0x060001EF RID: 495 RVA: 0x0000A8D0 File Offset: 0x00008AD0
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this.data.GetEnumerator();
			}

			// Token: 0x0400014B RID: 331
			private readonly IDictionary<string, object> data;

			// Token: 0x0400014C RID: 332
			private static PlatformHooks.SettingsWrapper wrapper;
		}
	}
}
