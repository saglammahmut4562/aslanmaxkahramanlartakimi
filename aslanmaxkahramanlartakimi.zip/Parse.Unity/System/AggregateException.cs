﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace System
{
	// Token: 0x02000051 RID: 81
	public class AggregateException : Exception
	{
		// Token: 0x060001F0 RID: 496 RVA: 0x0000A8E0 File Offset: 0x00008AE0
		public AggregateException(IEnumerable<Exception> innerExceptions)
		{
			this.InnerExceptions = new ReadOnlyCollection<Exception>(innerExceptions.ToList<Exception>());
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x060001F1 RID: 497 RVA: 0x0000A8FC File Offset: 0x00008AFC
		// (set) Token: 0x060001F2 RID: 498 RVA: 0x0000A904 File Offset: 0x00008B04
		public ReadOnlyCollection<Exception> InnerExceptions { get; private set; }

		// Token: 0x060001F3 RID: 499 RVA: 0x0000A910 File Offset: 0x00008B10
		public AggregateException Flatten()
		{
			List<Exception> list = new List<Exception>();
			foreach (Exception ex in this.InnerExceptions)
			{
				AggregateException ex2 = ex as AggregateException;
				if (ex2 != null)
				{
					list.AddRange(ex2.Flatten().InnerExceptions);
				}
				else
				{
					list.Add(ex);
				}
			}
			return new AggregateException(list);
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000A988 File Offset: 0x00008B88
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(base.ToString());
			foreach (Exception ex in this.InnerExceptions)
			{
				stringBuilder.AppendLine("\n-----------------");
				stringBuilder.AppendLine(ex.ToString());
			}
			return stringBuilder.ToString();
		}
	}
}
