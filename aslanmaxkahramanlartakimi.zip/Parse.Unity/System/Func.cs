﻿using System;

namespace System
{
	// Token: 0x02000052 RID: 82
	// (Invoke) Token: 0x060001F6 RID: 502
	internal delegate TResult Func<TArg1, TArg2, TArg3, TArg4, TArg5, TResult>(TArg1 arg1, TArg2 arg2, TArg3 arg3, TArg4 arg4, TArg5 arg5);
}
