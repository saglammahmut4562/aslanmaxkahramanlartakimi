﻿using System;

namespace System
{
	// Token: 0x02000053 RID: 83
	public interface IProgress<in T>
	{
		// Token: 0x060001F9 RID: 505
		void Report(T value);
	}
}
