﻿using System;
using System.Collections.Generic;

namespace System.Runtime.CompilerServices
{
	// Token: 0x02000054 RID: 84
	internal class ConditionalWeakTable<TKey, TValue> where TKey : class where TValue : class
	{
		// Token: 0x060001FA RID: 506 RVA: 0x0000A9FC File Offset: 0x00008BFC
		public ConditionalWeakTable()
		{
			this.data = new Dictionary<ConditionalWeakTable<TKey, TValue>.Reference, TValue>();
		}

		// Token: 0x060001FB RID: 507 RVA: 0x0000AA10 File Offset: 0x00008C10
		private void CleanUp()
		{
			foreach (ConditionalWeakTable<TKey, TValue>.Reference reference in new HashSet<ConditionalWeakTable<TKey, TValue>.Reference>(this.data.Keys))
			{
				if (!reference.WeakReference.IsAlive)
				{
					this.data.Remove(reference);
				}
			}
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0000AA80 File Offset: 0x00008C80
		public TValue GetValue(TKey key, ConditionalWeakTable<TKey, TValue>.CreateValueCallback createValueCallback)
		{
			this.CleanUp();
			ConditionalWeakTable<TKey, TValue>.Reference reference = new ConditionalWeakTable<TKey, TValue>.Reference(key);
			TValue tvalue;
			if (this.data.TryGetValue(reference, out tvalue))
			{
				return tvalue;
			}
			return this.data[reference] = createValueCallback(key);
		}

		// Token: 0x0400014E RID: 334
		private IDictionary<ConditionalWeakTable<TKey, TValue>.Reference, TValue> data;

		// Token: 0x02000055 RID: 85
		// (Invoke) Token: 0x060001FE RID: 510
		public delegate TValue CreateValueCallback(TKey key);

		// Token: 0x02000056 RID: 86
		private class Reference
		{
			// Token: 0x06000201 RID: 513 RVA: 0x0000AAC4 File Offset: 0x00008CC4
			public Reference(TKey obj)
			{
				this.hashCode = obj.GetHashCode();
				this.WeakReference = new WeakReference(obj);
			}

			// Token: 0x1700004B RID: 75
			// (get) Token: 0x06000202 RID: 514 RVA: 0x0000AAF0 File Offset: 0x00008CF0
			// (set) Token: 0x06000203 RID: 515 RVA: 0x0000AAF8 File Offset: 0x00008CF8
			public WeakReference WeakReference { get; private set; }

			// Token: 0x06000204 RID: 516 RVA: 0x0000AB04 File Offset: 0x00008D04
			public override int GetHashCode()
			{
				return this.hashCode;
			}

			// Token: 0x06000205 RID: 517 RVA: 0x0000AB0C File Offset: 0x00008D0C
			public override bool Equals(object obj)
			{
				ConditionalWeakTable<TKey, TValue>.Reference reference = obj as ConditionalWeakTable<TKey, TValue>.Reference;
				return reference != null && reference.GetHashCode() == this.GetHashCode() && object.ReferenceEquals(reference.WeakReference.Target, this.WeakReference.Target);
			}

			// Token: 0x0400014F RID: 335
			private int hashCode;
		}
	}
}
