﻿using System;

namespace System.Runtime.ExceptionServices
{
	// Token: 0x02000057 RID: 87
	internal class ExceptionDispatchInfo
	{
		// Token: 0x06000206 RID: 518 RVA: 0x0000AB50 File Offset: 0x00008D50
		private ExceptionDispatchInfo(Exception ex)
		{
			this.SourceException = ex;
		}

		// Token: 0x06000207 RID: 519 RVA: 0x0000AB60 File Offset: 0x00008D60
		public static ExceptionDispatchInfo Capture(Exception ex)
		{
			return new ExceptionDispatchInfo(ex);
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000208 RID: 520 RVA: 0x0000AB68 File Offset: 0x00008D68
		// (set) Token: 0x06000209 RID: 521 RVA: 0x0000AB70 File Offset: 0x00008D70
		public Exception SourceException { get; private set; }

		// Token: 0x0600020A RID: 522 RVA: 0x0000AB7C File Offset: 0x00008D7C
		public void Throw()
		{
			throw this.SourceException;
		}
	}
}
