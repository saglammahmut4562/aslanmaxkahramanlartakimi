﻿using System;

namespace System.Threading
{
	// Token: 0x02000058 RID: 88
	public struct CancellationToken
	{
		// Token: 0x1700004D RID: 77
		// (get) Token: 0x0600020B RID: 523 RVA: 0x0000AB84 File Offset: 0x00008D84
		public static CancellationToken None
		{
			get
			{
				return default(CancellationToken);
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x0600020C RID: 524 RVA: 0x0000AB9C File Offset: 0x00008D9C
		public bool IsCancellationRequested
		{
			get
			{
				return this.source != null && this.source.IsCancellationRequested;
			}
		}

		// Token: 0x0600020D RID: 525 RVA: 0x0000ABB4 File Offset: 0x00008DB4
		public CancellationTokenRegistration Register(Action callback)
		{
			if (this.source != null)
			{
				return this.source.Register(callback);
			}
			return default(CancellationTokenRegistration);
		}

		// Token: 0x0600020E RID: 526 RVA: 0x0000ABE0 File Offset: 0x00008DE0
		public void ThrowIfCancellationRequested()
		{
			if (this.IsCancellationRequested)
			{
				throw new OperationCanceledException();
			}
		}

		// Token: 0x04000152 RID: 338
		private CancellationTokenSource source;
	}
}
