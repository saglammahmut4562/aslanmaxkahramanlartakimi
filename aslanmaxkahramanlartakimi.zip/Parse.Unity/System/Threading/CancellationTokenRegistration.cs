﻿using System;

namespace System.Threading
{
	// Token: 0x02000059 RID: 89
	public struct CancellationTokenRegistration : IDisposable
	{
		// Token: 0x0600020F RID: 527 RVA: 0x0000ABF0 File Offset: 0x00008DF0
		internal CancellationTokenRegistration(CancellationTokenSource source, Action action)
		{
			this.source = source;
			this.action = action;
		}

		// Token: 0x06000210 RID: 528 RVA: 0x0000AC00 File Offset: 0x00008E00
		public void Dispose()
		{
			if (this.source != null && this.action != null)
			{
				this.source.Unregister(this.action);
				this.action = null;
				this.source = null;
			}
		}

		// Token: 0x04000153 RID: 339
		private Action action;

		// Token: 0x04000154 RID: 340
		private CancellationTokenSource source;
	}
}
