﻿using System;

namespace System.Threading
{
	// Token: 0x0200005A RID: 90
	public sealed class CancellationTokenSource
	{
		// Token: 0x06000211 RID: 529 RVA: 0x0000AC34 File Offset: 0x00008E34
		internal CancellationTokenRegistration Register(Action action)
		{
			CancellationTokenRegistration cancellationTokenRegistration;
			lock (this.mutex)
			{
				this.actions = (Action)Delegate.Combine(this.actions, action);
				cancellationTokenRegistration = new CancellationTokenRegistration(this, action);
			}
			return cancellationTokenRegistration;
		}

		// Token: 0x06000212 RID: 530 RVA: 0x0000AC88 File Offset: 0x00008E88
		internal void Unregister(Action action)
		{
			lock (this.mutex)
			{
				this.actions = (Action)Delegate.Remove(this.actions, action);
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000213 RID: 531 RVA: 0x0000ACD4 File Offset: 0x00008ED4
		internal bool IsCancellationRequested
		{
			get
			{
				bool flag;
				lock (this.mutex)
				{
					flag = this.isCancellationRequested;
				}
				return flag;
			}
		}

		// Token: 0x04000155 RID: 341
		private object mutex;

		// Token: 0x04000156 RID: 342
		private Action actions;

		// Token: 0x04000157 RID: 343
		private bool isCancellationRequested;
	}
}
