﻿using System;

namespace System.Threading.Tasks
{
	// Token: 0x02000060 RID: 96
	public sealed class Task<T> : Task
	{
		// Token: 0x06000232 RID: 562 RVA: 0x0000B274 File Offset: 0x00009474
		internal Task()
		{
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000233 RID: 563 RVA: 0x0000B27C File Offset: 0x0000947C
		public T Result
		{
			get
			{
				base.Wait();
				return this.result;
			}
		}

		// Token: 0x06000234 RID: 564 RVA: 0x0000B28C File Offset: 0x0000948C
		public Task ContinueWith(Action<Task<T>> continuation)
		{
			return base.ContinueWith(delegate(Task t)
			{
				continuation((Task<T>)t);
			});
		}

		// Token: 0x06000235 RID: 565 RVA: 0x0000B2B8 File Offset: 0x000094B8
		public Task<TResult> ContinueWith<TResult>(Func<Task<T>, TResult> continuation)
		{
			return base.ContinueWith<TResult>((Task t) => continuation((Task<T>)t));
		}

		// Token: 0x06000236 RID: 566 RVA: 0x0000B2E4 File Offset: 0x000094E4
		private void RunContinuations()
		{
			lock (this.mutex)
			{
				foreach (Action<Task> action in this.continuations)
				{
					action(this);
				}
				this.continuations = null;
			}
		}

		// Token: 0x06000237 RID: 567 RVA: 0x0000B35C File Offset: 0x0000955C
		internal bool TrySetResult(T result)
		{
			bool flag;
			lock (this.mutex)
			{
				if (this.isCompleted)
				{
					flag = false;
				}
				else
				{
					this.isCompleted = true;
					this.result = result;
					Monitor.PulseAll(this.mutex);
					this.RunContinuations();
					flag = true;
				}
			}
			return flag;
		}

		// Token: 0x06000238 RID: 568 RVA: 0x0000B3C0 File Offset: 0x000095C0
		internal bool TrySetCanceled()
		{
			bool flag;
			lock (this.mutex)
			{
				if (this.isCompleted)
				{
					flag = false;
				}
				else
				{
					this.isCompleted = true;
					this.isCanceled = true;
					Monitor.PulseAll(this.mutex);
					this.RunContinuations();
					flag = true;
				}
			}
			return flag;
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0000B424 File Offset: 0x00009624
		internal bool TrySetException(AggregateException exception)
		{
			bool flag;
			lock (this.mutex)
			{
				if (this.isCompleted)
				{
					flag = false;
				}
				else
				{
					this.isCompleted = true;
					this.exception = exception;
					Monitor.PulseAll(this.mutex);
					this.RunContinuations();
					flag = true;
				}
			}
			return flag;
		}

		// Token: 0x0400016C RID: 364
		private T result;
	}
}
