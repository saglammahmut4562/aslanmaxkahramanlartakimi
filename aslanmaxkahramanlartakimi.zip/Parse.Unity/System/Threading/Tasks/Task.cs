﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace System.Threading.Tasks
{
	// Token: 0x0200005B RID: 91
	public abstract class Task
	{
		// Token: 0x06000214 RID: 532 RVA: 0x0000AD10 File Offset: 0x00008F10
		internal Task()
		{
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000216 RID: 534 RVA: 0x0000AD88 File Offset: 0x00008F88
		internal static TaskFactory Factory
		{
			get
			{
				return new TaskFactory();
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000217 RID: 535 RVA: 0x0000AD90 File Offset: 0x00008F90
		public AggregateException Exception
		{
			get
			{
				AggregateException ex;
				lock (this.mutex)
				{
					ex = this.exception;
				}
				return ex;
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000218 RID: 536 RVA: 0x0000ADCC File Offset: 0x00008FCC
		public bool IsCanceled
		{
			get
			{
				bool flag;
				lock (this.mutex)
				{
					flag = this.isCanceled;
				}
				return flag;
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000219 RID: 537 RVA: 0x0000AE08 File Offset: 0x00009008
		public bool IsCompleted
		{
			get
			{
				bool flag;
				lock (this.mutex)
				{
					flag = this.isCompleted;
				}
				return flag;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x0600021A RID: 538 RVA: 0x0000AE44 File Offset: 0x00009044
		public bool IsFaulted
		{
			get
			{
				return this.Exception != null;
			}
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000AE54 File Offset: 0x00009054
		public void Wait()
		{
			lock (this.mutex)
			{
				if (!this.IsCompleted)
				{
					Monitor.Wait(this.mutex);
				}
				if (this.IsFaulted)
				{
					throw this.Exception;
				}
			}
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000AEAC File Offset: 0x000090AC
		public Task<T> ContinueWith<T>(Func<Task, T> continuation)
		{
			return this.ContinueWith<T>(continuation, CancellationToken.None);
		}

		// Token: 0x0600021D RID: 541 RVA: 0x0000AEBC File Offset: 0x000090BC
		public Task<T> ContinueWith<T>(Func<Task, T> continuation, CancellationToken cancellationToken)
		{
			bool flag = false;
			TaskCompletionSource<T> tcs = new TaskCompletionSource<T>();
			CancellationTokenRegistration cancellation = cancellationToken.Register(delegate
			{
				tcs.TrySetCanceled();
			});
			Action<Task> action = delegate(Task t)
			{
				Task.immediateExecutor(delegate
				{
					try
					{
						tcs.TrySetResult(continuation(t));
						cancellation.Dispose();
					}
					catch (Exception ex)
					{
						tcs.TrySetException(ex);
						cancellation.Dispose();
					}
				});
			};
			lock (this.mutex)
			{
				flag = this.IsCompleted;
				if (!flag)
				{
					this.continuations.Add(action);
				}
			}
			if (flag)
			{
				action(this);
			}
			return tcs.Task;
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0000AF5C File Offset: 0x0000915C
		public Task ContinueWith(Action<Task> continuation)
		{
			return this.ContinueWith(continuation, CancellationToken.None);
		}

		// Token: 0x0600021F RID: 543 RVA: 0x0000AF6C File Offset: 0x0000916C
		public Task ContinueWith(Action<Task> continuation, CancellationToken cancellationToken)
		{
			return this.ContinueWith<int>(delegate(Task t)
			{
				continuation(t);
				return 0;
			}, cancellationToken);
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0000AF9C File Offset: 0x0000919C
		public static Task WhenAll(params Task[] tasks)
		{
			return Task.WhenAll((IEnumerable<Task>)tasks);
		}

		// Token: 0x06000221 RID: 545 RVA: 0x0000AFAC File Offset: 0x000091AC
		public static Task WhenAll(IEnumerable<Task> tasks)
		{
			Task[] taskArr = tasks.ToArray<Task>();
			if (taskArr.Length == 0)
			{
				return Task.FromResult<int>(0);
			}
			TaskCompletionSource<int> tcs = new TaskCompletionSource<int>();
			Task.Factory.ContinueWhenAll(taskArr, delegate(Task[] _)
			{
				AggregateException[] array = (from t in taskArr
					where t.IsFaulted
					select t.Exception).ToArray<AggregateException>();
				if (array.Length > 0)
				{
					tcs.SetException(new AggregateException(array));
					return;
				}
				if (taskArr.Any<Task>((Task t) => t.IsCanceled))
				{
					tcs.SetCanceled();
					return;
				}
				tcs.SetResult(0);
			});
			return tcs.Task;
		}

		// Token: 0x06000222 RID: 546 RVA: 0x0000B010 File Offset: 0x00009210
		public static Task<T> FromResult<T>(T result)
		{
			TaskCompletionSource<T> taskCompletionSource = new TaskCompletionSource<T>();
			taskCompletionSource.SetResult(result);
			return taskCompletionSource.Task;
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000B030 File Offset: 0x00009230
		public static Task<T> Run<T>(Func<T> toRun)
		{
			return Task.Factory.StartNew<T>(toRun);
		}

		// Token: 0x04000158 RID: 344
		private static readonly ThreadLocal<int> executionDepth = new ThreadLocal<int>(() => 0);

		// Token: 0x04000159 RID: 345
		private static readonly Action<Action> immediateExecutor = delegate(Action a)
		{
			Task.executionDepth.Value++;
			try
			{
				if (Task.executionDepth.Value <= 10)
				{
					a();
				}
				else
				{
					Task.Factory.Scheduler.Post(a);
				}
			}
			finally
			{
				Task.executionDepth.Value--;
			}
		};

		// Token: 0x0400015A RID: 346
		internal readonly object mutex = new object();

		// Token: 0x0400015B RID: 347
		internal IList<Action<Task>> continuations = new List<Action<Task>>();

		// Token: 0x0400015C RID: 348
		internal AggregateException exception;

		// Token: 0x0400015D RID: 349
		internal bool isCanceled;

		// Token: 0x0400015E RID: 350
		internal bool isCompleted;
	}
}
