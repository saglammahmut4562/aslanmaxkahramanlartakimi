﻿using System;

namespace System.Threading.Tasks
{
	// Token: 0x02000063 RID: 99
	public class TaskCompletionSource<T>
	{
		// Token: 0x0600023E RID: 574 RVA: 0x0000B4C0 File Offset: 0x000096C0
		public TaskCompletionSource()
		{
			this.Task = new Task<T>();
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600023F RID: 575 RVA: 0x0000B4D4 File Offset: 0x000096D4
		// (set) Token: 0x06000240 RID: 576 RVA: 0x0000B4DC File Offset: 0x000096DC
		public Task<T> Task { get; private set; }

		// Token: 0x06000241 RID: 577 RVA: 0x0000B4E8 File Offset: 0x000096E8
		public bool TrySetResult(T result)
		{
			return this.Task.TrySetResult(result);
		}

		// Token: 0x06000242 RID: 578 RVA: 0x0000B4F8 File Offset: 0x000096F8
		public bool TrySetException(AggregateException exception)
		{
			return this.Task.TrySetException(exception);
		}

		// Token: 0x06000243 RID: 579 RVA: 0x0000B508 File Offset: 0x00009708
		public bool TrySetException(Exception exception)
		{
			AggregateException ex = exception as AggregateException;
			if (ex != null)
			{
				return this.Task.TrySetException(ex);
			}
			return this.Task.TrySetException(new AggregateException(new Exception[] { exception }).Flatten());
		}

		// Token: 0x06000244 RID: 580 RVA: 0x0000B550 File Offset: 0x00009750
		public bool TrySetCanceled()
		{
			return this.Task.TrySetCanceled();
		}

		// Token: 0x06000245 RID: 581 RVA: 0x0000B560 File Offset: 0x00009760
		public void SetResult(T result)
		{
			if (!this.TrySetResult(result))
			{
				throw new InvalidOperationException("Cannot set the result of a completed task.");
			}
		}

		// Token: 0x06000246 RID: 582 RVA: 0x0000B578 File Offset: 0x00009778
		public void SetException(AggregateException exception)
		{
			if (!this.TrySetException(exception))
			{
				throw new InvalidOperationException("Cannot set the exception of a completed task.");
			}
		}

		// Token: 0x06000247 RID: 583 RVA: 0x0000B590 File Offset: 0x00009790
		public void SetException(Exception exception)
		{
			if (!this.TrySetException(exception))
			{
				throw new InvalidOperationException("Cannot set the exception of a completed task.");
			}
		}

		// Token: 0x06000248 RID: 584 RVA: 0x0000B5A8 File Offset: 0x000097A8
		public void SetCanceled()
		{
			if (!this.TrySetCanceled())
			{
				throw new InvalidOperationException("Cannot cancel a completed task.");
			}
		}
	}
}
