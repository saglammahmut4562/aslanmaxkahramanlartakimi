﻿using System;

namespace System.Threading.Tasks
{
	// Token: 0x02000064 RID: 100
	internal enum TaskContinuationOptions
	{
		// Token: 0x04000171 RID: 369
		None,
		// Token: 0x04000172 RID: 370
		ExecuteSynchronously = 524288
	}
}
