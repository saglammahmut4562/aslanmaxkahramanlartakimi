﻿using System;

namespace System.Threading.Tasks
{
	// Token: 0x02000065 RID: 101
	internal enum TaskCreationOptions
	{
		// Token: 0x04000174 RID: 372
		None
	}
}
