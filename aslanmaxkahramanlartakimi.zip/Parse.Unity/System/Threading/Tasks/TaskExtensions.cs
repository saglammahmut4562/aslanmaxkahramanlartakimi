﻿using System;

namespace System.Threading.Tasks
{
	// Token: 0x02000066 RID: 102
	public static class TaskExtensions
	{
		// Token: 0x06000249 RID: 585 RVA: 0x0000B5C0 File Offset: 0x000097C0
		public static Task Unwrap(this Task<Task> task)
		{
			TaskCompletionSource<int> tcs = new TaskCompletionSource<int>();
			task.ContinueWith(delegate(Task<Task> t)
			{
				if (t.IsFaulted)
				{
					tcs.TrySetException(t.Exception);
					return;
				}
				if (t.IsCanceled)
				{
					tcs.TrySetCanceled();
					return;
				}
				task.Result.ContinueWith(delegate(Task inner)
				{
					if (inner.IsFaulted)
					{
						tcs.TrySetException(inner.Exception);
						return;
					}
					if (inner.IsCanceled)
					{
						tcs.TrySetCanceled();
						return;
					}
					tcs.TrySetResult(0);
				});
			});
			return tcs.Task;
		}

		// Token: 0x0600024A RID: 586 RVA: 0x0000B608 File Offset: 0x00009808
		public static Task<T> Unwrap<T>(this Task<Task<T>> task)
		{
			TaskCompletionSource<T> tcs = new TaskCompletionSource<T>();
			task.ContinueWith(delegate(Task<Task<T>> t)
			{
				if (t.IsFaulted)
				{
					tcs.TrySetException(t.Exception);
					return;
				}
				if (t.IsCanceled)
				{
					tcs.TrySetCanceled();
					return;
				}
				t.Result.ContinueWith(delegate(Task<T> inner)
				{
					if (inner.IsFaulted)
					{
						tcs.TrySetException(inner.Exception);
						return;
					}
					if (inner.IsCanceled)
					{
						tcs.TrySetCanceled();
						return;
					}
					tcs.TrySetResult(inner.Result);
				});
			});
			return tcs.Task;
		}
	}
}
