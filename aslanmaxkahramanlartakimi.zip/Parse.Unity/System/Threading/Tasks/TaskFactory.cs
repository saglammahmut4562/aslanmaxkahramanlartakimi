﻿using System;

namespace System.Threading.Tasks
{
	// Token: 0x02000069 RID: 105
	internal class TaskFactory
	{
		// Token: 0x06000251 RID: 593 RVA: 0x0000B7A4 File Offset: 0x000099A4
		internal TaskFactory(TaskScheduler scheduler, CancellationToken cancellationToken)
		{
			this.scheduler = scheduler;
			this.cancellationToken = cancellationToken;
		}

		// Token: 0x06000252 RID: 594 RVA: 0x0000B7BC File Offset: 0x000099BC
		public TaskFactory()
			: this(TaskScheduler.FromCurrentSynchronizationContext(), CancellationToken.None)
		{
		}

		// Token: 0x06000253 RID: 595 RVA: 0x0000B7D0 File Offset: 0x000099D0
		public TaskFactory(CancellationToken cancellationToken, TaskCreationOptions creationOptions, TaskContinuationOptions continuationOptions, TaskScheduler scheduler)
			: this(scheduler, cancellationToken)
		{
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000254 RID: 596 RVA: 0x0000B7DC File Offset: 0x000099DC
		public TaskScheduler Scheduler
		{
			get
			{
				return this.scheduler;
			}
		}

		// Token: 0x06000255 RID: 597 RVA: 0x0000B7E4 File Offset: 0x000099E4
		public Task<T> StartNew<T>(Func<T> func)
		{
			TaskCompletionSource<T> tcs = new TaskCompletionSource<T>();
			this.scheduler.Post(delegate
			{
				try
				{
					tcs.SetResult(func());
				}
				catch (Exception ex)
				{
					tcs.SetException(ex);
				}
			});
			return tcs.Task;
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0000B82C File Offset: 0x00009A2C
		public Task FromAsync<TArg1, TArg2, TArg3>(Func<TArg1, TArg2, TArg3, AsyncCallback, object, IAsyncResult> beginMethod, Action<IAsyncResult> endMethod, TArg1 arg1, TArg2 arg2, TArg3 arg3, object state)
		{
			return this.FromAsync((AsyncCallback callback, object _) => beginMethod(arg1, arg2, arg3, callback, state), endMethod, state);
		}

		// Token: 0x06000257 RID: 599 RVA: 0x0000B880 File Offset: 0x00009A80
		public Task<TResult> FromAsync<TArg1, TArg2, TArg3, TResult>(Func<TArg1, TArg2, TArg3, AsyncCallback, object, IAsyncResult> beginMethod, Func<IAsyncResult, TResult> endMethod, TArg1 arg1, TArg2 arg2, TArg3 arg3, object state)
		{
			return this.FromAsync<TResult>((AsyncCallback callback, object _) => beginMethod(arg1, arg2, arg3, callback, state), endMethod, state);
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0000B8D4 File Offset: 0x00009AD4
		public Task FromAsync(Func<AsyncCallback, object, IAsyncResult> beginMethod, Action<IAsyncResult> endMethod, object state)
		{
			return this.FromAsync<int>(beginMethod, delegate(IAsyncResult result)
			{
				endMethod(result);
				return 0;
			}, state);
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0000B904 File Offset: 0x00009B04
		public Task<TResult> FromAsync<TResult>(Func<AsyncCallback, object, IAsyncResult> beginMethod, Func<IAsyncResult, TResult> endMethod, object state)
		{
			TaskCompletionSource<TResult> tcs = new TaskCompletionSource<TResult>();
			CancellationTokenRegistration cancellation = this.cancellationToken.Register(delegate
			{
				tcs.TrySetCanceled();
			});
			if (this.cancellationToken.IsCancellationRequested)
			{
				tcs.TrySetCanceled();
				cancellation.Dispose();
				return tcs.Task;
			}
			try
			{
				beginMethod(delegate(IAsyncResult result)
				{
					try
					{
						TResult tresult = endMethod(result);
						tcs.TrySetResult(tresult);
						cancellation.Dispose();
					}
					catch (Exception ex2)
					{
						tcs.TrySetException(ex2);
						cancellation.Dispose();
					}
				}, state);
			}
			catch (Exception ex)
			{
				tcs.TrySetException(ex);
				cancellation.Dispose();
			}
			return tcs.Task;
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0000B9D0 File Offset: 0x00009BD0
		public Task ContinueWhenAll(Task[] tasks, Action<Task[]> continuationAction)
		{
			int remaining = tasks.Length;
			TaskCompletionSource<Task[]> tcs = new TaskCompletionSource<Task[]>();
			if (remaining == 0)
			{
				tcs.TrySetResult(tasks);
			}
			foreach (Task task in tasks)
			{
				task.ContinueWith(delegate(Task _)
				{
					if (Interlocked.Decrement(ref remaining) == 0)
					{
						tcs.TrySetResult(tasks);
					}
				});
			}
			return tcs.Task.ContinueWith(delegate(Task<Task[]> t)
			{
				continuationAction(t.Result);
			});
		}

		// Token: 0x04000178 RID: 376
		private readonly TaskScheduler scheduler;

		// Token: 0x04000179 RID: 377
		private readonly CancellationToken cancellationToken;
	}
}
