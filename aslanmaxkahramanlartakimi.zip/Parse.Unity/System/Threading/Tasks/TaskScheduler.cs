﻿using System;

namespace System.Threading.Tasks
{
	// Token: 0x02000070 RID: 112
	internal class TaskScheduler
	{
		// Token: 0x06000269 RID: 617 RVA: 0x0000BBF4 File Offset: 0x00009DF4
		public TaskScheduler(SynchronizationContext context)
		{
			this.context = context ?? TaskScheduler.defaultContext;
		}

		// Token: 0x0600026B RID: 619 RVA: 0x0000BC18 File Offset: 0x00009E18
		public void Post(Action action)
		{
			this.context.Post(delegate(object o)
			{
				action();
			}, null);
		}

		// Token: 0x0600026C RID: 620 RVA: 0x0000BC4C File Offset: 0x00009E4C
		public static TaskScheduler FromCurrentSynchronizationContext()
		{
			return new TaskScheduler(SynchronizationContext.Current);
		}

		// Token: 0x0400018E RID: 398
		private static SynchronizationContext defaultContext = new SynchronizationContext();

		// Token: 0x0400018F RID: 399
		private SynchronizationContext context;
	}
}
