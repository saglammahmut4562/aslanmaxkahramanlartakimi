﻿using System;
using System.Collections.Generic;

namespace System.Threading
{
	// Token: 0x02000072 RID: 114
	internal class ThreadLocal<T> : IDisposable
	{
		// Token: 0x0600026F RID: 623 RVA: 0x0000BC70 File Offset: 0x00009E70
		public ThreadLocal(Func<T> valueFactory)
		{
			this.valueFactory = valueFactory;
			this.id = Interlocked.Increment(ref ThreadLocal<T>.lastId);
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000271 RID: 625 RVA: 0x0000BCA4 File Offset: 0x00009EA4
		private static IDictionary<long, T> ThreadLocalData
		{
			get
			{
				if (ThreadLocal<T>.threadLocalData == null)
				{
					ThreadLocal<T>.threadLocalData = new Dictionary<long, T>();
					lock (ThreadLocal<T>.allDataDictionaries)
					{
						ThreadLocal<T>.allDataDictionaries.Add(new WeakReference(ThreadLocal<T>.threadLocalData));
					}
				}
				return ThreadLocal<T>.threadLocalData;
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000272 RID: 626 RVA: 0x0000BD00 File Offset: 0x00009F00
		// (set) Token: 0x06000273 RID: 627 RVA: 0x0000BD48 File Offset: 0x00009F48
		public T Value
		{
			get
			{
				this.CheckDisposed();
				T t;
				if (ThreadLocal<T>.ThreadLocalData.TryGetValue(this.id, out t))
				{
					return t;
				}
				return ThreadLocal<T>.ThreadLocalData[this.id] = this.valueFactory();
			}
			set
			{
				this.CheckDisposed();
				ThreadLocal<T>.ThreadLocalData[this.id] = value;
			}
		}

		// Token: 0x06000274 RID: 628 RVA: 0x0000BD64 File Offset: 0x00009F64
		~ThreadLocal()
		{
			if (!this.disposed)
			{
				this.Dispose();
			}
		}

		// Token: 0x06000275 RID: 629 RVA: 0x0000BD98 File Offset: 0x00009F98
		private void CheckDisposed()
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("ThreadLocal has been disposed.");
			}
		}

		// Token: 0x06000276 RID: 630 RVA: 0x0000BDB0 File Offset: 0x00009FB0
		public void Dispose()
		{
			lock (ThreadLocal<T>.allDataDictionaries)
			{
				for (int i = 0; i < ThreadLocal<T>.allDataDictionaries.Count; i++)
				{
					IDictionary<object, T> dictionary = ThreadLocal<T>.allDataDictionaries[i].Target as IDictionary<object, T>;
					if (dictionary == null)
					{
						ThreadLocal<T>.allDataDictionaries.RemoveAt(i);
						i--;
					}
					else
					{
						dictionary.Remove(this.id);
					}
				}
			}
			this.disposed = true;
		}

		// Token: 0x04000191 RID: 401
		private static long lastId = -1L;

		// Token: 0x04000192 RID: 402
		[ThreadStatic]
		private static IDictionary<long, T> threadLocalData;

		// Token: 0x04000193 RID: 403
		private static IList<WeakReference> allDataDictionaries = new List<WeakReference>();

		// Token: 0x04000194 RID: 404
		private bool disposed;

		// Token: 0x04000195 RID: 405
		private readonly long id;

		// Token: 0x04000196 RID: 406
		private readonly Func<T> valueFactory;
	}
}
