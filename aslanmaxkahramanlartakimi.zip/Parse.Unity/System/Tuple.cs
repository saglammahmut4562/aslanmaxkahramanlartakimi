﻿using System;

namespace System
{
	// Token: 0x02000073 RID: 115
	internal class Tuple<T1, T2>
	{
		// Token: 0x06000277 RID: 631 RVA: 0x0000BE3C File Offset: 0x0000A03C
		public Tuple(T1 item1, T2 item2)
		{
			this.Item1 = item1;
			this.Item2 = item2;
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000278 RID: 632 RVA: 0x0000BE54 File Offset: 0x0000A054
		// (set) Token: 0x06000279 RID: 633 RVA: 0x0000BE5C File Offset: 0x0000A05C
		public T1 Item1 { get; private set; }

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x0600027A RID: 634 RVA: 0x0000BE68 File Offset: 0x0000A068
		// (set) Token: 0x0600027B RID: 635 RVA: 0x0000BE70 File Offset: 0x0000A070
		public T2 Item2 { get; private set; }

		// Token: 0x0600027C RID: 636 RVA: 0x0000BE7C File Offset: 0x0000A07C
		public override bool Equals(object obj)
		{
			Tuple<T1, T2> tuple = obj as Tuple<T1, T2>;
			return tuple != null && object.Equals(this.Item1, tuple.Item1) && object.Equals(this.Item2, tuple.Item2);
		}

		// Token: 0x0600027D RID: 637 RVA: 0x0000BED0 File Offset: 0x0000A0D0
		public override int GetHashCode()
		{
			int num;
			if (this.Item1 == null)
			{
				num = 0;
			}
			else
			{
				T1 item = this.Item1;
				num = item.GetHashCode();
			}
			int num2 = num;
			int num3;
			if (this.Item2 == null)
			{
				num3 = 0;
			}
			else
			{
				T2 item2 = this.Item2;
				num3 = item2.GetHashCode();
			}
			int num4 = num3;
			return num2 ^ num4;
		}
	}
}
