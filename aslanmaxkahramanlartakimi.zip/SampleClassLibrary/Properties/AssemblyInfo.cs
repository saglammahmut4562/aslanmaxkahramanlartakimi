﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyTitle("SampleClassLibrary")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
[assembly: Guid("178cf652-c764-49c2-bd8f-329fd5b831b2")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("SampleClassLibrary")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright ©  2013")]
