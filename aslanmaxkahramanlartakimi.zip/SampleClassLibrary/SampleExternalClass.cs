﻿using System;
using System.Collections.Generic;

namespace SampleClassLibrary
{
	// Token: 0x02000002 RID: 2
	public class SampleExternalClass
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public SampleExternalClass()
		{
			this.SampleDictionary = new Dictionary<int, string>();
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000002 RID: 2 RVA: 0x00002064 File Offset: 0x00000264
		// (set) Token: 0x06000003 RID: 3 RVA: 0x0000206C File Offset: 0x0000026C
		public string SampleString { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000004 RID: 4 RVA: 0x00002078 File Offset: 0x00000278
		// (set) Token: 0x06000005 RID: 5 RVA: 0x00002080 File Offset: 0x00000280
		public Dictionary<int, string> SampleDictionary { get; set; }
	}
}
