﻿using System;

namespace Mono.Math.Prime
{
	// Token: 0x02000047 RID: 71
	internal enum ConfidenceFactor
	{
		// Token: 0x04000112 RID: 274
		ExtraLow,
		// Token: 0x04000113 RID: 275
		Low,
		// Token: 0x04000114 RID: 276
		Medium,
		// Token: 0x04000115 RID: 277
		High,
		// Token: 0x04000116 RID: 278
		ExtraHigh,
		// Token: 0x04000117 RID: 279
		Provable
	}
}
