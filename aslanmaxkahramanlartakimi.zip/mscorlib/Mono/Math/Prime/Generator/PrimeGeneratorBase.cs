﻿using System;

namespace Mono.Math.Prime.Generator
{
	// Token: 0x02000048 RID: 72
	internal abstract class PrimeGeneratorBase
	{
		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000136 RID: 310 RVA: 0x0000B010 File Offset: 0x00009210
		public virtual ConfidenceFactor Confidence
		{
			get
			{
				return ConfidenceFactor.Medium;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000137 RID: 311 RVA: 0x0000B014 File Offset: 0x00009214
		public virtual PrimalityTest PrimalityTest
		{
			get
			{
				return new PrimalityTest(PrimalityTests.RabinMillerTest);
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000138 RID: 312 RVA: 0x0000B024 File Offset: 0x00009224
		public virtual int TrialDivisionBounds
		{
			get
			{
				return 4000;
			}
		}

		// Token: 0x06000139 RID: 313
		public abstract BigInteger GenerateNewPrime(int bits);
	}
}
