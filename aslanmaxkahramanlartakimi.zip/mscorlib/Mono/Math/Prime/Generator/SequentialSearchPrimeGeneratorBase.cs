﻿using System;

namespace Mono.Math.Prime.Generator
{
	// Token: 0x02000049 RID: 73
	internal class SequentialSearchPrimeGeneratorBase : PrimeGeneratorBase
	{
		// Token: 0x0600013B RID: 315 RVA: 0x0000B034 File Offset: 0x00009234
		protected virtual BigInteger GenerateSearchBase(int bits, object context)
		{
			BigInteger bigInteger = BigInteger.GenerateRandom(bits);
			bigInteger.SetBit(0U);
			return bigInteger;
		}

		// Token: 0x0600013C RID: 316 RVA: 0x0000B050 File Offset: 0x00009250
		public override BigInteger GenerateNewPrime(int bits)
		{
			return this.GenerateNewPrime(bits, null);
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0000B05C File Offset: 0x0000925C
		public virtual BigInteger GenerateNewPrime(int bits, object context)
		{
			BigInteger bigInteger = this.GenerateSearchBase(bits, context);
			uint num = bigInteger % 3234846615U;
			int trialDivisionBounds = this.TrialDivisionBounds;
			uint[] smallPrimes = BigInteger.smallPrimes;
			for (;;)
			{
				if (num % 3U != 0U)
				{
					if (num % 5U != 0U)
					{
						if (num % 7U != 0U)
						{
							if (num % 11U != 0U)
							{
								if (num % 13U != 0U)
								{
									if (num % 17U != 0U)
									{
										if (num % 19U != 0U)
										{
											if (num % 23U != 0U)
											{
												if (num % 29U != 0U)
												{
													int num2 = 10;
													while (num2 < smallPrimes.Length && (ulong)smallPrimes[num2] <= (ulong)((long)trialDivisionBounds))
													{
														if (bigInteger % smallPrimes[num2] == 0U)
														{
															goto IL_0105;
														}
														num2++;
													}
													if (this.IsPrimeAcceptable(bigInteger, context))
													{
														if (this.PrimalityTest(bigInteger, this.Confidence))
														{
															break;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				IL_0105:
				num += 2U;
				if (num >= 3234846615U)
				{
					num -= 3234846615U;
				}
				bigInteger.Incr2();
			}
			return bigInteger;
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0000B190 File Offset: 0x00009390
		protected virtual bool IsPrimeAcceptable(BigInteger bi, object context)
		{
			return true;
		}
	}
}
