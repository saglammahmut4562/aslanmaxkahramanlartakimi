﻿using System;

namespace Mono.Math.Prime
{
	// Token: 0x0200004A RID: 74
	// (Invoke) Token: 0x06000140 RID: 320
	internal delegate bool PrimalityTest(BigInteger bi, ConfidenceFactor confidence);
}
