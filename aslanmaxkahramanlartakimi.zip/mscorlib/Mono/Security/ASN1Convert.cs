﻿using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace Mono.Security
{
	// Token: 0x0200004D RID: 77
	internal static class ASN1Convert
	{
		// Token: 0x06000158 RID: 344 RVA: 0x0000BBC0 File Offset: 0x00009DC0
		public static ASN1 FromInt32(int value)
		{
			byte[] bytes = BitConverterLE.GetBytes(value);
			Array.Reverse(bytes);
			int num = 0;
			while (num < bytes.Length && bytes[num] == 0)
			{
				num++;
			}
			ASN1 asn = new ASN1(2);
			int num2 = num;
			if (num2 != 0)
			{
				if (num2 != 4)
				{
					byte[] array = new byte[4 - num];
					Buffer.BlockCopy(bytes, num, array, 0, array.Length);
					asn.Value = array;
				}
				else
				{
					asn.Value = new byte[1];
				}
			}
			else
			{
				asn.Value = bytes;
			}
			return asn;
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0000BC54 File Offset: 0x00009E54
		public static ASN1 FromOid(string oid)
		{
			if (oid == null)
			{
				throw new ArgumentNullException("oid");
			}
			return new ASN1(CryptoConfig.EncodeOID(oid));
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0000BC74 File Offset: 0x00009E74
		public static int ToInt32(ASN1 asn1)
		{
			if (asn1 == null)
			{
				throw new ArgumentNullException("asn1");
			}
			if (asn1.Tag != 2)
			{
				throw new FormatException("Only integer can be converted");
			}
			int num = 0;
			for (int i = 0; i < asn1.Value.Length; i++)
			{
				num = (num << 8) + (int)asn1.Value[i];
			}
			return num;
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0000BCD4 File Offset: 0x00009ED4
		public static string ToOid(ASN1 asn1)
		{
			if (asn1 == null)
			{
				throw new ArgumentNullException("asn1");
			}
			byte[] value = asn1.Value;
			StringBuilder stringBuilder = new StringBuilder();
			byte b = value[0] / 40;
			byte b2 = value[0] % 40;
			if (b > 2)
			{
				b2 += (b - 2) * 40;
				b = 2;
			}
			stringBuilder.Append(b.ToString(CultureInfo.InvariantCulture));
			stringBuilder.Append(".");
			stringBuilder.Append(b2.ToString(CultureInfo.InvariantCulture));
			ulong num = 0UL;
			b = 1;
			while ((int)b < value.Length)
			{
				num = (num << 7) | (ulong)(value[(int)b] & 127);
				if ((value[(int)b] & 128) != 128)
				{
					stringBuilder.Append(".");
					stringBuilder.Append(num.ToString(CultureInfo.InvariantCulture));
					num = 0UL;
				}
				b += 1;
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600015C RID: 348 RVA: 0x0000BDBC File Offset: 0x00009FBC
		public static DateTime ToDateTime(ASN1 time)
		{
			if (time == null)
			{
				throw new ArgumentNullException("time");
			}
			string text = Encoding.ASCII.GetString(time.Value);
			string text2 = null;
			switch (text.Length)
			{
			case 11:
				text2 = "yyMMddHHmmZ";
				break;
			case 13:
			{
				int num = (int)Convert.ToInt16(text.Substring(0, 2), CultureInfo.InvariantCulture);
				if (num >= 50)
				{
					text = "19" + text;
				}
				else
				{
					text = "20" + text;
				}
				text2 = "yyyyMMddHHmmssZ";
				break;
			}
			case 15:
				text2 = "yyyyMMddHHmmssZ";
				break;
			case 17:
			{
				int num = (int)Convert.ToInt16(text.Substring(0, 2), CultureInfo.InvariantCulture);
				string text3 = ((num < 50) ? "20" : "19");
				char c = ((text[12] != '+') ? '+' : '-');
				text = string.Format("{0}{1}{2}{3}{4}:{5}{6}", new object[]
				{
					text3,
					text.Substring(0, 12),
					c,
					text[13],
					text[14],
					text[15],
					text[16]
				});
				text2 = "yyyyMMddHHmmsszzz";
				break;
			}
			}
			return DateTime.ParseExact(text, text2, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal);
		}
	}
}
