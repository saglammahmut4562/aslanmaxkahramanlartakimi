﻿using System;

namespace Mono.Security
{
	// Token: 0x0200004E RID: 78
	internal sealed class BitConverterLE
	{
		// Token: 0x0600015D RID: 349 RVA: 0x0000BF44 File Offset: 0x0000A144
		private unsafe static byte[] GetUShortBytes(byte* bytes)
		{
			if (BitConverter.IsLittleEndian)
			{
				return new byte[]
				{
					*bytes,
					bytes[1]
				};
			}
			return new byte[]
			{
				bytes[1],
				*bytes
			};
		}

		// Token: 0x0600015E RID: 350 RVA: 0x0000BF78 File Offset: 0x0000A178
		private unsafe static byte[] GetUIntBytes(byte* bytes)
		{
			if (BitConverter.IsLittleEndian)
			{
				return new byte[]
				{
					*bytes,
					bytes[1],
					bytes[2],
					bytes[3]
				};
			}
			return new byte[]
			{
				bytes[3],
				bytes[2],
				bytes[1],
				*bytes
			};
		}

		// Token: 0x0600015F RID: 351 RVA: 0x0000BFD0 File Offset: 0x0000A1D0
		private unsafe static byte[] GetULongBytes(byte* bytes)
		{
			if (BitConverter.IsLittleEndian)
			{
				return new byte[]
				{
					*bytes,
					bytes[1],
					bytes[2],
					bytes[3],
					bytes[4],
					bytes[5],
					bytes[6],
					bytes[7]
				};
			}
			return new byte[]
			{
				bytes[7],
				bytes[6],
				bytes[5],
				bytes[4],
				bytes[3],
				bytes[2],
				bytes[1],
				*bytes
			};
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000C060 File Offset: 0x0000A260
		internal unsafe static byte[] GetBytes(short value)
		{
			return BitConverterLE.GetUShortBytes((byte*)(&value));
		}

		// Token: 0x06000161 RID: 353 RVA: 0x0000C06C File Offset: 0x0000A26C
		internal unsafe static byte[] GetBytes(int value)
		{
			return BitConverterLE.GetUIntBytes((byte*)(&value));
		}

		// Token: 0x06000162 RID: 354 RVA: 0x0000C078 File Offset: 0x0000A278
		internal unsafe static byte[] GetBytes(float value)
		{
			return BitConverterLE.GetUIntBytes((byte*)(&value));
		}

		// Token: 0x06000163 RID: 355 RVA: 0x0000C084 File Offset: 0x0000A284
		internal unsafe static byte[] GetBytes(double value)
		{
			return BitConverterLE.GetULongBytes((byte*)(&value));
		}

		// Token: 0x06000164 RID: 356 RVA: 0x0000C090 File Offset: 0x0000A290
		private unsafe static void UShortFromBytes(byte* dst, byte[] src, int startIndex)
		{
			if (BitConverter.IsLittleEndian)
			{
				*dst = src[startIndex];
				dst[1] = src[startIndex + 1];
			}
			else
			{
				*dst = src[startIndex + 1];
				dst[1] = src[startIndex];
			}
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000C0C0 File Offset: 0x0000A2C0
		private unsafe static void UIntFromBytes(byte* dst, byte[] src, int startIndex)
		{
			if (BitConverter.IsLittleEndian)
			{
				*dst = src[startIndex];
				dst[1] = src[startIndex + 1];
				dst[2] = src[startIndex + 2];
				dst[3] = src[startIndex + 3];
			}
			else
			{
				*dst = src[startIndex + 3];
				dst[1] = src[startIndex + 2];
				dst[2] = src[startIndex + 1];
				dst[3] = src[startIndex];
			}
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0000C11C File Offset: 0x0000A31C
		private unsafe static void ULongFromBytes(byte* dst, byte[] src, int startIndex)
		{
			if (BitConverter.IsLittleEndian)
			{
				for (int i = 0; i < 8; i++)
				{
					dst[i] = src[startIndex + i];
				}
			}
			else
			{
				for (int j = 0; j < 8; j++)
				{
					dst[j] = src[startIndex + (7 - j)];
				}
			}
		}

		// Token: 0x06000167 RID: 359 RVA: 0x0000C170 File Offset: 0x0000A370
		internal unsafe static short ToInt16(byte[] value, int startIndex)
		{
			short num;
			BitConverterLE.UShortFromBytes((byte*)(&num), value, startIndex);
			return num;
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000C188 File Offset: 0x0000A388
		internal unsafe static int ToInt32(byte[] value, int startIndex)
		{
			int num;
			BitConverterLE.UIntFromBytes((byte*)(&num), value, startIndex);
			return num;
		}

		// Token: 0x06000169 RID: 361 RVA: 0x0000C1A0 File Offset: 0x0000A3A0
		internal unsafe static float ToSingle(byte[] value, int startIndex)
		{
			float num;
			BitConverterLE.UIntFromBytes((byte*)(&num), value, startIndex);
			return num;
		}

		// Token: 0x0600016A RID: 362 RVA: 0x0000C1B8 File Offset: 0x0000A3B8
		internal unsafe static double ToDouble(byte[] value, int startIndex)
		{
			double num;
			BitConverterLE.ULongFromBytes((byte*)(&num), value, startIndex);
			return num;
		}
	}
}
