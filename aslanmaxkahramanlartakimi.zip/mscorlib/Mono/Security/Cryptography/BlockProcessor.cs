﻿using System;
using System.Security.Cryptography;

namespace Mono.Security.Cryptography
{
	// Token: 0x0200004F RID: 79
	internal class BlockProcessor
	{
		// Token: 0x0600016B RID: 363 RVA: 0x0000C1D0 File Offset: 0x0000A3D0
		public BlockProcessor(ICryptoTransform transform, int blockSize)
		{
			this.transform = transform;
			this.blockSize = blockSize;
			this.block = new byte[blockSize];
		}

		// Token: 0x0600016C RID: 364 RVA: 0x0000C1F4 File Offset: 0x0000A3F4
		~BlockProcessor()
		{
			Array.Clear(this.block, 0, this.blockSize);
		}

		// Token: 0x0600016D RID: 365 RVA: 0x0000C230 File Offset: 0x0000A430
		public void Initialize()
		{
			Array.Clear(this.block, 0, this.blockSize);
			this.blockCount = 0;
		}

		// Token: 0x0600016E RID: 366 RVA: 0x0000C24C File Offset: 0x0000A44C
		public void Core(byte[] rgb)
		{
			this.Core(rgb, 0, rgb.Length);
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000C25C File Offset: 0x0000A45C
		public void Core(byte[] rgb, int ib, int cb)
		{
			int num = Math.Min(this.blockSize - this.blockCount, cb);
			Buffer.BlockCopy(rgb, ib, this.block, this.blockCount, num);
			this.blockCount += num;
			if (this.blockCount == this.blockSize)
			{
				this.transform.TransformBlock(this.block, 0, this.blockSize, this.block, 0);
				int num2 = (cb - num) / this.blockSize;
				for (int i = 0; i < num2; i++)
				{
					this.transform.TransformBlock(rgb, num + ib, this.blockSize, this.block, 0);
					num += this.blockSize;
				}
				this.blockCount = cb - num;
				if (this.blockCount > 0)
				{
					Buffer.BlockCopy(rgb, num + ib, this.block, 0, this.blockCount);
				}
			}
		}

		// Token: 0x06000170 RID: 368 RVA: 0x0000C340 File Offset: 0x0000A540
		public byte[] Final()
		{
			return this.transform.TransformFinalBlock(this.block, 0, this.blockCount);
		}

		// Token: 0x0400011B RID: 283
		private ICryptoTransform transform;

		// Token: 0x0400011C RID: 284
		private byte[] block;

		// Token: 0x0400011D RID: 285
		private int blockSize;

		// Token: 0x0400011E RID: 286
		private int blockCount;
	}
}
