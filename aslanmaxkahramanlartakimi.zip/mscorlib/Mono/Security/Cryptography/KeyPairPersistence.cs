﻿using System;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using Mono.Xml;

namespace Mono.Security.Cryptography
{
	// Token: 0x02000053 RID: 83
	internal class KeyPairPersistence
	{
		// Token: 0x06000194 RID: 404 RVA: 0x0000D77C File Offset: 0x0000B97C
		public KeyPairPersistence(CspParameters parameters)
			: this(parameters, null)
		{
		}

		// Token: 0x06000195 RID: 405 RVA: 0x0000D788 File Offset: 0x0000B988
		public KeyPairPersistence(CspParameters parameters, string keyPair)
		{
			if (parameters == null)
			{
				throw new ArgumentNullException("parameters");
			}
			this._params = this.Copy(parameters);
			this._keyvalue = keyPair;
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000197 RID: 407 RVA: 0x0000D7D0 File Offset: 0x0000B9D0
		public string Filename
		{
			get
			{
				if (this._filename == null)
				{
					this._filename = string.Format(CultureInfo.InvariantCulture, "[{0}][{1}][{2}].xml", new object[]
					{
						this._params.ProviderType,
						this.ContainerName,
						this._params.KeyNumber
					});
					if (this.UseMachineKeyStore)
					{
						this._filename = Path.Combine(KeyPairPersistence.MachinePath, this._filename);
					}
					else
					{
						this._filename = Path.Combine(KeyPairPersistence.UserPath, this._filename);
					}
				}
				return this._filename;
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000198 RID: 408 RVA: 0x0000D874 File Offset: 0x0000BA74
		// (set) Token: 0x06000199 RID: 409 RVA: 0x0000D87C File Offset: 0x0000BA7C
		public string KeyValue
		{
			get
			{
				return this._keyvalue;
			}
			set
			{
				if (this.CanChange)
				{
					this._keyvalue = value;
				}
			}
		}

		// Token: 0x0600019A RID: 410 RVA: 0x0000D890 File Offset: 0x0000BA90
		public bool Load()
		{
			if (Environment.SocketSecurityEnabled)
			{
				return false;
			}
			bool flag = File.Exists(this.Filename);
			if (flag)
			{
				using (StreamReader streamReader = File.OpenText(this.Filename))
				{
					this.FromXml(streamReader.ReadToEnd());
				}
			}
			return flag;
		}

		// Token: 0x0600019B RID: 411 RVA: 0x0000D8F8 File Offset: 0x0000BAF8
		public void Save()
		{
			if (Environment.SocketSecurityEnabled)
			{
				return;
			}
			using (FileStream fileStream = File.Open(this.Filename, FileMode.Create))
			{
				StreamWriter streamWriter = new StreamWriter(fileStream, Encoding.UTF8);
				streamWriter.Write(this.ToXml());
				streamWriter.Close();
			}
			if (this.UseMachineKeyStore)
			{
				KeyPairPersistence.ProtectMachine(this.Filename);
			}
			else
			{
				KeyPairPersistence.ProtectUser(this.Filename);
			}
		}

		// Token: 0x0600019C RID: 412 RVA: 0x0000D988 File Offset: 0x0000BB88
		public void Remove()
		{
			if (Environment.SocketSecurityEnabled)
			{
				return;
			}
			File.Delete(this.Filename);
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x0600019D RID: 413 RVA: 0x0000D9A0 File Offset: 0x0000BBA0
		private static string UserPath
		{
			get
			{
				object obj = KeyPairPersistence.lockobj;
				lock (obj)
				{
					if (KeyPairPersistence._userPath == null || !KeyPairPersistence._userPathExists)
					{
						KeyPairPersistence._userPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".mono");
						KeyPairPersistence._userPath = Path.Combine(KeyPairPersistence._userPath, "keypairs");
						KeyPairPersistence._userPathExists = Directory.Exists(KeyPairPersistence._userPath);
						if (!KeyPairPersistence._userPathExists)
						{
							try
							{
								Directory.CreateDirectory(KeyPairPersistence._userPath);
								KeyPairPersistence.ProtectUser(KeyPairPersistence._userPath);
								KeyPairPersistence._userPathExists = true;
							}
							catch (Exception ex)
							{
								string text = Locale.GetText("Could not create user key store '{0}'.");
								throw new CryptographicException(string.Format(text, KeyPairPersistence._userPath), ex);
							}
						}
					}
				}
				if (!KeyPairPersistence.IsUserProtected(KeyPairPersistence._userPath))
				{
					string text2 = Locale.GetText("Improperly protected user's key pairs in '{0}'.");
					throw new CryptographicException(string.Format(text2, KeyPairPersistence._userPath));
				}
				return KeyPairPersistence._userPath;
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600019E RID: 414 RVA: 0x0000DAAC File Offset: 0x0000BCAC
		private static string MachinePath
		{
			get
			{
				object obj = KeyPairPersistence.lockobj;
				lock (obj)
				{
					if (KeyPairPersistence._machinePath == null || !KeyPairPersistence._machinePathExists)
					{
						KeyPairPersistence._machinePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), ".mono");
						KeyPairPersistence._machinePath = Path.Combine(KeyPairPersistence._machinePath, "keypairs");
						KeyPairPersistence._machinePathExists = Directory.Exists(KeyPairPersistence._machinePath);
						if (!KeyPairPersistence._machinePathExists)
						{
							try
							{
								Directory.CreateDirectory(KeyPairPersistence._machinePath);
								KeyPairPersistence.ProtectMachine(KeyPairPersistence._machinePath);
								KeyPairPersistence._machinePathExists = true;
							}
							catch (Exception ex)
							{
								string text = Locale.GetText("Could not create machine key store '{0}'.");
								throw new CryptographicException(string.Format(text, KeyPairPersistence._machinePath), ex);
							}
						}
					}
				}
				if (!KeyPairPersistence.IsMachineProtected(KeyPairPersistence._machinePath))
				{
					string text2 = Locale.GetText("Improperly protected machine's key pairs in '{0}'.");
					throw new CryptographicException(string.Format(text2, KeyPairPersistence._machinePath));
				}
				return KeyPairPersistence._machinePath;
			}
		}

		// Token: 0x0600019F RID: 415
		[MethodImpl(4096)]
		internal static extern bool _CanSecure(string root);

		// Token: 0x060001A0 RID: 416
		[MethodImpl(4096)]
		internal static extern bool _ProtectUser(string path);

		// Token: 0x060001A1 RID: 417
		[MethodImpl(4096)]
		internal static extern bool _ProtectMachine(string path);

		// Token: 0x060001A2 RID: 418
		[MethodImpl(4096)]
		internal static extern bool _IsUserProtected(string path);

		// Token: 0x060001A3 RID: 419
		[MethodImpl(4096)]
		internal static extern bool _IsMachineProtected(string path);

		// Token: 0x060001A4 RID: 420 RVA: 0x0000DBB8 File Offset: 0x0000BDB8
		private static bool CanSecure(string path)
		{
			int platform = (int)Environment.OSVersion.Platform;
			return platform == 4 || platform == 128 || platform == 6 || KeyPairPersistence._CanSecure(Path.GetPathRoot(path));
		}

		// Token: 0x060001A5 RID: 421 RVA: 0x0000DBF8 File Offset: 0x0000BDF8
		private static bool ProtectUser(string path)
		{
			return !KeyPairPersistence.CanSecure(path) || KeyPairPersistence._ProtectUser(path);
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x0000DC10 File Offset: 0x0000BE10
		private static bool ProtectMachine(string path)
		{
			return !KeyPairPersistence.CanSecure(path) || KeyPairPersistence._ProtectMachine(path);
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x0000DC28 File Offset: 0x0000BE28
		private static bool IsUserProtected(string path)
		{
			return !KeyPairPersistence.CanSecure(path) || KeyPairPersistence._IsUserProtected(path);
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x0000DC40 File Offset: 0x0000BE40
		private static bool IsMachineProtected(string path)
		{
			return !KeyPairPersistence.CanSecure(path) || KeyPairPersistence._IsMachineProtected(path);
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x0000DC58 File Offset: 0x0000BE58
		private bool CanChange
		{
			get
			{
				return this._keyvalue == null;
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060001AA RID: 426 RVA: 0x0000DC64 File Offset: 0x0000BE64
		private bool UseDefaultKeyContainer
		{
			get
			{
				return (this._params.Flags & CspProviderFlags.UseDefaultKeyContainer) == CspProviderFlags.UseDefaultKeyContainer;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060001AB RID: 427 RVA: 0x0000DC78 File Offset: 0x0000BE78
		private bool UseMachineKeyStore
		{
			get
			{
				return (this._params.Flags & CspProviderFlags.UseMachineKeyStore) == CspProviderFlags.UseMachineKeyStore;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060001AC RID: 428 RVA: 0x0000DC8C File Offset: 0x0000BE8C
		private string ContainerName
		{
			get
			{
				if (this._container == null)
				{
					if (this.UseDefaultKeyContainer)
					{
						this._container = "default";
					}
					else if (this._params.KeyContainerName == null || this._params.KeyContainerName.Length == 0)
					{
						this._container = Guid.NewGuid().ToString();
					}
					else
					{
						byte[] bytes = Encoding.UTF8.GetBytes(this._params.KeyContainerName);
						MD5 md = MD5.Create();
						byte[] array = md.ComputeHash(bytes);
						Guid guid = new Guid(array);
						this._container = guid.ToString();
					}
				}
				return this._container;
			}
		}

		// Token: 0x060001AD RID: 429 RVA: 0x0000DD3C File Offset: 0x0000BF3C
		private CspParameters Copy(CspParameters p)
		{
			return new CspParameters(p.ProviderType, p.ProviderName, p.KeyContainerName)
			{
				KeyNumber = p.KeyNumber,
				Flags = p.Flags
			};
		}

		// Token: 0x060001AE RID: 430 RVA: 0x0000DD7C File Offset: 0x0000BF7C
		private void FromXml(string xml)
		{
			SecurityParser securityParser = new SecurityParser();
			securityParser.LoadXml(xml);
			SecurityElement securityElement = securityParser.ToXml();
			if (securityElement.Tag == "KeyPair")
			{
				SecurityElement securityElement2 = securityElement.SearchForChildByTag("KeyValue");
				if (securityElement2.Children.Count > 0)
				{
					this._keyvalue = securityElement2.Children[0].ToString();
				}
			}
		}

		// Token: 0x060001AF RID: 431 RVA: 0x0000DDE8 File Offset: 0x0000BFE8
		private string ToXml()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendFormat("<KeyPair>{0}\t<Properties>{0}\t\t<Provider ", Environment.NewLine);
			if (this._params.ProviderName != null && this._params.ProviderName.Length != 0)
			{
				stringBuilder.AppendFormat("Name=\"{0}\" ", this._params.ProviderName);
			}
			stringBuilder.AppendFormat("Type=\"{0}\" />{1}\t\t<Container ", this._params.ProviderType, Environment.NewLine);
			stringBuilder.AppendFormat("Name=\"{0}\" />{1}\t</Properties>{1}\t<KeyValue", this.ContainerName, Environment.NewLine);
			if (this._params.KeyNumber != -1)
			{
				stringBuilder.AppendFormat(" Id=\"{0}\" ", this._params.KeyNumber);
			}
			stringBuilder.AppendFormat(">{1}\t\t{0}{1}\t</KeyValue>{1}</KeyPair>{1}", this.KeyValue, Environment.NewLine);
			return stringBuilder.ToString();
		}

		// Token: 0x0400012D RID: 301
		private static bool _userPathExists = false;

		// Token: 0x0400012E RID: 302
		private static string _userPath;

		// Token: 0x0400012F RID: 303
		private static bool _machinePathExists = false;

		// Token: 0x04000130 RID: 304
		private static string _machinePath;

		// Token: 0x04000131 RID: 305
		private CspParameters _params;

		// Token: 0x04000132 RID: 306
		private string _keyvalue;

		// Token: 0x04000133 RID: 307
		private string _filename;

		// Token: 0x04000134 RID: 308
		private string _container;

		// Token: 0x04000135 RID: 309
		private static object lockobj = new object();
	}
}
