﻿using System;
using System.Security.Cryptography;

namespace Mono.Security.Cryptography
{
	// Token: 0x02000054 RID: 84
	internal sealed class PKCS1
	{
		// Token: 0x060001B1 RID: 433 RVA: 0x0000DF38 File Offset: 0x0000C138
		private static bool Compare(byte[] array1, byte[] array2)
		{
			bool flag = array1.Length == array2.Length;
			if (flag)
			{
				for (int i = 0; i < array1.Length; i++)
				{
					if (array1[i] != array2[i])
					{
						return false;
					}
				}
			}
			return flag;
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x0000DF78 File Offset: 0x0000C178
		public static byte[] I2OSP(byte[] x, int size)
		{
			byte[] array = new byte[size];
			Buffer.BlockCopy(x, 0, array, array.Length - x.Length, x.Length);
			return array;
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x0000DFA0 File Offset: 0x0000C1A0
		public static byte[] OS2IP(byte[] x)
		{
			int num = 0;
			while (x[num++] == 0 && num < x.Length)
			{
			}
			num--;
			if (num > 0)
			{
				byte[] array = new byte[x.Length - num];
				Buffer.BlockCopy(x, num, array, 0, array.Length);
				return array;
			}
			return x;
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x0000DFF0 File Offset: 0x0000C1F0
		public static byte[] RSAVP1(RSA rsa, byte[] s)
		{
			return rsa.EncryptValue(s);
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x0000DFFC File Offset: 0x0000C1FC
		public static bool Verify_v15(RSA rsa, HashAlgorithm hash, byte[] hashValue, byte[] signature)
		{
			return PKCS1.Verify_v15(rsa, hash, hashValue, signature, false);
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x0000E008 File Offset: 0x0000C208
		public static bool Verify_v15(RSA rsa, HashAlgorithm hash, byte[] hashValue, byte[] signature, bool tryNonStandardEncoding)
		{
			int num = rsa.KeySize >> 3;
			byte[] array = PKCS1.OS2IP(signature);
			byte[] array2 = PKCS1.RSAVP1(rsa, array);
			byte[] array3 = PKCS1.I2OSP(array2, num);
			byte[] array4 = PKCS1.Encode_v15(hash, hashValue, num);
			bool flag = PKCS1.Compare(array4, array3);
			if (flag || !tryNonStandardEncoding)
			{
				return flag;
			}
			if (array3[0] != 0 || array3[1] != 1)
			{
				return false;
			}
			int i;
			for (i = 2; i < array3.Length - hashValue.Length - 1; i++)
			{
				if (array3[i] != 255)
				{
					return false;
				}
			}
			if (array3[i++] != 0)
			{
				return false;
			}
			byte[] array5 = new byte[hashValue.Length];
			Buffer.BlockCopy(array3, i, array5, 0, array5.Length);
			return PKCS1.Compare(array5, hashValue);
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x0000E0CC File Offset: 0x0000C2CC
		public static byte[] Encode_v15(HashAlgorithm hash, byte[] hashValue, int emLength)
		{
			if (hashValue.Length != hash.HashSize >> 3)
			{
				throw new CryptographicException("bad hash length for " + hash.ToString());
			}
			string text = CryptoConfig.MapNameToOID(hash.ToString());
			byte[] array;
			if (text != null)
			{
				ASN1 asn = new ASN1(48);
				asn.Add(new ASN1(CryptoConfig.EncodeOID(text)));
				asn.Add(new ASN1(5));
				ASN1 asn2 = new ASN1(4, hashValue);
				ASN1 asn3 = new ASN1(48);
				asn3.Add(asn);
				asn3.Add(asn2);
				array = asn3.GetBytes();
			}
			else
			{
				array = hashValue;
			}
			Buffer.BlockCopy(hashValue, 0, array, array.Length - hashValue.Length, hashValue.Length);
			int num = Math.Max(8, emLength - array.Length - 3);
			byte[] array2 = new byte[num + array.Length + 3];
			array2[1] = 1;
			for (int i = 2; i < num + 2; i++)
			{
				array2[i] = byte.MaxValue;
			}
			Buffer.BlockCopy(array, 0, array2, num + 3, array.Length);
			return array2;
		}

		// Token: 0x04000136 RID: 310
		private static byte[] emptySHA1 = new byte[]
		{
			218, 57, 163, 238, 94, 107, 75, 13, 50, 85,
			191, 239, 149, 96, 24, 144, 175, 216, 7, 9
		};

		// Token: 0x04000137 RID: 311
		private static byte[] emptySHA256 = new byte[]
		{
			227, 176, 196, 66, 152, 252, 28, 20, 154, 251,
			244, 200, 153, 111, 185, 36, 39, 174, 65, 228,
			100, 155, 147, 76, 164, 149, 153, 27, 120, 82,
			184, 85
		};

		// Token: 0x04000138 RID: 312
		private static byte[] emptySHA384 = new byte[]
		{
			56, 176, 96, 167, 81, 172, 150, 56, 76, 217,
			50, 126, 177, 177, 227, 106, 33, 253, 183, 17,
			20, 190, 7, 67, 76, 12, 199, 191, 99, 246,
			225, 218, 39, 78, 222, 191, 231, 111, 101, 251,
			213, 26, 210, 241, 72, 152, 185, 91
		};

		// Token: 0x04000139 RID: 313
		private static byte[] emptySHA512 = new byte[]
		{
			207, 131, 225, 53, 126, 239, 184, 189, 241, 84,
			40, 80, 214, 109, 128, 7, 214, 32, 228, 5,
			11, 87, 21, 220, 131, 244, 169, 33, 211, 108,
			233, 206, 71, 208, 209, 60, 93, 133, 242, 176,
			byte.MaxValue, 131, 24, 210, 135, 126, 236, 47, 99, 185,
			49, 189, 71, 65, 122, 129, 165, 56, 50, 122,
			249, 39, 218, 62
		};
	}
}
