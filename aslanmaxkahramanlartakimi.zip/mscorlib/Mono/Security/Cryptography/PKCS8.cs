﻿using System;
using System.Collections;
using System.Security.Cryptography;

namespace Mono.Security.Cryptography
{
	// Token: 0x02000055 RID: 85
	internal sealed class PKCS8
	{
		// Token: 0x02000056 RID: 86
		public class EncryptedPrivateKeyInfo
		{
			// Token: 0x060001B8 RID: 440 RVA: 0x0000E1D8 File Offset: 0x0000C3D8
			public EncryptedPrivateKeyInfo()
			{
			}

			// Token: 0x060001B9 RID: 441 RVA: 0x0000E1E0 File Offset: 0x0000C3E0
			public EncryptedPrivateKeyInfo(byte[] data)
				: this()
			{
				this.Decode(data);
			}

			// Token: 0x17000020 RID: 32
			// (get) Token: 0x060001BA RID: 442 RVA: 0x0000E1F0 File Offset: 0x0000C3F0
			public string Algorithm
			{
				get
				{
					return this._algorithm;
				}
			}

			// Token: 0x17000021 RID: 33
			// (get) Token: 0x060001BB RID: 443 RVA: 0x0000E1F8 File Offset: 0x0000C3F8
			public byte[] EncryptedData
			{
				get
				{
					return (this._data != null) ? ((byte[])this._data.Clone()) : null;
				}
			}

			// Token: 0x17000022 RID: 34
			// (get) Token: 0x060001BC RID: 444 RVA: 0x0000E21C File Offset: 0x0000C41C
			public byte[] Salt
			{
				get
				{
					if (this._salt == null)
					{
						RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create();
						this._salt = new byte[8];
						randomNumberGenerator.GetBytes(this._salt);
					}
					return (byte[])this._salt.Clone();
				}
			}

			// Token: 0x17000023 RID: 35
			// (get) Token: 0x060001BD RID: 445 RVA: 0x0000E264 File Offset: 0x0000C464
			public int IterationCount
			{
				get
				{
					return this._iterations;
				}
			}

			// Token: 0x060001BE RID: 446 RVA: 0x0000E26C File Offset: 0x0000C46C
			private void Decode(byte[] data)
			{
				ASN1 asn = new ASN1(data);
				if (asn.Tag != 48)
				{
					throw new CryptographicException("invalid EncryptedPrivateKeyInfo");
				}
				ASN1 asn2 = asn[0];
				if (asn2.Tag != 48)
				{
					throw new CryptographicException("invalid encryptionAlgorithm");
				}
				ASN1 asn3 = asn2[0];
				if (asn3.Tag != 6)
				{
					throw new CryptographicException("invalid algorithm");
				}
				this._algorithm = ASN1Convert.ToOid(asn3);
				if (asn2.Count > 1)
				{
					ASN1 asn4 = asn2[1];
					if (asn4.Tag != 48)
					{
						throw new CryptographicException("invalid parameters");
					}
					ASN1 asn5 = asn4[0];
					if (asn5.Tag != 4)
					{
						throw new CryptographicException("invalid salt");
					}
					this._salt = asn5.Value;
					ASN1 asn6 = asn4[1];
					if (asn6.Tag != 2)
					{
						throw new CryptographicException("invalid iterationCount");
					}
					this._iterations = ASN1Convert.ToInt32(asn6);
				}
				ASN1 asn7 = asn[1];
				if (asn7.Tag != 4)
				{
					throw new CryptographicException("invalid EncryptedData");
				}
				this._data = asn7.Value;
			}

			// Token: 0x0400013A RID: 314
			private string _algorithm;

			// Token: 0x0400013B RID: 315
			private byte[] _salt;

			// Token: 0x0400013C RID: 316
			private int _iterations;

			// Token: 0x0400013D RID: 317
			private byte[] _data;
		}

		// Token: 0x02000057 RID: 87
		public class PrivateKeyInfo
		{
			// Token: 0x060001BF RID: 447 RVA: 0x0000E39C File Offset: 0x0000C59C
			public PrivateKeyInfo()
			{
				this._version = 0;
				this._list = new ArrayList();
			}

			// Token: 0x060001C0 RID: 448 RVA: 0x0000E3B8 File Offset: 0x0000C5B8
			public PrivateKeyInfo(byte[] data)
				: this()
			{
				this.Decode(data);
			}

			// Token: 0x17000024 RID: 36
			// (get) Token: 0x060001C1 RID: 449 RVA: 0x0000E3C8 File Offset: 0x0000C5C8
			public byte[] PrivateKey
			{
				get
				{
					if (this._key == null)
					{
						return null;
					}
					return (byte[])this._key.Clone();
				}
			}

			// Token: 0x060001C2 RID: 450 RVA: 0x0000E3E8 File Offset: 0x0000C5E8
			private void Decode(byte[] data)
			{
				ASN1 asn = new ASN1(data);
				if (asn.Tag != 48)
				{
					throw new CryptographicException("invalid PrivateKeyInfo");
				}
				ASN1 asn2 = asn[0];
				if (asn2.Tag != 2)
				{
					throw new CryptographicException("invalid version");
				}
				this._version = (int)asn2.Value[0];
				ASN1 asn3 = asn[1];
				if (asn3.Tag != 48)
				{
					throw new CryptographicException("invalid algorithm");
				}
				ASN1 asn4 = asn3[0];
				if (asn4.Tag != 6)
				{
					throw new CryptographicException("missing algorithm OID");
				}
				this._algorithm = ASN1Convert.ToOid(asn4);
				ASN1 asn5 = asn[2];
				this._key = asn5.Value;
				if (asn.Count > 3)
				{
					ASN1 asn6 = asn[3];
					for (int i = 0; i < asn6.Count; i++)
					{
						this._list.Add(asn6[i]);
					}
				}
			}

			// Token: 0x060001C3 RID: 451 RVA: 0x0000E4E8 File Offset: 0x0000C6E8
			private static byte[] RemoveLeadingZero(byte[] bigInt)
			{
				int num = 0;
				int num2 = bigInt.Length;
				if (bigInt[0] == 0)
				{
					num = 1;
					num2--;
				}
				byte[] array = new byte[num2];
				Buffer.BlockCopy(bigInt, num, array, 0, num2);
				return array;
			}

			// Token: 0x060001C4 RID: 452 RVA: 0x0000E51C File Offset: 0x0000C71C
			private static byte[] Normalize(byte[] bigInt, int length)
			{
				if (bigInt.Length == length)
				{
					return bigInt;
				}
				if (bigInt.Length > length)
				{
					return PKCS8.PrivateKeyInfo.RemoveLeadingZero(bigInt);
				}
				byte[] array = new byte[length];
				Buffer.BlockCopy(bigInt, 0, array, length - bigInt.Length, bigInt.Length);
				return array;
			}

			// Token: 0x060001C5 RID: 453 RVA: 0x0000E55C File Offset: 0x0000C75C
			public static RSA DecodeRSA(byte[] keypair)
			{
				ASN1 asn = new ASN1(keypair);
				if (asn.Tag != 48)
				{
					throw new CryptographicException("invalid private key format");
				}
				ASN1 asn2 = asn[0];
				if (asn2.Tag != 2)
				{
					throw new CryptographicException("missing version");
				}
				if (asn.Count < 9)
				{
					throw new CryptographicException("not enough key parameters");
				}
				RSAParameters rsaparameters = default(RSAParameters);
				rsaparameters.Modulus = PKCS8.PrivateKeyInfo.RemoveLeadingZero(asn[1].Value);
				int num = rsaparameters.Modulus.Length;
				int num2 = num >> 1;
				rsaparameters.D = PKCS8.PrivateKeyInfo.Normalize(asn[3].Value, num);
				rsaparameters.DP = PKCS8.PrivateKeyInfo.Normalize(asn[6].Value, num2);
				rsaparameters.DQ = PKCS8.PrivateKeyInfo.Normalize(asn[7].Value, num2);
				rsaparameters.Exponent = PKCS8.PrivateKeyInfo.RemoveLeadingZero(asn[2].Value);
				rsaparameters.InverseQ = PKCS8.PrivateKeyInfo.Normalize(asn[8].Value, num2);
				rsaparameters.P = PKCS8.PrivateKeyInfo.Normalize(asn[4].Value, num2);
				rsaparameters.Q = PKCS8.PrivateKeyInfo.Normalize(asn[5].Value, num2);
				RSA rsa = null;
				try
				{
					rsa = RSA.Create();
					rsa.ImportParameters(rsaparameters);
				}
				catch (CryptographicException)
				{
					rsa = new RSACryptoServiceProvider(new CspParameters
					{
						Flags = CspProviderFlags.UseMachineKeyStore
					});
					rsa.ImportParameters(rsaparameters);
				}
				return rsa;
			}

			// Token: 0x060001C6 RID: 454 RVA: 0x0000E6F0 File Offset: 0x0000C8F0
			public static DSA DecodeDSA(byte[] privateKey, DSAParameters dsaParameters)
			{
				ASN1 asn = new ASN1(privateKey);
				if (asn.Tag != 2)
				{
					throw new CryptographicException("invalid private key format");
				}
				dsaParameters.X = PKCS8.PrivateKeyInfo.Normalize(asn.Value, 20);
				DSA dsa = DSA.Create();
				dsa.ImportParameters(dsaParameters);
				return dsa;
			}

			// Token: 0x0400013E RID: 318
			private int _version;

			// Token: 0x0400013F RID: 319
			private string _algorithm;

			// Token: 0x04000140 RID: 320
			private byte[] _key;

			// Token: 0x04000141 RID: 321
			private ArrayList _list;
		}
	}
}
