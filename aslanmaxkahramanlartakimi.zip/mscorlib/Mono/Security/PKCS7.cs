﻿using System;

namespace Mono.Security
{
	// Token: 0x0200005A RID: 90
	internal sealed class PKCS7
	{
		// Token: 0x0200005B RID: 91
		public class ContentInfo
		{
			// Token: 0x060001D8 RID: 472 RVA: 0x0000F2E4 File Offset: 0x0000D4E4
			public ContentInfo()
			{
				this.content = new ASN1(160);
			}

			// Token: 0x060001D9 RID: 473 RVA: 0x0000F2FC File Offset: 0x0000D4FC
			public ContentInfo(string oid)
				: this()
			{
				this.contentType = oid;
			}

			// Token: 0x060001DA RID: 474 RVA: 0x0000F30C File Offset: 0x0000D50C
			public ContentInfo(byte[] data)
				: this(new ASN1(data))
			{
			}

			// Token: 0x060001DB RID: 475 RVA: 0x0000F31C File Offset: 0x0000D51C
			public ContentInfo(ASN1 asn1)
			{
				if (asn1.Tag != 48 || (asn1.Count < 1 && asn1.Count > 2))
				{
					throw new ArgumentException("Invalid ASN1");
				}
				if (asn1[0].Tag != 6)
				{
					throw new ArgumentException("Invalid contentType");
				}
				this.contentType = ASN1Convert.ToOid(asn1[0]);
				if (asn1.Count > 1)
				{
					if (asn1[1].Tag != 160)
					{
						throw new ArgumentException("Invalid content");
					}
					this.content = asn1[1];
				}
			}

			// Token: 0x17000027 RID: 39
			// (get) Token: 0x060001DC RID: 476 RVA: 0x0000F3C8 File Offset: 0x0000D5C8
			public ASN1 ASN1
			{
				get
				{
					return this.GetASN1();
				}
			}

			// Token: 0x17000028 RID: 40
			// (get) Token: 0x060001DD RID: 477 RVA: 0x0000F3D0 File Offset: 0x0000D5D0
			// (set) Token: 0x060001DE RID: 478 RVA: 0x0000F3D8 File Offset: 0x0000D5D8
			public ASN1 Content
			{
				get
				{
					return this.content;
				}
				set
				{
					this.content = value;
				}
			}

			// Token: 0x17000029 RID: 41
			// (get) Token: 0x060001DF RID: 479 RVA: 0x0000F3E4 File Offset: 0x0000D5E4
			// (set) Token: 0x060001E0 RID: 480 RVA: 0x0000F3EC File Offset: 0x0000D5EC
			public string ContentType
			{
				get
				{
					return this.contentType;
				}
				set
				{
					this.contentType = value;
				}
			}

			// Token: 0x060001E1 RID: 481 RVA: 0x0000F3F8 File Offset: 0x0000D5F8
			internal ASN1 GetASN1()
			{
				ASN1 asn = new ASN1(48);
				asn.Add(ASN1Convert.FromOid(this.contentType));
				if (this.content != null && this.content.Count > 0)
				{
					asn.Add(this.content);
				}
				return asn;
			}

			// Token: 0x04000150 RID: 336
			private string contentType;

			// Token: 0x04000151 RID: 337
			private ASN1 content;
		}

		// Token: 0x0200005C RID: 92
		public class EncryptedData
		{
			// Token: 0x060001E2 RID: 482 RVA: 0x0000F44C File Offset: 0x0000D64C
			public EncryptedData()
			{
				this._version = 0;
			}

			// Token: 0x060001E3 RID: 483 RVA: 0x0000F45C File Offset: 0x0000D65C
			public EncryptedData(ASN1 asn1)
				: this()
			{
				if (asn1.Tag != 48 || asn1.Count < 2)
				{
					throw new ArgumentException("Invalid EncryptedData");
				}
				if (asn1[0].Tag != 2)
				{
					throw new ArgumentException("Invalid version");
				}
				this._version = asn1[0].Value[0];
				ASN1 asn2 = asn1[1];
				if (asn2.Tag != 48)
				{
					throw new ArgumentException("missing EncryptedContentInfo");
				}
				ASN1 asn3 = asn2[0];
				if (asn3.Tag != 6)
				{
					throw new ArgumentException("missing EncryptedContentInfo.ContentType");
				}
				this._content = new PKCS7.ContentInfo(ASN1Convert.ToOid(asn3));
				ASN1 asn4 = asn2[1];
				if (asn4.Tag != 48)
				{
					throw new ArgumentException("missing EncryptedContentInfo.ContentEncryptionAlgorithmIdentifier");
				}
				this._encryptionAlgorithm = new PKCS7.ContentInfo(ASN1Convert.ToOid(asn4[0]));
				this._encryptionAlgorithm.Content = asn4[1];
				ASN1 asn5 = asn2[2];
				if (asn5.Tag != 128)
				{
					throw new ArgumentException("missing EncryptedContentInfo.EncryptedContent");
				}
				this._encrypted = asn5.Value;
			}

			// Token: 0x1700002A RID: 42
			// (get) Token: 0x060001E4 RID: 484 RVA: 0x0000F58C File Offset: 0x0000D78C
			public PKCS7.ContentInfo EncryptionAlgorithm
			{
				get
				{
					return this._encryptionAlgorithm;
				}
			}

			// Token: 0x1700002B RID: 43
			// (get) Token: 0x060001E5 RID: 485 RVA: 0x0000F594 File Offset: 0x0000D794
			public byte[] EncryptedContent
			{
				get
				{
					if (this._encrypted == null)
					{
						return null;
					}
					return (byte[])this._encrypted.Clone();
				}
			}

			// Token: 0x04000152 RID: 338
			private byte _version;

			// Token: 0x04000153 RID: 339
			private PKCS7.ContentInfo _content;

			// Token: 0x04000154 RID: 340
			private PKCS7.ContentInfo _encryptionAlgorithm;

			// Token: 0x04000155 RID: 341
			private byte[] _encrypted;
		}
	}
}
