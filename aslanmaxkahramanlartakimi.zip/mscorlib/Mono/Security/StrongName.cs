﻿using System;
using System.Security.Cryptography;
using Mono.Security.Cryptography;

namespace Mono.Security
{
	// Token: 0x0200005D RID: 93
	internal sealed class StrongName
	{
		// Token: 0x060001E6 RID: 486 RVA: 0x0000F5B4 File Offset: 0x0000D7B4
		public StrongName(byte[] data)
		{
			if (data == null)
			{
				throw new ArgumentNullException("data");
			}
			if (data.Length == 16)
			{
				int i = 0;
				int num = 0;
				while (i < data.Length)
				{
					num += (int)data[i++];
				}
				if (num == 4)
				{
					this.publicKey = (byte[])data.Clone();
				}
			}
			else
			{
				this.RSA = CryptoConvert.FromCapiKeyBlob(data);
				if (this.rsa == null)
				{
					throw new ArgumentException("data isn't a correctly encoded RSA public key");
				}
			}
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x0000F640 File Offset: 0x0000D840
		public StrongName(RSA rsa)
		{
			if (rsa == null)
			{
				throw new ArgumentNullException("rsa");
			}
			this.RSA = rsa;
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0000F674 File Offset: 0x0000D874
		private void InvalidateCache()
		{
			this.publicKey = null;
			this.keyToken = null;
		}

		// Token: 0x1700002C RID: 44
		// (set) Token: 0x060001EA RID: 490 RVA: 0x0000F684 File Offset: 0x0000D884
		public RSA RSA
		{
			set
			{
				this.rsa = value;
				this.InvalidateCache();
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060001EB RID: 491 RVA: 0x0000F694 File Offset: 0x0000D894
		public byte[] PublicKey
		{
			get
			{
				if (this.publicKey == null)
				{
					byte[] array = CryptoConvert.ToCapiKeyBlob(this.rsa, false);
					this.publicKey = new byte[32 + (this.rsa.KeySize >> 3)];
					this.publicKey[0] = array[4];
					this.publicKey[1] = array[5];
					this.publicKey[2] = array[6];
					this.publicKey[3] = array[7];
					this.publicKey[4] = 4;
					this.publicKey[5] = 128;
					this.publicKey[6] = 0;
					this.publicKey[7] = 0;
					byte[] bytes = BitConverterLE.GetBytes(this.publicKey.Length - 12);
					this.publicKey[8] = bytes[0];
					this.publicKey[9] = bytes[1];
					this.publicKey[10] = bytes[2];
					this.publicKey[11] = bytes[3];
					this.publicKey[12] = 6;
					Buffer.BlockCopy(array, 1, this.publicKey, 13, this.publicKey.Length - 13);
					this.publicKey[23] = 49;
				}
				return (byte[])this.publicKey.Clone();
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060001EC RID: 492 RVA: 0x0000F7A8 File Offset: 0x0000D9A8
		public byte[] PublicKeyToken
		{
			get
			{
				if (this.keyToken == null)
				{
					byte[] array = this.PublicKey;
					if (array == null)
					{
						return null;
					}
					HashAlgorithm hashAlgorithm = HashAlgorithm.Create(this.TokenAlgorithm);
					byte[] array2 = hashAlgorithm.ComputeHash(array);
					this.keyToken = new byte[8];
					Buffer.BlockCopy(array2, array2.Length - 8, this.keyToken, 0, 8);
					Array.Reverse(this.keyToken, 0, 8);
				}
				return (byte[])this.keyToken.Clone();
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060001ED RID: 493 RVA: 0x0000F820 File Offset: 0x0000DA20
		public string TokenAlgorithm
		{
			get
			{
				if (this.tokenAlgorithm == null)
				{
					this.tokenAlgorithm = "SHA1";
				}
				return this.tokenAlgorithm;
			}
		}

		// Token: 0x04000156 RID: 342
		private RSA rsa;

		// Token: 0x04000157 RID: 343
		private byte[] publicKey;

		// Token: 0x04000158 RID: 344
		private byte[] keyToken;

		// Token: 0x04000159 RID: 345
		private string tokenAlgorithm;

		// Token: 0x0400015A RID: 346
		private static object lockObject = new object();

		// Token: 0x0400015B RID: 347
		private static bool initialized = false;
	}
}
