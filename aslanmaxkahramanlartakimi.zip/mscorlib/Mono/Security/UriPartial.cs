﻿using System;

namespace Mono.Security
{
	// Token: 0x02000060 RID: 96
	internal enum UriPartial
	{
		// Token: 0x0400017E RID: 382
		Scheme,
		// Token: 0x0400017F RID: 383
		Authority,
		// Token: 0x04000180 RID: 384
		Path
	}
}
