﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using Mono.Security.Cryptography;

namespace Mono.Security.X509
{
	// Token: 0x02000061 RID: 97
	internal class PKCS12 : ICloneable
	{
		// Token: 0x0600020D RID: 525 RVA: 0x00010E98 File Offset: 0x0000F098
		public PKCS12()
		{
			this._iterations = PKCS12.recommendedIterationCount;
			this._keyBags = new ArrayList();
			this._secretBags = new ArrayList();
			this._certs = new X509CertificateCollection();
			this._keyBagsChanged = false;
			this._secretBagsChanged = false;
			this._certsChanged = false;
			this._safeBags = new ArrayList();
		}

		// Token: 0x0600020E RID: 526 RVA: 0x00010EF8 File Offset: 0x0000F0F8
		public PKCS12(byte[] data)
			: this()
		{
			this.Password = null;
			this.Decode(data);
		}

		// Token: 0x0600020F RID: 527 RVA: 0x00010F10 File Offset: 0x0000F110
		public PKCS12(byte[] data, string password)
			: this()
		{
			this.Password = password;
			this.Decode(data);
		}

		// Token: 0x06000211 RID: 529 RVA: 0x00010F40 File Offset: 0x0000F140
		private void Decode(byte[] data)
		{
			ASN1 asn = new ASN1(data);
			if (asn.Tag != 48)
			{
				throw new ArgumentException("invalid data");
			}
			ASN1 asn2 = asn[0];
			if (asn2.Tag != 2)
			{
				throw new ArgumentException("invalid PFX version");
			}
			PKCS7.ContentInfo contentInfo = new PKCS7.ContentInfo(asn[1]);
			if (contentInfo.ContentType != "1.2.840.113549.1.7.1")
			{
				throw new ArgumentException("invalid authenticated safe");
			}
			if (asn.Count > 2)
			{
				ASN1 asn3 = asn[2];
				if (asn3.Tag != 48)
				{
					throw new ArgumentException("invalid MAC");
				}
				ASN1 asn4 = asn3[0];
				if (asn4.Tag != 48)
				{
					throw new ArgumentException("invalid MAC");
				}
				ASN1 asn5 = asn4[0];
				string text = ASN1Convert.ToOid(asn5[0]);
				if (text != "1.3.14.3.2.26")
				{
					throw new ArgumentException("unsupported HMAC");
				}
				byte[] value = asn4[1].Value;
				ASN1 asn6 = asn3[1];
				if (asn6.Tag != 4)
				{
					throw new ArgumentException("missing MAC salt");
				}
				this._iterations = 1;
				if (asn3.Count > 2)
				{
					ASN1 asn7 = asn3[2];
					if (asn7.Tag != 2)
					{
						throw new ArgumentException("invalid MAC iteration");
					}
					this._iterations = ASN1Convert.ToInt32(asn7);
				}
				byte[] value2 = contentInfo.Content[0].Value;
				byte[] array = this.MAC(this._password, asn6.Value, this._iterations, value2);
				if (!this.Compare(value, array))
				{
					throw new CryptographicException("Invalid MAC - file may have been tampered!");
				}
			}
			ASN1 asn8 = new ASN1(contentInfo.Content[0].Value);
			int i = 0;
			while (i < asn8.Count)
			{
				PKCS7.ContentInfo contentInfo2 = new PKCS7.ContentInfo(asn8[i]);
				string contentType = contentInfo2.ContentType;
				if (contentType != null)
				{
					if (PKCS12.<>f__switch$map8 == null)
					{
						PKCS12.<>f__switch$map8 = new Dictionary<string, int>(3)
						{
							{ "1.2.840.113549.1.7.1", 0 },
							{ "1.2.840.113549.1.7.6", 1 },
							{ "1.2.840.113549.1.7.3", 2 }
						};
					}
					int num;
					if (PKCS12.<>f__switch$map8.TryGetValue(contentType, out num))
					{
						switch (num)
						{
						case 0:
						{
							ASN1 asn9 = new ASN1(contentInfo2.Content[0].Value);
							for (int j = 0; j < asn9.Count; j++)
							{
								ASN1 asn10 = asn9[j];
								this.ReadSafeBag(asn10);
							}
							break;
						}
						case 1:
						{
							PKCS7.EncryptedData encryptedData = new PKCS7.EncryptedData(contentInfo2.Content[0]);
							ASN1 asn11 = new ASN1(this.Decrypt(encryptedData));
							for (int k = 0; k < asn11.Count; k++)
							{
								ASN1 asn12 = asn11[k];
								this.ReadSafeBag(asn12);
							}
							break;
						}
						case 2:
							throw new NotImplementedException("public key encrypted");
						default:
							goto IL_0303;
						}
						i++;
						continue;
					}
				}
				IL_0303:
				throw new ArgumentException("unknown authenticatedSafe");
			}
		}

		// Token: 0x06000212 RID: 530 RVA: 0x00011270 File Offset: 0x0000F470
		~PKCS12()
		{
			if (this._password != null)
			{
				Array.Clear(this._password, 0, this._password.Length);
			}
			this._password = null;
		}

		// Token: 0x17000034 RID: 52
		// (set) Token: 0x06000213 RID: 531 RVA: 0x000112C0 File Offset: 0x0000F4C0
		public string Password
		{
			set
			{
				if (value != null)
				{
					if (value.Length > 0)
					{
						int num = value.Length;
						int num2 = 0;
						if (num < PKCS12.MaximumPasswordLength)
						{
							if (value[num - 1] != '\0')
							{
								num2 = 1;
							}
						}
						else
						{
							num = PKCS12.MaximumPasswordLength;
						}
						this._password = new byte[num + num2 << 1];
						Encoding.BigEndianUnicode.GetBytes(value, 0, num, this._password, 0);
					}
					else
					{
						this._password = new byte[2];
					}
				}
				else
				{
					this._password = null;
				}
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000214 RID: 532 RVA: 0x00011350 File Offset: 0x0000F550
		// (set) Token: 0x06000215 RID: 533 RVA: 0x00011358 File Offset: 0x0000F558
		public int IterationCount
		{
			get
			{
				return this._iterations;
			}
			set
			{
				this._iterations = value;
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000216 RID: 534 RVA: 0x00011364 File Offset: 0x0000F564
		public X509CertificateCollection Certificates
		{
			get
			{
				if (this._certsChanged)
				{
					this._certs.Clear();
					foreach (object obj in this._safeBags)
					{
						SafeBag safeBag = (SafeBag)obj;
						if (safeBag.BagOID.Equals("1.2.840.113549.1.12.10.1.3"))
						{
							ASN1 asn = safeBag.ASN1;
							ASN1 asn2 = asn[1];
							PKCS7.ContentInfo contentInfo = new PKCS7.ContentInfo(asn2.Value);
							this._certs.Add(new X509Certificate(contentInfo.Content[0].Value));
						}
					}
					this._certsChanged = false;
				}
				return this._certs;
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000217 RID: 535 RVA: 0x0001143C File Offset: 0x0000F63C
		internal RandomNumberGenerator RNG
		{
			get
			{
				if (this._rng == null)
				{
					this._rng = RandomNumberGenerator.Create();
				}
				return this._rng;
			}
		}

		// Token: 0x06000218 RID: 536 RVA: 0x0001145C File Offset: 0x0000F65C
		private bool Compare(byte[] expected, byte[] actual)
		{
			bool flag = false;
			if (expected.Length == actual.Length)
			{
				for (int i = 0; i < expected.Length; i++)
				{
					if (expected[i] != actual[i])
					{
						return false;
					}
				}
				flag = true;
			}
			return flag;
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0001149C File Offset: 0x0000F69C
		private SymmetricAlgorithm GetSymmetricAlgorithm(string algorithmOid, byte[] salt, int iterationCount)
		{
			string text = null;
			int num = 8;
			int num2 = 8;
			PKCS12.DeriveBytes deriveBytes = new PKCS12.DeriveBytes();
			deriveBytes.Password = this._password;
			deriveBytes.Salt = salt;
			deriveBytes.IterationCount = iterationCount;
			if (algorithmOid != null)
			{
				if (PKCS12.<>f__switch$map9 == null)
				{
					PKCS12.<>f__switch$map9 = new Dictionary<string, int>(12)
					{
						{ "1.2.840.113549.1.5.1", 0 },
						{ "1.2.840.113549.1.5.3", 1 },
						{ "1.2.840.113549.1.5.4", 2 },
						{ "1.2.840.113549.1.5.6", 3 },
						{ "1.2.840.113549.1.5.10", 4 },
						{ "1.2.840.113549.1.5.11", 5 },
						{ "1.2.840.113549.1.12.1.1", 6 },
						{ "1.2.840.113549.1.12.1.2", 7 },
						{ "1.2.840.113549.1.12.1.3", 8 },
						{ "1.2.840.113549.1.12.1.4", 9 },
						{ "1.2.840.113549.1.12.1.5", 10 },
						{ "1.2.840.113549.1.12.1.6", 11 }
					};
				}
				int num3;
				if (PKCS12.<>f__switch$map9.TryGetValue(algorithmOid, out num3))
				{
					switch (num3)
					{
					case 0:
						deriveBytes.HashName = "MD2";
						text = "DES";
						break;
					case 1:
						deriveBytes.HashName = "MD5";
						text = "DES";
						break;
					case 2:
						deriveBytes.HashName = "MD2";
						text = "RC2";
						num = 4;
						break;
					case 3:
						deriveBytes.HashName = "MD5";
						text = "RC2";
						num = 4;
						break;
					case 4:
						deriveBytes.HashName = "SHA1";
						text = "DES";
						break;
					case 5:
						deriveBytes.HashName = "SHA1";
						text = "RC2";
						num = 4;
						break;
					case 6:
						deriveBytes.HashName = "SHA1";
						text = "RC4";
						num = 16;
						num2 = 0;
						break;
					case 7:
						deriveBytes.HashName = "SHA1";
						text = "RC4";
						num = 5;
						num2 = 0;
						break;
					case 8:
						deriveBytes.HashName = "SHA1";
						text = "TripleDES";
						num = 24;
						break;
					case 9:
						deriveBytes.HashName = "SHA1";
						text = "TripleDES";
						num = 16;
						break;
					case 10:
						deriveBytes.HashName = "SHA1";
						text = "RC2";
						num = 16;
						break;
					case 11:
						deriveBytes.HashName = "SHA1";
						text = "RC2";
						num = 5;
						break;
					default:
						goto IL_025A;
					}
					SymmetricAlgorithm symmetricAlgorithm = SymmetricAlgorithm.Create(text);
					symmetricAlgorithm.Key = deriveBytes.DeriveKey(num);
					if (num2 > 0)
					{
						symmetricAlgorithm.IV = deriveBytes.DeriveIV(num2);
						symmetricAlgorithm.Mode = CipherMode.CBC;
					}
					return symmetricAlgorithm;
				}
			}
			IL_025A:
			throw new NotSupportedException("unknown oid " + text);
		}

		// Token: 0x0600021A RID: 538 RVA: 0x0001174C File Offset: 0x0000F94C
		public byte[] Decrypt(string algorithmOid, byte[] salt, int iterationCount, byte[] encryptedData)
		{
			SymmetricAlgorithm symmetricAlgorithm = null;
			byte[] array = null;
			try
			{
				symmetricAlgorithm = this.GetSymmetricAlgorithm(algorithmOid, salt, iterationCount);
				ICryptoTransform cryptoTransform = symmetricAlgorithm.CreateDecryptor();
				array = cryptoTransform.TransformFinalBlock(encryptedData, 0, encryptedData.Length);
			}
			finally
			{
				if (symmetricAlgorithm != null)
				{
					symmetricAlgorithm.Clear();
				}
			}
			return array;
		}

		// Token: 0x0600021B RID: 539 RVA: 0x000117A0 File Offset: 0x0000F9A0
		public byte[] Decrypt(PKCS7.EncryptedData ed)
		{
			return this.Decrypt(ed.EncryptionAlgorithm.ContentType, ed.EncryptionAlgorithm.Content[0].Value, ASN1Convert.ToInt32(ed.EncryptionAlgorithm.Content[1]), ed.EncryptedContent);
		}

		// Token: 0x0600021C RID: 540 RVA: 0x000117F0 File Offset: 0x0000F9F0
		public byte[] Encrypt(string algorithmOid, byte[] salt, int iterationCount, byte[] data)
		{
			byte[] array = null;
			using (SymmetricAlgorithm symmetricAlgorithm = this.GetSymmetricAlgorithm(algorithmOid, salt, iterationCount))
			{
				ICryptoTransform cryptoTransform = symmetricAlgorithm.CreateEncryptor();
				array = cryptoTransform.TransformFinalBlock(data, 0, data.Length);
			}
			return array;
		}

		// Token: 0x0600021D RID: 541 RVA: 0x00011844 File Offset: 0x0000FA44
		private DSAParameters GetExistingParameters(out bool found)
		{
			foreach (X509Certificate x509Certificate in this.Certificates)
			{
				if (x509Certificate.KeyAlgorithmParameters != null)
				{
					DSA dsa = x509Certificate.DSA;
					if (dsa != null)
					{
						found = true;
						return dsa.ExportParameters(false);
					}
				}
			}
			found = false;
			return default(DSAParameters);
		}

		// Token: 0x0600021E RID: 542 RVA: 0x000118D8 File Offset: 0x0000FAD8
		private void AddPrivateKey(PKCS8.PrivateKeyInfo pki)
		{
			byte[] privateKey = pki.PrivateKey;
			byte b = privateKey[0];
			if (b != 2)
			{
				if (b != 48)
				{
					Array.Clear(privateKey, 0, privateKey.Length);
					throw new CryptographicException("Unknown private key format");
				}
				this._keyBags.Add(PKCS8.PrivateKeyInfo.DecodeRSA(privateKey));
			}
			else
			{
				bool flag;
				DSAParameters existingParameters = this.GetExistingParameters(out flag);
				if (flag)
				{
					this._keyBags.Add(PKCS8.PrivateKeyInfo.DecodeDSA(privateKey, existingParameters));
				}
			}
			Array.Clear(privateKey, 0, privateKey.Length);
		}

		// Token: 0x0600021F RID: 543 RVA: 0x00011964 File Offset: 0x0000FB64
		private void ReadSafeBag(ASN1 safeBag)
		{
			if (safeBag.Tag != 48)
			{
				throw new ArgumentException("invalid safeBag");
			}
			ASN1 asn = safeBag[0];
			if (asn.Tag != 6)
			{
				throw new ArgumentException("invalid safeBag id");
			}
			ASN1 asn2 = safeBag[1];
			string text = ASN1Convert.ToOid(asn);
			string text2 = text;
			if (text2 != null)
			{
				if (PKCS12.<>f__switch$mapA == null)
				{
					PKCS12.<>f__switch$mapA = new Dictionary<string, int>(6)
					{
						{ "1.2.840.113549.1.12.10.1.1", 0 },
						{ "1.2.840.113549.1.12.10.1.2", 1 },
						{ "1.2.840.113549.1.12.10.1.3", 2 },
						{ "1.2.840.113549.1.12.10.1.4", 3 },
						{ "1.2.840.113549.1.12.10.1.5", 4 },
						{ "1.2.840.113549.1.12.10.1.6", 5 }
					};
				}
				int num;
				if (PKCS12.<>f__switch$mapA.TryGetValue(text2, out num))
				{
					switch (num)
					{
					case 0:
						this.AddPrivateKey(new PKCS8.PrivateKeyInfo(asn2.Value));
						break;
					case 1:
					{
						PKCS8.EncryptedPrivateKeyInfo encryptedPrivateKeyInfo = new PKCS8.EncryptedPrivateKeyInfo(asn2.Value);
						byte[] array = this.Decrypt(encryptedPrivateKeyInfo.Algorithm, encryptedPrivateKeyInfo.Salt, encryptedPrivateKeyInfo.IterationCount, encryptedPrivateKeyInfo.EncryptedData);
						this.AddPrivateKey(new PKCS8.PrivateKeyInfo(array));
						Array.Clear(array, 0, array.Length);
						break;
					}
					case 2:
					{
						PKCS7.ContentInfo contentInfo = new PKCS7.ContentInfo(asn2.Value);
						if (contentInfo.ContentType != "1.2.840.113549.1.9.22.1")
						{
							throw new NotSupportedException("unsupport certificate type");
						}
						X509Certificate x509Certificate = new X509Certificate(contentInfo.Content[0].Value);
						this._certs.Add(x509Certificate);
						break;
					}
					case 3:
						break;
					case 4:
					{
						byte[] value = asn2.Value;
						this._secretBags.Add(value);
						break;
					}
					case 5:
						break;
					default:
						goto IL_01CD;
					}
					if (safeBag.Count > 2)
					{
						ASN1 asn3 = safeBag[2];
						if (asn3.Tag != 49)
						{
							throw new ArgumentException("invalid safeBag attributes id");
						}
						for (int i = 0; i < asn3.Count; i++)
						{
							ASN1 asn4 = asn3[i];
							if (asn4.Tag != 48)
							{
								throw new ArgumentException("invalid PKCS12 attributes id");
							}
							ASN1 asn5 = asn4[0];
							if (asn5.Tag != 6)
							{
								throw new ArgumentException("invalid attribute id");
							}
							string text3 = ASN1Convert.ToOid(asn5);
							ASN1 asn6 = asn4[1];
							int j = 0;
							while (j < asn6.Count)
							{
								ASN1 asn7 = asn6[j];
								text2 = text3;
								if (text2 != null)
								{
									if (PKCS12.<>f__switch$mapB == null)
									{
										PKCS12.<>f__switch$mapB = new Dictionary<string, int>(2)
										{
											{ "1.2.840.113549.1.9.20", 0 },
											{ "1.2.840.113549.1.9.21", 1 }
										};
									}
									if (PKCS12.<>f__switch$mapB.TryGetValue(text2, out num))
									{
										if (num != 0)
										{
											if (num == 1)
											{
												if (asn7.Tag != 4)
												{
													throw new ArgumentException("invalid attribute value id");
												}
											}
										}
										else if (asn7.Tag != 30)
										{
											throw new ArgumentException("invalid attribute value id");
										}
									}
								}
								IL_031F:
								j++;
								continue;
								goto IL_031F;
							}
						}
					}
					this._safeBags.Add(new SafeBag(text, safeBag));
					return;
				}
			}
			IL_01CD:
			throw new ArgumentException("unknown safeBag oid");
		}

		// Token: 0x06000220 RID: 544 RVA: 0x00011CCC File Offset: 0x0000FECC
		private ASN1 CertificateSafeBag(X509Certificate x509, IDictionary attributes)
		{
			ASN1 asn = new ASN1(4, x509.RawData);
			PKCS7.ContentInfo contentInfo = new PKCS7.ContentInfo();
			contentInfo.ContentType = "1.2.840.113549.1.9.22.1";
			contentInfo.Content.Add(asn);
			ASN1 asn2 = new ASN1(160);
			asn2.Add(contentInfo.ASN1);
			ASN1 asn3 = new ASN1(48);
			asn3.Add(ASN1Convert.FromOid("1.2.840.113549.1.12.10.1.3"));
			asn3.Add(asn2);
			if (attributes != null)
			{
				ASN1 asn4 = new ASN1(49);
				IDictionaryEnumerator enumerator = attributes.GetEnumerator();
				while (enumerator.MoveNext())
				{
					string text = (string)enumerator.Key;
					string text2 = text;
					if (text2 != null)
					{
						if (PKCS12.<>f__switch$mapF == null)
						{
							PKCS12.<>f__switch$mapF = new Dictionary<string, int>(2)
							{
								{ "1.2.840.113549.1.9.20", 0 },
								{ "1.2.840.113549.1.9.21", 1 }
							};
						}
						int num;
						if (PKCS12.<>f__switch$mapF.TryGetValue(text2, out num))
						{
							if (num != 0)
							{
								if (num == 1)
								{
									ArrayList arrayList = (ArrayList)enumerator.Value;
									if (arrayList.Count > 0)
									{
										ASN1 asn5 = new ASN1(48);
										asn5.Add(ASN1Convert.FromOid("1.2.840.113549.1.9.21"));
										ASN1 asn6 = new ASN1(49);
										foreach (object obj in arrayList)
										{
											byte[] array = (byte[])obj;
											asn6.Add(new ASN1(4)
											{
												Value = array
											});
										}
										asn5.Add(asn6);
										asn4.Add(asn5);
									}
								}
							}
							else
							{
								ArrayList arrayList2 = (ArrayList)enumerator.Value;
								if (arrayList2.Count > 0)
								{
									ASN1 asn7 = new ASN1(48);
									asn7.Add(ASN1Convert.FromOid("1.2.840.113549.1.9.20"));
									ASN1 asn8 = new ASN1(49);
									foreach (object obj2 in arrayList2)
									{
										byte[] array2 = (byte[])obj2;
										asn8.Add(new ASN1(30)
										{
											Value = array2
										});
									}
									asn7.Add(asn8);
									asn4.Add(asn7);
								}
							}
						}
					}
				}
				if (asn4.Count > 0)
				{
					asn3.Add(asn4);
				}
			}
			return asn3;
		}

		// Token: 0x06000221 RID: 545 RVA: 0x00011F80 File Offset: 0x00010180
		private byte[] MAC(byte[] password, byte[] salt, int iterations, byte[] data)
		{
			PKCS12.DeriveBytes deriveBytes = new PKCS12.DeriveBytes();
			deriveBytes.HashName = "SHA1";
			deriveBytes.Password = password;
			deriveBytes.Salt = salt;
			deriveBytes.IterationCount = iterations;
			HMACSHA1 hmacsha = (HMACSHA1)HMAC.Create();
			hmacsha.Key = deriveBytes.DeriveMAC(20);
			return hmacsha.ComputeHash(data, 0, data.Length);
		}

		// Token: 0x06000222 RID: 546 RVA: 0x00011FDC File Offset: 0x000101DC
		public byte[] GetBytes()
		{
			ASN1 asn = new ASN1(48);
			ArrayList arrayList = new ArrayList();
			foreach (object obj in this._safeBags)
			{
				SafeBag safeBag = (SafeBag)obj;
				if (safeBag.BagOID.Equals("1.2.840.113549.1.12.10.1.3"))
				{
					ASN1 asn2 = safeBag.ASN1;
					ASN1 asn3 = asn2[1];
					PKCS7.ContentInfo contentInfo = new PKCS7.ContentInfo(asn3.Value);
					arrayList.Add(new X509Certificate(contentInfo.Content[0].Value));
				}
			}
			ArrayList arrayList2 = new ArrayList();
			ArrayList arrayList3 = new ArrayList();
			foreach (X509Certificate x509Certificate in this.Certificates)
			{
				bool flag = false;
				foreach (object obj2 in arrayList)
				{
					X509Certificate x509Certificate2 = (X509Certificate)obj2;
					if (this.Compare(x509Certificate.RawData, x509Certificate2.RawData))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					arrayList2.Add(x509Certificate);
				}
			}
			foreach (object obj3 in arrayList)
			{
				X509Certificate x509Certificate3 = (X509Certificate)obj3;
				bool flag2 = false;
				foreach (X509Certificate x509Certificate4 in this.Certificates)
				{
					if (this.Compare(x509Certificate3.RawData, x509Certificate4.RawData))
					{
						flag2 = true;
					}
				}
				if (!flag2)
				{
					arrayList3.Add(x509Certificate3);
				}
			}
			foreach (object obj4 in arrayList3)
			{
				X509Certificate x509Certificate5 = (X509Certificate)obj4;
				this.RemoveCertificate(x509Certificate5);
			}
			foreach (object obj5 in arrayList2)
			{
				X509Certificate x509Certificate6 = (X509Certificate)obj5;
				this.AddCertificate(x509Certificate6);
			}
			if (this._safeBags.Count > 0)
			{
				ASN1 asn4 = new ASN1(48);
				foreach (object obj6 in this._safeBags)
				{
					SafeBag safeBag2 = (SafeBag)obj6;
					if (safeBag2.BagOID.Equals("1.2.840.113549.1.12.10.1.3"))
					{
						asn4.Add(safeBag2.ASN1);
					}
				}
				if (asn4.Count > 0)
				{
					PKCS7.ContentInfo contentInfo2 = this.EncryptedContentInfo(asn4, "1.2.840.113549.1.12.1.3");
					asn.Add(contentInfo2.ASN1);
				}
			}
			if (this._safeBags.Count > 0)
			{
				ASN1 asn5 = new ASN1(48);
				foreach (object obj7 in this._safeBags)
				{
					SafeBag safeBag3 = (SafeBag)obj7;
					if (safeBag3.BagOID.Equals("1.2.840.113549.1.12.10.1.1") || safeBag3.BagOID.Equals("1.2.840.113549.1.12.10.1.2"))
					{
						asn5.Add(safeBag3.ASN1);
					}
				}
				if (asn5.Count > 0)
				{
					ASN1 asn6 = new ASN1(160);
					asn6.Add(new ASN1(4, asn5.GetBytes()));
					asn.Add(new PKCS7.ContentInfo("1.2.840.113549.1.7.1")
					{
						Content = asn6
					}.ASN1);
				}
			}
			if (this._safeBags.Count > 0)
			{
				ASN1 asn7 = new ASN1(48);
				foreach (object obj8 in this._safeBags)
				{
					SafeBag safeBag4 = (SafeBag)obj8;
					if (safeBag4.BagOID.Equals("1.2.840.113549.1.12.10.1.5"))
					{
						asn7.Add(safeBag4.ASN1);
					}
				}
				if (asn7.Count > 0)
				{
					PKCS7.ContentInfo contentInfo3 = this.EncryptedContentInfo(asn7, "1.2.840.113549.1.12.1.3");
					asn.Add(contentInfo3.ASN1);
				}
			}
			ASN1 asn8 = new ASN1(4, asn.GetBytes());
			ASN1 asn9 = new ASN1(160);
			asn9.Add(asn8);
			PKCS7.ContentInfo contentInfo4 = new PKCS7.ContentInfo("1.2.840.113549.1.7.1");
			contentInfo4.Content = asn9;
			ASN1 asn10 = new ASN1(48);
			if (this._password != null)
			{
				byte[] array = new byte[20];
				this.RNG.GetBytes(array);
				byte[] array2 = this.MAC(this._password, array, this._iterations, contentInfo4.Content[0].Value);
				ASN1 asn11 = new ASN1(48);
				asn11.Add(ASN1Convert.FromOid("1.3.14.3.2.26"));
				asn11.Add(new ASN1(5));
				ASN1 asn12 = new ASN1(48);
				asn12.Add(asn11);
				asn12.Add(new ASN1(4, array2));
				asn10.Add(asn12);
				asn10.Add(new ASN1(4, array));
				asn10.Add(ASN1Convert.FromInt32(this._iterations));
			}
			ASN1 asn13 = new ASN1(2, new byte[] { 3 });
			ASN1 asn14 = new ASN1(48);
			asn14.Add(asn13);
			asn14.Add(contentInfo4.ASN1);
			if (asn10.Count > 0)
			{
				asn14.Add(asn10);
			}
			return asn14.GetBytes();
		}

		// Token: 0x06000223 RID: 547 RVA: 0x000126B8 File Offset: 0x000108B8
		private PKCS7.ContentInfo EncryptedContentInfo(ASN1 safeBags, string algorithmOid)
		{
			byte[] array = new byte[8];
			this.RNG.GetBytes(array);
			ASN1 asn = new ASN1(48);
			asn.Add(new ASN1(4, array));
			asn.Add(ASN1Convert.FromInt32(this._iterations));
			ASN1 asn2 = new ASN1(48);
			asn2.Add(ASN1Convert.FromOid(algorithmOid));
			asn2.Add(asn);
			byte[] array2 = this.Encrypt(algorithmOid, array, this._iterations, safeBags.GetBytes());
			ASN1 asn3 = new ASN1(128, array2);
			ASN1 asn4 = new ASN1(48);
			asn4.Add(ASN1Convert.FromOid("1.2.840.113549.1.7.1"));
			asn4.Add(asn2);
			asn4.Add(asn3);
			ASN1 asn5 = new ASN1(2, new byte[1]);
			ASN1 asn6 = new ASN1(48);
			asn6.Add(asn5);
			asn6.Add(asn4);
			ASN1 asn7 = new ASN1(160);
			asn7.Add(asn6);
			return new PKCS7.ContentInfo("1.2.840.113549.1.7.6")
			{
				Content = asn7
			};
		}

		// Token: 0x06000224 RID: 548 RVA: 0x000127C8 File Offset: 0x000109C8
		public void AddCertificate(X509Certificate cert)
		{
			this.AddCertificate(cert, null);
		}

		// Token: 0x06000225 RID: 549 RVA: 0x000127D4 File Offset: 0x000109D4
		public void AddCertificate(X509Certificate cert, IDictionary attributes)
		{
			bool flag = false;
			int num = 0;
			while (!flag && num < this._safeBags.Count)
			{
				SafeBag safeBag = (SafeBag)this._safeBags[num];
				if (safeBag.BagOID.Equals("1.2.840.113549.1.12.10.1.3"))
				{
					ASN1 asn = safeBag.ASN1;
					ASN1 asn2 = asn[1];
					PKCS7.ContentInfo contentInfo = new PKCS7.ContentInfo(asn2.Value);
					X509Certificate x509Certificate = new X509Certificate(contentInfo.Content[0].Value);
					if (this.Compare(cert.RawData, x509Certificate.RawData))
					{
						flag = true;
					}
				}
				num++;
			}
			if (!flag)
			{
				this._safeBags.Add(new SafeBag("1.2.840.113549.1.12.10.1.3", this.CertificateSafeBag(cert, attributes)));
				this._certsChanged = true;
			}
		}

		// Token: 0x06000226 RID: 550 RVA: 0x000128A8 File Offset: 0x00010AA8
		public void RemoveCertificate(X509Certificate cert)
		{
			this.RemoveCertificate(cert, null);
		}

		// Token: 0x06000227 RID: 551 RVA: 0x000128B4 File Offset: 0x00010AB4
		public void RemoveCertificate(X509Certificate cert, IDictionary attrs)
		{
			int num = -1;
			int num2 = 0;
			while (num == -1 && num2 < this._safeBags.Count)
			{
				SafeBag safeBag = (SafeBag)this._safeBags[num2];
				if (safeBag.BagOID.Equals("1.2.840.113549.1.12.10.1.3"))
				{
					ASN1 asn = safeBag.ASN1;
					ASN1 asn2 = asn[1];
					PKCS7.ContentInfo contentInfo = new PKCS7.ContentInfo(asn2.Value);
					X509Certificate x509Certificate = new X509Certificate(contentInfo.Content[0].Value);
					if (this.Compare(cert.RawData, x509Certificate.RawData))
					{
						if (attrs != null)
						{
							if (asn.Count == 3)
							{
								ASN1 asn3 = asn[2];
								int num3 = 0;
								for (int i = 0; i < asn3.Count; i++)
								{
									ASN1 asn4 = asn3[i];
									ASN1 asn5 = asn4[0];
									string text = ASN1Convert.ToOid(asn5);
									ArrayList arrayList = (ArrayList)attrs[text];
									if (arrayList != null)
									{
										ASN1 asn6 = asn4[1];
										if (arrayList.Count == asn6.Count)
										{
											int num4 = 0;
											for (int j = 0; j < asn6.Count; j++)
											{
												ASN1 asn7 = asn6[j];
												byte[] array = (byte[])arrayList[j];
												if (this.Compare(array, asn7.Value))
												{
													num4++;
												}
											}
											if (num4 == asn6.Count)
											{
												num3++;
											}
										}
									}
								}
								if (num3 == asn3.Count)
								{
									num = num2;
								}
							}
						}
						else
						{
							num = num2;
						}
					}
				}
				num2++;
			}
			if (num != -1)
			{
				this._safeBags.RemoveAt(num);
				this._certsChanged = true;
			}
		}

		// Token: 0x06000228 RID: 552 RVA: 0x00012A80 File Offset: 0x00010C80
		public object Clone()
		{
			PKCS12 pkcs;
			if (this._password != null)
			{
				pkcs = new PKCS12(this.GetBytes(), Encoding.BigEndianUnicode.GetString(this._password));
			}
			else
			{
				pkcs = new PKCS12(this.GetBytes());
			}
			pkcs.IterationCount = this.IterationCount;
			return pkcs;
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000229 RID: 553 RVA: 0x00012AD4 File Offset: 0x00010CD4
		public static int MaximumPasswordLength
		{
			get
			{
				return PKCS12.password_max_length;
			}
		}

		// Token: 0x04000181 RID: 385
		public const string pbeWithSHAAnd128BitRC4 = "1.2.840.113549.1.12.1.1";

		// Token: 0x04000182 RID: 386
		public const string pbeWithSHAAnd40BitRC4 = "1.2.840.113549.1.12.1.2";

		// Token: 0x04000183 RID: 387
		public const string pbeWithSHAAnd3KeyTripleDESCBC = "1.2.840.113549.1.12.1.3";

		// Token: 0x04000184 RID: 388
		public const string pbeWithSHAAnd2KeyTripleDESCBC = "1.2.840.113549.1.12.1.4";

		// Token: 0x04000185 RID: 389
		public const string pbeWithSHAAnd128BitRC2CBC = "1.2.840.113549.1.12.1.5";

		// Token: 0x04000186 RID: 390
		public const string pbeWithSHAAnd40BitRC2CBC = "1.2.840.113549.1.12.1.6";

		// Token: 0x04000187 RID: 391
		public const string keyBag = "1.2.840.113549.1.12.10.1.1";

		// Token: 0x04000188 RID: 392
		public const string pkcs8ShroudedKeyBag = "1.2.840.113549.1.12.10.1.2";

		// Token: 0x04000189 RID: 393
		public const string certBag = "1.2.840.113549.1.12.10.1.3";

		// Token: 0x0400018A RID: 394
		public const string crlBag = "1.2.840.113549.1.12.10.1.4";

		// Token: 0x0400018B RID: 395
		public const string secretBag = "1.2.840.113549.1.12.10.1.5";

		// Token: 0x0400018C RID: 396
		public const string safeContentsBag = "1.2.840.113549.1.12.10.1.6";

		// Token: 0x0400018D RID: 397
		public const string x509Certificate = "1.2.840.113549.1.9.22.1";

		// Token: 0x0400018E RID: 398
		public const string sdsiCertificate = "1.2.840.113549.1.9.22.2";

		// Token: 0x0400018F RID: 399
		public const string x509Crl = "1.2.840.113549.1.9.23.1";

		// Token: 0x04000190 RID: 400
		public const int CryptoApiPasswordLimit = 32;

		// Token: 0x04000191 RID: 401
		private static int recommendedIterationCount = 2000;

		// Token: 0x04000192 RID: 402
		private byte[] _password;

		// Token: 0x04000193 RID: 403
		private ArrayList _keyBags;

		// Token: 0x04000194 RID: 404
		private ArrayList _secretBags;

		// Token: 0x04000195 RID: 405
		private X509CertificateCollection _certs;

		// Token: 0x04000196 RID: 406
		private bool _keyBagsChanged;

		// Token: 0x04000197 RID: 407
		private bool _secretBagsChanged;

		// Token: 0x04000198 RID: 408
		private bool _certsChanged;

		// Token: 0x04000199 RID: 409
		private int _iterations;

		// Token: 0x0400019A RID: 410
		private ArrayList _safeBags;

		// Token: 0x0400019B RID: 411
		private RandomNumberGenerator _rng;

		// Token: 0x0400019C RID: 412
		private static int password_max_length = int.MaxValue;

		// Token: 0x02000062 RID: 98
		public class DeriveBytes
		{
			// Token: 0x17000039 RID: 57
			// (set) Token: 0x0600022C RID: 556 RVA: 0x00012B38 File Offset: 0x00010D38
			public string HashName
			{
				set
				{
					this._hashName = value;
				}
			}

			// Token: 0x1700003A RID: 58
			// (set) Token: 0x0600022D RID: 557 RVA: 0x00012B44 File Offset: 0x00010D44
			public int IterationCount
			{
				set
				{
					this._iterations = value;
				}
			}

			// Token: 0x1700003B RID: 59
			// (set) Token: 0x0600022E RID: 558 RVA: 0x00012B50 File Offset: 0x00010D50
			public byte[] Password
			{
				set
				{
					if (value == null)
					{
						this._password = new byte[0];
					}
					else
					{
						this._password = (byte[])value.Clone();
					}
				}
			}

			// Token: 0x1700003C RID: 60
			// (set) Token: 0x0600022F RID: 559 RVA: 0x00012B7C File Offset: 0x00010D7C
			public byte[] Salt
			{
				set
				{
					if (value != null)
					{
						this._salt = (byte[])value.Clone();
					}
					else
					{
						this._salt = null;
					}
				}
			}

			// Token: 0x06000230 RID: 560 RVA: 0x00012BA4 File Offset: 0x00010DA4
			private void Adjust(byte[] a, int aOff, byte[] b)
			{
				int num = (int)((b[b.Length - 1] & byte.MaxValue) + (a[aOff + b.Length - 1] & byte.MaxValue) + 1);
				a[aOff + b.Length - 1] = (byte)num;
				num >>= 8;
				for (int i = b.Length - 2; i >= 0; i--)
				{
					num += (int)((b[i] & byte.MaxValue) + (a[aOff + i] & byte.MaxValue));
					a[aOff + i] = (byte)num;
					num >>= 8;
				}
			}

			// Token: 0x06000231 RID: 561 RVA: 0x00012C1C File Offset: 0x00010E1C
			private byte[] Derive(byte[] diversifier, int n)
			{
				HashAlgorithm hashAlgorithm = HashAlgorithm.Create(this._hashName);
				int num = hashAlgorithm.HashSize >> 3;
				int num2 = 64;
				byte[] array = new byte[n];
				byte[] array2;
				if (this._salt != null && this._salt.Length != 0)
				{
					array2 = new byte[num2 * ((this._salt.Length + num2 - 1) / num2)];
					for (int num3 = 0; num3 != array2.Length; num3++)
					{
						array2[num3] = this._salt[num3 % this._salt.Length];
					}
				}
				else
				{
					array2 = new byte[0];
				}
				byte[] array3;
				if (this._password != null && this._password.Length != 0)
				{
					array3 = new byte[num2 * ((this._password.Length + num2 - 1) / num2)];
					for (int num4 = 0; num4 != array3.Length; num4++)
					{
						array3[num4] = this._password[num4 % this._password.Length];
					}
				}
				else
				{
					array3 = new byte[0];
				}
				byte[] array4 = new byte[array2.Length + array3.Length];
				Buffer.BlockCopy(array2, 0, array4, 0, array2.Length);
				Buffer.BlockCopy(array3, 0, array4, array2.Length, array3.Length);
				byte[] array5 = new byte[num2];
				int num5 = (n + num - 1) / num;
				for (int i = 1; i <= num5; i++)
				{
					hashAlgorithm.TransformBlock(diversifier, 0, diversifier.Length, diversifier, 0);
					hashAlgorithm.TransformFinalBlock(array4, 0, array4.Length);
					byte[] array6 = hashAlgorithm.Hash;
					hashAlgorithm.Initialize();
					for (int num6 = 1; num6 != this._iterations; num6++)
					{
						array6 = hashAlgorithm.ComputeHash(array6, 0, array6.Length);
					}
					for (int num7 = 0; num7 != array5.Length; num7++)
					{
						array5[num7] = array6[num7 % array6.Length];
					}
					for (int num8 = 0; num8 != array4.Length / num2; num8++)
					{
						this.Adjust(array4, num8 * num2, array5);
					}
					if (i == num5)
					{
						Buffer.BlockCopy(array6, 0, array, (i - 1) * num, array.Length - (i - 1) * num);
					}
					else
					{
						Buffer.BlockCopy(array6, 0, array, (i - 1) * num, array6.Length);
					}
				}
				return array;
			}

			// Token: 0x06000232 RID: 562 RVA: 0x00012E5C File Offset: 0x0001105C
			public byte[] DeriveKey(int size)
			{
				return this.Derive(PKCS12.DeriveBytes.keyDiversifier, size);
			}

			// Token: 0x06000233 RID: 563 RVA: 0x00012E6C File Offset: 0x0001106C
			public byte[] DeriveIV(int size)
			{
				return this.Derive(PKCS12.DeriveBytes.ivDiversifier, size);
			}

			// Token: 0x06000234 RID: 564 RVA: 0x00012E7C File Offset: 0x0001107C
			public byte[] DeriveMAC(int size)
			{
				return this.Derive(PKCS12.DeriveBytes.macDiversifier, size);
			}

			// Token: 0x040001A5 RID: 421
			private static byte[] keyDiversifier = new byte[]
			{
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1
			};

			// Token: 0x040001A6 RID: 422
			private static byte[] ivDiversifier = new byte[]
			{
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2
			};

			// Token: 0x040001A7 RID: 423
			private static byte[] macDiversifier = new byte[]
			{
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3
			};

			// Token: 0x040001A8 RID: 424
			private string _hashName;

			// Token: 0x040001A9 RID: 425
			private int _iterations;

			// Token: 0x040001AA RID: 426
			private byte[] _password;

			// Token: 0x040001AB RID: 427
			private byte[] _salt;
		}
	}
}
