﻿using System;

namespace Mono.Security.X509
{
	// Token: 0x02000063 RID: 99
	internal class SafeBag
	{
		// Token: 0x06000235 RID: 565 RVA: 0x00012E8C File Offset: 0x0001108C
		public SafeBag(string bagOID, ASN1 asn1)
		{
			this._bagOID = bagOID;
			this._asn1 = asn1;
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000236 RID: 566 RVA: 0x00012EA4 File Offset: 0x000110A4
		public string BagOID
		{
			get
			{
				return this._bagOID;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000237 RID: 567 RVA: 0x00012EAC File Offset: 0x000110AC
		public ASN1 ASN1
		{
			get
			{
				return this._asn1;
			}
		}

		// Token: 0x040001AC RID: 428
		private string _bagOID;

		// Token: 0x040001AD RID: 429
		private ASN1 _asn1;
	}
}
