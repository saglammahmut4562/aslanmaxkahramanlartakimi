﻿using System;
using System.Text;

namespace Mono.Security.X509
{
	// Token: 0x02000064 RID: 100
	internal sealed class X501
	{
		// Token: 0x06000239 RID: 569 RVA: 0x00013030 File Offset: 0x00011230
		public static string ToString(ASN1 seq)
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < seq.Count; i++)
			{
				ASN1 asn = seq[i];
				X501.AppendEntry(stringBuilder, asn, true);
				if (i < seq.Count - 1)
				{
					stringBuilder.Append(", ");
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600023A RID: 570 RVA: 0x0001308C File Offset: 0x0001128C
		public static string ToString(ASN1 seq, bool reversed, string separator, bool quotes)
		{
			StringBuilder stringBuilder = new StringBuilder();
			if (reversed)
			{
				for (int i = seq.Count - 1; i >= 0; i--)
				{
					ASN1 asn = seq[i];
					X501.AppendEntry(stringBuilder, asn, quotes);
					if (i > 0)
					{
						stringBuilder.Append(separator);
					}
				}
			}
			else
			{
				for (int j = 0; j < seq.Count; j++)
				{
					ASN1 asn2 = seq[j];
					X501.AppendEntry(stringBuilder, asn2, quotes);
					if (j < seq.Count - 1)
					{
						stringBuilder.Append(separator);
					}
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600023B RID: 571 RVA: 0x00013128 File Offset: 0x00011328
		private static void AppendEntry(StringBuilder sb, ASN1 entry, bool quotes)
		{
			for (int i = 0; i < entry.Count; i++)
			{
				ASN1 asn = entry[i];
				ASN1 asn2 = asn[1];
				if (asn2 != null)
				{
					ASN1 asn3 = asn[0];
					if (asn3 != null)
					{
						if (asn3.CompareValue(X501.countryName))
						{
							sb.Append("C=");
						}
						else if (asn3.CompareValue(X501.organizationName))
						{
							sb.Append("O=");
						}
						else if (asn3.CompareValue(X501.organizationalUnitName))
						{
							sb.Append("OU=");
						}
						else if (asn3.CompareValue(X501.commonName))
						{
							sb.Append("CN=");
						}
						else if (asn3.CompareValue(X501.localityName))
						{
							sb.Append("L=");
						}
						else if (asn3.CompareValue(X501.stateOrProvinceName))
						{
							sb.Append("S=");
						}
						else if (asn3.CompareValue(X501.streetAddress))
						{
							sb.Append("STREET=");
						}
						else if (asn3.CompareValue(X501.domainComponent))
						{
							sb.Append("DC=");
						}
						else if (asn3.CompareValue(X501.userid))
						{
							sb.Append("UID=");
						}
						else if (asn3.CompareValue(X501.email))
						{
							sb.Append("E=");
						}
						else if (asn3.CompareValue(X501.dnQualifier))
						{
							sb.Append("dnQualifier=");
						}
						else if (asn3.CompareValue(X501.title))
						{
							sb.Append("T=");
						}
						else if (asn3.CompareValue(X501.surname))
						{
							sb.Append("SN=");
						}
						else if (asn3.CompareValue(X501.givenName))
						{
							sb.Append("G=");
						}
						else if (asn3.CompareValue(X501.initial))
						{
							sb.Append("I=");
						}
						else
						{
							sb.Append("OID.");
							sb.Append(ASN1Convert.ToOid(asn3));
							sb.Append("=");
						}
						string text;
						if (asn2.Tag == 30)
						{
							StringBuilder stringBuilder = new StringBuilder();
							for (int j = 1; j < asn2.Value.Length; j += 2)
							{
								stringBuilder.Append((char)asn2.Value[j]);
							}
							text = stringBuilder.ToString();
						}
						else
						{
							if (asn2.Tag == 20)
							{
								text = Encoding.UTF7.GetString(asn2.Value);
							}
							else
							{
								text = Encoding.UTF8.GetString(asn2.Value);
							}
							char[] array = new char[] { ',', '+', '"', '\\', '<', '>', ';' };
							if (quotes && (text.IndexOfAny(array, 0, text.Length) > 0 || text.StartsWith(" ") || text.EndsWith(" ")))
							{
								text = "\"" + text + "\"";
							}
						}
						sb.Append(text);
						if (i < entry.Count - 1)
						{
							sb.Append(", ");
						}
					}
				}
			}
		}

		// Token: 0x040001AE RID: 430
		private static byte[] countryName = new byte[] { 85, 4, 6 };

		// Token: 0x040001AF RID: 431
		private static byte[] organizationName = new byte[] { 85, 4, 10 };

		// Token: 0x040001B0 RID: 432
		private static byte[] organizationalUnitName = new byte[] { 85, 4, 11 };

		// Token: 0x040001B1 RID: 433
		private static byte[] commonName = new byte[] { 85, 4, 3 };

		// Token: 0x040001B2 RID: 434
		private static byte[] localityName = new byte[] { 85, 4, 7 };

		// Token: 0x040001B3 RID: 435
		private static byte[] stateOrProvinceName = new byte[] { 85, 4, 8 };

		// Token: 0x040001B4 RID: 436
		private static byte[] streetAddress = new byte[] { 85, 4, 9 };

		// Token: 0x040001B5 RID: 437
		private static byte[] domainComponent = new byte[] { 9, 146, 38, 137, 147, 242, 44, 100, 1, 25 };

		// Token: 0x040001B6 RID: 438
		private static byte[] userid = new byte[] { 9, 146, 38, 137, 147, 242, 44, 100, 1, 1 };

		// Token: 0x040001B7 RID: 439
		private static byte[] email = new byte[] { 42, 134, 72, 134, 247, 13, 1, 9, 1 };

		// Token: 0x040001B8 RID: 440
		private static byte[] dnQualifier = new byte[] { 85, 4, 46 };

		// Token: 0x040001B9 RID: 441
		private static byte[] title = new byte[] { 85, 4, 12 };

		// Token: 0x040001BA RID: 442
		private static byte[] surname = new byte[] { 85, 4, 4 };

		// Token: 0x040001BB RID: 443
		private static byte[] givenName = new byte[] { 85, 4, 42 };

		// Token: 0x040001BC RID: 444
		private static byte[] initial = new byte[] { 85, 4, 43 };
	}
}
