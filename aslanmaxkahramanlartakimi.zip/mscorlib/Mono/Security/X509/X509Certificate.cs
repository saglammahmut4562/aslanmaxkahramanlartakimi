﻿using System;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;

namespace Mono.Security.X509
{
	// Token: 0x02000065 RID: 101
	internal class X509Certificate : ISerializable
	{
		// Token: 0x0600023C RID: 572 RVA: 0x000134A0 File Offset: 0x000116A0
		public X509Certificate(byte[] data)
		{
			if (data != null)
			{
				if (data.Length > 0 && data[0] != 48)
				{
					try
					{
						data = X509Certificate.PEM("CERTIFICATE", data);
					}
					catch (Exception ex)
					{
						throw new CryptographicException(X509Certificate.encoding_error, ex);
					}
				}
				this.Parse(data);
			}
		}

		// Token: 0x0600023E RID: 574 RVA: 0x0001351C File Offset: 0x0001171C
		private void Parse(byte[] data)
		{
			try
			{
				this.decoder = new ASN1(data);
				if (this.decoder.Tag != 48)
				{
					throw new CryptographicException(X509Certificate.encoding_error);
				}
				if (this.decoder[0].Tag != 48)
				{
					throw new CryptographicException(X509Certificate.encoding_error);
				}
				ASN1 asn = this.decoder[0];
				int num = 0;
				ASN1 asn2 = this.decoder[0][num];
				this.version = 1;
				if (asn2.Tag == 160 && asn2.Count > 0)
				{
					this.version += (int)asn2[0].Value[0];
					num++;
				}
				ASN1 asn3 = this.decoder[0][num++];
				if (asn3.Tag != 2)
				{
					throw new CryptographicException(X509Certificate.encoding_error);
				}
				this.serialnumber = asn3.Value;
				Array.Reverse(this.serialnumber, 0, this.serialnumber.Length);
				num++;
				this.issuer = asn.Element(num++, 48);
				this.m_issuername = X501.ToString(this.issuer);
				ASN1 asn4 = asn.Element(num++, 48);
				ASN1 asn5 = asn4[0];
				this.m_from = ASN1Convert.ToDateTime(asn5);
				ASN1 asn6 = asn4[1];
				this.m_until = ASN1Convert.ToDateTime(asn6);
				this.subject = asn.Element(num++, 48);
				this.m_subject = X501.ToString(this.subject);
				ASN1 asn7 = asn.Element(num++, 48);
				ASN1 asn8 = asn7.Element(0, 48);
				ASN1 asn9 = asn8.Element(0, 6);
				this.m_keyalgo = ASN1Convert.ToOid(asn9);
				ASN1 asn10 = asn8[1];
				this.m_keyalgoparams = ((asn8.Count <= 1) ? null : asn10.GetBytes());
				ASN1 asn11 = asn7.Element(1, 3);
				int num2 = asn11.Length - 1;
				this.m_publickey = new byte[num2];
				Buffer.BlockCopy(asn11.Value, 1, this.m_publickey, 0, num2);
				byte[] value = this.decoder[2].Value;
				this.signature = new byte[value.Length - 1];
				Buffer.BlockCopy(value, 1, this.signature, 0, this.signature.Length);
				asn8 = this.decoder[1];
				asn9 = asn8.Element(0, 6);
				this.m_signaturealgo = ASN1Convert.ToOid(asn9);
				asn10 = asn8[1];
				if (asn10 != null)
				{
					this.m_signaturealgoparams = asn10.GetBytes();
				}
				else
				{
					this.m_signaturealgoparams = null;
				}
				ASN1 asn12 = asn.Element(num, 129);
				if (asn12 != null)
				{
					num++;
					this.issuerUniqueID = asn12.Value;
				}
				ASN1 asn13 = asn.Element(num, 130);
				if (asn13 != null)
				{
					num++;
					this.subjectUniqueID = asn13.Value;
				}
				ASN1 asn14 = asn.Element(num, 163);
				if (asn14 != null && asn14.Count == 1)
				{
					this.extensions = new X509ExtensionCollection(asn14[0]);
				}
				else
				{
					this.extensions = new X509ExtensionCollection(null);
				}
				this.m_encodedcert = (byte[])data.Clone();
			}
			catch (Exception ex)
			{
				throw new CryptographicException(X509Certificate.encoding_error, ex);
			}
		}

		// Token: 0x0600023F RID: 575 RVA: 0x000138AC File Offset: 0x00011AAC
		private byte[] GetUnsignedBigInteger(byte[] integer)
		{
			if (integer[0] == 0)
			{
				int num = integer.Length - 1;
				byte[] array = new byte[num];
				Buffer.BlockCopy(integer, 1, array, 0, num);
				return array;
			}
			return integer;
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000240 RID: 576 RVA: 0x000138DC File Offset: 0x00011ADC
		public DSA DSA
		{
			get
			{
				if (this.m_keyalgoparams == null)
				{
					throw new CryptographicException("Missing key algorithm parameters.");
				}
				if (this._dsa == null)
				{
					DSAParameters dsaparameters = default(DSAParameters);
					ASN1 asn = new ASN1(this.m_publickey);
					if (asn == null || asn.Tag != 2)
					{
						return null;
					}
					dsaparameters.Y = this.GetUnsignedBigInteger(asn.Value);
					ASN1 asn2 = new ASN1(this.m_keyalgoparams);
					if (asn2 == null || asn2.Tag != 48 || asn2.Count < 3)
					{
						return null;
					}
					if (asn2[0].Tag != 2 || asn2[1].Tag != 2 || asn2[2].Tag != 2)
					{
						return null;
					}
					dsaparameters.P = this.GetUnsignedBigInteger(asn2[0].Value);
					dsaparameters.Q = this.GetUnsignedBigInteger(asn2[1].Value);
					dsaparameters.G = this.GetUnsignedBigInteger(asn2[2].Value);
					this._dsa = new DSACryptoServiceProvider(dsaparameters.Y.Length << 3);
					this._dsa.ImportParameters(dsaparameters);
				}
				return this._dsa;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000241 RID: 577 RVA: 0x00013A20 File Offset: 0x00011C20
		public virtual byte[] KeyAlgorithmParameters
		{
			get
			{
				if (this.m_keyalgoparams == null)
				{
					return null;
				}
				return (byte[])this.m_keyalgoparams.Clone();
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000242 RID: 578 RVA: 0x00013A40 File Offset: 0x00011C40
		public virtual byte[] RawData
		{
			get
			{
				if (this.m_encodedcert == null)
				{
					return null;
				}
				return (byte[])this.m_encodedcert.Clone();
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000243 RID: 579 RVA: 0x00013A60 File Offset: 0x00011C60
		public virtual DateTime ValidFrom
		{
			get
			{
				return this.m_from;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000244 RID: 580 RVA: 0x00013A68 File Offset: 0x00011C68
		public virtual DateTime ValidUntil
		{
			get
			{
				return this.m_until;
			}
		}

		// Token: 0x06000245 RID: 581 RVA: 0x00013A70 File Offset: 0x00011C70
		public ASN1 GetIssuerName()
		{
			return this.issuer;
		}

		// Token: 0x06000246 RID: 582 RVA: 0x00013A78 File Offset: 0x00011C78
		public ASN1 GetSubjectName()
		{
			return this.subject;
		}

		// Token: 0x06000247 RID: 583 RVA: 0x00013A80 File Offset: 0x00011C80
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("raw", this.m_encodedcert);
		}

		// Token: 0x06000248 RID: 584 RVA: 0x00013A94 File Offset: 0x00011C94
		private static byte[] PEM(string type, byte[] data)
		{
			string @string = Encoding.ASCII.GetString(data);
			string text = string.Format("-----BEGIN {0}-----", type);
			string text2 = string.Format("-----END {0}-----", type);
			int num = @string.IndexOf(text) + text.Length;
			int num2 = @string.IndexOf(text2, num);
			string text3 = @string.Substring(num, num2 - num);
			return Convert.FromBase64String(text3);
		}

		// Token: 0x040001BE RID: 446
		private ASN1 decoder;

		// Token: 0x040001BF RID: 447
		private byte[] m_encodedcert;

		// Token: 0x040001C0 RID: 448
		private DateTime m_from;

		// Token: 0x040001C1 RID: 449
		private DateTime m_until;

		// Token: 0x040001C2 RID: 450
		private ASN1 issuer;

		// Token: 0x040001C3 RID: 451
		private string m_issuername;

		// Token: 0x040001C4 RID: 452
		private string m_keyalgo;

		// Token: 0x040001C5 RID: 453
		private byte[] m_keyalgoparams;

		// Token: 0x040001C6 RID: 454
		private ASN1 subject;

		// Token: 0x040001C7 RID: 455
		private string m_subject;

		// Token: 0x040001C8 RID: 456
		private byte[] m_publickey;

		// Token: 0x040001C9 RID: 457
		private byte[] signature;

		// Token: 0x040001CA RID: 458
		private string m_signaturealgo;

		// Token: 0x040001CB RID: 459
		private byte[] m_signaturealgoparams;

		// Token: 0x040001CC RID: 460
		private byte[] certhash;

		// Token: 0x040001CD RID: 461
		private RSA _rsa;

		// Token: 0x040001CE RID: 462
		private DSA _dsa;

		// Token: 0x040001CF RID: 463
		private int version;

		// Token: 0x040001D0 RID: 464
		private byte[] serialnumber;

		// Token: 0x040001D1 RID: 465
		private byte[] issuerUniqueID;

		// Token: 0x040001D2 RID: 466
		private byte[] subjectUniqueID;

		// Token: 0x040001D3 RID: 467
		private X509ExtensionCollection extensions;

		// Token: 0x040001D4 RID: 468
		private static string encoding_error = Locale.GetText("Input data cannot be coded as a valid certificate.");
	}
}
