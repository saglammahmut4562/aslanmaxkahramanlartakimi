﻿using System;
using System.Collections;

namespace Mono.Security.X509
{
	// Token: 0x02000066 RID: 102
	[Serializable]
	internal class X509CertificateCollection : CollectionBase, IEnumerable
	{
		// Token: 0x0600024A RID: 586 RVA: 0x00013AFC File Offset: 0x00011CFC
		IEnumerator IEnumerable.GetEnumerator()
		{
			return base.InnerList.GetEnumerator();
		}

		// Token: 0x17000044 RID: 68
		public X509Certificate this[int index]
		{
			get
			{
				return (X509Certificate)base.InnerList[index];
			}
		}

		// Token: 0x0600024C RID: 588 RVA: 0x00013B20 File Offset: 0x00011D20
		public int Add(X509Certificate value)
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			return base.InnerList.Add(value);
		}

		// Token: 0x0600024D RID: 589 RVA: 0x00013B40 File Offset: 0x00011D40
		public new X509CertificateCollection.X509CertificateEnumerator GetEnumerator()
		{
			return new X509CertificateCollection.X509CertificateEnumerator(this);
		}

		// Token: 0x0600024E RID: 590 RVA: 0x00013B48 File Offset: 0x00011D48
		public override int GetHashCode()
		{
			return base.InnerList.GetHashCode();
		}

		// Token: 0x02000067 RID: 103
		public class X509CertificateEnumerator : IEnumerator
		{
			// Token: 0x0600024F RID: 591 RVA: 0x00013B58 File Offset: 0x00011D58
			public X509CertificateEnumerator(X509CertificateCollection mappings)
			{
				this.enumerator = ((IEnumerable)mappings).GetEnumerator();
			}

			// Token: 0x17000045 RID: 69
			// (get) Token: 0x06000250 RID: 592 RVA: 0x00013B6C File Offset: 0x00011D6C
			object IEnumerator.Current
			{
				get
				{
					return this.enumerator.Current;
				}
			}

			// Token: 0x06000251 RID: 593 RVA: 0x00013B7C File Offset: 0x00011D7C
			bool IEnumerator.MoveNext()
			{
				return this.enumerator.MoveNext();
			}

			// Token: 0x06000252 RID: 594 RVA: 0x00013B8C File Offset: 0x00011D8C
			void IEnumerator.Reset()
			{
				this.enumerator.Reset();
			}

			// Token: 0x17000046 RID: 70
			// (get) Token: 0x06000253 RID: 595 RVA: 0x00013B9C File Offset: 0x00011D9C
			public X509Certificate Current
			{
				get
				{
					return (X509Certificate)this.enumerator.Current;
				}
			}

			// Token: 0x06000254 RID: 596 RVA: 0x00013BB0 File Offset: 0x00011DB0
			public bool MoveNext()
			{
				return this.enumerator.MoveNext();
			}

			// Token: 0x06000255 RID: 597 RVA: 0x00013BC0 File Offset: 0x00011DC0
			public void Reset()
			{
				this.enumerator.Reset();
			}

			// Token: 0x040001D8 RID: 472
			private IEnumerator enumerator;
		}
	}
}
