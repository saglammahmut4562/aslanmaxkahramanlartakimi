﻿using System;
using System.Globalization;
using System.Text;

namespace Mono.Security.X509
{
	// Token: 0x02000068 RID: 104
	internal class X509Extension
	{
		// Token: 0x06000256 RID: 598 RVA: 0x00013BD0 File Offset: 0x00011DD0
		public X509Extension(ASN1 asn1)
		{
			if (asn1.Tag != 48 || asn1.Count < 2)
			{
				throw new ArgumentException(Locale.GetText("Invalid X.509 extension."));
			}
			if (asn1[0].Tag != 6)
			{
				throw new ArgumentException(Locale.GetText("Invalid X.509 extension."));
			}
			this.extnOid = ASN1Convert.ToOid(asn1[0]);
			this.extnCritical = asn1[1].Tag == 1 && asn1[1].Value[0] == byte.MaxValue;
			this.extnValue = asn1[asn1.Count - 1];
			if (this.extnValue.Tag == 4 && this.extnValue.Length > 0 && this.extnValue.Count == 0)
			{
				try
				{
					ASN1 asn2 = new ASN1(this.extnValue.Value);
					this.extnValue.Value = null;
					this.extnValue.Add(asn2);
				}
				catch
				{
				}
			}
			this.Decode();
		}

		// Token: 0x06000257 RID: 599 RVA: 0x00013D04 File Offset: 0x00011F04
		protected virtual void Decode()
		{
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00013D08 File Offset: 0x00011F08
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			X509Extension x509Extension = obj as X509Extension;
			if (x509Extension == null)
			{
				return false;
			}
			if (this.extnCritical != x509Extension.extnCritical)
			{
				return false;
			}
			if (this.extnOid != x509Extension.extnOid)
			{
				return false;
			}
			if (this.extnValue.Length != x509Extension.extnValue.Length)
			{
				return false;
			}
			for (int i = 0; i < this.extnValue.Length; i++)
			{
				if (this.extnValue[i] != x509Extension.extnValue[i])
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000259 RID: 601 RVA: 0x00013DB0 File Offset: 0x00011FB0
		public override int GetHashCode()
		{
			return this.extnOid.GetHashCode();
		}

		// Token: 0x0600025A RID: 602 RVA: 0x00013DC0 File Offset: 0x00011FC0
		private void WriteLine(StringBuilder sb, int n, int pos)
		{
			byte[] value = this.extnValue.Value;
			int num = pos;
			for (int i = 0; i < 8; i++)
			{
				if (i < n)
				{
					sb.Append(value[num++].ToString("X2", CultureInfo.InvariantCulture));
					sb.Append(" ");
				}
				else
				{
					sb.Append("   ");
				}
			}
			sb.Append("  ");
			num = pos;
			for (int j = 0; j < n; j++)
			{
				byte b = value[num++];
				if (b < 32)
				{
					sb.Append(".");
				}
				else
				{
					sb.Append(Convert.ToChar(b));
				}
			}
			sb.Append(Environment.NewLine);
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00013E90 File Offset: 0x00012090
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			int num = this.extnValue.Length >> 3;
			int num2 = this.extnValue.Length - (num << 3);
			int num3 = 0;
			for (int i = 0; i < num; i++)
			{
				this.WriteLine(stringBuilder, 8, num3);
				num3 += 8;
			}
			this.WriteLine(stringBuilder, num2, num3);
			return stringBuilder.ToString();
		}

		// Token: 0x040001D9 RID: 473
		protected string extnOid;

		// Token: 0x040001DA RID: 474
		protected bool extnCritical;

		// Token: 0x040001DB RID: 475
		protected ASN1 extnValue;
	}
}
