﻿using System;
using System.Collections;
using System.Reflection;

namespace Mono.Security.X509
{
	// Token: 0x02000069 RID: 105
	[DefaultMember("Item")]
	internal sealed class X509ExtensionCollection : CollectionBase, IEnumerable
	{
		// Token: 0x0600025C RID: 604 RVA: 0x00013EF8 File Offset: 0x000120F8
		public X509ExtensionCollection()
		{
		}

		// Token: 0x0600025D RID: 605 RVA: 0x00013F00 File Offset: 0x00012100
		public X509ExtensionCollection(ASN1 asn1)
			: this()
		{
			this.readOnly = true;
			if (asn1 == null)
			{
				return;
			}
			if (asn1.Tag != 48)
			{
				throw new Exception("Invalid extensions format");
			}
			for (int i = 0; i < asn1.Count; i++)
			{
				X509Extension x509Extension = new X509Extension(asn1[i]);
				base.InnerList.Add(x509Extension);
			}
		}

		// Token: 0x0600025E RID: 606 RVA: 0x00013F6C File Offset: 0x0001216C
		IEnumerator IEnumerable.GetEnumerator()
		{
			return base.InnerList.GetEnumerator();
		}

		// Token: 0x040001DC RID: 476
		private bool readOnly;
	}
}
