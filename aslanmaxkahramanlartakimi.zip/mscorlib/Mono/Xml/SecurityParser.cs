﻿using System;
using System.Collections;
using System.IO;
using System.Security;

namespace Mono.Xml
{
	// Token: 0x0200006A RID: 106
	internal class SecurityParser : SmallXmlParser, SmallXmlParser.IContentHandler
	{
		// Token: 0x0600025F RID: 607 RVA: 0x00013F7C File Offset: 0x0001217C
		public SecurityParser()
		{
			this.stack = new Stack();
		}

		// Token: 0x06000260 RID: 608 RVA: 0x00013F90 File Offset: 0x00012190
		public void LoadXml(string xml)
		{
			this.root = null;
			this.stack.Clear();
			base.Parse(new StringReader(xml), this);
		}

		// Token: 0x06000261 RID: 609 RVA: 0x00013FB4 File Offset: 0x000121B4
		public SecurityElement ToXml()
		{
			return this.root;
		}

		// Token: 0x06000262 RID: 610 RVA: 0x00013FBC File Offset: 0x000121BC
		public void OnStartParsing(SmallXmlParser parser)
		{
		}

		// Token: 0x06000263 RID: 611 RVA: 0x00013FC0 File Offset: 0x000121C0
		public void OnProcessingInstruction(string name, string text)
		{
		}

		// Token: 0x06000264 RID: 612 RVA: 0x00013FC4 File Offset: 0x000121C4
		public void OnIgnorableWhitespace(string s)
		{
		}

		// Token: 0x06000265 RID: 613 RVA: 0x00013FC8 File Offset: 0x000121C8
		public void OnStartElement(string name, SmallXmlParser.IAttrList attrs)
		{
			SecurityElement securityElement = new SecurityElement(name);
			if (this.root == null)
			{
				this.root = securityElement;
				this.current = securityElement;
			}
			else
			{
				SecurityElement securityElement2 = (SecurityElement)this.stack.Peek();
				securityElement2.AddChild(securityElement);
			}
			this.stack.Push(securityElement);
			this.current = securityElement;
			int length = attrs.Length;
			for (int i = 0; i < length; i++)
			{
				this.current.AddAttribute(attrs.GetName(i), SecurityElement.Escape(attrs.GetValue(i)));
			}
		}

		// Token: 0x06000266 RID: 614 RVA: 0x0001405C File Offset: 0x0001225C
		public void OnEndElement(string name)
		{
			this.current = (SecurityElement)this.stack.Pop();
		}

		// Token: 0x06000267 RID: 615 RVA: 0x00014074 File Offset: 0x00012274
		public void OnChars(string ch)
		{
			this.current.Text = SecurityElement.Escape(ch);
		}

		// Token: 0x06000268 RID: 616 RVA: 0x00014088 File Offset: 0x00012288
		public void OnEndParsing(SmallXmlParser parser)
		{
		}

		// Token: 0x040001DD RID: 477
		private SecurityElement root;

		// Token: 0x040001DE RID: 478
		private SecurityElement current;

		// Token: 0x040001DF RID: 479
		private Stack stack;
	}
}
