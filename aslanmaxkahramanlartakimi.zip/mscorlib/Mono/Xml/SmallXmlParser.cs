﻿using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;

namespace Mono.Xml
{
	// Token: 0x0200006B RID: 107
	internal class SmallXmlParser
	{
		// Token: 0x0600026A RID: 618 RVA: 0x000140E4 File Offset: 0x000122E4
		private Exception Error(string msg)
		{
			return new SmallXmlParserException(msg, this.line, this.column);
		}

		// Token: 0x0600026B RID: 619 RVA: 0x000140F8 File Offset: 0x000122F8
		private Exception UnexpectedEndError()
		{
			string[] array = new string[this.elementNames.Count];
			this.elementNames.CopyTo(array, 0);
			return this.Error(string.Format("Unexpected end of stream. Element stack content is {0}", string.Join(",", array)));
		}

		// Token: 0x0600026C RID: 620 RVA: 0x00014140 File Offset: 0x00012340
		private bool IsNameChar(char c, bool start)
		{
			if (c == '-' || c == '.')
			{
				return !start;
			}
			if (c == ':' || c == '_')
			{
				return true;
			}
			if (c > 'Ā')
			{
				if (c == 'ۥ' || c == 'ۦ' || c == 'ՙ')
				{
					return true;
				}
				if ('ʻ' <= c && c <= 'ˁ')
				{
					return true;
				}
			}
			switch (char.GetUnicodeCategory(c))
			{
			case UnicodeCategory.UppercaseLetter:
			case UnicodeCategory.LowercaseLetter:
			case UnicodeCategory.TitlecaseLetter:
			case UnicodeCategory.OtherLetter:
			case UnicodeCategory.LetterNumber:
				return true;
			case UnicodeCategory.ModifierLetter:
			case UnicodeCategory.NonSpacingMark:
			case UnicodeCategory.SpacingCombiningMark:
			case UnicodeCategory.EnclosingMark:
			case UnicodeCategory.DecimalDigitNumber:
				return !start;
			default:
				return false;
			}
		}

		// Token: 0x0600026D RID: 621 RVA: 0x0001420C File Offset: 0x0001240C
		private bool IsWhitespace(int c)
		{
			switch (c)
			{
			case 9:
			case 10:
			case 13:
				break;
			default:
				if (c != 32)
				{
					return false;
				}
				break;
			}
			return true;
		}

		// Token: 0x0600026E RID: 622 RVA: 0x00014248 File Offset: 0x00012448
		public void SkipWhitespaces()
		{
			this.SkipWhitespaces(false);
		}

		// Token: 0x0600026F RID: 623 RVA: 0x00014254 File Offset: 0x00012454
		private void HandleWhitespaces()
		{
			while (this.IsWhitespace(this.Peek()))
			{
				this.buffer.Append((char)this.Read());
			}
			if (this.Peek() != 60 && this.Peek() >= 0)
			{
				this.isWhitespace = false;
			}
		}

		// Token: 0x06000270 RID: 624 RVA: 0x000142AC File Offset: 0x000124AC
		public void SkipWhitespaces(bool expected)
		{
			for (;;)
			{
				int num = this.Peek();
				switch (num)
				{
				case 9:
				case 10:
				case 13:
					break;
				default:
					if (num != 32)
					{
						goto Block_0;
					}
					break;
				}
				this.Read();
				if (expected)
				{
					expected = false;
				}
			}
			Block_0:
			if (expected)
			{
				throw this.Error("Whitespace is expected.");
			}
		}

		// Token: 0x06000271 RID: 625 RVA: 0x00014318 File Offset: 0x00012518
		private int Peek()
		{
			return this.reader.Peek();
		}

		// Token: 0x06000272 RID: 626 RVA: 0x00014328 File Offset: 0x00012528
		private int Read()
		{
			int num = this.reader.Read();
			if (num == 10)
			{
				this.resetColumn = true;
			}
			if (this.resetColumn)
			{
				this.line++;
				this.resetColumn = false;
				this.column = 1;
			}
			else
			{
				this.column++;
			}
			return num;
		}

		// Token: 0x06000273 RID: 627 RVA: 0x0001438C File Offset: 0x0001258C
		public void Expect(int c)
		{
			int num = this.Read();
			if (num < 0)
			{
				throw this.UnexpectedEndError();
			}
			if (num != c)
			{
				throw this.Error(string.Format("Expected '{0}' but got {1}", (char)c, (char)num));
			}
		}

		// Token: 0x06000274 RID: 628 RVA: 0x000143D4 File Offset: 0x000125D4
		private string ReadUntil(char until, bool handleReferences)
		{
			while (this.Peek() >= 0)
			{
				char c = (char)this.Read();
				if (c == until)
				{
					string text = this.buffer.ToString();
					this.buffer.Length = 0;
					return text;
				}
				if (handleReferences && c == '&')
				{
					this.ReadReference();
				}
				else
				{
					this.buffer.Append(c);
				}
			}
			throw this.UnexpectedEndError();
		}

		// Token: 0x06000275 RID: 629 RVA: 0x0001444C File Offset: 0x0001264C
		public string ReadName()
		{
			int num = 0;
			if (this.Peek() < 0 || !this.IsNameChar((char)this.Peek(), true))
			{
				throw this.Error("XML name start character is expected.");
			}
			for (int i = this.Peek(); i >= 0; i = this.Peek())
			{
				char c = (char)i;
				if (!this.IsNameChar(c, false))
				{
					break;
				}
				if (num == this.nameBuffer.Length)
				{
					char[] array = new char[num * 2];
					Array.Copy(this.nameBuffer, array, num);
					this.nameBuffer = array;
				}
				this.nameBuffer[num++] = c;
				this.Read();
			}
			if (num == 0)
			{
				throw this.Error("Valid XML name is expected.");
			}
			return new string(this.nameBuffer, 0, num);
		}

		// Token: 0x06000276 RID: 630 RVA: 0x00014514 File Offset: 0x00012714
		public void Parse(TextReader input, SmallXmlParser.IContentHandler handler)
		{
			this.reader = input;
			this.handler = handler;
			handler.OnStartParsing(this);
			while (this.Peek() >= 0)
			{
				this.ReadContent();
			}
			this.HandleBufferedContent();
			if (this.elementNames.Count > 0)
			{
				throw this.Error(string.Format("Insufficient close tag: {0}", this.elementNames.Peek()));
			}
			handler.OnEndParsing(this);
			this.Cleanup();
		}

		// Token: 0x06000277 RID: 631 RVA: 0x00014590 File Offset: 0x00012790
		private void Cleanup()
		{
			this.line = 1;
			this.column = 0;
			this.handler = null;
			this.reader = null;
			this.elementNames.Clear();
			this.xmlSpaces.Clear();
			this.attributes.Clear();
			this.buffer.Length = 0;
			this.xmlSpace = null;
			this.isWhitespace = false;
		}

		// Token: 0x06000278 RID: 632 RVA: 0x000145F4 File Offset: 0x000127F4
		public void ReadContent()
		{
			if (this.IsWhitespace(this.Peek()))
			{
				if (this.buffer.Length == 0)
				{
					this.isWhitespace = true;
				}
				this.HandleWhitespaces();
			}
			if (this.Peek() != 60)
			{
				this.ReadCharacters();
				return;
			}
			this.Read();
			int num = this.Peek();
			if (num != 33)
			{
				if (num != 47)
				{
					string text;
					if (num != 63)
					{
						this.HandleBufferedContent();
						text = this.ReadName();
						while (this.Peek() != 62 && this.Peek() != 47)
						{
							this.ReadAttribute(this.attributes);
						}
						this.handler.OnStartElement(text, this.attributes);
						this.attributes.Clear();
						this.SkipWhitespaces();
						if (this.Peek() == 47)
						{
							this.Read();
							this.handler.OnEndElement(text);
						}
						else
						{
							this.elementNames.Push(text);
							this.xmlSpaces.Push(this.xmlSpace);
						}
						this.Expect(62);
						return;
					}
					this.HandleBufferedContent();
					this.Read();
					text = this.ReadName();
					this.SkipWhitespaces();
					string text2 = string.Empty;
					if (this.Peek() != 63)
					{
						for (;;)
						{
							text2 += this.ReadUntil('?', false);
							if (this.Peek() == 62)
							{
								break;
							}
							text2 += "?";
						}
					}
					this.handler.OnProcessingInstruction(text, text2);
					this.Expect(62);
					return;
				}
				else
				{
					this.HandleBufferedContent();
					if (this.elementNames.Count == 0)
					{
						throw this.UnexpectedEndError();
					}
					this.Read();
					string text = this.ReadName();
					this.SkipWhitespaces();
					string text3 = (string)this.elementNames.Pop();
					this.xmlSpaces.Pop();
					if (this.xmlSpaces.Count > 0)
					{
						this.xmlSpace = (string)this.xmlSpaces.Peek();
					}
					else
					{
						this.xmlSpace = null;
					}
					if (text != text3)
					{
						throw this.Error(string.Format("End tag mismatch: expected {0} but found {1}", text3, text));
					}
					this.handler.OnEndElement(text);
					this.Expect(62);
					return;
				}
			}
			else
			{
				this.Read();
				if (this.Peek() == 91)
				{
					this.Read();
					if (this.ReadName() != "CDATA")
					{
						throw this.Error("Invalid declaration markup");
					}
					this.Expect(91);
					this.ReadCDATASection();
					return;
				}
				else
				{
					if (this.Peek() == 45)
					{
						this.ReadComment();
						return;
					}
					if (this.ReadName() != "DOCTYPE")
					{
						throw this.Error("Invalid declaration markup.");
					}
					throw this.Error("This parser does not support document type.");
				}
			}
		}

		// Token: 0x06000279 RID: 633 RVA: 0x000148CC File Offset: 0x00012ACC
		private void HandleBufferedContent()
		{
			if (this.buffer.Length == 0)
			{
				return;
			}
			if (this.isWhitespace)
			{
				this.handler.OnIgnorableWhitespace(this.buffer.ToString());
			}
			else
			{
				this.handler.OnChars(this.buffer.ToString());
			}
			this.buffer.Length = 0;
			this.isWhitespace = false;
		}

		// Token: 0x0600027A RID: 634 RVA: 0x0001493C File Offset: 0x00012B3C
		private void ReadCharacters()
		{
			this.isWhitespace = false;
			for (;;)
			{
				int num = this.Peek();
				int num2 = num;
				if (num2 == -1)
				{
					break;
				}
				if (num2 != 38)
				{
					if (num2 == 60)
					{
						return;
					}
					this.buffer.Append((char)this.Read());
				}
				else
				{
					this.Read();
					this.ReadReference();
				}
			}
		}

		// Token: 0x0600027B RID: 635 RVA: 0x000149A8 File Offset: 0x00012BA8
		private void ReadReference()
		{
			if (this.Peek() != 35)
			{
				string text = this.ReadName();
				this.Expect(59);
				string text2 = text;
				switch (text2)
				{
				case "amp":
					this.buffer.Append('&');
					return;
				case "quot":
					this.buffer.Append('"');
					return;
				case "apos":
					this.buffer.Append('\'');
					return;
				case "lt":
					this.buffer.Append('<');
					return;
				case "gt":
					this.buffer.Append('>');
					return;
				}
				throw this.Error("General non-predefined entity reference is not supported in this parser.");
			}
			this.Read();
			this.ReadCharacterReference();
		}

		// Token: 0x0600027C RID: 636 RVA: 0x00014ADC File Offset: 0x00012CDC
		private int ReadCharacterReference()
		{
			int num = 0;
			if (this.Peek() == 120)
			{
				this.Read();
				for (int i = this.Peek(); i >= 0; i = this.Peek())
				{
					if (48 <= i && i <= 57)
					{
						num <<= 4 + i - 48;
					}
					else if (65 <= i && i <= 70)
					{
						num <<= 4 + i - 65 + 10;
					}
					else
					{
						if (97 > i || i > 102)
						{
							break;
						}
						num <<= 4 + i - 97 + 10;
					}
					this.Read();
				}
			}
			else
			{
				for (int j = this.Peek(); j >= 0; j = this.Peek())
				{
					if (48 > j || j > 57)
					{
						break;
					}
					num <<= 4 + j - 48;
					this.Read();
				}
			}
			return num;
		}

		// Token: 0x0600027D RID: 637 RVA: 0x00014BDC File Offset: 0x00012DDC
		private void ReadAttribute(SmallXmlParser.AttrListImpl a)
		{
			this.SkipWhitespaces(true);
			if (this.Peek() == 47 || this.Peek() == 62)
			{
				return;
			}
			string text = this.ReadName();
			this.SkipWhitespaces();
			this.Expect(61);
			this.SkipWhitespaces();
			int num = this.Read();
			string text2;
			if (num != 34)
			{
				if (num != 39)
				{
					throw this.Error("Invalid attribute value markup.");
				}
				text2 = this.ReadUntil('\'', true);
			}
			else
			{
				text2 = this.ReadUntil('"', true);
			}
			if (text == "xml:space")
			{
				this.xmlSpace = text2;
			}
			a.Add(text, text2);
		}

		// Token: 0x0600027E RID: 638 RVA: 0x00014C8C File Offset: 0x00012E8C
		private void ReadCDATASection()
		{
			int num = 0;
			while (this.Peek() >= 0)
			{
				char c = (char)this.Read();
				if (c == ']')
				{
					num++;
				}
				else
				{
					if (c == '>' && num > 1)
					{
						for (int i = num; i > 2; i--)
						{
							this.buffer.Append(']');
						}
						return;
					}
					for (int j = 0; j < num; j++)
					{
						this.buffer.Append(']');
					}
					num = 0;
					this.buffer.Append(c);
				}
			}
			throw this.UnexpectedEndError();
		}

		// Token: 0x0600027F RID: 639 RVA: 0x00014D30 File Offset: 0x00012F30
		private void ReadComment()
		{
			this.Expect(45);
			this.Expect(45);
			for (;;)
			{
				if (this.Read() == 45)
				{
					if (this.Read() == 45)
					{
						break;
					}
				}
			}
			if (this.Read() != 62)
			{
				throw this.Error("'--' is not allowed inside comment markup.");
			}
		}

		// Token: 0x040001E0 RID: 480
		private SmallXmlParser.IContentHandler handler;

		// Token: 0x040001E1 RID: 481
		private TextReader reader;

		// Token: 0x040001E2 RID: 482
		private Stack elementNames = new Stack();

		// Token: 0x040001E3 RID: 483
		private Stack xmlSpaces = new Stack();

		// Token: 0x040001E4 RID: 484
		private string xmlSpace;

		// Token: 0x040001E5 RID: 485
		private StringBuilder buffer = new StringBuilder(200);

		// Token: 0x040001E6 RID: 486
		private char[] nameBuffer = new char[30];

		// Token: 0x040001E7 RID: 487
		private bool isWhitespace;

		// Token: 0x040001E8 RID: 488
		private SmallXmlParser.AttrListImpl attributes = new SmallXmlParser.AttrListImpl();

		// Token: 0x040001E9 RID: 489
		private int line = 1;

		// Token: 0x040001EA RID: 490
		private int column;

		// Token: 0x040001EB RID: 491
		private bool resetColumn;

		// Token: 0x0200006C RID: 108
		private class AttrListImpl : SmallXmlParser.IAttrList
		{
			// Token: 0x17000047 RID: 71
			// (get) Token: 0x06000281 RID: 641 RVA: 0x00014DB4 File Offset: 0x00012FB4
			public int Length
			{
				get
				{
					return this.attrNames.Count;
				}
			}

			// Token: 0x06000282 RID: 642 RVA: 0x00014DC4 File Offset: 0x00012FC4
			public string GetName(int i)
			{
				return (string)this.attrNames[i];
			}

			// Token: 0x06000283 RID: 643 RVA: 0x00014DD8 File Offset: 0x00012FD8
			public string GetValue(int i)
			{
				return (string)this.attrValues[i];
			}

			// Token: 0x06000284 RID: 644 RVA: 0x00014DEC File Offset: 0x00012FEC
			public string GetValue(string name)
			{
				for (int i = 0; i < this.attrNames.Count; i++)
				{
					if ((string)this.attrNames[i] == name)
					{
						return (string)this.attrValues[i];
					}
				}
				return null;
			}

			// Token: 0x17000048 RID: 72
			// (get) Token: 0x06000285 RID: 645 RVA: 0x00014E44 File Offset: 0x00013044
			public string[] Names
			{
				get
				{
					return (string[])this.attrNames.ToArray(typeof(string));
				}
			}

			// Token: 0x17000049 RID: 73
			// (get) Token: 0x06000286 RID: 646 RVA: 0x00014E60 File Offset: 0x00013060
			public string[] Values
			{
				get
				{
					return (string[])this.attrValues.ToArray(typeof(string));
				}
			}

			// Token: 0x06000287 RID: 647 RVA: 0x00014E7C File Offset: 0x0001307C
			internal void Clear()
			{
				this.attrNames.Clear();
				this.attrValues.Clear();
			}

			// Token: 0x06000288 RID: 648 RVA: 0x00014E94 File Offset: 0x00013094
			internal void Add(string name, string value)
			{
				this.attrNames.Add(name);
				this.attrValues.Add(value);
			}

			// Token: 0x040001ED RID: 493
			private ArrayList attrNames = new ArrayList();

			// Token: 0x040001EE RID: 494
			private ArrayList attrValues = new ArrayList();
		}

		// Token: 0x0200006D RID: 109
		public interface IAttrList
		{
			// Token: 0x1700004A RID: 74
			// (get) Token: 0x06000289 RID: 649
			int Length { get; }

			// Token: 0x0600028A RID: 650
			string GetName(int i);

			// Token: 0x0600028B RID: 651
			string GetValue(int i);

			// Token: 0x0600028C RID: 652
			string GetValue(string name);

			// Token: 0x1700004B RID: 75
			// (get) Token: 0x0600028D RID: 653
			string[] Names { get; }

			// Token: 0x1700004C RID: 76
			// (get) Token: 0x0600028E RID: 654
			string[] Values { get; }
		}

		// Token: 0x0200006E RID: 110
		public interface IContentHandler
		{
			// Token: 0x0600028F RID: 655
			void OnStartParsing(SmallXmlParser parser);

			// Token: 0x06000290 RID: 656
			void OnEndParsing(SmallXmlParser parser);

			// Token: 0x06000291 RID: 657
			void OnStartElement(string name, SmallXmlParser.IAttrList attrs);

			// Token: 0x06000292 RID: 658
			void OnEndElement(string name);

			// Token: 0x06000293 RID: 659
			void OnProcessingInstruction(string name, string text);

			// Token: 0x06000294 RID: 660
			void OnChars(string text);

			// Token: 0x06000295 RID: 661
			void OnIgnorableWhitespace(string text);
		}
	}
}
