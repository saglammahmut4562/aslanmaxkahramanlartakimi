﻿using System;

namespace Mono.Xml
{
	// Token: 0x0200006F RID: 111
	internal class SmallXmlParserException : SystemException
	{
		// Token: 0x06000296 RID: 662 RVA: 0x00014EB0 File Offset: 0x000130B0
		public SmallXmlParserException(string msg, int line, int column)
			: base(string.Format("{0}. At ({1},{2})", msg, line, column))
		{
			this.line = line;
			this.column = column;
		}

		// Token: 0x040001EF RID: 495
		private int line;

		// Token: 0x040001F0 RID: 496
		private int column;
	}
}
