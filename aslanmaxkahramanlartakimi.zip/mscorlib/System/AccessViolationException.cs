﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000071 RID: 113
	[ComVisible(true)]
	[Serializable]
	public class AccessViolationException : SystemException
	{
		// Token: 0x060002AA RID: 682 RVA: 0x0001516C File Offset: 0x0001336C
		public AccessViolationException()
			: base(Locale.GetText("Attempted to read or write protected memory. This is often an indication that other memory has been corrupted."))
		{
			base.HResult = -2147467261;
		}

		// Token: 0x060002AB RID: 683 RVA: 0x0001518C File Offset: 0x0001338C
		protected AccessViolationException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x040001F3 RID: 499
		private const int Result = -2147467261;
	}
}
