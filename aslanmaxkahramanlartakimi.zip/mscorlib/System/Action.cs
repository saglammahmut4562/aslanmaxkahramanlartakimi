﻿using System;

namespace System
{
	// Token: 0x02000072 RID: 114
	// (Invoke) Token: 0x060002AD RID: 685
	public delegate void Action<T>(T obj);
}
