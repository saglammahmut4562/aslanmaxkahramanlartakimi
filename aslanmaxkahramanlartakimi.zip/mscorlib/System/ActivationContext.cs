﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000073 RID: 115
	[ComVisible(false)]
	[Serializable]
	public sealed class ActivationContext : IDisposable, ISerializable
	{
		// Token: 0x060002B0 RID: 688 RVA: 0x00015198 File Offset: 0x00013398
		[MonoTODO("Missing serialization support")]
		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x000151AC File Offset: 0x000133AC
		~ActivationContext()
		{
			this.Dispose(false);
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060002B2 RID: 690 RVA: 0x000151DC File Offset: 0x000133DC
		public ApplicationIdentity Identity
		{
			get
			{
				return this._appid;
			}
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x000151E4 File Offset: 0x000133E4
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x000151F4 File Offset: 0x000133F4
		private void Dispose(bool disposing)
		{
			if (this._disposed)
			{
				if (disposing)
				{
				}
				this._disposed = true;
			}
		}

		// Token: 0x040001F4 RID: 500
		private ActivationContext.ContextForm _form;

		// Token: 0x040001F5 RID: 501
		private ApplicationIdentity _appid;

		// Token: 0x040001F6 RID: 502
		private bool _disposed;

		// Token: 0x02000074 RID: 116
		public enum ContextForm
		{
			// Token: 0x040001F8 RID: 504
			Loose,
			// Token: 0x040001F9 RID: 505
			StoreBounded
		}
	}
}
