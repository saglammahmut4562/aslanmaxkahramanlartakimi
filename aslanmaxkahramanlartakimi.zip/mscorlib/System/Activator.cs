﻿using System;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Activation;
using System.Security.Policy;
using System.Text;

namespace System
{
	// Token: 0x02000075 RID: 117
	[ComDefaultInterface(typeof(_Activator))]
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	public sealed class Activator : _Activator
	{
		// Token: 0x060002B5 RID: 693 RVA: 0x00015210 File Offset: 0x00013410
		public static ObjectHandle CreateInstanceFrom(string assemblyFile, string typeName)
		{
			return Activator.CreateInstanceFrom(assemblyFile, typeName, null);
		}

		// Token: 0x060002B6 RID: 694 RVA: 0x0001521C File Offset: 0x0001341C
		public static ObjectHandle CreateInstanceFrom(string assemblyFile, string typeName, object[] activationAttributes)
		{
			return Activator.CreateInstanceFrom(assemblyFile, typeName, false, BindingFlags.Instance | BindingFlags.Public | BindingFlags.CreateInstance, null, null, null, activationAttributes, null);
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x0001523C File Offset: 0x0001343C
		public static ObjectHandle CreateInstanceFrom(string assemblyFile, string typeName, bool ignoreCase, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes, Evidence securityInfo)
		{
			Assembly assembly = Assembly.LoadFrom(assemblyFile, securityInfo);
			if (assembly == null)
			{
				return null;
			}
			Type type = assembly.GetType(typeName, true, ignoreCase);
			if (type == null)
			{
				return null;
			}
			object obj = Activator.CreateInstance(type, bindingAttr, binder, args, culture, activationAttributes);
			return (obj == null) ? null : new ObjectHandle(obj);
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x00015290 File Offset: 0x00013490
		public static ObjectHandle CreateInstance(string assemblyName, string typeName)
		{
			if (assemblyName == null)
			{
				assemblyName = Assembly.GetCallingAssembly().GetName().Name;
			}
			return Activator.CreateInstance(assemblyName, typeName, null);
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x000152B4 File Offset: 0x000134B4
		public static ObjectHandle CreateInstance(string assemblyName, string typeName, object[] activationAttributes)
		{
			if (assemblyName == null)
			{
				assemblyName = Assembly.GetCallingAssembly().GetName().Name;
			}
			return Activator.CreateInstance(assemblyName, typeName, false, BindingFlags.Instance | BindingFlags.Public | BindingFlags.CreateInstance, null, null, null, activationAttributes, null);
		}

		// Token: 0x060002BA RID: 698 RVA: 0x000152EC File Offset: 0x000134EC
		public static ObjectHandle CreateInstance(string assemblyName, string typeName, bool ignoreCase, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes, Evidence securityInfo)
		{
			Assembly assembly;
			if (assemblyName == null)
			{
				assembly = Assembly.GetCallingAssembly();
			}
			else
			{
				assembly = Assembly.Load(assemblyName, securityInfo);
			}
			Type type = assembly.GetType(typeName, true, ignoreCase);
			object obj = Activator.CreateInstance(type, bindingAttr, binder, args, culture, activationAttributes);
			return (obj == null) ? null : new ObjectHandle(obj);
		}

		// Token: 0x060002BB RID: 699 RVA: 0x00015344 File Offset: 0x00013544
		public static T CreateInstance<T>()
		{
			return (T)((object)Activator.CreateInstance(typeof(T)));
		}

		// Token: 0x060002BC RID: 700 RVA: 0x0001535C File Offset: 0x0001355C
		public static object CreateInstance(Type type)
		{
			return Activator.CreateInstance(type, false);
		}

		// Token: 0x060002BD RID: 701 RVA: 0x00015368 File Offset: 0x00013568
		public static object CreateInstance(Type type, params object[] args)
		{
			return Activator.CreateInstance(type, args, new object[0]);
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00015378 File Offset: 0x00013578
		public static object CreateInstance(Type type, object[] args, object[] activationAttributes)
		{
			return Activator.CreateInstance(type, BindingFlags.Default, Binder.DefaultBinder, args, null, activationAttributes);
		}

		// Token: 0x060002BF RID: 703 RVA: 0x0001538C File Offset: 0x0001358C
		public static object CreateInstance(Type type, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes)
		{
			Activator.CheckType(type);
			if (type.ContainsGenericParameters)
			{
				throw new ArgumentException(type + " is an open generic type", "type");
			}
			if ((bindingAttr & (BindingFlags.IgnoreCase | BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy)) == BindingFlags.Default)
			{
				bindingAttr |= BindingFlags.Instance | BindingFlags.Public;
			}
			int num = 0;
			if (args != null)
			{
				num = args.Length;
			}
			Type[] array = ((num != 0) ? new Type[num] : Type.EmptyTypes);
			for (int i = 0; i < num; i++)
			{
				if (args[i] != null)
				{
					array[i] = args[i].GetType();
				}
			}
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			ConstructorInfo constructorInfo = (ConstructorInfo)binder.SelectMethod(bindingAttr, type.GetConstructors(bindingAttr), array, null);
			if (constructorInfo != null)
			{
				Activator.CheckAbstractType(type);
				if (activationAttributes != null && activationAttributes.Length > 0)
				{
					if (!type.IsMarshalByRef)
					{
						string text = Locale.GetText("Type '{0}' doesn't derive from MarshalByRefObject.", new object[] { type.FullName });
						throw new NotSupportedException(text);
					}
					object obj = ActivationServices.CreateProxyFromAttributes(type, activationAttributes);
					if (obj != null)
					{
						constructorInfo.Invoke(obj, bindingAttr, binder, args, culture);
						return obj;
					}
				}
				return constructorInfo.Invoke(bindingAttr, binder, args, culture);
			}
			if (type.IsValueType && array.Length == 0)
			{
				return Activator.CreateInstanceInternal(type);
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (Type type2 in array)
			{
				stringBuilder.Append((type2 == null) ? "(unknown)" : type2.ToString());
				stringBuilder.Append(", ");
			}
			if (stringBuilder.Length > 2)
			{
				stringBuilder.Length -= 2;
			}
			throw new MissingMethodException(string.Format(Locale.GetText("No constructor found for {0}::.ctor({1})"), type.FullName, stringBuilder));
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x0001555C File Offset: 0x0001375C
		public static object CreateInstance(Type type, bool nonPublic)
		{
			Activator.CheckType(type);
			if (type.ContainsGenericParameters)
			{
				throw new ArgumentException(type + " is an open generic type", "type");
			}
			Activator.CheckAbstractType(type);
			MonoType monoType = type as MonoType;
			ConstructorInfo constructorInfo;
			if (monoType != null)
			{
				constructorInfo = monoType.GetDefaultConstructor();
				if (!nonPublic && constructorInfo != null && !constructorInfo.IsPublic)
				{
					constructorInfo = null;
				}
			}
			else
			{
				BindingFlags bindingFlags = BindingFlags.Instance | BindingFlags.Public;
				if (nonPublic)
				{
					bindingFlags |= BindingFlags.NonPublic;
				}
				constructorInfo = type.GetConstructor(bindingFlags, null, CallingConventions.Any, Type.EmptyTypes, null);
			}
			if (constructorInfo != null)
			{
				return constructorInfo.Invoke(null);
			}
			if (type.IsValueType)
			{
				return Activator.CreateInstanceInternal(type);
			}
			throw new MissingMethodException(Locale.GetText("Default constructor not found."), ".ctor() of " + type.FullName);
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00015628 File Offset: 0x00013828
		private static void CheckType(Type type)
		{
			if (type == null)
			{
				throw new ArgumentNullException("type");
			}
			if (type == typeof(TypedReference) || type == typeof(ArgIterator) || type == typeof(void) || type == typeof(RuntimeArgumentHandle))
			{
				string text = Locale.GetText("CreateInstance cannot be used to create this type ({0}).", new object[] { type.FullName });
				throw new NotSupportedException(text);
			}
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x000156A8 File Offset: 0x000138A8
		private static void CheckAbstractType(Type type)
		{
			if (type.IsAbstract)
			{
				string text = Locale.GetText("Cannot create an abstract class '{0}'.", new object[] { type.FullName });
				throw new MissingMethodException(text);
			}
		}

		// Token: 0x060002C3 RID: 707
		[MethodImpl(4096)]
		internal static extern object CreateInstanceInternal(Type type);

		// Token: 0x040001FA RID: 506
		private const BindingFlags _flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.CreateInstance;

		// Token: 0x040001FB RID: 507
		private const BindingFlags _accessFlags = BindingFlags.IgnoreCase | BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy;
	}
}
