﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration.Assemblies;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;
using System.Security;
using System.Security.Permissions;
using System.Security.Policy;
using System.Security.Principal;
using System.Threading;
using Mono.Security;

namespace System
{
	// Token: 0x02000076 RID: 118
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	public sealed class AppDomain : MarshalByRefObject
	{
		// Token: 0x060002C4 RID: 708 RVA: 0x000156E4 File Offset: 0x000138E4
		private AppDomain()
		{
		}

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x060002C5 RID: 709 RVA: 0x000156EC File Offset: 0x000138EC
		// (remove) Token: 0x060002C6 RID: 710 RVA: 0x00015708 File Offset: 0x00013908
		public event AssemblyLoadEventHandler AssemblyLoad;

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x060002C7 RID: 711 RVA: 0x00015724 File Offset: 0x00013924
		// (remove) Token: 0x060002C8 RID: 712 RVA: 0x00015740 File Offset: 0x00013940
		public event ResolveEventHandler AssemblyResolve;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x060002C9 RID: 713 RVA: 0x0001575C File Offset: 0x0001395C
		// (remove) Token: 0x060002CA RID: 714 RVA: 0x00015778 File Offset: 0x00013978
		public event EventHandler DomainUnload;

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x060002CB RID: 715 RVA: 0x00015794 File Offset: 0x00013994
		// (remove) Token: 0x060002CC RID: 716 RVA: 0x000157B0 File Offset: 0x000139B0
		public event EventHandler ProcessExit;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x060002CD RID: 717 RVA: 0x000157CC File Offset: 0x000139CC
		// (remove) Token: 0x060002CE RID: 718 RVA: 0x000157E8 File Offset: 0x000139E8
		public event ResolveEventHandler ResourceResolve;

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060002CF RID: 719 RVA: 0x00015804 File Offset: 0x00013A04
		// (remove) Token: 0x060002D0 RID: 720 RVA: 0x00015820 File Offset: 0x00013A20
		public event ResolveEventHandler TypeResolve;

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060002D1 RID: 721 RVA: 0x0001583C File Offset: 0x00013A3C
		// (remove) Token: 0x060002D2 RID: 722 RVA: 0x00015858 File Offset: 0x00013A58
		public event UnhandledExceptionEventHandler UnhandledException;

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060002D3 RID: 723 RVA: 0x00015874 File Offset: 0x00013A74
		// (remove) Token: 0x060002D4 RID: 724 RVA: 0x00015890 File Offset: 0x00013A90
		public event ResolveEventHandler ReflectionOnlyAssemblyResolve;

		// Token: 0x060002D5 RID: 725
		[MethodImpl(4096)]
		private extern AppDomainSetup getSetup();

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060002D6 RID: 726 RVA: 0x000158AC File Offset: 0x00013AAC
		internal AppDomainSetup SetupInformationNoCopy
		{
			get
			{
				return this.getSetup();
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060002D7 RID: 727 RVA: 0x000158B4 File Offset: 0x00013AB4
		public AppDomainSetup SetupInformation
		{
			get
			{
				AppDomainSetup setup = this.getSetup();
				return new AppDomainSetup(setup);
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060002D8 RID: 728 RVA: 0x000158D0 File Offset: 0x00013AD0
		public string BaseDirectory
		{
			get
			{
				string applicationBase = this.SetupInformationNoCopy.ApplicationBase;
				if (SecurityManager.SecurityEnabled && applicationBase != null && applicationBase.Length > 0)
				{
					new FileIOPermission(FileIOPermissionAccess.PathDiscovery, applicationBase).Demand();
				}
				return applicationBase;
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060002D9 RID: 729 RVA: 0x00015914 File Offset: 0x00013B14
		public string RelativeSearchPath
		{
			get
			{
				string privateBinPath = this.SetupInformationNoCopy.PrivateBinPath;
				if (SecurityManager.SecurityEnabled && privateBinPath != null && privateBinPath.Length > 0)
				{
					new FileIOPermission(FileIOPermissionAccess.PathDiscovery, privateBinPath).Demand();
				}
				return privateBinPath;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x060002DA RID: 730 RVA: 0x00015958 File Offset: 0x00013B58
		public string DynamicDirectory
		{
			get
			{
				AppDomainSetup setupInformationNoCopy = this.SetupInformationNoCopy;
				if (setupInformationNoCopy.DynamicBase == null)
				{
					return null;
				}
				string text = Path.Combine(setupInformationNoCopy.DynamicBase, setupInformationNoCopy.ApplicationName);
				if (SecurityManager.SecurityEnabled && text != null && text.Length > 0)
				{
					new FileIOPermission(FileIOPermissionAccess.PathDiscovery, text).Demand();
				}
				return text;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x060002DB RID: 731 RVA: 0x000159B4 File Offset: 0x00013BB4
		public bool ShadowCopyFiles
		{
			get
			{
				return this.SetupInformationNoCopy.ShadowCopyFiles == "true";
			}
		}

		// Token: 0x060002DC RID: 732
		[MethodImpl(4096)]
		private extern string getFriendlyName();

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x060002DD RID: 733 RVA: 0x000159CC File Offset: 0x00013BCC
		public string FriendlyName
		{
			get
			{
				return this.getFriendlyName();
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x060002DE RID: 734 RVA: 0x000159D4 File Offset: 0x00013BD4
		public Evidence Evidence
		{
			get
			{
				if (this._evidence == null)
				{
					lock (this)
					{
						Assembly entryAssembly = Assembly.GetEntryAssembly();
						if (entryAssembly == null)
						{
							if (this == AppDomain.DefaultDomain)
							{
								return new Evidence();
							}
							this._evidence = AppDomain.DefaultDomain.Evidence;
						}
						else
						{
							this._evidence = Evidence.GetDefaultHostEvidence(entryAssembly);
						}
					}
				}
				return new Evidence(this._evidence);
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060002DF RID: 735 RVA: 0x00015A60 File Offset: 0x00013C60
		internal IPrincipal DefaultPrincipal
		{
			get
			{
				if (AppDomain._principal == null)
				{
					switch (this._principalPolicy)
					{
					case PrincipalPolicy.UnauthenticatedPrincipal:
						AppDomain._principal = new GenericPrincipal(new GenericIdentity(string.Empty, string.Empty), null);
						break;
					case PrincipalPolicy.WindowsPrincipal:
						AppDomain._principal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
						break;
					}
				}
				return AppDomain._principal;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060002E0 RID: 736 RVA: 0x00015AD0 File Offset: 0x00013CD0
		internal PermissionSet GrantedPermissionSet
		{
			get
			{
				return this._granted;
			}
		}

		// Token: 0x060002E1 RID: 737
		[MethodImpl(4096)]
		private static extern AppDomain getCurDomain();

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060002E2 RID: 738 RVA: 0x00015AD8 File Offset: 0x00013CD8
		public static AppDomain CurrentDomain
		{
			get
			{
				return AppDomain.getCurDomain();
			}
		}

		// Token: 0x060002E3 RID: 739
		[MethodImpl(4096)]
		private static extern AppDomain getRootDomain();

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060002E4 RID: 740 RVA: 0x00015AE0 File Offset: 0x00013CE0
		internal static AppDomain DefaultDomain
		{
			get
			{
				if (AppDomain.default_domain == null)
				{
					AppDomain rootDomain = AppDomain.getRootDomain();
					if (rootDomain == AppDomain.CurrentDomain)
					{
						AppDomain.default_domain = rootDomain;
					}
					else
					{
						AppDomain.default_domain = (AppDomain)RemotingServices.GetDomainProxy(rootDomain);
					}
				}
				return AppDomain.default_domain;
			}
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x00015B28 File Offset: 0x00013D28
		[Obsolete("AppDomain.AppendPrivatePath has been deprecated. Please investigate the use of AppDomainSetup.PrivateBinPath instead.")]
		public void AppendPrivatePath(string path)
		{
			if (path == null || path.Length == 0)
			{
				return;
			}
			AppDomainSetup setupInformationNoCopy = this.SetupInformationNoCopy;
			string text = setupInformationNoCopy.PrivateBinPath;
			if (text == null || text.Length == 0)
			{
				setupInformationNoCopy.PrivateBinPath = path;
				return;
			}
			text = text.Trim();
			if (text[text.Length - 1] != Path.PathSeparator)
			{
				text += Path.PathSeparator;
			}
			setupInformationNoCopy.PrivateBinPath = text + path;
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x00015BAC File Offset: 0x00013DAC
		[Obsolete("AppDomain.ClearPrivatePath has been deprecated. Please investigate the use of AppDomainSetup.PrivateBinPath instead.")]
		public void ClearPrivatePath()
		{
			this.SetupInformationNoCopy.PrivateBinPath = string.Empty;
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x00015BC0 File Offset: 0x00013DC0
		[Obsolete("Use AppDomainSetup.ShadowCopyDirectories")]
		public void ClearShadowCopyPath()
		{
			this.SetupInformationNoCopy.ShadowCopyDirectories = string.Empty;
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x00015BD4 File Offset: 0x00013DD4
		public ObjectHandle CreateInstance(string assemblyName, string typeName)
		{
			if (assemblyName == null)
			{
				throw new ArgumentNullException("assemblyName");
			}
			return Activator.CreateInstance(assemblyName, typeName);
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x00015BF0 File Offset: 0x00013DF0
		public ObjectHandle CreateInstance(string assemblyName, string typeName, object[] activationAttributes)
		{
			if (assemblyName == null)
			{
				throw new ArgumentNullException("assemblyName");
			}
			return Activator.CreateInstance(assemblyName, typeName, activationAttributes);
		}

		// Token: 0x060002EA RID: 746 RVA: 0x00015C0C File Offset: 0x00013E0C
		public ObjectHandle CreateInstance(string assemblyName, string typeName, bool ignoreCase, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes, Evidence securityAttributes)
		{
			if (assemblyName == null)
			{
				throw new ArgumentNullException("assemblyName");
			}
			return Activator.CreateInstance(assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes);
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00015C40 File Offset: 0x00013E40
		public object CreateInstanceAndUnwrap(string assemblyName, string typeName)
		{
			ObjectHandle objectHandle = this.CreateInstance(assemblyName, typeName);
			return (objectHandle == null) ? null : objectHandle.Unwrap();
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00015C68 File Offset: 0x00013E68
		public object CreateInstanceAndUnwrap(string assemblyName, string typeName, object[] activationAttributes)
		{
			ObjectHandle objectHandle = this.CreateInstance(assemblyName, typeName, activationAttributes);
			return (objectHandle == null) ? null : objectHandle.Unwrap();
		}

		// Token: 0x060002ED RID: 749 RVA: 0x00015C94 File Offset: 0x00013E94
		public object CreateInstanceAndUnwrap(string assemblyName, string typeName, bool ignoreCase, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes, Evidence securityAttributes)
		{
			ObjectHandle objectHandle = this.CreateInstance(assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes);
			return (objectHandle == null) ? null : objectHandle.Unwrap();
		}

		// Token: 0x060002EE RID: 750 RVA: 0x00015CCC File Offset: 0x00013ECC
		public ObjectHandle CreateInstanceFrom(string assemblyFile, string typeName)
		{
			if (assemblyFile == null)
			{
				throw new ArgumentNullException("assemblyFile");
			}
			return Activator.CreateInstanceFrom(assemblyFile, typeName);
		}

		// Token: 0x060002EF RID: 751 RVA: 0x00015CE8 File Offset: 0x00013EE8
		public ObjectHandle CreateInstanceFrom(string assemblyFile, string typeName, object[] activationAttributes)
		{
			if (assemblyFile == null)
			{
				throw new ArgumentNullException("assemblyFile");
			}
			return Activator.CreateInstanceFrom(assemblyFile, typeName, activationAttributes);
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x00015D04 File Offset: 0x00013F04
		public ObjectHandle CreateInstanceFrom(string assemblyFile, string typeName, bool ignoreCase, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes, Evidence securityAttributes)
		{
			if (assemblyFile == null)
			{
				throw new ArgumentNullException("assemblyFile");
			}
			return Activator.CreateInstanceFrom(assemblyFile, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes);
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x00015D38 File Offset: 0x00013F38
		public object CreateInstanceFromAndUnwrap(string assemblyName, string typeName)
		{
			ObjectHandle objectHandle = this.CreateInstanceFrom(assemblyName, typeName);
			return (objectHandle == null) ? null : objectHandle.Unwrap();
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x00015D60 File Offset: 0x00013F60
		public object CreateInstanceFromAndUnwrap(string assemblyName, string typeName, object[] activationAttributes)
		{
			ObjectHandle objectHandle = this.CreateInstanceFrom(assemblyName, typeName, activationAttributes);
			return (objectHandle == null) ? null : objectHandle.Unwrap();
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x00015D8C File Offset: 0x00013F8C
		public object CreateInstanceFromAndUnwrap(string assemblyName, string typeName, bool ignoreCase, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes, Evidence securityAttributes)
		{
			ObjectHandle objectHandle = this.CreateInstanceFrom(assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes);
			return (objectHandle == null) ? null : objectHandle.Unwrap();
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x00015DC4 File Offset: 0x00013FC4
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access)
		{
			return this.DefineDynamicAssembly(name, access, null, null, null, null, null, false);
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x00015DE0 File Offset: 0x00013FE0
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, Evidence evidence)
		{
			return this.DefineDynamicAssembly(name, access, null, evidence, null, null, null, false);
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x00015DFC File Offset: 0x00013FFC
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, string dir)
		{
			return this.DefineDynamicAssembly(name, access, dir, null, null, null, null, false);
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x00015E18 File Offset: 0x00014018
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, string dir, Evidence evidence)
		{
			return this.DefineDynamicAssembly(name, access, dir, evidence, null, null, null, false);
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x00015E34 File Offset: 0x00014034
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, PermissionSet requiredPermissions, PermissionSet optionalPermissions, PermissionSet refusedPermissions)
		{
			return this.DefineDynamicAssembly(name, access, null, null, requiredPermissions, optionalPermissions, refusedPermissions, false);
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x00015E54 File Offset: 0x00014054
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, Evidence evidence, PermissionSet requiredPermissions, PermissionSet optionalPermissions, PermissionSet refusedPermissions)
		{
			return this.DefineDynamicAssembly(name, access, null, evidence, requiredPermissions, optionalPermissions, refusedPermissions, false);
		}

		// Token: 0x060002FA RID: 762 RVA: 0x00015E74 File Offset: 0x00014074
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, string dir, PermissionSet requiredPermissions, PermissionSet optionalPermissions, PermissionSet refusedPermissions)
		{
			return this.DefineDynamicAssembly(name, access, dir, null, requiredPermissions, optionalPermissions, refusedPermissions, false);
		}

		// Token: 0x060002FB RID: 763 RVA: 0x00015E94 File Offset: 0x00014094
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, string dir, Evidence evidence, PermissionSet requiredPermissions, PermissionSet optionalPermissions, PermissionSet refusedPermissions)
		{
			return this.DefineDynamicAssembly(name, access, dir, evidence, requiredPermissions, optionalPermissions, refusedPermissions, false);
		}

		// Token: 0x060002FC RID: 764 RVA: 0x00015EB4 File Offset: 0x000140B4
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, string dir, Evidence evidence, PermissionSet requiredPermissions, PermissionSet optionalPermissions, PermissionSet refusedPermissions, bool isSynchronized)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			AppDomain.ValidateAssemblyName(name.Name);
			AssemblyBuilder assemblyBuilder = new AssemblyBuilder(name, dir, access, false);
			assemblyBuilder.AddPermissionRequests(requiredPermissions, optionalPermissions, refusedPermissions);
			return assemblyBuilder;
		}

		// Token: 0x060002FD RID: 765 RVA: 0x00015EF4 File Offset: 0x000140F4
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, string dir, Evidence evidence, PermissionSet requiredPermissions, PermissionSet optionalPermissions, PermissionSet refusedPermissions, bool isSynchronized, IEnumerable<CustomAttributeBuilder> assemblyAttributes)
		{
			AssemblyBuilder assemblyBuilder = this.DefineDynamicAssembly(name, access, dir, evidence, requiredPermissions, optionalPermissions, refusedPermissions, isSynchronized);
			if (assemblyAttributes != null)
			{
				foreach (CustomAttributeBuilder customAttributeBuilder in assemblyAttributes)
				{
					assemblyBuilder.SetCustomAttribute(customAttributeBuilder);
				}
			}
			return assemblyBuilder;
		}

		// Token: 0x060002FE RID: 766 RVA: 0x00015F64 File Offset: 0x00014164
		public AssemblyBuilder DefineDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access, IEnumerable<CustomAttributeBuilder> assemblyAttributes)
		{
			return this.DefineDynamicAssembly(name, access, null, null, null, null, null, false, assemblyAttributes);
		}

		// Token: 0x060002FF RID: 767 RVA: 0x00015F80 File Offset: 0x00014180
		internal AssemblyBuilder DefineInternalDynamicAssembly(AssemblyName name, AssemblyBuilderAccess access)
		{
			return new AssemblyBuilder(name, null, access, true);
		}

		// Token: 0x06000300 RID: 768 RVA: 0x00015F8C File Offset: 0x0001418C
		public void DoCallBack(CrossAppDomainDelegate callBackDelegate)
		{
			if (callBackDelegate != null)
			{
				callBackDelegate();
			}
		}

		// Token: 0x06000301 RID: 769 RVA: 0x00015F9C File Offset: 0x0001419C
		public int ExecuteAssembly(string assemblyFile)
		{
			return this.ExecuteAssembly(assemblyFile, null, null);
		}

		// Token: 0x06000302 RID: 770 RVA: 0x00015FA8 File Offset: 0x000141A8
		public int ExecuteAssembly(string assemblyFile, Evidence assemblySecurity)
		{
			return this.ExecuteAssembly(assemblyFile, assemblySecurity, null);
		}

		// Token: 0x06000303 RID: 771 RVA: 0x00015FB4 File Offset: 0x000141B4
		public int ExecuteAssembly(string assemblyFile, Evidence assemblySecurity, string[] args)
		{
			Assembly assembly = Assembly.LoadFrom(assemblyFile, assemblySecurity);
			return this.ExecuteAssemblyInternal(assembly, args);
		}

		// Token: 0x06000304 RID: 772 RVA: 0x00015FD4 File Offset: 0x000141D4
		public int ExecuteAssembly(string assemblyFile, Evidence assemblySecurity, string[] args, byte[] hashValue, AssemblyHashAlgorithm hashAlgorithm)
		{
			Assembly assembly = Assembly.LoadFrom(assemblyFile, assemblySecurity, hashValue, hashAlgorithm);
			return this.ExecuteAssemblyInternal(assembly, args);
		}

		// Token: 0x06000305 RID: 773 RVA: 0x00015FF8 File Offset: 0x000141F8
		private int ExecuteAssemblyInternal(Assembly a, string[] args)
		{
			if (a.EntryPoint == null)
			{
				throw new MissingMethodException("Entry point not found in assembly '" + a.FullName + "'.");
			}
			return this.ExecuteAssembly(a, args);
		}

		// Token: 0x06000306 RID: 774
		[MethodImpl(4096)]
		private extern int ExecuteAssembly(Assembly a, string[] args);

		// Token: 0x06000307 RID: 775
		[MethodImpl(4096)]
		private extern Assembly[] GetAssemblies(bool refOnly);

		// Token: 0x06000308 RID: 776 RVA: 0x00016028 File Offset: 0x00014228
		public Assembly[] GetAssemblies()
		{
			return this.GetAssemblies(false);
		}

		// Token: 0x06000309 RID: 777
		[MethodImpl(4096)]
		public extern object GetData(string name);

		// Token: 0x0600030A RID: 778 RVA: 0x00016034 File Offset: 0x00014234
		public new Type GetType()
		{
			return base.GetType();
		}

		// Token: 0x0600030B RID: 779 RVA: 0x0001603C File Offset: 0x0001423C
		public override object InitializeLifetimeService()
		{
			return null;
		}

		// Token: 0x0600030C RID: 780
		[MethodImpl(4096)]
		internal extern Assembly LoadAssembly(string assemblyRef, Evidence securityEvidence, bool refOnly);

		// Token: 0x0600030D RID: 781 RVA: 0x00016040 File Offset: 0x00014240
		public Assembly Load(AssemblyName assemblyRef)
		{
			return this.Load(assemblyRef, null);
		}

		// Token: 0x0600030E RID: 782 RVA: 0x0001604C File Offset: 0x0001424C
		internal Assembly LoadSatellite(AssemblyName assemblyRef, bool throwOnError)
		{
			if (assemblyRef == null)
			{
				throw new ArgumentNullException("assemblyRef");
			}
			Assembly assembly = this.LoadAssembly(assemblyRef.FullName, null, false);
			if (assembly == null && throwOnError)
			{
				throw new FileNotFoundException(null, assemblyRef.Name);
			}
			return assembly;
		}

		// Token: 0x0600030F RID: 783 RVA: 0x00016094 File Offset: 0x00014294
		public Assembly Load(AssemblyName assemblyRef, Evidence assemblySecurity)
		{
			if (assemblyRef == null)
			{
				throw new ArgumentNullException("assemblyRef");
			}
			if (assemblyRef.Name == null || assemblyRef.Name.Length == 0)
			{
				if (assemblyRef.CodeBase != null)
				{
					return Assembly.LoadFrom(assemblyRef.CodeBase, assemblySecurity);
				}
				throw new ArgumentException(Locale.GetText("assemblyRef.Name cannot be empty."), "assemblyRef");
			}
			else
			{
				Assembly assembly = this.LoadAssembly(assemblyRef.FullName, assemblySecurity, false);
				if (assembly != null)
				{
					return assembly;
				}
				if (assemblyRef.CodeBase == null)
				{
					throw new FileNotFoundException(null, assemblyRef.Name);
				}
				string text = assemblyRef.CodeBase;
				if (text.ToLower(CultureInfo.InvariantCulture).StartsWith("file://"))
				{
					text = new Uri(text).LocalPath;
				}
				try
				{
					assembly = Assembly.LoadFrom(text, assemblySecurity);
				}
				catch
				{
					throw new FileNotFoundException(null, assemblyRef.Name);
				}
				AssemblyName name = assembly.GetName();
				if (assemblyRef.Name != name.Name)
				{
					throw new FileNotFoundException(null, assemblyRef.Name);
				}
				if (assemblyRef.Version != new Version() && assemblyRef.Version != name.Version)
				{
					throw new FileNotFoundException(null, assemblyRef.Name);
				}
				if (assemblyRef.CultureInfo != null && assemblyRef.CultureInfo.Equals(name))
				{
					throw new FileNotFoundException(null, assemblyRef.Name);
				}
				byte[] publicKeyToken = assemblyRef.GetPublicKeyToken();
				if (publicKeyToken != null)
				{
					byte[] publicKeyToken2 = name.GetPublicKeyToken();
					if (publicKeyToken2 == null || publicKeyToken.Length != publicKeyToken2.Length)
					{
						throw new FileNotFoundException(null, assemblyRef.Name);
					}
					for (int i = publicKeyToken.Length - 1; i >= 0; i--)
					{
						if (publicKeyToken2[i] != publicKeyToken[i])
						{
							throw new FileNotFoundException(null, assemblyRef.Name);
						}
					}
				}
				return assembly;
			}
		}

		// Token: 0x06000310 RID: 784 RVA: 0x0001627C File Offset: 0x0001447C
		public Assembly Load(string assemblyString)
		{
			return this.Load(assemblyString, null, false);
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00016288 File Offset: 0x00014488
		public Assembly Load(string assemblyString, Evidence assemblySecurity)
		{
			return this.Load(assemblyString, assemblySecurity, false);
		}

		// Token: 0x06000312 RID: 786 RVA: 0x00016294 File Offset: 0x00014494
		internal Assembly Load(string assemblyString, Evidence assemblySecurity, bool refonly)
		{
			if (assemblyString == null)
			{
				throw new ArgumentNullException("assemblyString");
			}
			if (assemblyString.Length == 0)
			{
				throw new ArgumentException("assemblyString cannot have zero length");
			}
			Assembly assembly = this.LoadAssembly(assemblyString, assemblySecurity, refonly);
			if (assembly == null)
			{
				throw new FileNotFoundException(null, assemblyString);
			}
			return assembly;
		}

		// Token: 0x06000313 RID: 787 RVA: 0x000162E4 File Offset: 0x000144E4
		public Assembly Load(byte[] rawAssembly)
		{
			return this.Load(rawAssembly, null, null);
		}

		// Token: 0x06000314 RID: 788 RVA: 0x000162F0 File Offset: 0x000144F0
		public Assembly Load(byte[] rawAssembly, byte[] rawSymbolStore)
		{
			return this.Load(rawAssembly, rawSymbolStore, null);
		}

		// Token: 0x06000315 RID: 789
		[MethodImpl(4096)]
		internal extern Assembly LoadAssemblyRaw(byte[] rawAssembly, byte[] rawSymbolStore, Evidence securityEvidence, bool refonly);

		// Token: 0x06000316 RID: 790 RVA: 0x000162FC File Offset: 0x000144FC
		public Assembly Load(byte[] rawAssembly, byte[] rawSymbolStore, Evidence securityEvidence)
		{
			return this.Load(rawAssembly, rawSymbolStore, securityEvidence, false);
		}

		// Token: 0x06000317 RID: 791 RVA: 0x00016308 File Offset: 0x00014508
		internal Assembly Load(byte[] rawAssembly, byte[] rawSymbolStore, Evidence securityEvidence, bool refonly)
		{
			if (rawAssembly == null)
			{
				throw new ArgumentNullException("rawAssembly");
			}
			Assembly assembly = this.LoadAssemblyRaw(rawAssembly, rawSymbolStore, securityEvidence, refonly);
			assembly.FromByteArray = true;
			return assembly;
		}

		// Token: 0x06000318 RID: 792 RVA: 0x0001633C File Offset: 0x0001453C
		public void SetAppDomainPolicy(PolicyLevel domainPolicy)
		{
			if (domainPolicy == null)
			{
				throw new ArgumentNullException("domainPolicy");
			}
			if (this._granted != null)
			{
				throw new PolicyException(Locale.GetText("An AppDomain policy is already specified."));
			}
			if (this.IsFinalizingForUnload())
			{
				throw new AppDomainUnloadedException();
			}
			PolicyStatement policyStatement = domainPolicy.Resolve(this._evidence);
			this._granted = policyStatement.PermissionSet;
		}

		// Token: 0x06000319 RID: 793 RVA: 0x000163A0 File Offset: 0x000145A0
		[Obsolete("Use AppDomainSetup.SetCachePath")]
		public void SetCachePath(string path)
		{
			this.SetupInformationNoCopy.CachePath = path;
		}

		// Token: 0x0600031A RID: 794 RVA: 0x000163B0 File Offset: 0x000145B0
		public void SetPrincipalPolicy(PrincipalPolicy policy)
		{
			if (this.IsFinalizingForUnload())
			{
				throw new AppDomainUnloadedException();
			}
			this._principalPolicy = policy;
			AppDomain._principal = null;
		}

		// Token: 0x0600031B RID: 795 RVA: 0x000163D0 File Offset: 0x000145D0
		[Obsolete("Use AppDomainSetup.ShadowCopyFiles")]
		public void SetShadowCopyFiles()
		{
			this.SetupInformationNoCopy.ShadowCopyFiles = "true";
		}

		// Token: 0x0600031C RID: 796 RVA: 0x000163E4 File Offset: 0x000145E4
		[Obsolete("Use AppDomainSetup.ShadowCopyDirectories")]
		public void SetShadowCopyPath(string path)
		{
			this.SetupInformationNoCopy.ShadowCopyDirectories = path;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x000163F4 File Offset: 0x000145F4
		public void SetThreadPrincipal(IPrincipal principal)
		{
			if (principal == null)
			{
				throw new ArgumentNullException("principal");
			}
			if (AppDomain._principal != null)
			{
				throw new PolicyException(Locale.GetText("principal already present."));
			}
			if (this.IsFinalizingForUnload())
			{
				throw new AppDomainUnloadedException();
			}
			AppDomain._principal = principal;
		}

		// Token: 0x0600031E RID: 798
		[MethodImpl(4096)]
		private static extern AppDomain InternalSetDomainByID(int domain_id);

		// Token: 0x0600031F RID: 799
		[MethodImpl(4096)]
		private static extern AppDomain InternalSetDomain(AppDomain context);

		// Token: 0x06000320 RID: 800
		[MethodImpl(4096)]
		internal static extern void InternalPushDomainRef(AppDomain domain);

		// Token: 0x06000321 RID: 801
		[MethodImpl(4096)]
		internal static extern void InternalPushDomainRefByID(int domain_id);

		// Token: 0x06000322 RID: 802
		[MethodImpl(4096)]
		internal static extern void InternalPopDomainRef();

		// Token: 0x06000323 RID: 803
		[MethodImpl(4096)]
		internal static extern Context InternalSetContext(Context context);

		// Token: 0x06000324 RID: 804
		[MethodImpl(4096)]
		internal static extern Context InternalGetContext();

		// Token: 0x06000325 RID: 805
		[MethodImpl(4096)]
		internal static extern Context InternalGetDefaultContext();

		// Token: 0x06000326 RID: 806
		[MethodImpl(4096)]
		internal static extern string InternalGetProcessGuid(string newguid);

		// Token: 0x06000327 RID: 807 RVA: 0x00016444 File Offset: 0x00014644
		internal static object InvokeInDomain(AppDomain domain, MethodInfo method, object obj, object[] args)
		{
			AppDomain currentDomain = AppDomain.CurrentDomain;
			bool flag = false;
			object obj3;
			try
			{
				AppDomain.InternalPushDomainRef(domain);
				flag = true;
				AppDomain.InternalSetDomain(domain);
				Exception ex;
				object obj2 = ((MonoMethod)method).InternalInvoke(obj, args, out ex);
				if (ex != null)
				{
					throw ex;
				}
				obj3 = obj2;
			}
			finally
			{
				AppDomain.InternalSetDomain(currentDomain);
				if (flag)
				{
					AppDomain.InternalPopDomainRef();
				}
			}
			return obj3;
		}

		// Token: 0x06000328 RID: 808 RVA: 0x000164B4 File Offset: 0x000146B4
		internal static object InvokeInDomainByID(int domain_id, MethodInfo method, object obj, object[] args)
		{
			AppDomain currentDomain = AppDomain.CurrentDomain;
			bool flag = false;
			object obj3;
			try
			{
				AppDomain.InternalPushDomainRefByID(domain_id);
				flag = true;
				AppDomain.InternalSetDomainByID(domain_id);
				Exception ex;
				object obj2 = ((MonoMethod)method).InternalInvoke(obj, args, out ex);
				if (ex != null)
				{
					throw ex;
				}
				obj3 = obj2;
			}
			finally
			{
				AppDomain.InternalSetDomain(currentDomain);
				if (flag)
				{
					AppDomain.InternalPopDomainRef();
				}
			}
			return obj3;
		}

		// Token: 0x06000329 RID: 809 RVA: 0x00016524 File Offset: 0x00014724
		internal static string GetProcessGuid()
		{
			if (AppDomain._process_guid == null)
			{
				AppDomain._process_guid = AppDomain.InternalGetProcessGuid(Guid.NewGuid().ToString());
			}
			return AppDomain._process_guid;
		}

		// Token: 0x0600032A RID: 810 RVA: 0x00016558 File Offset: 0x00014758
		public static AppDomain CreateDomain(string friendlyName)
		{
			return AppDomain.CreateDomain(friendlyName, null, null);
		}

		// Token: 0x0600032B RID: 811 RVA: 0x00016564 File Offset: 0x00014764
		public static AppDomain CreateDomain(string friendlyName, Evidence securityInfo)
		{
			return AppDomain.CreateDomain(friendlyName, securityInfo, null);
		}

		// Token: 0x0600032C RID: 812
		[MethodImpl(4096)]
		private static extern AppDomain createDomain(string friendlyName, AppDomainSetup info);

		// Token: 0x0600032D RID: 813 RVA: 0x00016570 File Offset: 0x00014770
		[MonoLimitation("Currently it does not allow the setup in the other domain")]
		public static AppDomain CreateDomain(string friendlyName, Evidence securityInfo, AppDomainSetup info)
		{
			if (friendlyName == null)
			{
				throw new ArgumentNullException("friendlyName");
			}
			AppDomain defaultDomain = AppDomain.DefaultDomain;
			if (info == null)
			{
				if (defaultDomain == null)
				{
					info = new AppDomainSetup();
				}
				else
				{
					info = defaultDomain.SetupInformation;
				}
			}
			else
			{
				info = new AppDomainSetup(info);
			}
			if (defaultDomain != null)
			{
				if (!info.Equals(defaultDomain.SetupInformation))
				{
					if (info.ApplicationBase == null)
					{
						info.ApplicationBase = defaultDomain.SetupInformation.ApplicationBase;
					}
					if (info.ConfigurationFile == null)
					{
						info.ConfigurationFile = Path.GetFileName(defaultDomain.SetupInformation.ConfigurationFile);
					}
				}
			}
			else if (info.ConfigurationFile == null)
			{
				info.ConfigurationFile = "[I don't have a config file]";
			}
			AppDomain appDomain = (AppDomain)RemotingServices.GetDomainProxy(AppDomain.createDomain(friendlyName, info));
			if (securityInfo == null)
			{
				if (defaultDomain == null)
				{
					appDomain._evidence = null;
				}
				else
				{
					appDomain._evidence = defaultDomain.Evidence;
				}
			}
			else
			{
				appDomain._evidence = new Evidence(securityInfo);
			}
			return appDomain;
		}

		// Token: 0x0600032E RID: 814 RVA: 0x00016678 File Offset: 0x00014878
		public static AppDomain CreateDomain(string friendlyName, Evidence securityInfo, string appBasePath, string appRelativeSearchPath, bool shadowCopyFiles)
		{
			return AppDomain.CreateDomain(friendlyName, securityInfo, AppDomain.CreateDomainSetup(appBasePath, appRelativeSearchPath, shadowCopyFiles));
		}

		// Token: 0x0600032F RID: 815 RVA: 0x0001668C File Offset: 0x0001488C
		private static AppDomainSetup CreateDomainSetup(string appBasePath, string appRelativeSearchPath, bool shadowCopyFiles)
		{
			AppDomainSetup appDomainSetup = new AppDomainSetup();
			appDomainSetup.ApplicationBase = appBasePath;
			appDomainSetup.PrivateBinPath = appRelativeSearchPath;
			if (shadowCopyFiles)
			{
				appDomainSetup.ShadowCopyFiles = "true";
			}
			else
			{
				appDomainSetup.ShadowCopyFiles = "false";
			}
			return appDomainSetup;
		}

		// Token: 0x06000330 RID: 816
		[MethodImpl(4096)]
		private static extern bool InternalIsFinalizingForUnload(int domain_id);

		// Token: 0x06000331 RID: 817 RVA: 0x000166D0 File Offset: 0x000148D0
		public bool IsFinalizingForUnload()
		{
			return AppDomain.InternalIsFinalizingForUnload(this.getDomainID());
		}

		// Token: 0x06000332 RID: 818
		[MethodImpl(4096)]
		private static extern void InternalUnload(int domain_id);

		// Token: 0x06000333 RID: 819 RVA: 0x000166E0 File Offset: 0x000148E0
		private int getDomainID()
		{
			return Thread.GetDomainID();
		}

		// Token: 0x06000334 RID: 820 RVA: 0x000166E8 File Offset: 0x000148E8
		[ReliabilityContract(Consistency.MayCorruptAppDomain, Cer.MayFail)]
		public static void Unload(AppDomain domain)
		{
			if (domain == null)
			{
				throw new ArgumentNullException("domain");
			}
			AppDomain.InternalUnload(domain.getDomainID());
		}

		// Token: 0x06000335 RID: 821
		[MethodImpl(4096)]
		public extern void SetData(string name, object data);

		// Token: 0x06000336 RID: 822 RVA: 0x00016708 File Offset: 0x00014908
		[MonoTODO]
		public void SetData(string name, object data, IPermission permission)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000337 RID: 823 RVA: 0x00016710 File Offset: 0x00014910
		[Obsolete("AppDomain.GetCurrentThreadId has been deprecated because it does not provide a stable Id when managed threads are running on fibers (aka lightweight threads). To get a stable identifier for a managed thread, use the ManagedThreadId property on Thread.'")]
		public static int GetCurrentThreadId()
		{
			return Thread.CurrentThreadId;
		}

		// Token: 0x06000338 RID: 824 RVA: 0x00016718 File Offset: 0x00014918
		public override string ToString()
		{
			return this.getFriendlyName();
		}

		// Token: 0x06000339 RID: 825 RVA: 0x00016720 File Offset: 0x00014920
		private static void ValidateAssemblyName(string name)
		{
			if (name == null || name.Length == 0)
			{
				throw new ArgumentException("The Name of AssemblyName cannot be null or a zero-length string.");
			}
			bool flag = true;
			for (int i = 0; i < name.Length; i++)
			{
				char c = name[i];
				if (i == 0 && char.IsWhiteSpace(c))
				{
					flag = false;
					break;
				}
				if (c == '/' || c == '\\' || c == ':')
				{
					flag = false;
					break;
				}
			}
			if (!flag)
			{
				throw new ArgumentException("The Name of AssemblyName cannot start with whitespace, or contain '/', '\\'  or ':'.");
			}
		}

		// Token: 0x0600033A RID: 826 RVA: 0x000167B4 File Offset: 0x000149B4
		private void DoAssemblyLoad(Assembly assembly)
		{
			if (this.AssemblyLoad == null)
			{
				return;
			}
			this.AssemblyLoad(this, new AssemblyLoadEventArgs(assembly));
		}

		// Token: 0x0600033B RID: 827 RVA: 0x000167D4 File Offset: 0x000149D4
		private Assembly DoAssemblyResolve(string name, bool refonly)
		{
			ResolveEventHandler assemblyResolve = this.AssemblyResolve;
			if (assemblyResolve == null)
			{
				return null;
			}
			Hashtable hashtable;
			if (refonly)
			{
				hashtable = AppDomain.assembly_resolve_in_progress_refonly;
				if (hashtable == null)
				{
					hashtable = new Hashtable();
					AppDomain.assembly_resolve_in_progress_refonly = hashtable;
				}
			}
			else
			{
				hashtable = AppDomain.assembly_resolve_in_progress;
				if (hashtable == null)
				{
					hashtable = new Hashtable();
					AppDomain.assembly_resolve_in_progress = hashtable;
				}
			}
			string text = (string)hashtable[name];
			if (text != null)
			{
				return null;
			}
			hashtable[name] = name;
			Assembly assembly2;
			try
			{
				Delegate[] invocationList = assemblyResolve.GetInvocationList();
				foreach (Delegate @delegate in invocationList)
				{
					ResolveEventHandler resolveEventHandler = (ResolveEventHandler)@delegate;
					Assembly assembly = resolveEventHandler(this, new ResolveEventArgs(name));
					if (assembly != null)
					{
						return assembly;
					}
				}
				assembly2 = null;
			}
			finally
			{
				hashtable.Remove(name);
			}
			return assembly2;
		}

		// Token: 0x0600033C RID: 828 RVA: 0x000168C4 File Offset: 0x00014AC4
		internal Assembly DoTypeResolve(object name_or_tb)
		{
			if (this.TypeResolve == null)
			{
				return null;
			}
			string text;
			if (name_or_tb is TypeBuilder)
			{
				text = ((TypeBuilder)name_or_tb).FullName;
			}
			else
			{
				text = (string)name_or_tb;
			}
			Hashtable hashtable = AppDomain.type_resolve_in_progress;
			if (hashtable == null)
			{
				hashtable = new Hashtable();
				AppDomain.type_resolve_in_progress = hashtable;
			}
			if (hashtable.Contains(text))
			{
				return null;
			}
			hashtable[text] = text;
			Assembly assembly2;
			try
			{
				foreach (Delegate @delegate in this.TypeResolve.GetInvocationList())
				{
					ResolveEventHandler resolveEventHandler = (ResolveEventHandler)@delegate;
					Assembly assembly = resolveEventHandler(this, new ResolveEventArgs(text));
					if (assembly != null)
					{
						return assembly;
					}
				}
				assembly2 = null;
			}
			finally
			{
				hashtable.Remove(text);
			}
			return assembly2;
		}

		// Token: 0x0600033D RID: 829 RVA: 0x000169A8 File Offset: 0x00014BA8
		private void DoDomainUnload()
		{
			if (this.DomainUnload != null)
			{
				this.DomainUnload(this, null);
			}
		}

		// Token: 0x0600033E RID: 830 RVA: 0x000169C4 File Offset: 0x00014BC4
		internal void ProcessMessageInDomain(byte[] arrRequest, CADMethodCallMessage cadMsg, out byte[] arrResponse, out CADMethodReturnMessage cadMrm)
		{
			IMessage message;
			if (arrRequest != null)
			{
				message = CADSerializer.DeserializeMessage(new MemoryStream(arrRequest), null);
			}
			else
			{
				message = new MethodCall(cadMsg);
			}
			IMessage message2 = ChannelServices.SyncDispatchMessage(message);
			cadMrm = CADMethodReturnMessage.Create(message2);
			if (cadMrm == null)
			{
				arrResponse = CADSerializer.SerializeMessage(message2).GetBuffer();
			}
			else
			{
				arrResponse = null;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600033F RID: 831 RVA: 0x00016A20 File Offset: 0x00014C20
		public AppDomainManager DomainManager
		{
			get
			{
				return this._domain_manager;
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000340 RID: 832 RVA: 0x00016A28 File Offset: 0x00014C28
		public ActivationContext ActivationContext
		{
			get
			{
				return this._activation;
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000341 RID: 833 RVA: 0x00016A30 File Offset: 0x00014C30
		public ApplicationIdentity ApplicationIdentity
		{
			get
			{
				return this._applicationIdentity;
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000342 RID: 834 RVA: 0x00016A38 File Offset: 0x00014C38
		public int Id
		{
			[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
			get
			{
				return this.getDomainID();
			}
		}

		// Token: 0x06000343 RID: 835 RVA: 0x00016A40 File Offset: 0x00014C40
		[MonoTODO("This routine only returns the parameter currently")]
		[ComVisible(false)]
		public string ApplyPolicy(string assemblyName)
		{
			if (assemblyName == null)
			{
				throw new ArgumentNullException("assemblyName");
			}
			if (assemblyName.Length == 0)
			{
				throw new ArgumentException("assemblyName");
			}
			return assemblyName;
		}

		// Token: 0x06000344 RID: 836 RVA: 0x00016A6C File Offset: 0x00014C6C
		public static AppDomain CreateDomain(string friendlyName, Evidence securityInfo, string appBasePath, string appRelativeSearchPath, bool shadowCopyFiles, AppDomainInitializer adInit, string[] adInitArgs)
		{
			AppDomainSetup appDomainSetup = AppDomain.CreateDomainSetup(appBasePath, appRelativeSearchPath, shadowCopyFiles);
			appDomainSetup.AppDomainInitializerArguments = adInitArgs;
			appDomainSetup.AppDomainInitializer = adInit;
			return AppDomain.CreateDomain(friendlyName, securityInfo, appDomainSetup);
		}

		// Token: 0x06000345 RID: 837 RVA: 0x00016A9C File Offset: 0x00014C9C
		public int ExecuteAssemblyByName(string assemblyName)
		{
			return this.ExecuteAssemblyByName(assemblyName, null, null);
		}

		// Token: 0x06000346 RID: 838 RVA: 0x00016AA8 File Offset: 0x00014CA8
		public int ExecuteAssemblyByName(string assemblyName, Evidence assemblySecurity)
		{
			return this.ExecuteAssemblyByName(assemblyName, assemblySecurity, null);
		}

		// Token: 0x06000347 RID: 839 RVA: 0x00016AB4 File Offset: 0x00014CB4
		public int ExecuteAssemblyByName(string assemblyName, Evidence assemblySecurity, params string[] args)
		{
			Assembly assembly = Assembly.Load(assemblyName, assemblySecurity);
			return this.ExecuteAssemblyInternal(assembly, args);
		}

		// Token: 0x06000348 RID: 840 RVA: 0x00016AD4 File Offset: 0x00014CD4
		public int ExecuteAssemblyByName(AssemblyName assemblyName, Evidence assemblySecurity, params string[] args)
		{
			Assembly assembly = Assembly.Load(assemblyName, assemblySecurity);
			return this.ExecuteAssemblyInternal(assembly, args);
		}

		// Token: 0x06000349 RID: 841 RVA: 0x00016AF4 File Offset: 0x00014CF4
		public bool IsDefaultAppDomain()
		{
			return object.ReferenceEquals(this, AppDomain.DefaultDomain);
		}

		// Token: 0x0600034A RID: 842 RVA: 0x00016B04 File Offset: 0x00014D04
		public Assembly[] ReflectionOnlyGetAssemblies()
		{
			return this.GetAssemblies(true);
		}

		// Token: 0x040001FC RID: 508
		private IntPtr _mono_app_domain;

		// Token: 0x040001FD RID: 509
		private static string _process_guid;

		// Token: 0x040001FE RID: 510
		[ThreadStatic]
		private static Hashtable type_resolve_in_progress;

		// Token: 0x040001FF RID: 511
		[ThreadStatic]
		private static Hashtable assembly_resolve_in_progress;

		// Token: 0x04000200 RID: 512
		[ThreadStatic]
		private static Hashtable assembly_resolve_in_progress_refonly;

		// Token: 0x04000201 RID: 513
		private Evidence _evidence;

		// Token: 0x04000202 RID: 514
		private PermissionSet _granted;

		// Token: 0x04000203 RID: 515
		private PrincipalPolicy _principalPolicy;

		// Token: 0x04000204 RID: 516
		[ThreadStatic]
		private static IPrincipal _principal;

		// Token: 0x04000205 RID: 517
		private static AppDomain default_domain;

		// Token: 0x04000206 RID: 518
		private AppDomainManager _domain_manager;

		// Token: 0x04000207 RID: 519
		private ActivationContext _activation;

		// Token: 0x04000208 RID: 520
		private ApplicationIdentity _applicationIdentity;
	}
}
