﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000077 RID: 119
	// (Invoke) Token: 0x0600034C RID: 844
	[ComVisible(true)]
	[Serializable]
	public delegate void AppDomainInitializer(string[] args);
}
