﻿using System;
using System.Runtime.Hosting;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000078 RID: 120
	[ComVisible(true)]
	public class AppDomainManager : MarshalByRefObject
	{
		// Token: 0x04000211 RID: 529
		private ApplicationActivator _activator;

		// Token: 0x04000212 RID: 530
		private AppDomainManagerInitializationOptions _flags;
	}
}
