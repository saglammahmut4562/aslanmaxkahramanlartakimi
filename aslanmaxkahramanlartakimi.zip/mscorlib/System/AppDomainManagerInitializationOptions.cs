﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000079 RID: 121
	[Flags]
	[ComVisible(true)]
	public enum AppDomainManagerInitializationOptions
	{
		// Token: 0x04000214 RID: 532
		None = 0,
		// Token: 0x04000215 RID: 533
		RegisterWithHost = 1
	}
}
