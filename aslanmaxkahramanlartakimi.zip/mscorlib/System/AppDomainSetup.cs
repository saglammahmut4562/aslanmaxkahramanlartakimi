﻿using System;
using System.IO;
using System.Runtime.Hosting;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Policy;

namespace System
{
	// Token: 0x0200007A RID: 122
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[Serializable]
	public sealed class AppDomainSetup
	{
		// Token: 0x0600034F RID: 847 RVA: 0x00016B10 File Offset: 0x00014D10
		public AppDomainSetup()
		{
		}

		// Token: 0x06000350 RID: 848 RVA: 0x00016B18 File Offset: 0x00014D18
		internal AppDomainSetup(AppDomainSetup setup)
		{
			this.application_base = setup.application_base;
			this.application_name = setup.application_name;
			this.cache_path = setup.cache_path;
			this.configuration_file = setup.configuration_file;
			this.dynamic_base = setup.dynamic_base;
			this.license_file = setup.license_file;
			this.private_bin_path = setup.private_bin_path;
			this.private_bin_path_probe = setup.private_bin_path_probe;
			this.shadow_copy_directories = setup.shadow_copy_directories;
			this.shadow_copy_files = setup.shadow_copy_files;
			this.publisher_policy = setup.publisher_policy;
			this.path_changed = setup.path_changed;
			this.loader_optimization = setup.loader_optimization;
			this.disallow_binding_redirects = setup.disallow_binding_redirects;
			this.disallow_code_downloads = setup.disallow_code_downloads;
			this._activationArguments = setup._activationArguments;
			this.domain_initializer = setup.domain_initializer;
			this.domain_initializer_args = setup.domain_initializer_args;
			this.application_trust_xml = setup.application_trust_xml;
			this.disallow_appbase_probe = setup.disallow_appbase_probe;
			this.configuration_bytes = setup.configuration_bytes;
		}

		// Token: 0x06000351 RID: 849 RVA: 0x00016C28 File Offset: 0x00014E28
		public AppDomainSetup(ActivationArguments activationArguments)
		{
			this._activationArguments = activationArguments;
		}

		// Token: 0x06000352 RID: 850 RVA: 0x00016C38 File Offset: 0x00014E38
		public AppDomainSetup(ActivationContext activationContext)
		{
			this._activationArguments = new ActivationArguments(activationContext);
		}

		// Token: 0x06000353 RID: 851 RVA: 0x00016C4C File Offset: 0x00014E4C
		private static string GetAppBase(string appBase)
		{
			if (appBase == null)
			{
				return null;
			}
			int length = appBase.Length;
			if (length >= 8 && appBase.ToLower().StartsWith("file://"))
			{
				appBase = appBase.Substring(7);
				if (Path.DirectorySeparatorChar != '/')
				{
					appBase = appBase.Replace('/', Path.DirectorySeparatorChar);
				}
				if (Environment.IsRunningOnWindows)
				{
					appBase = "//" + appBase;
				}
			}
			else
			{
				appBase = Path.GetFullPath(appBase);
			}
			return appBase;
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000354 RID: 852 RVA: 0x00016CD0 File Offset: 0x00014ED0
		// (set) Token: 0x06000355 RID: 853 RVA: 0x00016CE0 File Offset: 0x00014EE0
		public string ApplicationBase
		{
			get
			{
				return AppDomainSetup.GetAppBase(this.application_base);
			}
			set
			{
				this.application_base = value;
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000356 RID: 854 RVA: 0x00016CEC File Offset: 0x00014EEC
		// (set) Token: 0x06000357 RID: 855 RVA: 0x00016CF4 File Offset: 0x00014EF4
		public string ApplicationName
		{
			get
			{
				return this.application_name;
			}
			set
			{
				this.application_name = value;
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x06000358 RID: 856 RVA: 0x00016D00 File Offset: 0x00014F00
		// (set) Token: 0x06000359 RID: 857 RVA: 0x00016D08 File Offset: 0x00014F08
		public string CachePath
		{
			get
			{
				return this.cache_path;
			}
			set
			{
				this.cache_path = value;
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x0600035A RID: 858 RVA: 0x00016D14 File Offset: 0x00014F14
		// (set) Token: 0x0600035B RID: 859 RVA: 0x00016D6C File Offset: 0x00014F6C
		public string ConfigurationFile
		{
			get
			{
				if (this.configuration_file == null)
				{
					return null;
				}
				if (Path.IsPathRooted(this.configuration_file))
				{
					return this.configuration_file;
				}
				if (this.ApplicationBase == null)
				{
					throw new MemberAccessException("The ApplicationBase must be set before retrieving this property.");
				}
				return Path.Combine(this.ApplicationBase, this.configuration_file);
			}
			set
			{
				this.configuration_file = value;
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x0600035C RID: 860 RVA: 0x00016D78 File Offset: 0x00014F78
		// (set) Token: 0x0600035D RID: 861 RVA: 0x00016D80 File Offset: 0x00014F80
		public bool DisallowPublisherPolicy
		{
			get
			{
				return this.publisher_policy;
			}
			set
			{
				this.publisher_policy = value;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x0600035E RID: 862 RVA: 0x00016D8C File Offset: 0x00014F8C
		// (set) Token: 0x0600035F RID: 863 RVA: 0x00016DE4 File Offset: 0x00014FE4
		public string DynamicBase
		{
			get
			{
				if (this.dynamic_base == null)
				{
					return null;
				}
				if (Path.IsPathRooted(this.dynamic_base))
				{
					return this.dynamic_base;
				}
				if (this.ApplicationBase == null)
				{
					throw new MemberAccessException("The ApplicationBase must be set before retrieving this property.");
				}
				return Path.Combine(this.ApplicationBase, this.dynamic_base);
			}
			set
			{
				if (this.application_name == null)
				{
					throw new MemberAccessException("ApplicationName must be set before the DynamicBase can be set.");
				}
				this.dynamic_base = Path.Combine(value, ((uint)this.application_name.GetHashCode()).ToString("x"));
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000360 RID: 864 RVA: 0x00016E2C File Offset: 0x0001502C
		// (set) Token: 0x06000361 RID: 865 RVA: 0x00016E34 File Offset: 0x00015034
		public string LicenseFile
		{
			get
			{
				return this.license_file;
			}
			set
			{
				this.license_file = value;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000362 RID: 866 RVA: 0x00016E40 File Offset: 0x00015040
		// (set) Token: 0x06000363 RID: 867 RVA: 0x00016E48 File Offset: 0x00015048
		[MonoLimitation("In Mono this is controlled by the --share-code flag")]
		public LoaderOptimization LoaderOptimization
		{
			get
			{
				return this.loader_optimization;
			}
			set
			{
				this.loader_optimization = value;
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000364 RID: 868 RVA: 0x00016E54 File Offset: 0x00015054
		// (set) Token: 0x06000365 RID: 869 RVA: 0x00016E5C File Offset: 0x0001505C
		public string PrivateBinPath
		{
			get
			{
				return this.private_bin_path;
			}
			set
			{
				this.private_bin_path = value;
				this.path_changed = true;
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000366 RID: 870 RVA: 0x00016E6C File Offset: 0x0001506C
		// (set) Token: 0x06000367 RID: 871 RVA: 0x00016E74 File Offset: 0x00015074
		public string PrivateBinPathProbe
		{
			get
			{
				return this.private_bin_path_probe;
			}
			set
			{
				this.private_bin_path_probe = value;
				this.path_changed = true;
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000368 RID: 872 RVA: 0x00016E84 File Offset: 0x00015084
		// (set) Token: 0x06000369 RID: 873 RVA: 0x00016E8C File Offset: 0x0001508C
		public string ShadowCopyDirectories
		{
			get
			{
				return this.shadow_copy_directories;
			}
			set
			{
				this.shadow_copy_directories = value;
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600036A RID: 874 RVA: 0x00016E98 File Offset: 0x00015098
		// (set) Token: 0x0600036B RID: 875 RVA: 0x00016EA0 File Offset: 0x000150A0
		public string ShadowCopyFiles
		{
			get
			{
				return this.shadow_copy_files;
			}
			set
			{
				this.shadow_copy_files = value;
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x0600036C RID: 876 RVA: 0x00016EAC File Offset: 0x000150AC
		// (set) Token: 0x0600036D RID: 877 RVA: 0x00016EB4 File Offset: 0x000150B4
		public bool DisallowBindingRedirects
		{
			get
			{
				return this.disallow_binding_redirects;
			}
			set
			{
				this.disallow_binding_redirects = value;
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x0600036E RID: 878 RVA: 0x00016EC0 File Offset: 0x000150C0
		// (set) Token: 0x0600036F RID: 879 RVA: 0x00016EC8 File Offset: 0x000150C8
		public bool DisallowCodeDownload
		{
			get
			{
				return this.disallow_code_downloads;
			}
			set
			{
				this.disallow_code_downloads = value;
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000370 RID: 880 RVA: 0x00016ED4 File Offset: 0x000150D4
		// (set) Token: 0x06000371 RID: 881 RVA: 0x00016EDC File Offset: 0x000150DC
		public ActivationArguments ActivationArguments
		{
			get
			{
				return this._activationArguments;
			}
			set
			{
				this._activationArguments = value;
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000372 RID: 882 RVA: 0x00016EE8 File Offset: 0x000150E8
		// (set) Token: 0x06000373 RID: 883 RVA: 0x00016EF0 File Offset: 0x000150F0
		[MonoLimitation("it needs to be invoked within the created domain")]
		public AppDomainInitializer AppDomainInitializer
		{
			get
			{
				return this.domain_initializer;
			}
			set
			{
				this.domain_initializer = value;
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000374 RID: 884 RVA: 0x00016EFC File Offset: 0x000150FC
		// (set) Token: 0x06000375 RID: 885 RVA: 0x00016F04 File Offset: 0x00015104
		[MonoLimitation("it needs to be used to invoke the initializer within the created domain")]
		public string[] AppDomainInitializerArguments
		{
			get
			{
				return this.domain_initializer_args;
			}
			set
			{
				this.domain_initializer_args = value;
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000376 RID: 886 RVA: 0x00016F10 File Offset: 0x00015110
		// (set) Token: 0x06000377 RID: 887 RVA: 0x00016F3C File Offset: 0x0001513C
		[MonoNotSupported("This property exists but not considered.")]
		public ApplicationTrust ApplicationTrust
		{
			get
			{
				if (this.application_trust_xml == null)
				{
					return null;
				}
				if (this.application_trust == null)
				{
					this.application_trust = new ApplicationTrust();
				}
				return this.application_trust;
			}
			set
			{
				this.application_trust = value;
				if (value != null)
				{
					this.application_trust_xml = value.ToXml();
					this.application_trust.FromXml(this.application_trust_xml);
				}
				else
				{
					this.application_trust_xml = null;
				}
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x06000378 RID: 888 RVA: 0x00016F74 File Offset: 0x00015174
		// (set) Token: 0x06000379 RID: 889 RVA: 0x00016F7C File Offset: 0x0001517C
		[MonoNotSupported("This property exists but not considered.")]
		public bool DisallowApplicationBaseProbing
		{
			get
			{
				return this.disallow_appbase_probe;
			}
			set
			{
				this.disallow_appbase_probe = value;
			}
		}

		// Token: 0x0600037A RID: 890 RVA: 0x00016F88 File Offset: 0x00015188
		[MonoNotSupported("This method exists but not considered.")]
		public byte[] GetConfigurationBytes()
		{
			return (this.configuration_bytes == null) ? null : (this.configuration_bytes.Clone() as byte[]);
		}

		// Token: 0x0600037B RID: 891 RVA: 0x00016FAC File Offset: 0x000151AC
		[MonoNotSupported("This method exists but not considered.")]
		public void SetConfigurationBytes(byte[] value)
		{
			this.configuration_bytes = value;
		}

		// Token: 0x04000216 RID: 534
		private string application_base;

		// Token: 0x04000217 RID: 535
		private string application_name;

		// Token: 0x04000218 RID: 536
		private string cache_path;

		// Token: 0x04000219 RID: 537
		private string configuration_file;

		// Token: 0x0400021A RID: 538
		private string dynamic_base;

		// Token: 0x0400021B RID: 539
		private string license_file;

		// Token: 0x0400021C RID: 540
		private string private_bin_path;

		// Token: 0x0400021D RID: 541
		private string private_bin_path_probe;

		// Token: 0x0400021E RID: 542
		private string shadow_copy_directories;

		// Token: 0x0400021F RID: 543
		private string shadow_copy_files;

		// Token: 0x04000220 RID: 544
		private bool publisher_policy;

		// Token: 0x04000221 RID: 545
		private bool path_changed;

		// Token: 0x04000222 RID: 546
		private LoaderOptimization loader_optimization;

		// Token: 0x04000223 RID: 547
		private bool disallow_binding_redirects;

		// Token: 0x04000224 RID: 548
		private bool disallow_code_downloads;

		// Token: 0x04000225 RID: 549
		private ActivationArguments _activationArguments;

		// Token: 0x04000226 RID: 550
		private AppDomainInitializer domain_initializer;

		// Token: 0x04000227 RID: 551
		[NonSerialized]
		private ApplicationTrust application_trust;

		// Token: 0x04000228 RID: 552
		private string[] domain_initializer_args;

		// Token: 0x04000229 RID: 553
		private SecurityElement application_trust_xml;

		// Token: 0x0400022A RID: 554
		private bool disallow_appbase_probe;

		// Token: 0x0400022B RID: 555
		private byte[] configuration_bytes;
	}
}
