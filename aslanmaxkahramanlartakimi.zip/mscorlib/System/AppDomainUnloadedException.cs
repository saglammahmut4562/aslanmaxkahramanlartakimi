﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200007B RID: 123
	[ComVisible(true)]
	[Serializable]
	public class AppDomainUnloadedException : SystemException
	{
		// Token: 0x0600037C RID: 892 RVA: 0x00016FB8 File Offset: 0x000151B8
		public AppDomainUnloadedException()
			: base(Locale.GetText("Can't access an unloaded application domain."))
		{
			base.HResult = -2146234348;
		}

		// Token: 0x0600037D RID: 893 RVA: 0x00016FD8 File Offset: 0x000151D8
		public AppDomainUnloadedException(string message)
			: base(message)
		{
			base.HResult = -2146234348;
		}

		// Token: 0x0600037E RID: 894 RVA: 0x00016FEC File Offset: 0x000151EC
		public AppDomainUnloadedException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2146234348;
		}

		// Token: 0x0600037F RID: 895 RVA: 0x00017004 File Offset: 0x00015204
		protected AppDomainUnloadedException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x0400022C RID: 556
		private const int Result = -2146234348;
	}
}
