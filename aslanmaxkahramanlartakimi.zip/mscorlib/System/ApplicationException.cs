﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200007C RID: 124
	[ComVisible(true)]
	[Serializable]
	public class ApplicationException : Exception
	{
		// Token: 0x06000380 RID: 896 RVA: 0x00017010 File Offset: 0x00015210
		public ApplicationException()
			: base(Locale.GetText("An application exception has occurred."))
		{
			base.HResult = -2146232832;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x00017030 File Offset: 0x00015230
		public ApplicationException(string message)
			: base(message)
		{
			base.HResult = -2146232832;
		}

		// Token: 0x06000382 RID: 898 RVA: 0x00017044 File Offset: 0x00015244
		protected ApplicationException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x0400022D RID: 557
		private const int Result = -2146232832;
	}
}
