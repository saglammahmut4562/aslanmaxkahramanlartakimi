﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200007D RID: 125
	[ComVisible(false)]
	[Serializable]
	public sealed class ApplicationIdentity : ISerializable
	{
		// Token: 0x06000383 RID: 899 RVA: 0x00017050 File Offset: 0x00015250
		public ApplicationIdentity(string applicationIdentityFullName)
		{
			if (applicationIdentityFullName == null)
			{
				throw new ArgumentNullException("applicationIdentityFullName");
			}
			if (applicationIdentityFullName.IndexOf(", Culture=") == -1)
			{
				this._fullName = applicationIdentityFullName + ", Culture=neutral";
			}
			else
			{
				this._fullName = applicationIdentityFullName;
			}
		}

		// Token: 0x06000384 RID: 900 RVA: 0x000170A4 File Offset: 0x000152A4
		[MonoTODO("Missing serialization")]
		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000385 RID: 901 RVA: 0x000170B8 File Offset: 0x000152B8
		public string FullName
		{
			get
			{
				return this._fullName;
			}
		}

		// Token: 0x06000386 RID: 902 RVA: 0x000170C0 File Offset: 0x000152C0
		public override string ToString()
		{
			return this._fullName;
		}

		// Token: 0x0400022E RID: 558
		private string _fullName;

		// Token: 0x0400022F RID: 559
		private string _codeBase;
	}
}
