﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200007E RID: 126
	[StructLayout(3)]
	public struct ArgIterator
	{
		// Token: 0x06000387 RID: 903 RVA: 0x000170C8 File Offset: 0x000152C8
		public ArgIterator(RuntimeArgumentHandle arglist)
		{
			this.sig = IntPtr.Zero;
			this.args = IntPtr.Zero;
			this.next_arg = (this.num_args = 0);
			this.Setup(arglist.args, IntPtr.Zero);
		}

		// Token: 0x06000388 RID: 904
		[MethodImpl(4096)]
		private extern void Setup(IntPtr argsp, IntPtr start);

		// Token: 0x06000389 RID: 905 RVA: 0x00017110 File Offset: 0x00015310
		public override bool Equals(object o)
		{
			throw new NotSupportedException(Locale.GetText("ArgIterator does not support Equals."));
		}

		// Token: 0x0600038A RID: 906 RVA: 0x00017124 File Offset: 0x00015324
		public override int GetHashCode()
		{
			return this.sig.GetHashCode();
		}

		// Token: 0x0600038B RID: 907 RVA: 0x00017134 File Offset: 0x00015334
		[CLSCompliant(false)]
		public TypedReference GetNextArg()
		{
			if (this.num_args == this.next_arg)
			{
				throw new InvalidOperationException(Locale.GetText("Invalid iterator position."));
			}
			return this.IntGetNextArg();
		}

		// Token: 0x0600038C RID: 908
		[MethodImpl(4096)]
		private extern TypedReference IntGetNextArg();

		// Token: 0x0600038D RID: 909 RVA: 0x00017160 File Offset: 0x00015360
		public int GetRemainingCount()
		{
			return this.num_args - this.next_arg;
		}

		// Token: 0x04000230 RID: 560
		private IntPtr sig;

		// Token: 0x04000231 RID: 561
		private IntPtr args;

		// Token: 0x04000232 RID: 562
		private int next_arg;

		// Token: 0x04000233 RID: 563
		private int num_args;
	}
}
