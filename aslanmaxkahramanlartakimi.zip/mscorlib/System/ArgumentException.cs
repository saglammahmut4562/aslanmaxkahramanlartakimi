﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200007F RID: 127
	[ComVisible(true)]
	[Serializable]
	public class ArgumentException : SystemException
	{
		// Token: 0x0600038E RID: 910 RVA: 0x00017170 File Offset: 0x00015370
		public ArgumentException()
			: base(Locale.GetText("Value does not fall within the expected range."))
		{
			base.HResult = -2147024809;
		}

		// Token: 0x0600038F RID: 911 RVA: 0x00017190 File Offset: 0x00015390
		public ArgumentException(string message)
			: base(message)
		{
			base.HResult = -2147024809;
		}

		// Token: 0x06000390 RID: 912 RVA: 0x000171A4 File Offset: 0x000153A4
		public ArgumentException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2147024809;
		}

		// Token: 0x06000391 RID: 913 RVA: 0x000171BC File Offset: 0x000153BC
		public ArgumentException(string message, string paramName)
			: base(message)
		{
			this.param_name = paramName;
			base.HResult = -2147024809;
		}

		// Token: 0x06000392 RID: 914 RVA: 0x000171D8 File Offset: 0x000153D8
		public ArgumentException(string message, string paramName, Exception innerException)
			: base(message, innerException)
		{
			this.param_name = paramName;
			base.HResult = -2147024809;
		}

		// Token: 0x06000393 RID: 915 RVA: 0x000171F4 File Offset: 0x000153F4
		protected ArgumentException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
			this.param_name = info.GetString("ParamName");
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000394 RID: 916 RVA: 0x00017210 File Offset: 0x00015410
		public virtual string ParamName
		{
			get
			{
				return this.param_name;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000395 RID: 917 RVA: 0x00017218 File Offset: 0x00015418
		public override string Message
		{
			get
			{
				if (this.ParamName != null && this.ParamName.Length != 0)
				{
					return base.Message + Environment.NewLine + Locale.GetText("Parameter name: ") + this.ParamName;
				}
				return base.Message;
			}
		}

		// Token: 0x06000396 RID: 918 RVA: 0x00017268 File Offset: 0x00015468
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("ParamName", this.ParamName);
		}

		// Token: 0x04000234 RID: 564
		private const int Result = -2147024809;

		// Token: 0x04000235 RID: 565
		private string param_name;
	}
}
