﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000080 RID: 128
	[ComVisible(true)]
	[Serializable]
	public class ArgumentNullException : ArgumentException
	{
		// Token: 0x06000397 RID: 919 RVA: 0x00017284 File Offset: 0x00015484
		public ArgumentNullException()
			: base(Locale.GetText("Argument cannot be null."))
		{
			base.HResult = -2147467261;
		}

		// Token: 0x06000398 RID: 920 RVA: 0x000172A4 File Offset: 0x000154A4
		public ArgumentNullException(string paramName)
			: base(Locale.GetText("Argument cannot be null."), paramName)
		{
			base.HResult = -2147467261;
		}

		// Token: 0x06000399 RID: 921 RVA: 0x000172C4 File Offset: 0x000154C4
		public ArgumentNullException(string paramName, string message)
			: base(message, paramName)
		{
			base.HResult = -2147467261;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x000172DC File Offset: 0x000154DC
		protected ArgumentNullException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000236 RID: 566
		private const int Result = -2147467261;
	}
}
