﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000081 RID: 129
	[ComVisible(true)]
	[Serializable]
	public class ArgumentOutOfRangeException : ArgumentException
	{
		// Token: 0x0600039B RID: 923 RVA: 0x000172E8 File Offset: 0x000154E8
		public ArgumentOutOfRangeException()
			: base(Locale.GetText("Argument is out of range."))
		{
			base.HResult = -2146233086;
		}

		// Token: 0x0600039C RID: 924 RVA: 0x00017308 File Offset: 0x00015508
		public ArgumentOutOfRangeException(string paramName)
			: base(Locale.GetText("Argument is out of range."), paramName)
		{
			base.HResult = -2146233086;
		}

		// Token: 0x0600039D RID: 925 RVA: 0x00017328 File Offset: 0x00015528
		public ArgumentOutOfRangeException(string paramName, string message)
			: base(message, paramName)
		{
			base.HResult = -2146233086;
		}

		// Token: 0x0600039E RID: 926 RVA: 0x00017340 File Offset: 0x00015540
		public ArgumentOutOfRangeException(string paramName, object actualValue, string message)
			: base(message, paramName)
		{
			this.actual_value = actualValue;
			base.HResult = -2146233086;
		}

		// Token: 0x0600039F RID: 927 RVA: 0x0001735C File Offset: 0x0001555C
		protected ArgumentOutOfRangeException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
			this.actual_value = info.GetString("ActualValue");
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060003A0 RID: 928 RVA: 0x00017378 File Offset: 0x00015578
		public override string Message
		{
			get
			{
				string message = base.Message;
				if (this.actual_value == null)
				{
					return message;
				}
				return message + Environment.NewLine + this.actual_value;
			}
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x000173AC File Offset: 0x000155AC
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("ActualValue", this.actual_value);
		}

		// Token: 0x04000237 RID: 567
		private const int Result = -2146233086;

		// Token: 0x04000238 RID: 568
		private object actual_value;
	}
}
