﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000082 RID: 130
	[ComVisible(true)]
	[Serializable]
	public class ArithmeticException : SystemException
	{
		// Token: 0x060003A2 RID: 930 RVA: 0x000173C8 File Offset: 0x000155C8
		public ArithmeticException()
			: base(Locale.GetText("Overflow or underflow in the arithmetic operation."))
		{
			base.HResult = -2147024362;
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x000173E8 File Offset: 0x000155E8
		public ArithmeticException(string message)
			: base(message)
		{
			base.HResult = -2147024362;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x000173FC File Offset: 0x000155FC
		public ArithmeticException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2147024362;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x00017414 File Offset: 0x00015614
		protected ArithmeticException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000239 RID: 569
		private const int Result = -2147024362;
	}
}
