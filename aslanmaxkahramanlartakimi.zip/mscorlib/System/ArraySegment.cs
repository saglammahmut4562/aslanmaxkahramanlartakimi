﻿using System;

namespace System
{
	// Token: 0x02000089 RID: 137
	[Serializable]
	public struct ArraySegment<T>
	{
		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000463 RID: 1123 RVA: 0x0001A1CC File Offset: 0x000183CC
		public T[] Array
		{
			get
			{
				return this.array;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000464 RID: 1124 RVA: 0x0001A1D4 File Offset: 0x000183D4
		public int Offset
		{
			get
			{
				return this.offset;
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000465 RID: 1125 RVA: 0x0001A1DC File Offset: 0x000183DC
		public int Count
		{
			get
			{
				return this.count;
			}
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x0001A1E4 File Offset: 0x000183E4
		public override bool Equals(object obj)
		{
			return obj is ArraySegment<T> && this.Equals((ArraySegment<T>)obj);
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x0001A200 File Offset: 0x00018400
		public bool Equals(ArraySegment<T> obj)
		{
			return this.array == obj.Array && this.offset == obj.Offset && this.count == obj.Count;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x0001A23C File Offset: 0x0001843C
		public override int GetHashCode()
		{
			return this.array.GetHashCode() ^ this.offset ^ this.count;
		}

		// Token: 0x04000246 RID: 582
		private T[] array;

		// Token: 0x04000247 RID: 583
		private int offset;

		// Token: 0x04000248 RID: 584
		private int count;
	}
}
