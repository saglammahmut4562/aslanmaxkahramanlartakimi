﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200008A RID: 138
	[ComVisible(true)]
	[Serializable]
	public class ArrayTypeMismatchException : SystemException
	{
		// Token: 0x06000469 RID: 1129 RVA: 0x0001A258 File Offset: 0x00018458
		public ArrayTypeMismatchException()
			: base(Locale.GetText("Source array type cannot be assigned to destination array type."))
		{
			base.HResult = -2146233085;
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x0001A278 File Offset: 0x00018478
		public ArrayTypeMismatchException(string message)
			: base(message)
		{
			base.HResult = -2146233085;
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x0001A28C File Offset: 0x0001848C
		protected ArrayTypeMismatchException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000249 RID: 585
		private const int Result = -2146233085;
	}
}
