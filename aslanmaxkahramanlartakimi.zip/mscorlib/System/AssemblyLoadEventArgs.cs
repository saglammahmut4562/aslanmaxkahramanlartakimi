﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200008B RID: 139
	[ComVisible(true)]
	public class AssemblyLoadEventArgs : EventArgs
	{
		// Token: 0x0600046C RID: 1132 RVA: 0x0001A298 File Offset: 0x00018498
		public AssemblyLoadEventArgs(Assembly loadedAssembly)
		{
			this.m_loadedAssembly = loadedAssembly;
		}

		// Token: 0x0400024A RID: 586
		private Assembly m_loadedAssembly;
	}
}
