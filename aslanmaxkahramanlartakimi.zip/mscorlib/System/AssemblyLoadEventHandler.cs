﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200008C RID: 140
	// (Invoke) Token: 0x0600046E RID: 1134
	[ComVisible(true)]
	[Serializable]
	public delegate void AssemblyLoadEventHandler(object sender, AssemblyLoadEventArgs args);
}
