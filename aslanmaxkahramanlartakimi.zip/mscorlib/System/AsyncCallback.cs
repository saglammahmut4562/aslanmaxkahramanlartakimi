﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200008D RID: 141
	// (Invoke) Token: 0x06000472 RID: 1138
	[ComVisible(true)]
	[Serializable]
	public delegate void AsyncCallback(IAsyncResult ar);
}
