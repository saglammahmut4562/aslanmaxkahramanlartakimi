﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200008E RID: 142
	[ComDefaultInterface(typeof(_Attribute))]
	[ClassInterface(ClassInterfaceType.None)]
	[AttributeUsage(AttributeTargets.All)]
	[ComVisible(true)]
	[Serializable]
	public abstract class Attribute : _Attribute
	{
		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000476 RID: 1142 RVA: 0x0001A2B0 File Offset: 0x000184B0
		public virtual object TypeId
		{
			get
			{
				return base.GetType();
			}
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x0001A2B8 File Offset: 0x000184B8
		private static void CheckParameters(object element, Type attributeType)
		{
			if (element == null)
			{
				throw new ArgumentNullException("element");
			}
			if (attributeType == null)
			{
				throw new ArgumentNullException("attributeType");
			}
			if (!typeof(Attribute).IsAssignableFrom(attributeType))
			{
				throw new ArgumentException(Locale.GetText("Type is not derived from System.Attribute."), "attributeType");
			}
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x0001A314 File Offset: 0x00018514
		public static Attribute GetCustomAttribute(MemberInfo element, Type attributeType)
		{
			return Attribute.GetCustomAttribute(element, attributeType, true);
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x0001A320 File Offset: 0x00018520
		public static Attribute GetCustomAttribute(MemberInfo element, Type attributeType, bool inherit)
		{
			Attribute.CheckParameters(element, attributeType);
			return MonoCustomAttrs.GetCustomAttribute(element, attributeType, inherit);
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x0001A334 File Offset: 0x00018534
		public static Attribute[] GetCustomAttributes(Assembly element, Type attributeType, bool inherit)
		{
			Attribute.CheckParameters(element, attributeType);
			return (Attribute[])element.GetCustomAttributes(attributeType, inherit);
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x0001A34C File Offset: 0x0001854C
		public static Attribute[] GetCustomAttributes(ParameterInfo element, Type attributeType, bool inherit)
		{
			Attribute.CheckParameters(element, attributeType);
			return (Attribute[])element.GetCustomAttributes(attributeType, inherit);
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0001A364 File Offset: 0x00018564
		public static Attribute[] GetCustomAttributes(Module element, Type attributeType, bool inherit)
		{
			Attribute.CheckParameters(element, attributeType);
			return (Attribute[])element.GetCustomAttributes(attributeType, inherit);
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x0001A37C File Offset: 0x0001857C
		public static Attribute[] GetCustomAttributes(MemberInfo element, Type type, bool inherit)
		{
			Attribute.CheckParameters(element, type);
			MemberTypes memberType = element.MemberType;
			if (memberType == MemberTypes.Property)
			{
				return (Attribute[])MonoCustomAttrs.GetCustomAttributes(element, type, inherit);
			}
			return (Attribute[])element.GetCustomAttributes(type, inherit);
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0001A3BC File Offset: 0x000185BC
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x0001A3C4 File Offset: 0x000185C4
		public virtual bool IsDefaultAttribute()
		{
			return false;
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0001A3C8 File Offset: 0x000185C8
		public static bool IsDefined(ParameterInfo element, Type attributeType)
		{
			return Attribute.IsDefined(element, attributeType, true);
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x0001A3D4 File Offset: 0x000185D4
		public static bool IsDefined(MemberInfo element, Type attributeType)
		{
			return Attribute.IsDefined(element, attributeType, true);
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x0001A3E0 File Offset: 0x000185E0
		public static bool IsDefined(MemberInfo element, Type attributeType, bool inherit)
		{
			Attribute.CheckParameters(element, attributeType);
			MemberTypes memberType = element.MemberType;
			if (memberType != MemberTypes.Constructor && memberType != MemberTypes.Event && memberType != MemberTypes.Field && memberType != MemberTypes.Method && memberType != MemberTypes.Property && memberType != MemberTypes.TypeInfo && memberType != MemberTypes.NestedType)
			{
				throw new NotSupportedException(Locale.GetText("Element is not a constructor, method, property, event, type or field."));
			}
			if (memberType == MemberTypes.Property)
			{
				return MonoCustomAttrs.IsDefined(element, attributeType, inherit);
			}
			return element.IsDefined(attributeType, inherit);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x0001A45C File Offset: 0x0001865C
		public static bool IsDefined(ParameterInfo element, Type attributeType, bool inherit)
		{
			Attribute.CheckParameters(element, attributeType);
			return element.IsDefined(attributeType, inherit) || Attribute.IsDefined(element.Member, attributeType, inherit);
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x0001A484 File Offset: 0x00018684
		public override bool Equals(object obj)
		{
			return obj != null && obj is Attribute && ValueType.DefaultEquals(this, obj);
		}
	}
}
