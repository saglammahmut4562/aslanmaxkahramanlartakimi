﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200008F RID: 143
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum AttributeTargets
	{
		// Token: 0x0400024C RID: 588
		Assembly = 1,
		// Token: 0x0400024D RID: 589
		Module = 2,
		// Token: 0x0400024E RID: 590
		Class = 4,
		// Token: 0x0400024F RID: 591
		Struct = 8,
		// Token: 0x04000250 RID: 592
		Enum = 16,
		// Token: 0x04000251 RID: 593
		Constructor = 32,
		// Token: 0x04000252 RID: 594
		Method = 64,
		// Token: 0x04000253 RID: 595
		Property = 128,
		// Token: 0x04000254 RID: 596
		Field = 256,
		// Token: 0x04000255 RID: 597
		Event = 512,
		// Token: 0x04000256 RID: 598
		Interface = 1024,
		// Token: 0x04000257 RID: 599
		Parameter = 2048,
		// Token: 0x04000258 RID: 600
		Delegate = 4096,
		// Token: 0x04000259 RID: 601
		ReturnValue = 8192,
		// Token: 0x0400025A RID: 602
		GenericParameter = 16384,
		// Token: 0x0400025B RID: 603
		All = 32767
	}
}
