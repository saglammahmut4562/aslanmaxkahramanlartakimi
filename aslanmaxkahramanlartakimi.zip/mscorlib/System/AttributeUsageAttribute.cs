﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000090 RID: 144
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Class)]
	[Serializable]
	public sealed class AttributeUsageAttribute : Attribute
	{
		// Token: 0x06000485 RID: 1157 RVA: 0x0001A4A0 File Offset: 0x000186A0
		public AttributeUsageAttribute(AttributeTargets validOn)
		{
			this.valid_on = validOn;
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000486 RID: 1158 RVA: 0x0001A4B8 File Offset: 0x000186B8
		// (set) Token: 0x06000487 RID: 1159 RVA: 0x0001A4C0 File Offset: 0x000186C0
		public bool AllowMultiple
		{
			get
			{
				return this.allow_multiple;
			}
			set
			{
				this.allow_multiple = value;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000488 RID: 1160 RVA: 0x0001A4CC File Offset: 0x000186CC
		// (set) Token: 0x06000489 RID: 1161 RVA: 0x0001A4D4 File Offset: 0x000186D4
		public bool Inherited
		{
			get
			{
				return this.inherited;
			}
			set
			{
				this.inherited = value;
			}
		}

		// Token: 0x0400025C RID: 604
		private AttributeTargets valid_on;

		// Token: 0x0400025D RID: 605
		private bool allow_multiple;

		// Token: 0x0400025E RID: 606
		private bool inherited = true;
	}
}
