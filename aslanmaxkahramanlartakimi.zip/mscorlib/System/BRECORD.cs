﻿using System;

namespace System
{
	// Token: 0x02000093 RID: 147
	internal struct BRECORD
	{
		// Token: 0x04000264 RID: 612
		private IntPtr pvRecord;

		// Token: 0x04000265 RID: 613
		private IntPtr pRecInfo;
	}
}
