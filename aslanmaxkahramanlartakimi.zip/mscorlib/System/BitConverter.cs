﻿using System;
using System.Text;

namespace System
{
	// Token: 0x02000091 RID: 145
	public static class BitConverter
	{
		// Token: 0x0600048B RID: 1163 RVA: 0x0001A4F8 File Offset: 0x000186F8
		private static bool AmILittleEndian()
		{
			double num = 1.0;
			return num == (double)0;
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0001A518 File Offset: 0x00018718
		private unsafe static bool DoubleWordsAreSwapped()
		{
			double num = 1.0;
			return *((ref num) + 2) == 240;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x0001A540 File Offset: 0x00018740
		public static long DoubleToInt64Bits(double value)
		{
			return BitConverter.ToInt64(BitConverter.GetBytes(value), 0);
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x0001A550 File Offset: 0x00018750
		private unsafe static byte[] GetBytes(byte* ptr, int count)
		{
			byte[] array = new byte[count];
			for (int i = 0; i < count; i++)
			{
				array[i] = ptr[i];
			}
			return array;
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x0001A580 File Offset: 0x00018780
		public unsafe static byte[] GetBytes(double value)
		{
			if (BitConverter.SwappedWordsInDouble)
			{
				return new byte[]
				{
					*((ref value) + 4),
					*((ref value) + 5),
					*((ref value) + 6),
					*((ref value) + 7),
					(byte)value,
					*((ref value) + 1),
					*((ref value) + 2),
					*((ref value) + 3)
				};
			}
			return BitConverter.GetBytes((byte*)(&value), 8);
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x0001A5E4 File Offset: 0x000187E4
		private unsafe static void PutBytes(byte* dst, byte[] src, int start_index, int count)
		{
			if (src == null)
			{
				throw new ArgumentNullException("value");
			}
			if (start_index < 0 || start_index > src.Length - 1)
			{
				throw new ArgumentOutOfRangeException("startIndex", "Index was out of range. Must be non-negative and less than the size of the collection.");
			}
			if (src.Length - count < start_index)
			{
				throw new ArgumentException("Destination array is not long enough to copy all the items in the collection. Check array index and length.");
			}
			for (int i = 0; i < count; i++)
			{
				dst[i] = src[i + start_index];
			}
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x0001A658 File Offset: 0x00018858
		public unsafe static int ToInt32(byte[] value, int startIndex)
		{
			int num;
			BitConverter.PutBytes((byte*)(&num), value, startIndex, 4);
			return num;
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x0001A670 File Offset: 0x00018870
		public unsafe static long ToInt64(byte[] value, int startIndex)
		{
			long num;
			BitConverter.PutBytes((byte*)(&num), value, startIndex, 8);
			return num;
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x0001A688 File Offset: 0x00018888
		public static string ToString(byte[] value)
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			return BitConverter.ToString(value, 0, value.Length);
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x0001A6A8 File Offset: 0x000188A8
		public static string ToString(byte[] value, int startIndex, int length)
		{
			if (value == null)
			{
				throw new ArgumentNullException("byteArray");
			}
			if (startIndex < 0 || startIndex >= value.Length)
			{
				if (startIndex == 0 && value.Length == 0)
				{
					return string.Empty;
				}
				throw new ArgumentOutOfRangeException("startIndex", "Index was out of range. Must be non-negative and less than the size of the collection.");
			}
			else
			{
				if (length < 0)
				{
					throw new ArgumentOutOfRangeException("length", "Value must be positive.");
				}
				if (startIndex > value.Length - length)
				{
					throw new ArgumentException("startIndex + length > value.Length");
				}
				if (length == 0)
				{
					return string.Empty;
				}
				StringBuilder stringBuilder = new StringBuilder(length * 3 - 1);
				int num = startIndex + length;
				for (int i = startIndex; i < num; i++)
				{
					if (i > startIndex)
					{
						stringBuilder.Append('-');
					}
					char c = (char)((value[i] >> 4) & 15);
					char c2 = (char)(value[i] & 15);
					if (c < '\n')
					{
						c += '0';
					}
					else
					{
						c -= '\n';
						c += 'A';
					}
					if (c2 < '\n')
					{
						c2 += '0';
					}
					else
					{
						c2 -= '\n';
						c2 += 'A';
					}
					stringBuilder.Append(c);
					stringBuilder.Append(c2);
				}
				return stringBuilder.ToString();
			}
		}

		// Token: 0x0400025F RID: 607
		private static readonly bool SwappedWordsInDouble = BitConverter.DoubleWordsAreSwapped();

		// Token: 0x04000260 RID: 608
		public static readonly bool IsLittleEndian = BitConverter.AmILittleEndian();
	}
}
