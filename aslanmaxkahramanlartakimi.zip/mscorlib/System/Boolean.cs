﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000092 RID: 146
	[ComVisible(true)]
	[Serializable]
	public struct Boolean : IComparable<bool>, IEquatable<bool>, IComparable, IConvertible
	{
		// Token: 0x06000496 RID: 1174 RVA: 0x0001A7EC File Offset: 0x000189EC
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			return Convert.ToType(this, targetType, provider, false);
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x0001A810 File Offset: 0x00018A10
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return this;
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x0001A814 File Offset: 0x00018A14
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this);
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x0001A820 File Offset: 0x00018A20
		char IConvertible.ToChar(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x0001A828 File Offset: 0x00018A28
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x0001A830 File Offset: 0x00018A30
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return Convert.ToDecimal(this);
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x0001A83C File Offset: 0x00018A3C
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this);
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0001A848 File Offset: 0x00018A48
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x0001A854 File Offset: 0x00018A54
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x0001A860 File Offset: 0x00018A60
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x0001A86C File Offset: 0x00018A6C
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x0001A878 File Offset: 0x00018A78
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return Convert.ToSingle(this);
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x0001A884 File Offset: 0x00018A84
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x0001A890 File Offset: 0x00018A90
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x0001A89C File Offset: 0x00018A9C
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0001A8A8 File Offset: 0x00018AA8
		public int CompareTo(object obj)
		{
			if (obj == null)
			{
				return 1;
			}
			if (!(obj is bool))
			{
				throw new ArgumentException(Locale.GetText("Object is not a Boolean."));
			}
			bool flag = (bool)obj;
			if (this && !flag)
			{
				return 1;
			}
			return (this != flag) ? (-1) : 0;
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x0001A900 File Offset: 0x00018B00
		public override bool Equals(object obj)
		{
			if (obj == null || !(obj is bool))
			{
				return false;
			}
			bool flag = (bool)obj;
			return (!this) ? (!flag) : flag;
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x0001A938 File Offset: 0x00018B38
		public int CompareTo(bool value)
		{
			if (this == value)
			{
				return 0;
			}
			return this ? 1 : (-1);
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x0001A954 File Offset: 0x00018B54
		public bool Equals(bool obj)
		{
			return this == obj;
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x0001A95C File Offset: 0x00018B5C
		public override int GetHashCode()
		{
			return (!this) ? 0 : 1;
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x0001A96C File Offset: 0x00018B6C
		public static bool Parse(string value)
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			value = value.Trim();
			if (string.Compare(value, bool.TrueString, true, CultureInfo.InvariantCulture) == 0)
			{
				return true;
			}
			if (string.Compare(value, bool.FalseString, true, CultureInfo.InvariantCulture) == 0)
			{
				return false;
			}
			throw new FormatException(Locale.GetText("Value is not equivalent to either TrueString or FalseString."));
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x0001A9D4 File Offset: 0x00018BD4
		public static bool TryParse(string value, out bool result)
		{
			result = false;
			if (value == null)
			{
				return false;
			}
			value = value.Trim();
			if (string.Compare(value, bool.TrueString, true, CultureInfo.InvariantCulture) == 0)
			{
				result = true;
				return true;
			}
			return string.Compare(value, bool.FalseString, true, CultureInfo.InvariantCulture) == 0;
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x0001AA28 File Offset: 0x00018C28
		public override string ToString()
		{
			return (!this) ? bool.FalseString : bool.TrueString;
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x0001AA40 File Offset: 0x00018C40
		public TypeCode GetTypeCode()
		{
			return TypeCode.Boolean;
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x0001AA44 File Offset: 0x00018C44
		public string ToString(IFormatProvider provider)
		{
			return this.ToString();
		}

		// Token: 0x04000261 RID: 609
		public static readonly string FalseString = "False";

		// Token: 0x04000262 RID: 610
		public static readonly string TrueString = "True";

		// Token: 0x04000263 RID: 611
		internal bool m_value;
	}
}
