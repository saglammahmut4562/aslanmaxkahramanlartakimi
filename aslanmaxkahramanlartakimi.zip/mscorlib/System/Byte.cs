﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000095 RID: 149
	[ComVisible(true)]
	[Serializable]
	public struct Byte : IComparable<byte>, IEquatable<byte>, IComparable, IConvertible, IFormattable
	{
		// Token: 0x060004B3 RID: 1203 RVA: 0x0001AB50 File Offset: 0x00018D50
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			return Convert.ToType(this, targetType, provider, false);
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x0001AB74 File Offset: 0x00018D74
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return Convert.ToBoolean(this);
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0001AB80 File Offset: 0x00018D80
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return this;
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0001AB84 File Offset: 0x00018D84
		char IConvertible.ToChar(IFormatProvider provider)
		{
			return Convert.ToChar(this);
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x0001AB90 File Offset: 0x00018D90
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x0001AB98 File Offset: 0x00018D98
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return Convert.ToDecimal(this);
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x0001ABA4 File Offset: 0x00018DA4
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this);
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x0001ABB0 File Offset: 0x00018DB0
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x0001ABBC File Offset: 0x00018DBC
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x0001ABC8 File Offset: 0x00018DC8
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x0001ABD4 File Offset: 0x00018DD4
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x0001ABE0 File Offset: 0x00018DE0
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return Convert.ToSingle(this);
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0001ABEC File Offset: 0x00018DEC
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0001ABF8 File Offset: 0x00018DF8
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0001AC04 File Offset: 0x00018E04
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0001AC10 File Offset: 0x00018E10
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is byte))
			{
				throw new ArgumentException(Locale.GetText("Value is not a System.Byte."));
			}
			byte b = (byte)value;
			if (this == b)
			{
				return 0;
			}
			if (this > b)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0001AC5C File Offset: 0x00018E5C
		public override bool Equals(object obj)
		{
			return obj is byte && (byte)obj == this;
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0001AC78 File Offset: 0x00018E78
		public override int GetHashCode()
		{
			return (int)this;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0001AC7C File Offset: 0x00018E7C
		public int CompareTo(byte value)
		{
			if (this == value)
			{
				return 0;
			}
			if (this > value)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0001AC94 File Offset: 0x00018E94
		public bool Equals(byte obj)
		{
			return this == obj;
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0001AC9C File Offset: 0x00018E9C
		public static byte Parse(string s, IFormatProvider provider)
		{
			return byte.Parse(s, NumberStyles.Integer, provider);
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x0001ACA8 File Offset: 0x00018EA8
		public static byte Parse(string s, NumberStyles style, IFormatProvider provider)
		{
			uint num = uint.Parse(s, style, provider);
			if (num > 255U)
			{
				throw new OverflowException(Locale.GetText("Value too large."));
			}
			return (byte)num;
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x0001ACDC File Offset: 0x00018EDC
		public static byte Parse(string s)
		{
			return byte.Parse(s, NumberStyles.Integer, null);
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x0001ACE8 File Offset: 0x00018EE8
		public static bool TryParse(string s, out byte result)
		{
			return byte.TryParse(s, NumberStyles.Integer, null, out result);
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x0001ACF4 File Offset: 0x00018EF4
		public static bool TryParse(string s, NumberStyles style, IFormatProvider provider, out byte result)
		{
			result = 0;
			uint num;
			if (!uint.TryParse(s, style, provider, out num))
			{
				return false;
			}
			if (num > 255U)
			{
				return false;
			}
			result = (byte)num;
			return true;
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x0001AD28 File Offset: 0x00018F28
		public override string ToString()
		{
			return NumberFormatter.NumberToString((int)this, null);
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x0001AD34 File Offset: 0x00018F34
		public string ToString(string format)
		{
			return this.ToString(format, null);
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x0001AD40 File Offset: 0x00018F40
		public string ToString(IFormatProvider provider)
		{
			return NumberFormatter.NumberToString((int)this, provider);
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x0001AD4C File Offset: 0x00018F4C
		public string ToString(string format, IFormatProvider provider)
		{
			return NumberFormatter.NumberToString(format, this, provider);
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x0001AD58 File Offset: 0x00018F58
		public TypeCode GetTypeCode()
		{
			return TypeCode.Byte;
		}

		// Token: 0x04000266 RID: 614
		public const byte MinValue = 0;

		// Token: 0x04000267 RID: 615
		public const byte MaxValue = 255;

		// Token: 0x04000268 RID: 616
		internal byte m_value;
	}
}
