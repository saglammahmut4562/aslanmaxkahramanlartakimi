﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000098 RID: 152
	[AttributeUsage(AttributeTargets.All)]
	[ComVisible(true)]
	[Serializable]
	public sealed class CLSCompliantAttribute : Attribute
	{
		// Token: 0x06000505 RID: 1285 RVA: 0x0001B244 File Offset: 0x00019444
		public CLSCompliantAttribute(bool isCompliant)
		{
			this.is_compliant = isCompliant;
		}

		// Token: 0x04000276 RID: 630
		private bool is_compliant;
	}
}
