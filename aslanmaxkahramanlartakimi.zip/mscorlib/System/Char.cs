﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000096 RID: 150
	[ComVisible(true)]
	[Serializable]
	public struct Char : IComparable<char>, IEquatable<char>, IComparable, IConvertible
	{
		// Token: 0x060004D1 RID: 1233 RVA: 0x0001AD5C File Offset: 0x00018F5C
		static Char()
		{
			char.GetDataTablePointers(out char.category_data, out char.numeric_data, out char.numeric_data_values, out char.to_lower_data_low, out char.to_lower_data_high, out char.to_upper_data_low, out char.to_upper_data_high);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x0001AD88 File Offset: 0x00018F88
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			return Convert.ToType(this, targetType, provider, false);
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x0001ADAC File Offset: 0x00018FAC
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x0001ADB4 File Offset: 0x00018FB4
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this);
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x0001ADC0 File Offset: 0x00018FC0
		char IConvertible.ToChar(IFormatProvider provider)
		{
			return this;
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x0001ADC4 File Offset: 0x00018FC4
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x0001ADCC File Offset: 0x00018FCC
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x0001ADD4 File Offset: 0x00018FD4
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x0001ADDC File Offset: 0x00018FDC
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x0001ADE8 File Offset: 0x00018FE8
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x0001ADF4 File Offset: 0x00018FF4
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x0001AE00 File Offset: 0x00019000
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x0001AE0C File Offset: 0x0001900C
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x0001AE14 File Offset: 0x00019014
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0001AE20 File Offset: 0x00019020
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0001AE2C File Offset: 0x0001902C
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x060004E1 RID: 1249
		[MethodImpl(4096)]
		private unsafe static extern void GetDataTablePointers(out byte* category_data, out byte* numeric_data, out double* numeric_data_values, out ushort* to_lower_data_low, out ushort* to_lower_data_high, out ushort* to_upper_data_low, out ushort* to_upper_data_high);

		// Token: 0x060004E2 RID: 1250 RVA: 0x0001AE38 File Offset: 0x00019038
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is char))
			{
				throw new ArgumentException(Locale.GetText("Value is not a System.Char"));
			}
			char c = (char)value;
			if (this == c)
			{
				return 0;
			}
			if (this > c)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x0001AE84 File Offset: 0x00019084
		public override bool Equals(object obj)
		{
			return obj is char && (char)obj == this;
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x0001AEA0 File Offset: 0x000190A0
		public int CompareTo(char value)
		{
			if (this == value)
			{
				return 0;
			}
			if (this > value)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x0001AEB8 File Offset: 0x000190B8
		public bool Equals(char obj)
		{
			return this == obj;
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x0001AEC0 File Offset: 0x000190C0
		public override int GetHashCode()
		{
			return (int)this;
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x0001AEC4 File Offset: 0x000190C4
		public unsafe static UnicodeCategory GetUnicodeCategory(char c)
		{
			return (UnicodeCategory)char.category_data[c];
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x0001AED0 File Offset: 0x000190D0
		public unsafe static bool IsDigit(char c)
		{
			return char.category_data[c] == 8;
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x0001AEE0 File Offset: 0x000190E0
		public static bool IsDigit(string s, int index)
		{
			char.CheckParameter(s, index);
			return char.IsDigit(s[index]);
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x0001AEF8 File Offset: 0x000190F8
		public unsafe static bool IsLetter(char c)
		{
			return char.category_data[c] <= 4;
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x0001AF08 File Offset: 0x00019108
		public unsafe static bool IsLetterOrDigit(char c)
		{
			int num = (int)char.category_data[c];
			return num <= 4 || num == 8;
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x0001AF2C File Offset: 0x0001912C
		public static bool IsLetterOrDigit(string s, int index)
		{
			char.CheckParameter(s, index);
			return char.IsLetterOrDigit(s[index]);
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x0001AF44 File Offset: 0x00019144
		public unsafe static bool IsLower(char c)
		{
			return char.category_data[c] == 1;
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x0001AF54 File Offset: 0x00019154
		public unsafe static bool IsNumber(char c)
		{
			int num = (int)char.category_data[c];
			return num >= 8 && num <= 10;
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x0001AF7C File Offset: 0x0001917C
		public unsafe static bool IsSurrogate(char c)
		{
			return char.category_data[c] == 16;
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x0001AF8C File Offset: 0x0001918C
		public unsafe static bool IsUpper(char c)
		{
			return char.category_data[c] == 0;
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x0001AF9C File Offset: 0x0001919C
		public unsafe static bool IsWhiteSpace(char c)
		{
			int num = (int)char.category_data[c];
			return num > 10 && (num <= 13 || (c >= '\t' && c <= '\r') || c == '\u0085' || c == '\u205f');
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x0001AFEC File Offset: 0x000191EC
		public static bool IsWhiteSpace(string s, int index)
		{
			char.CheckParameter(s, index);
			return char.IsWhiteSpace(s[index]);
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x0001B004 File Offset: 0x00019204
		private static void CheckParameter(string s, int index)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			if (index < 0 || index >= s.Length)
			{
				throw new ArgumentOutOfRangeException(Locale.GetText("The value of index is less than zero, or greater than or equal to the length of s."));
			}
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0001B03C File Offset: 0x0001923C
		public static char Parse(string s)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			if (s.Length != 1)
			{
				throw new FormatException(Locale.GetText("s contains more than one character."));
			}
			return s[0];
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x0001B074 File Offset: 0x00019274
		public static char ToLower(char c)
		{
			return CultureInfo.CurrentCulture.TextInfo.ToLower(c);
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x0001B088 File Offset: 0x00019288
		public unsafe static char ToLowerInvariant(char c)
		{
			if (c <= 'Ⓩ')
			{
				return (char)char.to_lower_data_low[c];
			}
			if (c >= 'Ａ')
			{
				return (char)char.to_lower_data_high[c - 'Ａ'];
			}
			return c;
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x0001B0C0 File Offset: 0x000192C0
		public static char ToLower(char c, CultureInfo culture)
		{
			if (culture == null)
			{
				throw new ArgumentNullException("culture");
			}
			if (culture.LCID == 127)
			{
				return char.ToLowerInvariant(c);
			}
			return culture.TextInfo.ToLower(c);
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x0001B0F4 File Offset: 0x000192F4
		public static char ToUpper(char c)
		{
			return CultureInfo.CurrentCulture.TextInfo.ToUpper(c);
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x0001B108 File Offset: 0x00019308
		public unsafe static char ToUpperInvariant(char c)
		{
			if (c <= 'ⓩ')
			{
				return (char)char.to_upper_data_low[c];
			}
			if (c >= 'Ａ')
			{
				return (char)char.to_upper_data_high[c - 'Ａ'];
			}
			return c;
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x0001B140 File Offset: 0x00019340
		public override string ToString()
		{
			return new string(this, 1);
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x0001B14C File Offset: 0x0001934C
		public static string ToString(char c)
		{
			return new string(c, 1);
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x0001B158 File Offset: 0x00019358
		public string ToString(IFormatProvider provider)
		{
			return new string(this, 1);
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x0001B164 File Offset: 0x00019364
		public TypeCode GetTypeCode()
		{
			return TypeCode.Char;
		}

		// Token: 0x04000269 RID: 617
		public const char MaxValue = '\uffff';

		// Token: 0x0400026A RID: 618
		public const char MinValue = '\0';

		// Token: 0x0400026B RID: 619
		internal char m_value;

		// Token: 0x0400026C RID: 620
		private unsafe static readonly byte* category_data;

		// Token: 0x0400026D RID: 621
		private unsafe static readonly byte* numeric_data;

		// Token: 0x0400026E RID: 622
		private unsafe static readonly double* numeric_data_values;

		// Token: 0x0400026F RID: 623
		private unsafe static readonly ushort* to_lower_data_low;

		// Token: 0x04000270 RID: 624
		private unsafe static readonly ushort* to_lower_data_high;

		// Token: 0x04000271 RID: 625
		private unsafe static readonly ushort* to_upper_data_low;

		// Token: 0x04000272 RID: 626
		private unsafe static readonly ushort* to_upper_data_high;
	}
}
