﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000097 RID: 151
	[ComVisible(true)]
	[Serializable]
	public sealed class CharEnumerator : IEnumerator<char>, IEnumerator, ICloneable, IDisposable
	{
		// Token: 0x060004FE RID: 1278 RVA: 0x0001B168 File Offset: 0x00019368
		internal CharEnumerator(string s)
		{
			this.str = s;
			this.index = -1;
			this.length = s.Length;
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060004FF RID: 1279 RVA: 0x0001B18C File Offset: 0x0001938C
		object IEnumerator.Current
		{
			get
			{
				return this.Current;
			}
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x0001B19C File Offset: 0x0001939C
		void IDisposable.Dispose()
		{
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000501 RID: 1281 RVA: 0x0001B1A0 File Offset: 0x000193A0
		public char Current
		{
			get
			{
				if (this.index == -1 || this.index >= this.length)
				{
					throw new InvalidOperationException(Locale.GetText("The position is not valid."));
				}
				return this.str[this.index];
			}
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x0001B1E0 File Offset: 0x000193E0
		public object Clone()
		{
			return new CharEnumerator(this.str)
			{
				index = this.index
			};
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x0001B208 File Offset: 0x00019408
		public bool MoveNext()
		{
			this.index++;
			if (this.index >= this.length)
			{
				this.index = this.length;
				return false;
			}
			return true;
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x0001B238 File Offset: 0x00019438
		public void Reset()
		{
			this.index = -1;
		}

		// Token: 0x04000273 RID: 627
		private string str;

		// Token: 0x04000274 RID: 628
		private int index;

		// Token: 0x04000275 RID: 629
		private int length;
	}
}
