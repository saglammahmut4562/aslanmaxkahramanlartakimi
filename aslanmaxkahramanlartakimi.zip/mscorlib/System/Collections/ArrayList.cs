﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x02000099 RID: 153
	[ComVisible(true)]
	[DebuggerTypeProxy(typeof(CollectionDebuggerView))]
	[DebuggerDisplay("Count={Count}")]
	[Serializable]
	public class ArrayList : ICollection, IEnumerable, IList, ICloneable
	{
		// Token: 0x06000506 RID: 1286 RVA: 0x0001B254 File Offset: 0x00019454
		public ArrayList()
		{
			this._items = ArrayList.EmptyArray;
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x0001B268 File Offset: 0x00019468
		public ArrayList(ICollection c)
		{
			if (c == null)
			{
				throw new ArgumentNullException("c");
			}
			Array array = c as Array;
			if (array != null && array.Rank != 1)
			{
				throw new RankException();
			}
			this._items = new object[c.Count];
			this.AddRange(c);
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x0001B2C4 File Offset: 0x000194C4
		public ArrayList(int capacity)
		{
			if (capacity < 0)
			{
				ArrayList.ThrowNewArgumentOutOfRangeException("capacity", capacity, "The initial capacity can't be smaller than zero.");
			}
			if (capacity == 0)
			{
				capacity = 4;
			}
			this._items = new object[capacity];
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x0001B300 File Offset: 0x00019500
		private ArrayList(object[] array, int index, int count)
		{
			if (count == 0)
			{
				this._items = new object[4];
			}
			else
			{
				this._items = new object[count];
			}
			Array.Copy(array, index, this._items, 0, count);
			this._size = count;
		}

		// Token: 0x17000092 RID: 146
		public virtual object this[int index]
		{
			get
			{
				if (index < 0 || index >= this._size)
				{
					ArrayList.ThrowNewArgumentOutOfRangeException("index", index, "Index is less than 0 or more than or equal to the list count.");
				}
				return this._items[index];
			}
			set
			{
				if (index < 0 || index >= this._size)
				{
					ArrayList.ThrowNewArgumentOutOfRangeException("index", index, "Index is less than 0 or more than or equal to the list count.");
				}
				this._items[index] = value;
				this._version++;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x0600050D RID: 1293 RVA: 0x0001B3DC File Offset: 0x000195DC
		public virtual int Count
		{
			get
			{
				return this._size;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600050E RID: 1294 RVA: 0x0001B3E4 File Offset: 0x000195E4
		// (set) Token: 0x0600050F RID: 1295 RVA: 0x0001B3F0 File Offset: 0x000195F0
		public virtual int Capacity
		{
			get
			{
				return this._items.Length;
			}
			set
			{
				if (value < this._size)
				{
					ArrayList.ThrowNewArgumentOutOfRangeException("Capacity", value, "Must be more than count.");
				}
				object[] array = new object[value];
				Array.Copy(this._items, 0, array, 0, this._size);
				this._items = array;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000510 RID: 1296 RVA: 0x0001B440 File Offset: 0x00019640
		public virtual bool IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000511 RID: 1297 RVA: 0x0001B444 File Offset: 0x00019644
		public virtual bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000512 RID: 1298 RVA: 0x0001B448 File Offset: 0x00019648
		public virtual bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000513 RID: 1299 RVA: 0x0001B44C File Offset: 0x0001964C
		public virtual object SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x0001B450 File Offset: 0x00019650
		private void EnsureCapacity(int count)
		{
			if (count <= this._items.Length)
			{
				return;
			}
			int i = this._items.Length << 1;
			if (i == 0)
			{
				i = 4;
			}
			while (i < count)
			{
				i <<= 1;
			}
			object[] array = new object[i];
			Array.Copy(this._items, 0, array, 0, this._items.Length);
			this._items = array;
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x0001B4B4 File Offset: 0x000196B4
		private void Shift(int index, int count)
		{
			if (count > 0)
			{
				if (this._size + count > this._items.Length)
				{
					int i;
					for (i = ((this._items.Length <= 0) ? 1 : (this._items.Length << 1)); i < this._size + count; i <<= 1)
					{
					}
					object[] array = new object[i];
					Array.Copy(this._items, 0, array, 0, index);
					Array.Copy(this._items, index, array, index + count, this._size - index);
					this._items = array;
				}
				else
				{
					Array.Copy(this._items, index, this._items, index + count, this._size - index);
				}
			}
			else if (count < 0)
			{
				int num = index - count;
				Array.Copy(this._items, num, this._items, index, this._size - num);
				Array.Clear(this._items, this._size + count, -count);
			}
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x0001B5AC File Offset: 0x000197AC
		public virtual int Add(object value)
		{
			if (this._items.Length <= this._size)
			{
				this.EnsureCapacity(this._size + 1);
			}
			this._items[this._size] = value;
			this._version++;
			return this._size++;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0001B608 File Offset: 0x00019808
		public virtual void Clear()
		{
			Array.Clear(this._items, 0, this._size);
			this._size = 0;
			this._version++;
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x0001B634 File Offset: 0x00019834
		public virtual bool Contains(object item)
		{
			return this.IndexOf(item, 0, this._size) > -1;
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x0001B648 File Offset: 0x00019848
		public virtual int IndexOf(object value)
		{
			return this.IndexOf(value, 0);
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x0001B654 File Offset: 0x00019854
		public virtual int IndexOf(object value, int startIndex)
		{
			return this.IndexOf(value, startIndex, this._size - startIndex);
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x0001B668 File Offset: 0x00019868
		public virtual int IndexOf(object value, int startIndex, int count)
		{
			if (startIndex < 0 || startIndex > this._size)
			{
				ArrayList.ThrowNewArgumentOutOfRangeException("startIndex", startIndex, "Does not specify valid index.");
			}
			if (count < 0)
			{
				ArrayList.ThrowNewArgumentOutOfRangeException("count", count, "Can't be less than 0.");
			}
			if (startIndex > this._size - count)
			{
				throw new ArgumentOutOfRangeException("count", "Start index and count do not specify a valid range.");
			}
			return Array.IndexOf<object>(this._items, value, startIndex, count);
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x0001B6E8 File Offset: 0x000198E8
		public virtual void Insert(int index, object value)
		{
			if (index < 0 || index > this._size)
			{
				ArrayList.ThrowNewArgumentOutOfRangeException("index", index, "Index must be >= 0 and <= Count.");
			}
			this.Shift(index, 1);
			this._items[index] = value;
			this._size++;
			this._version++;
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x0001B74C File Offset: 0x0001994C
		public virtual void InsertRange(int index, ICollection c)
		{
			if (c == null)
			{
				throw new ArgumentNullException("c");
			}
			if (index < 0 || index > this._size)
			{
				ArrayList.ThrowNewArgumentOutOfRangeException("index", index, "Index must be >= 0 and <= Count.");
			}
			int count = c.Count;
			if (this._items.Length < this._size + count)
			{
				this.EnsureCapacity(this._size + count);
			}
			if (index < this._size)
			{
				Array.Copy(this._items, index, this._items, index + count, this._size - index);
			}
			if (this == c.SyncRoot)
			{
				Array.Copy(this._items, 0, this._items, index, index);
				Array.Copy(this._items, index + count, this._items, index << 1, this._size - index);
			}
			else
			{
				c.CopyTo(this._items, index);
			}
			this._size += c.Count;
			this._version++;
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x0001B858 File Offset: 0x00019A58
		public virtual void Remove(object obj)
		{
			int num = this.IndexOf(obj);
			if (num > -1)
			{
				this.RemoveAt(num);
			}
			this._version++;
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x0001B88C File Offset: 0x00019A8C
		public virtual void RemoveAt(int index)
		{
			if (index < 0 || index >= this._size)
			{
				ArrayList.ThrowNewArgumentOutOfRangeException("index", index, "Less than 0 or more than list count.");
			}
			this.Shift(index, -1);
			this._size--;
			this._version++;
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x0001B8E8 File Offset: 0x00019AE8
		public virtual void CopyTo(Array array)
		{
			Array.Copy(this._items, array, this._size);
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x0001B8FC File Offset: 0x00019AFC
		public virtual void CopyTo(Array array, int arrayIndex)
		{
			this.CopyTo(0, array, arrayIndex, this._size);
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x0001B910 File Offset: 0x00019B10
		public virtual void CopyTo(int index, Array array, int arrayIndex, int count)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (array.Rank != 1)
			{
				throw new ArgumentException("Must have only 1 dimensions.", "array");
			}
			Array.Copy(this._items, index, array, arrayIndex, count);
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0001B950 File Offset: 0x00019B50
		public virtual IEnumerator GetEnumerator()
		{
			return new ArrayList.SimpleEnumerator(this);
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x0001B958 File Offset: 0x00019B58
		public virtual void AddRange(ICollection c)
		{
			this.InsertRange(this._size, c);
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x0001B968 File Offset: 0x00019B68
		public virtual void Sort()
		{
			Array.Sort<object>(this._items, 0, this._size);
			this._version++;
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x0001B98C File Offset: 0x00019B8C
		public virtual void Sort(IComparer comparer)
		{
			Array.Sort(this._items, 0, this._size, comparer);
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x0001B9A4 File Offset: 0x00019BA4
		public virtual object[] ToArray()
		{
			object[] array = new object[this._size];
			this.CopyTo(array);
			return array;
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0001B9C8 File Offset: 0x00019BC8
		public virtual Array ToArray(Type type)
		{
			Array array = Array.CreateInstance(type, this._size);
			this.CopyTo(array);
			return array;
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x0001B9EC File Offset: 0x00019BEC
		public virtual object Clone()
		{
			return new ArrayList(this._items, 0, this._size);
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x0001BA00 File Offset: 0x00019C00
		internal static void ThrowNewArgumentOutOfRangeException(string name, object actual, string message)
		{
			throw new ArgumentOutOfRangeException(name, actual, message);
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x0001BA0C File Offset: 0x00019C0C
		public static ArrayList Synchronized(ArrayList list)
		{
			if (list == null)
			{
				throw new ArgumentNullException("list");
			}
			if (list.IsSynchronized)
			{
				return list;
			}
			return new ArrayList.SynchronizedArrayListWrapper(list);
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x0001BA34 File Offset: 0x00019C34
		public static ArrayList ReadOnly(ArrayList list)
		{
			if (list == null)
			{
				throw new ArgumentNullException("list");
			}
			if (list.IsReadOnly)
			{
				return list;
			}
			return new ArrayList.ReadOnlyArrayListWrapper(list);
		}

		// Token: 0x04000277 RID: 631
		private const int DefaultInitialCapacity = 4;

		// Token: 0x04000278 RID: 632
		private int _size;

		// Token: 0x04000279 RID: 633
		private object[] _items;

		// Token: 0x0400027A RID: 634
		private int _version;

		// Token: 0x0400027B RID: 635
		private static readonly object[] EmptyArray = new object[0];

		// Token: 0x0200009A RID: 154
		[Serializable]
		private class ArrayListWrapper : ArrayList
		{
			// Token: 0x0600052D RID: 1325 RVA: 0x0001BA5C File Offset: 0x00019C5C
			public ArrayListWrapper(ArrayList innerArrayList)
			{
				this.m_InnerArrayList = innerArrayList;
			}

			// Token: 0x17000099 RID: 153
			public override object this[int index]
			{
				get
				{
					return this.m_InnerArrayList[index];
				}
				set
				{
					this.m_InnerArrayList[index] = value;
				}
			}

			// Token: 0x1700009A RID: 154
			// (get) Token: 0x06000530 RID: 1328 RVA: 0x0001BA8C File Offset: 0x00019C8C
			public override int Count
			{
				get
				{
					return this.m_InnerArrayList.Count;
				}
			}

			// Token: 0x1700009B RID: 155
			// (get) Token: 0x06000531 RID: 1329 RVA: 0x0001BA9C File Offset: 0x00019C9C
			// (set) Token: 0x06000532 RID: 1330 RVA: 0x0001BAAC File Offset: 0x00019CAC
			public override int Capacity
			{
				get
				{
					return this.m_InnerArrayList.Capacity;
				}
				set
				{
					this.m_InnerArrayList.Capacity = value;
				}
			}

			// Token: 0x1700009C RID: 156
			// (get) Token: 0x06000533 RID: 1331 RVA: 0x0001BABC File Offset: 0x00019CBC
			public override bool IsFixedSize
			{
				get
				{
					return this.m_InnerArrayList.IsFixedSize;
				}
			}

			// Token: 0x1700009D RID: 157
			// (get) Token: 0x06000534 RID: 1332 RVA: 0x0001BACC File Offset: 0x00019CCC
			public override bool IsReadOnly
			{
				get
				{
					return this.m_InnerArrayList.IsReadOnly;
				}
			}

			// Token: 0x1700009E RID: 158
			// (get) Token: 0x06000535 RID: 1333 RVA: 0x0001BADC File Offset: 0x00019CDC
			public override bool IsSynchronized
			{
				get
				{
					return this.m_InnerArrayList.IsSynchronized;
				}
			}

			// Token: 0x1700009F RID: 159
			// (get) Token: 0x06000536 RID: 1334 RVA: 0x0001BAEC File Offset: 0x00019CEC
			public override object SyncRoot
			{
				get
				{
					return this.m_InnerArrayList.SyncRoot;
				}
			}

			// Token: 0x06000537 RID: 1335 RVA: 0x0001BAFC File Offset: 0x00019CFC
			public override int Add(object value)
			{
				return this.m_InnerArrayList.Add(value);
			}

			// Token: 0x06000538 RID: 1336 RVA: 0x0001BB0C File Offset: 0x00019D0C
			public override void Clear()
			{
				this.m_InnerArrayList.Clear();
			}

			// Token: 0x06000539 RID: 1337 RVA: 0x0001BB1C File Offset: 0x00019D1C
			public override bool Contains(object value)
			{
				return this.m_InnerArrayList.Contains(value);
			}

			// Token: 0x0600053A RID: 1338 RVA: 0x0001BB2C File Offset: 0x00019D2C
			public override int IndexOf(object value)
			{
				return this.m_InnerArrayList.IndexOf(value);
			}

			// Token: 0x0600053B RID: 1339 RVA: 0x0001BB3C File Offset: 0x00019D3C
			public override int IndexOf(object value, int startIndex)
			{
				return this.m_InnerArrayList.IndexOf(value, startIndex);
			}

			// Token: 0x0600053C RID: 1340 RVA: 0x0001BB4C File Offset: 0x00019D4C
			public override int IndexOf(object value, int startIndex, int count)
			{
				return this.m_InnerArrayList.IndexOf(value, startIndex, count);
			}

			// Token: 0x0600053D RID: 1341 RVA: 0x0001BB5C File Offset: 0x00019D5C
			public override void Insert(int index, object value)
			{
				this.m_InnerArrayList.Insert(index, value);
			}

			// Token: 0x0600053E RID: 1342 RVA: 0x0001BB6C File Offset: 0x00019D6C
			public override void InsertRange(int index, ICollection c)
			{
				this.m_InnerArrayList.InsertRange(index, c);
			}

			// Token: 0x0600053F RID: 1343 RVA: 0x0001BB7C File Offset: 0x00019D7C
			public override void Remove(object value)
			{
				this.m_InnerArrayList.Remove(value);
			}

			// Token: 0x06000540 RID: 1344 RVA: 0x0001BB8C File Offset: 0x00019D8C
			public override void RemoveAt(int index)
			{
				this.m_InnerArrayList.RemoveAt(index);
			}

			// Token: 0x06000541 RID: 1345 RVA: 0x0001BB9C File Offset: 0x00019D9C
			public override void CopyTo(Array array)
			{
				this.m_InnerArrayList.CopyTo(array);
			}

			// Token: 0x06000542 RID: 1346 RVA: 0x0001BBAC File Offset: 0x00019DAC
			public override void CopyTo(Array array, int index)
			{
				this.m_InnerArrayList.CopyTo(array, index);
			}

			// Token: 0x06000543 RID: 1347 RVA: 0x0001BBBC File Offset: 0x00019DBC
			public override void CopyTo(int index, Array array, int arrayIndex, int count)
			{
				this.m_InnerArrayList.CopyTo(index, array, arrayIndex, count);
			}

			// Token: 0x06000544 RID: 1348 RVA: 0x0001BBD0 File Offset: 0x00019DD0
			public override IEnumerator GetEnumerator()
			{
				return this.m_InnerArrayList.GetEnumerator();
			}

			// Token: 0x06000545 RID: 1349 RVA: 0x0001BBE0 File Offset: 0x00019DE0
			public override void AddRange(ICollection c)
			{
				this.m_InnerArrayList.AddRange(c);
			}

			// Token: 0x06000546 RID: 1350 RVA: 0x0001BBF0 File Offset: 0x00019DF0
			public override object Clone()
			{
				return this.m_InnerArrayList.Clone();
			}

			// Token: 0x06000547 RID: 1351 RVA: 0x0001BC00 File Offset: 0x00019E00
			public override void Sort()
			{
				this.m_InnerArrayList.Sort();
			}

			// Token: 0x06000548 RID: 1352 RVA: 0x0001BC10 File Offset: 0x00019E10
			public override void Sort(IComparer comparer)
			{
				this.m_InnerArrayList.Sort(comparer);
			}

			// Token: 0x06000549 RID: 1353 RVA: 0x0001BC20 File Offset: 0x00019E20
			public override object[] ToArray()
			{
				return this.m_InnerArrayList.ToArray();
			}

			// Token: 0x0600054A RID: 1354 RVA: 0x0001BC30 File Offset: 0x00019E30
			public override Array ToArray(Type elementType)
			{
				return this.m_InnerArrayList.ToArray(elementType);
			}

			// Token: 0x0400027C RID: 636
			protected ArrayList m_InnerArrayList;
		}

		// Token: 0x0200009B RID: 155
		[Serializable]
		private class FixedSizeArrayListWrapper : ArrayList.ArrayListWrapper
		{
			// Token: 0x0600054B RID: 1355 RVA: 0x0001BC40 File Offset: 0x00019E40
			public FixedSizeArrayListWrapper(ArrayList innerList)
				: base(innerList)
			{
			}

			// Token: 0x170000A0 RID: 160
			// (get) Token: 0x0600054C RID: 1356 RVA: 0x0001BC4C File Offset: 0x00019E4C
			protected virtual string ErrorMessage
			{
				get
				{
					return "Can't add or remove from a fixed-size list.";
				}
			}

			// Token: 0x170000A1 RID: 161
			// (get) Token: 0x0600054D RID: 1357 RVA: 0x0001BC54 File Offset: 0x00019E54
			// (set) Token: 0x0600054E RID: 1358 RVA: 0x0001BC5C File Offset: 0x00019E5C
			public override int Capacity
			{
				get
				{
					return base.Capacity;
				}
				set
				{
					throw new NotSupportedException(this.ErrorMessage);
				}
			}

			// Token: 0x170000A2 RID: 162
			// (get) Token: 0x0600054F RID: 1359 RVA: 0x0001BC6C File Offset: 0x00019E6C
			public override bool IsFixedSize
			{
				get
				{
					return true;
				}
			}

			// Token: 0x06000550 RID: 1360 RVA: 0x0001BC70 File Offset: 0x00019E70
			public override int Add(object value)
			{
				throw new NotSupportedException(this.ErrorMessage);
			}

			// Token: 0x06000551 RID: 1361 RVA: 0x0001BC80 File Offset: 0x00019E80
			public override void AddRange(ICollection c)
			{
				throw new NotSupportedException(this.ErrorMessage);
			}

			// Token: 0x06000552 RID: 1362 RVA: 0x0001BC90 File Offset: 0x00019E90
			public override void Clear()
			{
				throw new NotSupportedException(this.ErrorMessage);
			}

			// Token: 0x06000553 RID: 1363 RVA: 0x0001BCA0 File Offset: 0x00019EA0
			public override void Insert(int index, object value)
			{
				throw new NotSupportedException(this.ErrorMessage);
			}

			// Token: 0x06000554 RID: 1364 RVA: 0x0001BCB0 File Offset: 0x00019EB0
			public override void InsertRange(int index, ICollection c)
			{
				throw new NotSupportedException(this.ErrorMessage);
			}

			// Token: 0x06000555 RID: 1365 RVA: 0x0001BCC0 File Offset: 0x00019EC0
			public override void Remove(object value)
			{
				throw new NotSupportedException(this.ErrorMessage);
			}

			// Token: 0x06000556 RID: 1366 RVA: 0x0001BCD0 File Offset: 0x00019ED0
			public override void RemoveAt(int index)
			{
				throw new NotSupportedException(this.ErrorMessage);
			}
		}

		// Token: 0x0200009C RID: 156
		[Serializable]
		private sealed class ReadOnlyArrayListWrapper : ArrayList.FixedSizeArrayListWrapper
		{
			// Token: 0x06000557 RID: 1367 RVA: 0x0001BCE0 File Offset: 0x00019EE0
			public ReadOnlyArrayListWrapper(ArrayList innerArrayList)
				: base(innerArrayList)
			{
			}

			// Token: 0x170000A3 RID: 163
			// (get) Token: 0x06000558 RID: 1368 RVA: 0x0001BCEC File Offset: 0x00019EEC
			protected override string ErrorMessage
			{
				get
				{
					return "Can't modify a readonly list.";
				}
			}

			// Token: 0x170000A4 RID: 164
			// (get) Token: 0x06000559 RID: 1369 RVA: 0x0001BCF4 File Offset: 0x00019EF4
			public override bool IsReadOnly
			{
				get
				{
					return true;
				}
			}

			// Token: 0x170000A5 RID: 165
			public override object this[int index]
			{
				get
				{
					return this.m_InnerArrayList[index];
				}
				set
				{
					throw new NotSupportedException(this.ErrorMessage);
				}
			}

			// Token: 0x0600055C RID: 1372 RVA: 0x0001BD18 File Offset: 0x00019F18
			public override void Sort()
			{
				throw new NotSupportedException(this.ErrorMessage);
			}

			// Token: 0x0600055D RID: 1373 RVA: 0x0001BD28 File Offset: 0x00019F28
			public override void Sort(IComparer comparer)
			{
				throw new NotSupportedException(this.ErrorMessage);
			}
		}

		// Token: 0x0200009D RID: 157
		private sealed class SimpleEnumerator : IEnumerator, ICloneable
		{
			// Token: 0x0600055E RID: 1374 RVA: 0x0001BD38 File Offset: 0x00019F38
			public SimpleEnumerator(ArrayList list)
			{
				this.list = list;
				this.index = -1;
				this.version = list._version;
				this.currentElement = ArrayList.SimpleEnumerator.endFlag;
			}

			// Token: 0x06000560 RID: 1376 RVA: 0x0001BD74 File Offset: 0x00019F74
			public object Clone()
			{
				return base.MemberwiseClone();
			}

			// Token: 0x06000561 RID: 1377 RVA: 0x0001BD7C File Offset: 0x00019F7C
			public bool MoveNext()
			{
				if (this.version != this.list._version)
				{
					throw new InvalidOperationException("List has changed.");
				}
				if (++this.index < this.list.Count)
				{
					this.currentElement = this.list[this.index];
					return true;
				}
				this.currentElement = ArrayList.SimpleEnumerator.endFlag;
				return false;
			}

			// Token: 0x170000A6 RID: 166
			// (get) Token: 0x06000562 RID: 1378 RVA: 0x0001BDF0 File Offset: 0x00019FF0
			public object Current
			{
				get
				{
					if (this.currentElement != ArrayList.SimpleEnumerator.endFlag)
					{
						return this.currentElement;
					}
					if (this.index == -1)
					{
						throw new InvalidOperationException("Enumerator not started");
					}
					throw new InvalidOperationException("Enumerator ended");
				}
			}

			// Token: 0x06000563 RID: 1379 RVA: 0x0001BE2C File Offset: 0x0001A02C
			public void Reset()
			{
				if (this.version != this.list._version)
				{
					throw new InvalidOperationException("List has changed.");
				}
				this.currentElement = ArrayList.SimpleEnumerator.endFlag;
				this.index = -1;
			}

			// Token: 0x0400027D RID: 637
			private ArrayList list;

			// Token: 0x0400027E RID: 638
			private int index;

			// Token: 0x0400027F RID: 639
			private int version;

			// Token: 0x04000280 RID: 640
			private object currentElement;

			// Token: 0x04000281 RID: 641
			private static object endFlag = new object();
		}

		// Token: 0x0200009E RID: 158
		[Serializable]
		private sealed class SynchronizedArrayListWrapper : ArrayList.ArrayListWrapper
		{
			// Token: 0x06000564 RID: 1380 RVA: 0x0001BE64 File Offset: 0x0001A064
			internal SynchronizedArrayListWrapper(ArrayList innerArrayList)
				: base(innerArrayList)
			{
				this.m_SyncRoot = innerArrayList.SyncRoot;
			}

			// Token: 0x170000A7 RID: 167
			public override object this[int index]
			{
				get
				{
					object syncRoot = this.m_SyncRoot;
					object obj;
					lock (syncRoot)
					{
						obj = this.m_InnerArrayList[index];
					}
					return obj;
				}
				set
				{
					object syncRoot = this.m_SyncRoot;
					lock (syncRoot)
					{
						this.m_InnerArrayList[index] = value;
					}
				}
			}

			// Token: 0x170000A8 RID: 168
			// (get) Token: 0x06000567 RID: 1383 RVA: 0x0001BF0C File Offset: 0x0001A10C
			public override int Count
			{
				get
				{
					object syncRoot = this.m_SyncRoot;
					int count;
					lock (syncRoot)
					{
						count = this.m_InnerArrayList.Count;
					}
					return count;
				}
			}

			// Token: 0x170000A9 RID: 169
			// (get) Token: 0x06000568 RID: 1384 RVA: 0x0001BF54 File Offset: 0x0001A154
			// (set) Token: 0x06000569 RID: 1385 RVA: 0x0001BF9C File Offset: 0x0001A19C
			public override int Capacity
			{
				get
				{
					object syncRoot = this.m_SyncRoot;
					int capacity;
					lock (syncRoot)
					{
						capacity = this.m_InnerArrayList.Capacity;
					}
					return capacity;
				}
				set
				{
					object syncRoot = this.m_SyncRoot;
					lock (syncRoot)
					{
						this.m_InnerArrayList.Capacity = value;
					}
				}
			}

			// Token: 0x170000AA RID: 170
			// (get) Token: 0x0600056A RID: 1386 RVA: 0x0001BFE0 File Offset: 0x0001A1E0
			public override bool IsFixedSize
			{
				get
				{
					object syncRoot = this.m_SyncRoot;
					bool isFixedSize;
					lock (syncRoot)
					{
						isFixedSize = this.m_InnerArrayList.IsFixedSize;
					}
					return isFixedSize;
				}
			}

			// Token: 0x170000AB RID: 171
			// (get) Token: 0x0600056B RID: 1387 RVA: 0x0001C028 File Offset: 0x0001A228
			public override bool IsReadOnly
			{
				get
				{
					object syncRoot = this.m_SyncRoot;
					bool isReadOnly;
					lock (syncRoot)
					{
						isReadOnly = this.m_InnerArrayList.IsReadOnly;
					}
					return isReadOnly;
				}
			}

			// Token: 0x170000AC RID: 172
			// (get) Token: 0x0600056C RID: 1388 RVA: 0x0001C070 File Offset: 0x0001A270
			public override bool IsSynchronized
			{
				get
				{
					return true;
				}
			}

			// Token: 0x170000AD RID: 173
			// (get) Token: 0x0600056D RID: 1389 RVA: 0x0001C074 File Offset: 0x0001A274
			public override object SyncRoot
			{
				get
				{
					return this.m_SyncRoot;
				}
			}

			// Token: 0x0600056E RID: 1390 RVA: 0x0001C07C File Offset: 0x0001A27C
			public override int Add(object value)
			{
				object syncRoot = this.m_SyncRoot;
				int num;
				lock (syncRoot)
				{
					num = this.m_InnerArrayList.Add(value);
				}
				return num;
			}

			// Token: 0x0600056F RID: 1391 RVA: 0x0001C0C8 File Offset: 0x0001A2C8
			public override void Clear()
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.Clear();
				}
			}

			// Token: 0x06000570 RID: 1392 RVA: 0x0001C10C File Offset: 0x0001A30C
			public override bool Contains(object value)
			{
				object syncRoot = this.m_SyncRoot;
				bool flag;
				lock (syncRoot)
				{
					flag = this.m_InnerArrayList.Contains(value);
				}
				return flag;
			}

			// Token: 0x06000571 RID: 1393 RVA: 0x0001C158 File Offset: 0x0001A358
			public override int IndexOf(object value)
			{
				object syncRoot = this.m_SyncRoot;
				int num;
				lock (syncRoot)
				{
					num = this.m_InnerArrayList.IndexOf(value);
				}
				return num;
			}

			// Token: 0x06000572 RID: 1394 RVA: 0x0001C1A4 File Offset: 0x0001A3A4
			public override int IndexOf(object value, int startIndex)
			{
				object syncRoot = this.m_SyncRoot;
				int num;
				lock (syncRoot)
				{
					num = this.m_InnerArrayList.IndexOf(value, startIndex);
				}
				return num;
			}

			// Token: 0x06000573 RID: 1395 RVA: 0x0001C1F0 File Offset: 0x0001A3F0
			public override int IndexOf(object value, int startIndex, int count)
			{
				object syncRoot = this.m_SyncRoot;
				int num;
				lock (syncRoot)
				{
					num = this.m_InnerArrayList.IndexOf(value, startIndex, count);
				}
				return num;
			}

			// Token: 0x06000574 RID: 1396 RVA: 0x0001C23C File Offset: 0x0001A43C
			public override void Insert(int index, object value)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.Insert(index, value);
				}
			}

			// Token: 0x06000575 RID: 1397 RVA: 0x0001C280 File Offset: 0x0001A480
			public override void InsertRange(int index, ICollection c)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.InsertRange(index, c);
				}
			}

			// Token: 0x06000576 RID: 1398 RVA: 0x0001C2C4 File Offset: 0x0001A4C4
			public override void Remove(object value)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.Remove(value);
				}
			}

			// Token: 0x06000577 RID: 1399 RVA: 0x0001C308 File Offset: 0x0001A508
			public override void RemoveAt(int index)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.RemoveAt(index);
				}
			}

			// Token: 0x06000578 RID: 1400 RVA: 0x0001C34C File Offset: 0x0001A54C
			public override void CopyTo(Array array)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.CopyTo(array);
				}
			}

			// Token: 0x06000579 RID: 1401 RVA: 0x0001C390 File Offset: 0x0001A590
			public override void CopyTo(Array array, int index)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.CopyTo(array, index);
				}
			}

			// Token: 0x0600057A RID: 1402 RVA: 0x0001C3D4 File Offset: 0x0001A5D4
			public override void CopyTo(int index, Array array, int arrayIndex, int count)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.CopyTo(index, array, arrayIndex, count);
				}
			}

			// Token: 0x0600057B RID: 1403 RVA: 0x0001C41C File Offset: 0x0001A61C
			public override IEnumerator GetEnumerator()
			{
				object syncRoot = this.m_SyncRoot;
				IEnumerator enumerator;
				lock (syncRoot)
				{
					enumerator = this.m_InnerArrayList.GetEnumerator();
				}
				return enumerator;
			}

			// Token: 0x0600057C RID: 1404 RVA: 0x0001C464 File Offset: 0x0001A664
			public override void AddRange(ICollection c)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.AddRange(c);
				}
			}

			// Token: 0x0600057D RID: 1405 RVA: 0x0001C4A8 File Offset: 0x0001A6A8
			public override object Clone()
			{
				object syncRoot = this.m_SyncRoot;
				object obj;
				lock (syncRoot)
				{
					obj = this.m_InnerArrayList.Clone();
				}
				return obj;
			}

			// Token: 0x0600057E RID: 1406 RVA: 0x0001C4F0 File Offset: 0x0001A6F0
			public override void Sort()
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.Sort();
				}
			}

			// Token: 0x0600057F RID: 1407 RVA: 0x0001C534 File Offset: 0x0001A734
			public override void Sort(IComparer comparer)
			{
				object syncRoot = this.m_SyncRoot;
				lock (syncRoot)
				{
					this.m_InnerArrayList.Sort(comparer);
				}
			}

			// Token: 0x06000580 RID: 1408 RVA: 0x0001C578 File Offset: 0x0001A778
			public override object[] ToArray()
			{
				object syncRoot = this.m_SyncRoot;
				object[] array;
				lock (syncRoot)
				{
					array = this.m_InnerArrayList.ToArray();
				}
				return array;
			}

			// Token: 0x06000581 RID: 1409 RVA: 0x0001C5C0 File Offset: 0x0001A7C0
			public override Array ToArray(Type elementType)
			{
				object syncRoot = this.m_SyncRoot;
				Array array;
				lock (syncRoot)
				{
					array = this.m_InnerArrayList.ToArray(elementType);
				}
				return array;
			}

			// Token: 0x04000282 RID: 642
			private object m_SyncRoot;
		}
	}
}
