﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x0200009F RID: 159
	[ComVisible(true)]
	[Serializable]
	public sealed class BitArray : ICollection, IEnumerable, ICloneable
	{
		// Token: 0x06000582 RID: 1410 RVA: 0x0001C60C File Offset: 0x0001A80C
		public BitArray(BitArray bits)
		{
			if (bits == null)
			{
				throw new ArgumentNullException("bits");
			}
			this.m_length = bits.m_length;
			this.m_array = new int[(this.m_length + 31) / 32];
			if (this.m_array.Length == 1)
			{
				this.m_array[0] = bits.m_array[0];
			}
			else
			{
				Array.Copy(bits.m_array, this.m_array, this.m_array.Length);
			}
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x0001C690 File Offset: 0x0001A890
		public BitArray(int length)
		{
			if (length < 0)
			{
				throw new ArgumentOutOfRangeException("length");
			}
			this.m_length = length;
			this.m_array = new int[(this.m_length + 31) / 32];
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x0001C6C8 File Offset: 0x0001A8C8
		private byte getByte(int byteIndex)
		{
			int num = byteIndex / 4;
			int num2 = byteIndex % 4 * 8;
			int num3 = this.m_array[num] & (255 << num2);
			return (byte)((num3 >> num2) & 255);
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000585 RID: 1413 RVA: 0x0001C700 File Offset: 0x0001A900
		public int Count
		{
			get
			{
				return this.m_length;
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000586 RID: 1414 RVA: 0x0001C708 File Offset: 0x0001A908
		public bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000B0 RID: 176
		public bool this[int index]
		{
			get
			{
				return this.Get(index);
			}
			set
			{
				this.Set(index, value);
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000589 RID: 1417 RVA: 0x0001C724 File Offset: 0x0001A924
		public int Length
		{
			get
			{
				return this.m_length;
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x0600058A RID: 1418 RVA: 0x0001C72C File Offset: 0x0001A92C
		public object SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x0001C730 File Offset: 0x0001A930
		public object Clone()
		{
			return new BitArray(this);
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x0001C738 File Offset: 0x0001A938
		public void CopyTo(Array array, int index)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (array.Rank != 1)
			{
				throw new ArgumentException("array", "Array rank must be 1");
			}
			if (index >= array.Length && this.m_length > 0)
			{
				throw new ArgumentException("index", "index is greater than array.Length");
			}
			if (array is bool[])
			{
				if (array.Length - index < this.m_length)
				{
					throw new ArgumentException();
				}
				bool[] array2 = (bool[])array;
				for (int i = 0; i < this.m_length; i++)
				{
					array2[index + i] = this[i];
				}
			}
			else if (array is byte[])
			{
				int num = (this.m_length + 7) / 8;
				if (array.Length - index < num)
				{
					throw new ArgumentException();
				}
				byte[] array3 = (byte[])array;
				for (int j = 0; j < num; j++)
				{
					array3[index + j] = this.getByte(j);
				}
			}
			else
			{
				if (!(array is int[]))
				{
					throw new ArgumentException("array", "Unsupported type");
				}
				Array.Copy(this.m_array, 0, array, index, (this.m_length + 31) / 32);
			}
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x0001C894 File Offset: 0x0001AA94
		public bool Get(int index)
		{
			if (index < 0 || index >= this.m_length)
			{
				throw new ArgumentOutOfRangeException();
			}
			return (this.m_array[index >> 5] & (1 << index)) != 0;
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x0001C8CC File Offset: 0x0001AACC
		public void Set(int index, bool value)
		{
			if (index < 0 || index >= this.m_length)
			{
				throw new ArgumentOutOfRangeException();
			}
			if (value)
			{
				this.m_array[index >> 5] |= 1 << index;
			}
			else
			{
				this.m_array[index >> 5] &= ~(1 << index);
			}
			this._version++;
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x0001C948 File Offset: 0x0001AB48
		public IEnumerator GetEnumerator()
		{
			return new BitArray.BitArrayEnumerator(this);
		}

		// Token: 0x04000283 RID: 643
		private int[] m_array;

		// Token: 0x04000284 RID: 644
		private int m_length;

		// Token: 0x04000285 RID: 645
		private int _version;

		// Token: 0x020000A0 RID: 160
		[Serializable]
		private class BitArrayEnumerator : IEnumerator, ICloneable
		{
			// Token: 0x06000590 RID: 1424 RVA: 0x0001C950 File Offset: 0x0001AB50
			public BitArrayEnumerator(BitArray ba)
			{
				this._index = -1;
				this._bitArray = ba;
				this._version = ba._version;
			}

			// Token: 0x06000591 RID: 1425 RVA: 0x0001C974 File Offset: 0x0001AB74
			public object Clone()
			{
				return base.MemberwiseClone();
			}

			// Token: 0x170000B3 RID: 179
			// (get) Token: 0x06000592 RID: 1426 RVA: 0x0001C97C File Offset: 0x0001AB7C
			public object Current
			{
				get
				{
					if (this._index == -1)
					{
						throw new InvalidOperationException("Enum not started");
					}
					if (this._index >= this._bitArray.Count)
					{
						throw new InvalidOperationException("Enum Ended");
					}
					return this._current;
				}
			}

			// Token: 0x06000593 RID: 1427 RVA: 0x0001C9CC File Offset: 0x0001ABCC
			public bool MoveNext()
			{
				this.checkVersion();
				if (this._index < this._bitArray.Count - 1)
				{
					this._current = this._bitArray[++this._index];
					return true;
				}
				this._index = this._bitArray.Count;
				return false;
			}

			// Token: 0x06000594 RID: 1428 RVA: 0x0001CA30 File Offset: 0x0001AC30
			public void Reset()
			{
				this.checkVersion();
				this._index = -1;
			}

			// Token: 0x06000595 RID: 1429 RVA: 0x0001CA40 File Offset: 0x0001AC40
			private void checkVersion()
			{
				if (this._version != this._bitArray._version)
				{
					throw new InvalidOperationException();
				}
			}

			// Token: 0x04000286 RID: 646
			private BitArray _bitArray;

			// Token: 0x04000287 RID: 647
			private bool _current;

			// Token: 0x04000288 RID: 648
			private int _index;

			// Token: 0x04000289 RID: 649
			private int _version;
		}
	}
}
