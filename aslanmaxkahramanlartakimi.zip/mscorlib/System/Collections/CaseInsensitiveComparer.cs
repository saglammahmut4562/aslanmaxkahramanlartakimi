﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000A1 RID: 161
	[ComVisible(true)]
	[Serializable]
	public class CaseInsensitiveComparer : IComparer
	{
		// Token: 0x06000596 RID: 1430 RVA: 0x0001CA60 File Offset: 0x0001AC60
		public CaseInsensitiveComparer()
		{
			this.culture = CultureInfo.CurrentCulture;
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x0001CA74 File Offset: 0x0001AC74
		private CaseInsensitiveComparer(bool invariant)
		{
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x06000599 RID: 1433 RVA: 0x0001CA94 File Offset: 0x0001AC94
		public static CaseInsensitiveComparer Default
		{
			get
			{
				return CaseInsensitiveComparer.defaultComparer;
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600059A RID: 1434 RVA: 0x0001CA9C File Offset: 0x0001AC9C
		public static CaseInsensitiveComparer DefaultInvariant
		{
			get
			{
				return CaseInsensitiveComparer.defaultInvariantComparer;
			}
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x0001CAA4 File Offset: 0x0001ACA4
		public int Compare(object a, object b)
		{
			string text = a as string;
			string text2 = b as string;
			if (text == null || text2 == null)
			{
				return Comparer.Default.Compare(a, b);
			}
			if (this.culture != null)
			{
				return this.culture.CompareInfo.Compare(text, text2, CompareOptions.IgnoreCase);
			}
			return CultureInfo.InvariantCulture.CompareInfo.Compare(text, text2, CompareOptions.IgnoreCase);
		}

		// Token: 0x0400028A RID: 650
		private static CaseInsensitiveComparer defaultComparer = new CaseInsensitiveComparer();

		// Token: 0x0400028B RID: 651
		private static CaseInsensitiveComparer defaultInvariantComparer = new CaseInsensitiveComparer(true);

		// Token: 0x0400028C RID: 652
		private CultureInfo culture;
	}
}
