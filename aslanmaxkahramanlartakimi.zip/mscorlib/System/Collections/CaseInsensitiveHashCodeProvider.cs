﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000A2 RID: 162
	[Obsolete("Please use StringComparer instead.")]
	[ComVisible(true)]
	[Serializable]
	public class CaseInsensitiveHashCodeProvider : IHashCodeProvider
	{
		// Token: 0x0600059C RID: 1436 RVA: 0x0001CB0C File Offset: 0x0001AD0C
		public CaseInsensitiveHashCodeProvider()
		{
			CultureInfo currentCulture = CultureInfo.CurrentCulture;
			if (!CaseInsensitiveHashCodeProvider.AreEqual(currentCulture, CultureInfo.InvariantCulture))
			{
				this.m_text = CultureInfo.CurrentCulture.TextInfo;
			}
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x0001CB48 File Offset: 0x0001AD48
		public CaseInsensitiveHashCodeProvider(CultureInfo culture)
		{
			if (culture == null)
			{
				throw new ArgumentNullException("culture");
			}
			if (!CaseInsensitiveHashCodeProvider.AreEqual(culture, CultureInfo.InvariantCulture))
			{
				this.m_text = culture.TextInfo;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x0600059F RID: 1439 RVA: 0x0001CB9C File Offset: 0x0001AD9C
		public static CaseInsensitiveHashCodeProvider Default
		{
			get
			{
				object obj = CaseInsensitiveHashCodeProvider.sync;
				CaseInsensitiveHashCodeProvider caseInsensitiveHashCodeProvider;
				lock (obj)
				{
					if (CaseInsensitiveHashCodeProvider.singleton == null)
					{
						CaseInsensitiveHashCodeProvider.singleton = new CaseInsensitiveHashCodeProvider();
					}
					else if (CaseInsensitiveHashCodeProvider.singleton.m_text == null)
					{
						if (!CaseInsensitiveHashCodeProvider.AreEqual(CultureInfo.CurrentCulture, CultureInfo.InvariantCulture))
						{
							CaseInsensitiveHashCodeProvider.singleton = new CaseInsensitiveHashCodeProvider();
						}
					}
					else if (!CaseInsensitiveHashCodeProvider.AreEqual(CaseInsensitiveHashCodeProvider.singleton.m_text, CultureInfo.CurrentCulture))
					{
						CaseInsensitiveHashCodeProvider.singleton = new CaseInsensitiveHashCodeProvider();
					}
					caseInsensitiveHashCodeProvider = CaseInsensitiveHashCodeProvider.singleton;
				}
				return caseInsensitiveHashCodeProvider;
			}
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x0001CC4C File Offset: 0x0001AE4C
		private static bool AreEqual(CultureInfo a, CultureInfo b)
		{
			return a.Name == b.Name;
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x0001CC60 File Offset: 0x0001AE60
		private static bool AreEqual(TextInfo info, CultureInfo culture)
		{
			return info.CultureName == culture.Name;
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060005A2 RID: 1442 RVA: 0x0001CC74 File Offset: 0x0001AE74
		public static CaseInsensitiveHashCodeProvider DefaultInvariant
		{
			get
			{
				return CaseInsensitiveHashCodeProvider.singletonInvariant;
			}
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x0001CC7C File Offset: 0x0001AE7C
		public int GetHashCode(object obj)
		{
			if (obj == null)
			{
				throw new ArgumentNullException("obj");
			}
			string text = obj as string;
			if (text == null)
			{
				return obj.GetHashCode();
			}
			int num = 0;
			if (this.m_text != null && !CaseInsensitiveHashCodeProvider.AreEqual(this.m_text, CultureInfo.InvariantCulture))
			{
				foreach (char c in this.m_text.ToLower(text))
				{
					num = num * 31 + (int)c;
				}
			}
			else
			{
				for (int j = 0; j < text.Length; j++)
				{
					char c = char.ToLower(text[j], CultureInfo.InvariantCulture);
					num = num * 31 + (int)c;
				}
			}
			return num;
		}

		// Token: 0x0400028D RID: 653
		private static readonly CaseInsensitiveHashCodeProvider singletonInvariant = new CaseInsensitiveHashCodeProvider(CultureInfo.InvariantCulture);

		// Token: 0x0400028E RID: 654
		private static CaseInsensitiveHashCodeProvider singleton;

		// Token: 0x0400028F RID: 655
		private static readonly object sync = new object();

		// Token: 0x04000290 RID: 656
		private TextInfo m_text;
	}
}
