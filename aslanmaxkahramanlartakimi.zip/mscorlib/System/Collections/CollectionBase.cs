﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000A3 RID: 163
	[ComVisible(true)]
	[Serializable]
	public abstract class CollectionBase : ICollection, IEnumerable, IList
	{
		// Token: 0x060005A5 RID: 1445 RVA: 0x0001CD48 File Offset: 0x0001AF48
		void ICollection.CopyTo(Array array, int index)
		{
			this.InnerList.CopyTo(array, index);
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060005A6 RID: 1446 RVA: 0x0001CD58 File Offset: 0x0001AF58
		object ICollection.SyncRoot
		{
			get
			{
				return this.InnerList.SyncRoot;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060005A7 RID: 1447 RVA: 0x0001CD68 File Offset: 0x0001AF68
		bool ICollection.IsSynchronized
		{
			get
			{
				return this.InnerList.IsSynchronized;
			}
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x0001CD78 File Offset: 0x0001AF78
		int IList.Add(object value)
		{
			this.OnValidate(value);
			int count = this.InnerList.Count;
			this.OnInsert(count, value);
			this.InnerList.Add(value);
			try
			{
				this.OnInsertComplete(count, value);
			}
			catch
			{
				this.InnerList.RemoveAt(count);
				throw;
			}
			return count;
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x0001CDE0 File Offset: 0x0001AFE0
		bool IList.Contains(object value)
		{
			return this.InnerList.Contains(value);
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0001CDF0 File Offset: 0x0001AFF0
		int IList.IndexOf(object value)
		{
			return this.InnerList.IndexOf(value);
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x0001CE00 File Offset: 0x0001B000
		void IList.Insert(int index, object value)
		{
			this.OnValidate(value);
			this.OnInsert(index, value);
			this.InnerList.Insert(index, value);
			try
			{
				this.OnInsertComplete(index, value);
			}
			catch
			{
				this.InnerList.RemoveAt(index);
				throw;
			}
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x0001CE5C File Offset: 0x0001B05C
		void IList.Remove(object value)
		{
			this.OnValidate(value);
			int num = this.InnerList.IndexOf(value);
			if (num == -1)
			{
				throw new ArgumentException("The element cannot be found.", "value");
			}
			this.OnRemove(num, value);
			this.InnerList.Remove(value);
			this.OnRemoveComplete(num, value);
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060005AD RID: 1453 RVA: 0x0001CEB0 File Offset: 0x0001B0B0
		bool IList.IsFixedSize
		{
			get
			{
				return this.InnerList.IsFixedSize;
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060005AE RID: 1454 RVA: 0x0001CEC0 File Offset: 0x0001B0C0
		bool IList.IsReadOnly
		{
			get
			{
				return this.InnerList.IsReadOnly;
			}
		}

		// Token: 0x170000BC RID: 188
		object IList.this[int index]
		{
			get
			{
				return this.InnerList[index];
			}
			set
			{
				if (index < 0 || index >= this.InnerList.Count)
				{
					throw new ArgumentOutOfRangeException("index");
				}
				this.OnValidate(value);
				object obj = this.InnerList[index];
				this.OnSet(index, obj, value);
				this.InnerList[index] = value;
				try
				{
					this.OnSetComplete(index, obj, value);
				}
				catch
				{
					this.InnerList[index] = obj;
					throw;
				}
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060005B1 RID: 1457 RVA: 0x0001CF70 File Offset: 0x0001B170
		public int Count
		{
			get
			{
				return this.InnerList.Count;
			}
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x0001CF80 File Offset: 0x0001B180
		public IEnumerator GetEnumerator()
		{
			return this.InnerList.GetEnumerator();
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x0001CF90 File Offset: 0x0001B190
		public void Clear()
		{
			this.OnClear();
			this.InnerList.Clear();
			this.OnClearComplete();
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x0001CFAC File Offset: 0x0001B1AC
		public void RemoveAt(int index)
		{
			object obj = this.InnerList[index];
			this.OnValidate(obj);
			this.OnRemove(index, obj);
			this.InnerList.RemoveAt(index);
			this.OnRemoveComplete(index, obj);
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060005B5 RID: 1461 RVA: 0x0001CFEC File Offset: 0x0001B1EC
		protected ArrayList InnerList
		{
			get
			{
				if (this.list == null)
				{
					this.list = new ArrayList();
				}
				return this.list;
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060005B6 RID: 1462 RVA: 0x0001D00C File Offset: 0x0001B20C
		protected IList List
		{
			get
			{
				return this;
			}
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x0001D010 File Offset: 0x0001B210
		protected virtual void OnClear()
		{
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x0001D014 File Offset: 0x0001B214
		protected virtual void OnClearComplete()
		{
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x0001D018 File Offset: 0x0001B218
		protected virtual void OnInsert(int index, object value)
		{
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x0001D01C File Offset: 0x0001B21C
		protected virtual void OnInsertComplete(int index, object value)
		{
		}

		// Token: 0x060005BB RID: 1467 RVA: 0x0001D020 File Offset: 0x0001B220
		protected virtual void OnRemove(int index, object value)
		{
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x0001D024 File Offset: 0x0001B224
		protected virtual void OnRemoveComplete(int index, object value)
		{
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x0001D028 File Offset: 0x0001B228
		protected virtual void OnSet(int index, object oldValue, object newValue)
		{
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x0001D02C File Offset: 0x0001B22C
		protected virtual void OnSetComplete(int index, object oldValue, object newValue)
		{
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x0001D030 File Offset: 0x0001B230
		protected virtual void OnValidate(object value)
		{
			if (value == null)
			{
				throw new ArgumentNullException("CollectionBase.OnValidate: Invalid parameter value passed to method: null");
			}
		}

		// Token: 0x04000291 RID: 657
		private ArrayList list;
	}
}
