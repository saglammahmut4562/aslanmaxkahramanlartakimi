﻿using System;

namespace System.Collections
{
	// Token: 0x020000A4 RID: 164
	internal sealed class CollectionDebuggerView
	{
		// Token: 0x04000292 RID: 658
		private readonly ICollection c;
	}
}
