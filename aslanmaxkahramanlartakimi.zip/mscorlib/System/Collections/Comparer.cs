﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Collections
{
	// Token: 0x020000A5 RID: 165
	[ComVisible(true)]
	[Serializable]
	public sealed class Comparer : IComparer, ISerializable
	{
		// Token: 0x060005C0 RID: 1472 RVA: 0x0001D044 File Offset: 0x0001B244
		private Comparer()
		{
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x0001D04C File Offset: 0x0001B24C
		public Comparer(CultureInfo culture)
		{
			if (culture == null)
			{
				throw new ArgumentNullException("culture");
			}
			this.m_compareInfo = culture.CompareInfo;
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x0001D090 File Offset: 0x0001B290
		public int Compare(object a, object b)
		{
			if (a == b)
			{
				return 0;
			}
			if (a == null)
			{
				return -1;
			}
			if (b == null)
			{
				return 1;
			}
			if (this.m_compareInfo != null)
			{
				string text = a as string;
				string text2 = b as string;
				if (text != null && text2 != null)
				{
					return this.m_compareInfo.Compare(text, text2);
				}
			}
			if (a is IComparable)
			{
				return (a as IComparable).CompareTo(b);
			}
			if (b is IComparable)
			{
				return -(b as IComparable).CompareTo(a);
			}
			throw new ArgumentException(Locale.GetText("Neither 'a' nor 'b' implements IComparable."));
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x0001D12C File Offset: 0x0001B32C
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			info.AddValue("CompareInfo", this.m_compareInfo, typeof(CompareInfo));
		}

		// Token: 0x04000293 RID: 659
		public static readonly Comparer Default = new Comparer();

		// Token: 0x04000294 RID: 660
		public static readonly Comparer DefaultInvariant = new Comparer(CultureInfo.InvariantCulture);

		// Token: 0x04000295 RID: 661
		private CompareInfo m_compareInfo;
	}
}
