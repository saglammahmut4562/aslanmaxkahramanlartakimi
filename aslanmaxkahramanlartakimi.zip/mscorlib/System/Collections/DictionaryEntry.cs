﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000A6 RID: 166
	[ComVisible(true)]
	[DebuggerDisplay("{_value}", Name = "[{_key}]")]
	[Serializable]
	public struct DictionaryEntry
	{
		// Token: 0x060005C5 RID: 1477 RVA: 0x0001D15C File Offset: 0x0001B35C
		public DictionaryEntry(object key, object value)
		{
			this._key = key;
			this._value = value;
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x060005C6 RID: 1478 RVA: 0x0001D16C File Offset: 0x0001B36C
		public object Key
		{
			get
			{
				return this._key;
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x060005C7 RID: 1479 RVA: 0x0001D174 File Offset: 0x0001B374
		public object Value
		{
			get
			{
				return this._value;
			}
		}

		// Token: 0x04000296 RID: 662
		private object _key;

		// Token: 0x04000297 RID: 663
		private object _value;
	}
}
