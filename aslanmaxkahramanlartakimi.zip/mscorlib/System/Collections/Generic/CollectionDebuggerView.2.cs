﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000A8 RID: 168
	internal sealed class CollectionDebuggerView<T, U>
	{
		// Token: 0x04000299 RID: 665
		private readonly ICollection<KeyValuePair<T, U>> c;
	}
}
