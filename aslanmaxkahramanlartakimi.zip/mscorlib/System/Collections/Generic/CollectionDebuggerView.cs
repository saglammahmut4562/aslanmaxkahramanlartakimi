﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000A7 RID: 167
	internal sealed class CollectionDebuggerView<T>
	{
		// Token: 0x04000298 RID: 664
		private readonly ICollection<T> c;
	}
}
