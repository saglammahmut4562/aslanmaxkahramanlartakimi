﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000A9 RID: 169
	[Serializable]
	public abstract class Comparer<T> : IComparer<T>, IComparer
	{
		// Token: 0x060005C9 RID: 1481 RVA: 0x0001D184 File Offset: 0x0001B384
		static Comparer()
		{
			if (typeof(IComparable<T>).IsAssignableFrom(typeof(T)))
			{
				Comparer<T>._default = (Comparer<T>)Activator.CreateInstance(typeof(GenericComparer<>).MakeGenericType(new Type[] { typeof(T) }));
			}
			else
			{
				Comparer<T>._default = new Comparer<T>.DefaultComparer();
			}
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x0001D1F0 File Offset: 0x0001B3F0
		int IComparer.Compare(object x, object y)
		{
			if (x == null)
			{
				return (y != null) ? (-1) : 0;
			}
			if (y == null)
			{
				return 1;
			}
			if (x is T && y is T)
			{
				return this.Compare((T)((object)x), (T)((object)y));
			}
			throw new ArgumentException();
		}

		// Token: 0x060005CB RID: 1483
		public abstract int Compare(T x, T y);

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060005CC RID: 1484 RVA: 0x0001D248 File Offset: 0x0001B448
		public static Comparer<T> Default
		{
			get
			{
				return Comparer<T>._default;
			}
		}

		// Token: 0x0400029A RID: 666
		private static readonly Comparer<T> _default;

		// Token: 0x020000AA RID: 170
		private sealed class DefaultComparer : Comparer<T>
		{
			// Token: 0x060005CE RID: 1486 RVA: 0x0001D258 File Offset: 0x0001B458
			public override int Compare(T x, T y)
			{
				if (x == null)
				{
					return (y != null) ? (-1) : 0;
				}
				if (y == null)
				{
					return 1;
				}
				if (x is IComparable<T>)
				{
					return ((IComparable<T>)((object)x)).CompareTo(y);
				}
				if (x is IComparable)
				{
					return ((IComparable)((object)x)).CompareTo(y);
				}
				throw new ArgumentException("does not implement right interface");
			}
		}
	}
}
