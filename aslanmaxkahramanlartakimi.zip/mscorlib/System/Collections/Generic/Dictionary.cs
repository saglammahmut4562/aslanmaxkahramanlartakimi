﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Collections.Generic
{
	// Token: 0x020000AB RID: 171
	[DebuggerDisplay("Count={Count}")]
	[ComVisible(false)]
	[DebuggerTypeProxy(typeof(CollectionDebuggerView<, >))]
	[Serializable]
	public class Dictionary<TKey, TValue> : IDictionary<TKey, TValue>, ICollection<KeyValuePair<TKey, TValue>>, IEnumerable<KeyValuePair<TKey, TValue>>, ICollection, IDictionary, IEnumerable, IDeserializationCallback, ISerializable
	{
		// Token: 0x060005CF RID: 1487 RVA: 0x0001D2E4 File Offset: 0x0001B4E4
		public Dictionary()
		{
			this.Init(10, null);
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x0001D2F8 File Offset: 0x0001B4F8
		public Dictionary(IEqualityComparer<TKey> comparer)
		{
			this.Init(10, comparer);
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x0001D30C File Offset: 0x0001B50C
		public Dictionary(IDictionary<TKey, TValue> dictionary)
			: this(dictionary, null)
		{
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x0001D318 File Offset: 0x0001B518
		public Dictionary(int capacity)
		{
			this.Init(capacity, null);
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x0001D328 File Offset: 0x0001B528
		public Dictionary(IDictionary<TKey, TValue> dictionary, IEqualityComparer<TKey> comparer)
		{
			if (dictionary == null)
			{
				throw new ArgumentNullException("dictionary");
			}
			int num = dictionary.Count;
			this.Init(num, comparer);
			foreach (KeyValuePair<TKey, TValue> keyValuePair in dictionary)
			{
				this.Add(keyValuePair.Key, keyValuePair.Value);
			}
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x0001D3B0 File Offset: 0x0001B5B0
		protected Dictionary(SerializationInfo info, StreamingContext context)
		{
			this.serialization_info = info;
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060005D5 RID: 1493 RVA: 0x0001D3C0 File Offset: 0x0001B5C0
		ICollection<TKey> IDictionary<TKey, TValue>.Keys
		{
			get
			{
				return this.Keys;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060005D6 RID: 1494 RVA: 0x0001D3C8 File Offset: 0x0001B5C8
		ICollection<TValue> IDictionary<TKey, TValue>.Values
		{
			get
			{
				return this.Values;
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x060005D7 RID: 1495 RVA: 0x0001D3D0 File Offset: 0x0001B5D0
		ICollection IDictionary.Keys
		{
			get
			{
				return this.Keys;
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x060005D8 RID: 1496 RVA: 0x0001D3D8 File Offset: 0x0001B5D8
		ICollection IDictionary.Values
		{
			get
			{
				return this.Values;
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060005D9 RID: 1497 RVA: 0x0001D3E0 File Offset: 0x0001B5E0
		bool IDictionary.IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x060005DA RID: 1498 RVA: 0x0001D3E4 File Offset: 0x0001B5E4
		bool IDictionary.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000C9 RID: 201
		object IDictionary.this[object key]
		{
			get
			{
				if (key is TKey && this.ContainsKey((TKey)((object)key)))
				{
					return this[this.ToTKey(key)];
				}
				return null;
			}
			set
			{
				this[this.ToTKey(key)] = this.ToTValue(value);
			}
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x0001D434 File Offset: 0x0001B634
		void IDictionary.Add(object key, object value)
		{
			this.Add(this.ToTKey(key), this.ToTValue(value));
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x0001D44C File Offset: 0x0001B64C
		bool IDictionary.Contains(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			return key is TKey && this.ContainsKey((TKey)((object)key));
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x0001D478 File Offset: 0x0001B678
		void IDictionary.Remove(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			if (key is TKey)
			{
				this.Remove((TKey)((object)key));
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x0001D4A4 File Offset: 0x0001B6A4
		bool ICollection.IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060005E1 RID: 1505 RVA: 0x0001D4A8 File Offset: 0x0001B6A8
		object ICollection.SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x0001D4AC File Offset: 0x0001B6AC
		bool ICollection<KeyValuePair<TKey, TValue>>.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x0001D4B0 File Offset: 0x0001B6B0
		void ICollection<KeyValuePair<TKey, TValue>>.Add(KeyValuePair<TKey, TValue> keyValuePair)
		{
			this.Add(keyValuePair.Key, keyValuePair.Value);
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0001D4C8 File Offset: 0x0001B6C8
		bool ICollection<KeyValuePair<TKey, TValue>>.Contains(KeyValuePair<TKey, TValue> keyValuePair)
		{
			return this.ContainsKeyValuePair(keyValuePair);
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x0001D4D4 File Offset: 0x0001B6D4
		void ICollection<KeyValuePair<TKey, TValue>>.CopyTo(KeyValuePair<TKey, TValue>[] array, int index)
		{
			this.CopyTo(array, index);
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x0001D4E0 File Offset: 0x0001B6E0
		bool ICollection<KeyValuePair<TKey, TValue>>.Remove(KeyValuePair<TKey, TValue> keyValuePair)
		{
			return this.ContainsKeyValuePair(keyValuePair) && this.Remove(keyValuePair.Key);
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x0001D500 File Offset: 0x0001B700
		void ICollection.CopyTo(Array array, int index)
		{
			KeyValuePair<TKey, TValue>[] array2 = array as KeyValuePair<TKey, TValue>[];
			if (array2 != null)
			{
				this.CopyTo(array2, index);
				return;
			}
			this.CopyToCheck(array, index);
			DictionaryEntry[] array3 = array as DictionaryEntry[];
			if (array3 != null)
			{
				this.Do_CopyTo<DictionaryEntry, DictionaryEntry>(array3, index, (TKey key, TValue value) => new DictionaryEntry(key, value));
				return;
			}
			this.Do_ICollectionCopyTo<KeyValuePair<TKey, TValue>>(array, index, new Dictionary<TKey, TValue>.Transform<KeyValuePair<TKey, TValue>>(Dictionary<TKey, TValue>.make_pair));
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x0001D574 File Offset: 0x0001B774
		IEnumerator IEnumerable.GetEnumerator()
		{
			return new Dictionary<TKey, TValue>.Enumerator(this);
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x0001D584 File Offset: 0x0001B784
		IEnumerator<KeyValuePair<TKey, TValue>> IEnumerable<KeyValuePair<TKey, TValue>>.GetEnumerator()
		{
			return new Dictionary<TKey, TValue>.Enumerator(this);
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x0001D594 File Offset: 0x0001B794
		IDictionaryEnumerator IDictionary.GetEnumerator()
		{
			return new Dictionary<TKey, TValue>.ShimEnumerator(this);
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060005EB RID: 1515 RVA: 0x0001D59C File Offset: 0x0001B79C
		public int Count
		{
			get
			{
				return this.count;
			}
		}

		// Token: 0x170000CE RID: 206
		public TValue this[TKey key]
		{
			get
			{
				if (key == null)
				{
					throw new ArgumentNullException("key");
				}
				int num = this.hcp.GetHashCode(key) | int.MinValue;
				for (int num2 = this.table[(num & int.MaxValue) % this.table.Length] - 1; num2 != -1; num2 = this.linkSlots[num2].Next)
				{
					if (this.linkSlots[num2].HashCode == num && this.hcp.Equals(this.keySlots[num2], key))
					{
						return this.valueSlots[num2];
					}
				}
				throw new KeyNotFoundException();
			}
			set
			{
				if (key == null)
				{
					throw new ArgumentNullException("key");
				}
				int num = this.hcp.GetHashCode(key) | int.MinValue;
				int num2 = (num & int.MaxValue) % this.table.Length;
				int num3 = this.table[num2] - 1;
				int num4 = -1;
				if (num3 != -1)
				{
					while (this.linkSlots[num3].HashCode != num || !this.hcp.Equals(this.keySlots[num3], key))
					{
						num4 = num3;
						num3 = this.linkSlots[num3].Next;
						if (num3 == -1)
						{
							break;
						}
					}
				}
				if (num3 == -1)
				{
					if (++this.count > this.threshold)
					{
						this.Resize();
						num2 = (num & int.MaxValue) % this.table.Length;
					}
					num3 = this.emptySlot;
					if (num3 == -1)
					{
						num3 = this.touchedSlots++;
					}
					else
					{
						this.emptySlot = this.linkSlots[num3].Next;
					}
					this.linkSlots[num3].Next = this.table[num2] - 1;
					this.table[num2] = num3 + 1;
					this.linkSlots[num3].HashCode = num;
					this.keySlots[num3] = key;
				}
				else if (num4 != -1)
				{
					this.linkSlots[num4].Next = this.linkSlots[num3].Next;
					this.linkSlots[num3].Next = this.table[num2] - 1;
					this.table[num2] = num3 + 1;
				}
				this.valueSlots[num3] = value;
				this.generation++;
			}
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x0001D838 File Offset: 0x0001BA38
		private void Init(int capacity, IEqualityComparer<TKey> hcp)
		{
			if (capacity < 0)
			{
				throw new ArgumentOutOfRangeException("capacity");
			}
			this.hcp = ((hcp == null) ? EqualityComparer<TKey>.Default : hcp);
			if (capacity == 0)
			{
				capacity = 10;
			}
			capacity = (int)((float)capacity / 0.9f) + 1;
			this.InitArrays(capacity);
			this.generation = 0;
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x0001D898 File Offset: 0x0001BA98
		private void InitArrays(int size)
		{
			this.table = new int[size];
			this.linkSlots = new Link[size];
			this.emptySlot = -1;
			this.keySlots = new TKey[size];
			this.valueSlots = new TValue[size];
			this.touchedSlots = 0;
			this.threshold = (int)((float)this.table.Length * 0.9f);
			if (this.threshold == 0 && this.table.Length > 0)
			{
				this.threshold = 1;
			}
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x0001D91C File Offset: 0x0001BB1C
		private void CopyToCheck(Array array, int index)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (index > array.Length)
			{
				throw new ArgumentException("index larger than largest valid index of array");
			}
			if (array.Length - index < this.Count)
			{
				throw new ArgumentException("Destination array cannot hold the requested elements!");
			}
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x0001D984 File Offset: 0x0001BB84
		private void Do_CopyTo<TRet, TElem>(TElem[] array, int index, Dictionary<TKey, TValue>.Transform<TRet> transform) where TRet : TElem
		{
			for (int i = 0; i < this.touchedSlots; i++)
			{
				if ((this.linkSlots[i].HashCode & -2147483648) != 0)
				{
					array[index++] = (TElem)((object)transform(this.keySlots[i], this.valueSlots[i]));
				}
			}
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x0001D9F8 File Offset: 0x0001BBF8
		private static KeyValuePair<TKey, TValue> make_pair(TKey key, TValue value)
		{
			return new KeyValuePair<TKey, TValue>(key, value);
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x0001DA04 File Offset: 0x0001BC04
		private static TKey pick_key(TKey key, TValue value)
		{
			return key;
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x0001DA08 File Offset: 0x0001BC08
		private static TValue pick_value(TKey key, TValue value)
		{
			return value;
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x0001DA0C File Offset: 0x0001BC0C
		private void CopyTo(KeyValuePair<TKey, TValue>[] array, int index)
		{
			this.CopyToCheck(array, index);
			this.Do_CopyTo<KeyValuePair<TKey, TValue>, KeyValuePair<TKey, TValue>>(array, index, new Dictionary<TKey, TValue>.Transform<KeyValuePair<TKey, TValue>>(Dictionary<TKey, TValue>.make_pair));
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x0001DA2C File Offset: 0x0001BC2C
		private void Do_ICollectionCopyTo<TRet>(Array array, int index, Dictionary<TKey, TValue>.Transform<TRet> transform)
		{
			Type typeFromHandle = typeof(TRet);
			Type elementType = array.GetType().GetElementType();
			try
			{
				if ((typeFromHandle.IsPrimitive || elementType.IsPrimitive) && !elementType.IsAssignableFrom(typeFromHandle))
				{
					throw new Exception();
				}
				this.Do_CopyTo<TRet, object>((object[])array, index, transform);
			}
			catch (Exception ex)
			{
				throw new ArgumentException("Cannot copy source collection elements to destination array", "array", ex);
			}
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x0001DAB4 File Offset: 0x0001BCB4
		private void Resize()
		{
			int num = Hashtable.ToPrime((this.table.Length << 1) | 1);
			int[] array = new int[num];
			Link[] array2 = new Link[num];
			for (int i = 0; i < this.table.Length; i++)
			{
				for (int num2 = this.table[i] - 1; num2 != -1; num2 = this.linkSlots[num2].Next)
				{
					int num3 = (array2[num2].HashCode = this.hcp.GetHashCode(this.keySlots[num2]) | int.MinValue);
					int num4 = (num3 & int.MaxValue) % num;
					array2[num2].Next = array[num4] - 1;
					array[num4] = num2 + 1;
				}
			}
			this.table = array;
			this.linkSlots = array2;
			TKey[] array3 = new TKey[num];
			TValue[] array4 = new TValue[num];
			Array.Copy(this.keySlots, 0, array3, 0, this.touchedSlots);
			Array.Copy(this.valueSlots, 0, array4, 0, this.touchedSlots);
			this.keySlots = array3;
			this.valueSlots = array4;
			this.threshold = (int)((float)num * 0.9f);
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x0001DBE8 File Offset: 0x0001BDE8
		public void Add(TKey key, TValue value)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			int num = this.hcp.GetHashCode(key) | int.MinValue;
			int num2 = (num & int.MaxValue) % this.table.Length;
			int num3;
			for (num3 = this.table[num2] - 1; num3 != -1; num3 = this.linkSlots[num3].Next)
			{
				if (this.linkSlots[num3].HashCode == num && this.hcp.Equals(this.keySlots[num3], key))
				{
					throw new ArgumentException("An element with the same key already exists in the dictionary.");
				}
			}
			if (++this.count > this.threshold)
			{
				this.Resize();
				num2 = (num & int.MaxValue) % this.table.Length;
			}
			num3 = this.emptySlot;
			if (num3 == -1)
			{
				num3 = this.touchedSlots++;
			}
			else
			{
				this.emptySlot = this.linkSlots[num3].Next;
			}
			this.linkSlots[num3].HashCode = num;
			this.linkSlots[num3].Next = this.table[num2] - 1;
			this.table[num2] = num3 + 1;
			this.keySlots[num3] = key;
			this.valueSlots[num3] = value;
			this.generation++;
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x0001DD68 File Offset: 0x0001BF68
		public void Clear()
		{
			this.count = 0;
			Array.Clear(this.table, 0, this.table.Length);
			Array.Clear(this.keySlots, 0, this.keySlots.Length);
			Array.Clear(this.valueSlots, 0, this.valueSlots.Length);
			Array.Clear(this.linkSlots, 0, this.linkSlots.Length);
			this.emptySlot = -1;
			this.touchedSlots = 0;
			this.generation++;
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x0001DDE8 File Offset: 0x0001BFE8
		public bool ContainsKey(TKey key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			int num = this.hcp.GetHashCode(key) | int.MinValue;
			for (int num2 = this.table[(num & int.MaxValue) % this.table.Length] - 1; num2 != -1; num2 = this.linkSlots[num2].Next)
			{
				if (this.linkSlots[num2].HashCode == num && this.hcp.Equals(this.keySlots[num2], key))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x0001DE90 File Offset: 0x0001C090
		public bool ContainsValue(TValue value)
		{
			IEqualityComparer<TValue> @default = EqualityComparer<TValue>.Default;
			for (int i = 0; i < this.table.Length; i++)
			{
				for (int num = this.table[i] - 1; num != -1; num = this.linkSlots[num].Next)
				{
					if (@default.Equals(this.valueSlots[num], value))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x0001DF00 File Offset: 0x0001C100
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			info.AddValue("Version", this.generation);
			info.AddValue("Comparer", this.hcp);
			KeyValuePair<TKey, TValue>[] array = null;
			if (this.count > 0)
			{
				array = new KeyValuePair<TKey, TValue>[this.count];
				this.CopyTo(array, 0);
			}
			info.AddValue("HashSize", this.table.Length);
			info.AddValue("KeyValuePairs", array);
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x0001DF84 File Offset: 0x0001C184
		public virtual void OnDeserialization(object sender)
		{
			if (this.serialization_info == null)
			{
				return;
			}
			this.generation = this.serialization_info.GetInt32("Version");
			this.hcp = (IEqualityComparer<TKey>)this.serialization_info.GetValue("Comparer", typeof(IEqualityComparer<TKey>));
			int num = this.serialization_info.GetInt32("HashSize");
			KeyValuePair<TKey, TValue>[] array = (KeyValuePair<TKey, TValue>[])this.serialization_info.GetValue("KeyValuePairs", typeof(KeyValuePair<TKey, TValue>[]));
			if (num < 10)
			{
				num = 10;
			}
			this.InitArrays(num);
			this.count = 0;
			if (array != null)
			{
				for (int i = 0; i < array.Length; i++)
				{
					this.Add(array[i].Key, array[i].Value);
				}
			}
			this.generation++;
			this.serialization_info = null;
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x0001E070 File Offset: 0x0001C270
		public bool Remove(TKey key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			int num = this.hcp.GetHashCode(key) | int.MinValue;
			int num2 = (num & int.MaxValue) % this.table.Length;
			int num3 = this.table[num2] - 1;
			if (num3 == -1)
			{
				return false;
			}
			int num4 = -1;
			while (this.linkSlots[num3].HashCode != num || !this.hcp.Equals(this.keySlots[num3], key))
			{
				num4 = num3;
				num3 = this.linkSlots[num3].Next;
				if (num3 == -1)
				{
					IL_00A4:
					if (num3 == -1)
					{
						return false;
					}
					this.count--;
					if (num4 == -1)
					{
						this.table[num2] = this.linkSlots[num3].Next + 1;
					}
					else
					{
						this.linkSlots[num4].Next = this.linkSlots[num3].Next;
					}
					this.linkSlots[num3].Next = this.emptySlot;
					this.emptySlot = num3;
					this.linkSlots[num3].HashCode = 0;
					this.keySlots[num3] = default(TKey);
					this.valueSlots[num3] = default(TValue);
					this.generation++;
					return true;
				}
			}
			goto IL_00A4;
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x0001E1EC File Offset: 0x0001C3EC
		public bool TryGetValue(TKey key, out TValue value)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			int num = this.hcp.GetHashCode(key) | int.MinValue;
			for (int num2 = this.table[(num & int.MaxValue) % this.table.Length] - 1; num2 != -1; num2 = this.linkSlots[num2].Next)
			{
				if (this.linkSlots[num2].HashCode == num && this.hcp.Equals(this.keySlots[num2], key))
				{
					value = this.valueSlots[num2];
					return true;
				}
			}
			value = default(TValue);
			return false;
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x0001E2B4 File Offset: 0x0001C4B4
		public Dictionary<TKey, TValue>.KeyCollection Keys
		{
			get
			{
				return new Dictionary<TKey, TValue>.KeyCollection(this);
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x06000601 RID: 1537 RVA: 0x0001E2BC File Offset: 0x0001C4BC
		public Dictionary<TKey, TValue>.ValueCollection Values
		{
			get
			{
				return new Dictionary<TKey, TValue>.ValueCollection(this);
			}
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x0001E2C4 File Offset: 0x0001C4C4
		private TKey ToTKey(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			if (!(key is TKey))
			{
				throw new ArgumentException("not of type: " + typeof(TKey).ToString(), "key");
			}
			return (TKey)((object)key);
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x0001E318 File Offset: 0x0001C518
		private TValue ToTValue(object value)
		{
			if (value == null && !typeof(TValue).IsValueType)
			{
				return default(TValue);
			}
			if (!(value is TValue))
			{
				throw new ArgumentException("not of type: " + typeof(TValue).ToString(), "value");
			}
			return (TValue)((object)value);
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x0001E380 File Offset: 0x0001C580
		private bool ContainsKeyValuePair(KeyValuePair<TKey, TValue> pair)
		{
			TValue tvalue;
			return this.TryGetValue(pair.Key, out tvalue) && EqualityComparer<TValue>.Default.Equals(pair.Value, tvalue);
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
		public Dictionary<TKey, TValue>.Enumerator GetEnumerator()
		{
			return new Dictionary<TKey, TValue>.Enumerator(this);
		}

		// Token: 0x0400029B RID: 667
		private const int INITIAL_SIZE = 10;

		// Token: 0x0400029C RID: 668
		private const float DEFAULT_LOAD_FACTOR = 0.9f;

		// Token: 0x0400029D RID: 669
		private const int NO_SLOT = -1;

		// Token: 0x0400029E RID: 670
		private const int HASH_FLAG = -2147483648;

		// Token: 0x0400029F RID: 671
		private int[] table;

		// Token: 0x040002A0 RID: 672
		private Link[] linkSlots;

		// Token: 0x040002A1 RID: 673
		private TKey[] keySlots;

		// Token: 0x040002A2 RID: 674
		private TValue[] valueSlots;

		// Token: 0x040002A3 RID: 675
		private int touchedSlots;

		// Token: 0x040002A4 RID: 676
		private int emptySlot;

		// Token: 0x040002A5 RID: 677
		private int count;

		// Token: 0x040002A6 RID: 678
		private int threshold;

		// Token: 0x040002A7 RID: 679
		private IEqualityComparer<TKey> hcp;

		// Token: 0x040002A8 RID: 680
		private SerializationInfo serialization_info;

		// Token: 0x040002A9 RID: 681
		private int generation;

		// Token: 0x020000AC RID: 172
		[Serializable]
		public struct Enumerator : IEnumerator<KeyValuePair<TKey, TValue>>, IDictionaryEnumerator, IEnumerator, IDisposable
		{
			// Token: 0x06000607 RID: 1543 RVA: 0x0001E3D4 File Offset: 0x0001C5D4
			internal Enumerator(Dictionary<TKey, TValue> dictionary)
			{
				this.dictionary = dictionary;
				this.stamp = dictionary.generation;
			}

			// Token: 0x170000D1 RID: 209
			// (get) Token: 0x06000608 RID: 1544 RVA: 0x0001E3EC File Offset: 0x0001C5EC
			object IEnumerator.Current
			{
				get
				{
					this.VerifyCurrent();
					return this.current;
				}
			}

			// Token: 0x06000609 RID: 1545 RVA: 0x0001E400 File Offset: 0x0001C600
			void IEnumerator.Reset()
			{
				this.Reset();
			}

			// Token: 0x170000D2 RID: 210
			// (get) Token: 0x0600060A RID: 1546 RVA: 0x0001E408 File Offset: 0x0001C608
			DictionaryEntry IDictionaryEnumerator.Entry
			{
				get
				{
					this.VerifyCurrent();
					return new DictionaryEntry(this.current.Key, this.current.Value);
				}
			}

			// Token: 0x170000D3 RID: 211
			// (get) Token: 0x0600060B RID: 1547 RVA: 0x0001E438 File Offset: 0x0001C638
			object IDictionaryEnumerator.Key
			{
				get
				{
					return this.CurrentKey;
				}
			}

			// Token: 0x170000D4 RID: 212
			// (get) Token: 0x0600060C RID: 1548 RVA: 0x0001E448 File Offset: 0x0001C648
			object IDictionaryEnumerator.Value
			{
				get
				{
					return this.CurrentValue;
				}
			}

			// Token: 0x0600060D RID: 1549 RVA: 0x0001E458 File Offset: 0x0001C658
			public bool MoveNext()
			{
				this.VerifyState();
				if (this.next < 0)
				{
					return false;
				}
				while (this.next < this.dictionary.touchedSlots)
				{
					int num = this.next++;
					if ((this.dictionary.linkSlots[num].HashCode & -2147483648) != 0)
					{
						this.current = new KeyValuePair<TKey, TValue>(this.dictionary.keySlots[num], this.dictionary.valueSlots[num]);
						return true;
					}
				}
				this.next = -1;
				return false;
			}

			// Token: 0x170000D5 RID: 213
			// (get) Token: 0x0600060E RID: 1550 RVA: 0x0001E500 File Offset: 0x0001C700
			public KeyValuePair<TKey, TValue> Current
			{
				get
				{
					return this.current;
				}
			}

			// Token: 0x170000D6 RID: 214
			// (get) Token: 0x0600060F RID: 1551 RVA: 0x0001E508 File Offset: 0x0001C708
			internal TKey CurrentKey
			{
				get
				{
					this.VerifyCurrent();
					return this.current.Key;
				}
			}

			// Token: 0x170000D7 RID: 215
			// (get) Token: 0x06000610 RID: 1552 RVA: 0x0001E51C File Offset: 0x0001C71C
			internal TValue CurrentValue
			{
				get
				{
					this.VerifyCurrent();
					return this.current.Value;
				}
			}

			// Token: 0x06000611 RID: 1553 RVA: 0x0001E530 File Offset: 0x0001C730
			internal void Reset()
			{
				this.VerifyState();
				this.next = 0;
			}

			// Token: 0x06000612 RID: 1554 RVA: 0x0001E540 File Offset: 0x0001C740
			private void VerifyState()
			{
				if (this.dictionary == null)
				{
					throw new ObjectDisposedException(null);
				}
				if (this.dictionary.generation != this.stamp)
				{
					throw new InvalidOperationException("out of sync");
				}
			}

			// Token: 0x06000613 RID: 1555 RVA: 0x0001E578 File Offset: 0x0001C778
			private void VerifyCurrent()
			{
				this.VerifyState();
				if (this.next <= 0)
				{
					throw new InvalidOperationException("Current is not valid");
				}
			}

			// Token: 0x06000614 RID: 1556 RVA: 0x0001E598 File Offset: 0x0001C798
			public void Dispose()
			{
				this.dictionary = null;
			}

			// Token: 0x040002AB RID: 683
			private Dictionary<TKey, TValue> dictionary;

			// Token: 0x040002AC RID: 684
			private int next;

			// Token: 0x040002AD RID: 685
			private int stamp;

			// Token: 0x040002AE RID: 686
			internal KeyValuePair<TKey, TValue> current;
		}

		// Token: 0x020000AD RID: 173
		[DebuggerTypeProxy(typeof(CollectionDebuggerView<, >))]
		[DebuggerDisplay("Count={Count}")]
		[Serializable]
		public sealed class KeyCollection : ICollection<TKey>, IEnumerable<TKey>, ICollection, IEnumerable
		{
			// Token: 0x06000615 RID: 1557 RVA: 0x0001E5A4 File Offset: 0x0001C7A4
			public KeyCollection(Dictionary<TKey, TValue> dictionary)
			{
				if (dictionary == null)
				{
					throw new ArgumentNullException("dictionary");
				}
				this.dictionary = dictionary;
			}

			// Token: 0x06000616 RID: 1558 RVA: 0x0001E5C4 File Offset: 0x0001C7C4
			void ICollection<TKey>.Add(TKey item)
			{
				throw new NotSupportedException("this is a read-only collection");
			}

			// Token: 0x06000617 RID: 1559 RVA: 0x0001E5D0 File Offset: 0x0001C7D0
			void ICollection<TKey>.Clear()
			{
				throw new NotSupportedException("this is a read-only collection");
			}

			// Token: 0x06000618 RID: 1560 RVA: 0x0001E5DC File Offset: 0x0001C7DC
			bool ICollection<TKey>.Contains(TKey item)
			{
				return this.dictionary.ContainsKey(item);
			}

			// Token: 0x06000619 RID: 1561 RVA: 0x0001E5EC File Offset: 0x0001C7EC
			bool ICollection<TKey>.Remove(TKey item)
			{
				throw new NotSupportedException("this is a read-only collection");
			}

			// Token: 0x0600061A RID: 1562 RVA: 0x0001E5F8 File Offset: 0x0001C7F8
			IEnumerator<TKey> IEnumerable<TKey>.GetEnumerator()
			{
				return this.GetEnumerator();
			}

			// Token: 0x0600061B RID: 1563 RVA: 0x0001E608 File Offset: 0x0001C808
			void ICollection.CopyTo(Array array, int index)
			{
				TKey[] array2 = array as TKey[];
				if (array2 != null)
				{
					this.CopyTo(array2, index);
					return;
				}
				this.dictionary.CopyToCheck(array, index);
				this.dictionary.Do_ICollectionCopyTo<TKey>(array, index, new Dictionary<TKey, TValue>.Transform<TKey>(Dictionary<TKey, TValue>.pick_key));
			}

			// Token: 0x0600061C RID: 1564 RVA: 0x0001E654 File Offset: 0x0001C854
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this.GetEnumerator();
			}

			// Token: 0x170000D8 RID: 216
			// (get) Token: 0x0600061D RID: 1565 RVA: 0x0001E664 File Offset: 0x0001C864
			bool ICollection<TKey>.IsReadOnly
			{
				get
				{
					return true;
				}
			}

			// Token: 0x170000D9 RID: 217
			// (get) Token: 0x0600061E RID: 1566 RVA: 0x0001E668 File Offset: 0x0001C868
			bool ICollection.IsSynchronized
			{
				get
				{
					return false;
				}
			}

			// Token: 0x170000DA RID: 218
			// (get) Token: 0x0600061F RID: 1567 RVA: 0x0001E66C File Offset: 0x0001C86C
			object ICollection.SyncRoot
			{
				get
				{
					return ((ICollection)this.dictionary).SyncRoot;
				}
			}

			// Token: 0x06000620 RID: 1568 RVA: 0x0001E67C File Offset: 0x0001C87C
			public void CopyTo(TKey[] array, int index)
			{
				this.dictionary.CopyToCheck(array, index);
				this.dictionary.Do_CopyTo<TKey, TKey>(array, index, new Dictionary<TKey, TValue>.Transform<TKey>(Dictionary<TKey, TValue>.pick_key));
			}

			// Token: 0x06000621 RID: 1569 RVA: 0x0001E6A4 File Offset: 0x0001C8A4
			public Dictionary<TKey, TValue>.KeyCollection.Enumerator GetEnumerator()
			{
				return new Dictionary<TKey, TValue>.KeyCollection.Enumerator(this.dictionary);
			}

			// Token: 0x170000DB RID: 219
			// (get) Token: 0x06000622 RID: 1570 RVA: 0x0001E6B4 File Offset: 0x0001C8B4
			public int Count
			{
				get
				{
					return this.dictionary.Count;
				}
			}

			// Token: 0x040002AF RID: 687
			private Dictionary<TKey, TValue> dictionary;

			// Token: 0x020000AE RID: 174
			[Serializable]
			public struct Enumerator : IEnumerator<TKey>, IEnumerator, IDisposable
			{
				// Token: 0x06000623 RID: 1571 RVA: 0x0001E6C4 File Offset: 0x0001C8C4
				internal Enumerator(Dictionary<TKey, TValue> host)
				{
					this.host_enumerator = host.GetEnumerator();
				}

				// Token: 0x170000DC RID: 220
				// (get) Token: 0x06000624 RID: 1572 RVA: 0x0001E6D4 File Offset: 0x0001C8D4
				object IEnumerator.Current
				{
					get
					{
						return this.host_enumerator.CurrentKey;
					}
				}

				// Token: 0x06000625 RID: 1573 RVA: 0x0001E6E8 File Offset: 0x0001C8E8
				void IEnumerator.Reset()
				{
					this.host_enumerator.Reset();
				}

				// Token: 0x06000626 RID: 1574 RVA: 0x0001E6F8 File Offset: 0x0001C8F8
				public void Dispose()
				{
					this.host_enumerator.Dispose();
				}

				// Token: 0x06000627 RID: 1575 RVA: 0x0001E708 File Offset: 0x0001C908
				public bool MoveNext()
				{
					return this.host_enumerator.MoveNext();
				}

				// Token: 0x170000DD RID: 221
				// (get) Token: 0x06000628 RID: 1576 RVA: 0x0001E718 File Offset: 0x0001C918
				public TKey Current
				{
					get
					{
						return this.host_enumerator.current.Key;
					}
				}

				// Token: 0x040002B0 RID: 688
				private Dictionary<TKey, TValue>.Enumerator host_enumerator;
			}
		}

		// Token: 0x020000AF RID: 175
		[Serializable]
		private class ShimEnumerator : IDictionaryEnumerator, IEnumerator
		{
			// Token: 0x06000629 RID: 1577 RVA: 0x0001E72C File Offset: 0x0001C92C
			public ShimEnumerator(Dictionary<TKey, TValue> host)
			{
				this.host_enumerator = host.GetEnumerator();
			}

			// Token: 0x0600062A RID: 1578 RVA: 0x0001E740 File Offset: 0x0001C940
			public bool MoveNext()
			{
				return this.host_enumerator.MoveNext();
			}

			// Token: 0x170000DE RID: 222
			// (get) Token: 0x0600062B RID: 1579 RVA: 0x0001E750 File Offset: 0x0001C950
			public DictionaryEntry Entry
			{
				get
				{
					return ((IDictionaryEnumerator)this.host_enumerator).Entry;
				}
			}

			// Token: 0x170000DF RID: 223
			// (get) Token: 0x0600062C RID: 1580 RVA: 0x0001E764 File Offset: 0x0001C964
			public object Key
			{
				get
				{
					KeyValuePair<TKey, TValue> keyValuePair = this.host_enumerator.Current;
					return keyValuePair.Key;
				}
			}

			// Token: 0x170000E0 RID: 224
			// (get) Token: 0x0600062D RID: 1581 RVA: 0x0001E78C File Offset: 0x0001C98C
			public object Value
			{
				get
				{
					KeyValuePair<TKey, TValue> keyValuePair = this.host_enumerator.Current;
					return keyValuePair.Value;
				}
			}

			// Token: 0x170000E1 RID: 225
			// (get) Token: 0x0600062E RID: 1582 RVA: 0x0001E7B4 File Offset: 0x0001C9B4
			public object Current
			{
				get
				{
					return this.Entry;
				}
			}

			// Token: 0x0600062F RID: 1583 RVA: 0x0001E7C4 File Offset: 0x0001C9C4
			public void Reset()
			{
				this.host_enumerator.Reset();
			}

			// Token: 0x040002B1 RID: 689
			private Dictionary<TKey, TValue>.Enumerator host_enumerator;
		}

		// Token: 0x020000B0 RID: 176
		// (Invoke) Token: 0x06000631 RID: 1585
		private delegate TRet Transform<TRet>(TKey key, TValue value);

		// Token: 0x020000B1 RID: 177
		[DebuggerDisplay("Count={Count}")]
		[DebuggerTypeProxy(typeof(CollectionDebuggerView<, >))]
		[Serializable]
		public sealed class ValueCollection : ICollection<TValue>, IEnumerable<TValue>, ICollection, IEnumerable
		{
			// Token: 0x06000634 RID: 1588 RVA: 0x0001E7D4 File Offset: 0x0001C9D4
			public ValueCollection(Dictionary<TKey, TValue> dictionary)
			{
				if (dictionary == null)
				{
					throw new ArgumentNullException("dictionary");
				}
				this.dictionary = dictionary;
			}

			// Token: 0x06000635 RID: 1589 RVA: 0x0001E7F4 File Offset: 0x0001C9F4
			void ICollection<TValue>.Add(TValue item)
			{
				throw new NotSupportedException("this is a read-only collection");
			}

			// Token: 0x06000636 RID: 1590 RVA: 0x0001E800 File Offset: 0x0001CA00
			void ICollection<TValue>.Clear()
			{
				throw new NotSupportedException("this is a read-only collection");
			}

			// Token: 0x06000637 RID: 1591 RVA: 0x0001E80C File Offset: 0x0001CA0C
			bool ICollection<TValue>.Contains(TValue item)
			{
				return this.dictionary.ContainsValue(item);
			}

			// Token: 0x06000638 RID: 1592 RVA: 0x0001E81C File Offset: 0x0001CA1C
			bool ICollection<TValue>.Remove(TValue item)
			{
				throw new NotSupportedException("this is a read-only collection");
			}

			// Token: 0x06000639 RID: 1593 RVA: 0x0001E828 File Offset: 0x0001CA28
			IEnumerator<TValue> IEnumerable<TValue>.GetEnumerator()
			{
				return this.GetEnumerator();
			}

			// Token: 0x0600063A RID: 1594 RVA: 0x0001E838 File Offset: 0x0001CA38
			void ICollection.CopyTo(Array array, int index)
			{
				TValue[] array2 = array as TValue[];
				if (array2 != null)
				{
					this.CopyTo(array2, index);
					return;
				}
				this.dictionary.CopyToCheck(array, index);
				this.dictionary.Do_ICollectionCopyTo<TValue>(array, index, new Dictionary<TKey, TValue>.Transform<TValue>(Dictionary<TKey, TValue>.pick_value));
			}

			// Token: 0x0600063B RID: 1595 RVA: 0x0001E884 File Offset: 0x0001CA84
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this.GetEnumerator();
			}

			// Token: 0x170000E2 RID: 226
			// (get) Token: 0x0600063C RID: 1596 RVA: 0x0001E894 File Offset: 0x0001CA94
			bool ICollection<TValue>.IsReadOnly
			{
				get
				{
					return true;
				}
			}

			// Token: 0x170000E3 RID: 227
			// (get) Token: 0x0600063D RID: 1597 RVA: 0x0001E898 File Offset: 0x0001CA98
			bool ICollection.IsSynchronized
			{
				get
				{
					return false;
				}
			}

			// Token: 0x170000E4 RID: 228
			// (get) Token: 0x0600063E RID: 1598 RVA: 0x0001E89C File Offset: 0x0001CA9C
			object ICollection.SyncRoot
			{
				get
				{
					return ((ICollection)this.dictionary).SyncRoot;
				}
			}

			// Token: 0x0600063F RID: 1599 RVA: 0x0001E8AC File Offset: 0x0001CAAC
			public void CopyTo(TValue[] array, int index)
			{
				this.dictionary.CopyToCheck(array, index);
				this.dictionary.Do_CopyTo<TValue, TValue>(array, index, new Dictionary<TKey, TValue>.Transform<TValue>(Dictionary<TKey, TValue>.pick_value));
			}

			// Token: 0x06000640 RID: 1600 RVA: 0x0001E8D4 File Offset: 0x0001CAD4
			public Dictionary<TKey, TValue>.ValueCollection.Enumerator GetEnumerator()
			{
				return new Dictionary<TKey, TValue>.ValueCollection.Enumerator(this.dictionary);
			}

			// Token: 0x170000E5 RID: 229
			// (get) Token: 0x06000641 RID: 1601 RVA: 0x0001E8E4 File Offset: 0x0001CAE4
			public int Count
			{
				get
				{
					return this.dictionary.Count;
				}
			}

			// Token: 0x040002B2 RID: 690
			private Dictionary<TKey, TValue> dictionary;

			// Token: 0x020000B2 RID: 178
			[Serializable]
			public struct Enumerator : IEnumerator<TValue>, IEnumerator, IDisposable
			{
				// Token: 0x06000642 RID: 1602 RVA: 0x0001E8F4 File Offset: 0x0001CAF4
				internal Enumerator(Dictionary<TKey, TValue> host)
				{
					this.host_enumerator = host.GetEnumerator();
				}

				// Token: 0x170000E6 RID: 230
				// (get) Token: 0x06000643 RID: 1603 RVA: 0x0001E904 File Offset: 0x0001CB04
				object IEnumerator.Current
				{
					get
					{
						return this.host_enumerator.CurrentValue;
					}
				}

				// Token: 0x06000644 RID: 1604 RVA: 0x0001E918 File Offset: 0x0001CB18
				void IEnumerator.Reset()
				{
					this.host_enumerator.Reset();
				}

				// Token: 0x06000645 RID: 1605 RVA: 0x0001E928 File Offset: 0x0001CB28
				public void Dispose()
				{
					this.host_enumerator.Dispose();
				}

				// Token: 0x06000646 RID: 1606 RVA: 0x0001E938 File Offset: 0x0001CB38
				public bool MoveNext()
				{
					return this.host_enumerator.MoveNext();
				}

				// Token: 0x170000E7 RID: 231
				// (get) Token: 0x06000647 RID: 1607 RVA: 0x0001E948 File Offset: 0x0001CB48
				public TValue Current
				{
					get
					{
						return this.host_enumerator.current.Value;
					}
				}

				// Token: 0x040002B3 RID: 691
				private Dictionary<TKey, TValue>.Enumerator host_enumerator;
			}
		}
	}
}
