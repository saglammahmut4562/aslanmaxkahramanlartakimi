﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000B3 RID: 179
	[Serializable]
	public abstract class EqualityComparer<T> : IEqualityComparer<T>, IEqualityComparer
	{
		// Token: 0x06000649 RID: 1609 RVA: 0x0001E964 File Offset: 0x0001CB64
		static EqualityComparer()
		{
			if (typeof(IEquatable<T>).IsAssignableFrom(typeof(T)))
			{
				EqualityComparer<T>._default = (EqualityComparer<T>)Activator.CreateInstance(typeof(GenericEqualityComparer<>).MakeGenericType(new Type[] { typeof(T) }));
			}
			else
			{
				EqualityComparer<T>._default = new EqualityComparer<T>.DefaultComparer();
			}
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x0001E9D0 File Offset: 0x0001CBD0
		int IEqualityComparer.GetHashCode(object obj)
		{
			return this.GetHashCode((T)((object)obj));
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x0001E9E0 File Offset: 0x0001CBE0
		bool IEqualityComparer.Equals(object x, object y)
		{
			return this.Equals((T)((object)x), (T)((object)y));
		}

		// Token: 0x0600064C RID: 1612
		public abstract int GetHashCode(T obj);

		// Token: 0x0600064D RID: 1613
		public abstract bool Equals(T x, T y);

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600064E RID: 1614 RVA: 0x0001E9F4 File Offset: 0x0001CBF4
		public static EqualityComparer<T> Default
		{
			get
			{
				return EqualityComparer<T>._default;
			}
		}

		// Token: 0x040002B4 RID: 692
		private static readonly EqualityComparer<T> _default;

		// Token: 0x020000B4 RID: 180
		[Serializable]
		private sealed class DefaultComparer : EqualityComparer<T>
		{
			// Token: 0x06000650 RID: 1616 RVA: 0x0001EA04 File Offset: 0x0001CC04
			public override int GetHashCode(T obj)
			{
				if (obj == null)
				{
					return 0;
				}
				return obj.GetHashCode();
			}

			// Token: 0x06000651 RID: 1617 RVA: 0x0001EA20 File Offset: 0x0001CC20
			public override bool Equals(T x, T y)
			{
				if (x == null)
				{
					return y == null;
				}
				return x.Equals(y);
			}
		}
	}
}
