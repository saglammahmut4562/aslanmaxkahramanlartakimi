﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000B5 RID: 181
	[Serializable]
	internal sealed class GenericComparer<T> : Comparer<T> where T : IComparable<T>
	{
		// Token: 0x06000653 RID: 1619 RVA: 0x0001EA54 File Offset: 0x0001CC54
		public override int Compare(T x, T y)
		{
			if (x == null)
			{
				return (y != null) ? (-1) : 0;
			}
			if (y == null)
			{
				return 1;
			}
			return x.CompareTo(y);
		}
	}
}
