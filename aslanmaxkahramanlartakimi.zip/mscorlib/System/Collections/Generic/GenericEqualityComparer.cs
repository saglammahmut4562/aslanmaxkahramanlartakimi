﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000B6 RID: 182
	[Serializable]
	internal sealed class GenericEqualityComparer<T> : EqualityComparer<T> where T : IEquatable<T>
	{
		// Token: 0x06000655 RID: 1621 RVA: 0x0001EA98 File Offset: 0x0001CC98
		public override int GetHashCode(T obj)
		{
			if (obj == null)
			{
				return 0;
			}
			return obj.GetHashCode();
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x0001EAB4 File Offset: 0x0001CCB4
		public override bool Equals(T x, T y)
		{
			if (x == null)
			{
				return y == null;
			}
			return x.Equals(y);
		}
	}
}
