﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000B7 RID: 183
	public interface ICollection<T> : IEnumerable<T>, IEnumerable
	{
		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06000657 RID: 1623
		int Count { get; }

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000658 RID: 1624
		bool IsReadOnly { get; }

		// Token: 0x06000659 RID: 1625
		void Add(T item);

		// Token: 0x0600065A RID: 1626
		void Clear();

		// Token: 0x0600065B RID: 1627
		bool Contains(T item);

		// Token: 0x0600065C RID: 1628
		void CopyTo(T[] array, int arrayIndex);

		// Token: 0x0600065D RID: 1629
		bool Remove(T item);
	}
}
