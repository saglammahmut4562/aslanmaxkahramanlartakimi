﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000B8 RID: 184
	public interface IComparer<T>
	{
		// Token: 0x0600065E RID: 1630
		int Compare(T x, T y);
	}
}
