﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000B9 RID: 185
	public interface IDictionary<TKey, TValue> : ICollection<KeyValuePair<TKey, TValue>>, IEnumerable<KeyValuePair<TKey, TValue>>, IEnumerable
	{
		// Token: 0x0600065F RID: 1631
		void Add(TKey key, TValue value);

		// Token: 0x06000660 RID: 1632
		bool ContainsKey(TKey key);

		// Token: 0x06000661 RID: 1633
		bool Remove(TKey key);

		// Token: 0x06000662 RID: 1634
		bool TryGetValue(TKey key, out TValue value);

		// Token: 0x170000EB RID: 235
		TValue this[TKey key] { get; set; }

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000665 RID: 1637
		ICollection<TKey> Keys { get; }

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000666 RID: 1638
		ICollection<TValue> Values { get; }
	}
}
