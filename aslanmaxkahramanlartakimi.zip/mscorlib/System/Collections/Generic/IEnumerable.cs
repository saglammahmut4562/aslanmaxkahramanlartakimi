﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000BA RID: 186
	public interface IEnumerable<T> : IEnumerable
	{
		// Token: 0x06000667 RID: 1639
		IEnumerator<T> GetEnumerator();
	}
}
