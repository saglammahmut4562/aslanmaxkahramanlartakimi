﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000BB RID: 187
	public interface IEnumerator<T> : IEnumerator, IDisposable
	{
		// Token: 0x170000EE RID: 238
		// (get) Token: 0x06000668 RID: 1640
		T Current { get; }
	}
}
