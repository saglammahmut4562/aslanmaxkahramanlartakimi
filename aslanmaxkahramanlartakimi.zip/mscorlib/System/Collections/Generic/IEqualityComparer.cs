﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000BC RID: 188
	public interface IEqualityComparer<T>
	{
		// Token: 0x06000669 RID: 1641
		bool Equals(T x, T y);

		// Token: 0x0600066A RID: 1642
		int GetHashCode(T obj);
	}
}
