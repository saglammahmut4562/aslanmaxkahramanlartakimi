﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000BD RID: 189
	public interface IList<T> : ICollection<T>, IEnumerable<T>, IEnumerable
	{
		// Token: 0x0600066B RID: 1643
		int IndexOf(T item);

		// Token: 0x0600066C RID: 1644
		void Insert(int index, T item);

		// Token: 0x0600066D RID: 1645
		void RemoveAt(int index);

		// Token: 0x170000EF RID: 239
		T this[int index] { get; set; }
	}
}
