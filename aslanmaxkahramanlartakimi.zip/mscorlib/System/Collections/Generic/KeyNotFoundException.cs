﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Collections.Generic
{
	// Token: 0x020000BE RID: 190
	[ComVisible(true)]
	[Serializable]
	public class KeyNotFoundException : SystemException, ISerializable
	{
		// Token: 0x06000670 RID: 1648 RVA: 0x0001EADC File Offset: 0x0001CCDC
		public KeyNotFoundException()
			: base("The given key was not present in the dictionary.")
		{
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x0001EAEC File Offset: 0x0001CCEC
		protected KeyNotFoundException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
