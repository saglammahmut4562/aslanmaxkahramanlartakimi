﻿using System;
using System.Diagnostics;

namespace System.Collections.Generic
{
	// Token: 0x020000BF RID: 191
	[DebuggerDisplay("{value}", Name = "[{key}]")]
	[Serializable]
	public struct KeyValuePair<TKey, TValue>
	{
		// Token: 0x06000672 RID: 1650 RVA: 0x0001EAF8 File Offset: 0x0001CCF8
		public KeyValuePair(TKey key, TValue value)
		{
			this.Key = key;
			this.Value = value;
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x06000673 RID: 1651 RVA: 0x0001EB08 File Offset: 0x0001CD08
		// (set) Token: 0x06000674 RID: 1652 RVA: 0x0001EB10 File Offset: 0x0001CD10
		public TKey Key
		{
			get
			{
				return this.key;
			}
			private set
			{
				this.key = value;
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000675 RID: 1653 RVA: 0x0001EB1C File Offset: 0x0001CD1C
		// (set) Token: 0x06000676 RID: 1654 RVA: 0x0001EB24 File Offset: 0x0001CD24
		public TValue Value
		{
			get
			{
				return this.value;
			}
			private set
			{
				this.value = value;
			}
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x0001EB30 File Offset: 0x0001CD30
		public override string ToString()
		{
			string[] array = new string[5];
			array[0] = "[";
			int num = 1;
			string text;
			if (this.Key != null)
			{
				TKey tkey = this.Key;
				text = tkey.ToString();
			}
			else
			{
				text = string.Empty;
			}
			array[num] = text;
			array[2] = ", ";
			int num2 = 3;
			string text2;
			if (this.Value != null)
			{
				TValue tvalue = this.Value;
				text2 = tvalue.ToString();
			}
			else
			{
				text2 = string.Empty;
			}
			array[num2] = text2;
			array[4] = "]";
			return string.Concat(array);
		}

		// Token: 0x040002B5 RID: 693
		private TKey key;

		// Token: 0x040002B6 RID: 694
		private TValue value;
	}
}
