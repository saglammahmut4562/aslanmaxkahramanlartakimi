﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020000C0 RID: 192
	internal struct Link
	{
		// Token: 0x040002B7 RID: 695
		public int HashCode;

		// Token: 0x040002B8 RID: 696
		public int Next;
	}
}
