﻿using System;
using System.Diagnostics;

namespace System.Collections.Generic
{
	// Token: 0x020000C1 RID: 193
	[DebuggerTypeProxy(typeof(CollectionDebuggerView<>))]
	[DebuggerDisplay("Count={Count}")]
	[Serializable]
	public class List<T> : ICollection<T>, IEnumerable<T>, IList<T>, ICollection, IEnumerable, IList
	{
		// Token: 0x06000678 RID: 1656 RVA: 0x0001EBC4 File Offset: 0x0001CDC4
		public List()
		{
			this._items = List<T>.EmptyArray;
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x0001EBD8 File Offset: 0x0001CDD8
		public List(IEnumerable<T> collection)
		{
			this.CheckCollection(collection);
			ICollection<T> collection2 = collection as ICollection<T>;
			if (collection2 == null)
			{
				this._items = List<T>.EmptyArray;
				this.AddEnumerable(collection);
			}
			else
			{
				this._items = new T[collection2.Count];
				this.AddCollection(collection2);
			}
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x0001EC30 File Offset: 0x0001CE30
		public List(int capacity)
		{
			if (capacity < 0)
			{
				throw new ArgumentOutOfRangeException("capacity");
			}
			this._items = new T[capacity];
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x0001EC58 File Offset: 0x0001CE58
		internal List(T[] data, int size)
		{
			this._items = data;
			this._size = size;
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x0001EC80 File Offset: 0x0001CE80
		IEnumerator<T> IEnumerable<T>.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x0001EC90 File Offset: 0x0001CE90
		void ICollection.CopyTo(Array array, int arrayIndex)
		{
			Array.Copy(this._items, 0, array, arrayIndex, this._size);
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x0001ECA8 File Offset: 0x0001CEA8
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x0001ECB8 File Offset: 0x0001CEB8
		int IList.Add(object item)
		{
			try
			{
				this.Add((T)((object)item));
				return this._size - 1;
			}
			catch (NullReferenceException)
			{
			}
			catch (InvalidCastException)
			{
			}
			throw new ArgumentException("item");
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x0001ED18 File Offset: 0x0001CF18
		bool IList.Contains(object item)
		{
			try
			{
				return this.Contains((T)((object)item));
			}
			catch (NullReferenceException)
			{
			}
			catch (InvalidCastException)
			{
			}
			return false;
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x0001ED68 File Offset: 0x0001CF68
		int IList.IndexOf(object item)
		{
			try
			{
				return this.IndexOf((T)((object)item));
			}
			catch (NullReferenceException)
			{
			}
			catch (InvalidCastException)
			{
			}
			return -1;
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x0001EDB8 File Offset: 0x0001CFB8
		void IList.Insert(int index, object item)
		{
			this.CheckIndex(index);
			try
			{
				this.Insert(index, (T)((object)item));
				return;
			}
			catch (NullReferenceException)
			{
			}
			catch (InvalidCastException)
			{
			}
			throw new ArgumentException("item");
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x0001EE18 File Offset: 0x0001D018
		void IList.Remove(object item)
		{
			try
			{
				this.Remove((T)((object)item));
			}
			catch (NullReferenceException)
			{
			}
			catch (InvalidCastException)
			{
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000685 RID: 1669 RVA: 0x0001EE64 File Offset: 0x0001D064
		bool ICollection<T>.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000686 RID: 1670 RVA: 0x0001EE68 File Offset: 0x0001D068
		bool ICollection.IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000687 RID: 1671 RVA: 0x0001EE6C File Offset: 0x0001D06C
		object ICollection.SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000688 RID: 1672 RVA: 0x0001EE70 File Offset: 0x0001D070
		bool IList.IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000689 RID: 1673 RVA: 0x0001EE74 File Offset: 0x0001D074
		bool IList.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170000F7 RID: 247
		object IList.this[int index]
		{
			get
			{
				return this[index];
			}
			set
			{
				try
				{
					this[index] = (T)((object)value);
					return;
				}
				catch (NullReferenceException)
				{
				}
				catch (InvalidCastException)
				{
				}
				throw new ArgumentException("value");
			}
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x0001EEE0 File Offset: 0x0001D0E0
		public void Add(T item)
		{
			if (this._size == this._items.Length)
			{
				this.GrowIfNeeded(1);
			}
			this._items[this._size++] = item;
			this._version++;
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x0001EF34 File Offset: 0x0001D134
		private void GrowIfNeeded(int newCount)
		{
			int num = this._size + newCount;
			if (num > this._items.Length)
			{
				this.Capacity = Math.Max(Math.Max(this.Capacity * 2, 4), num);
			}
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x0001EF74 File Offset: 0x0001D174
		private void CheckRange(int idx, int count)
		{
			if (idx < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if (idx + count > this._size)
			{
				throw new ArgumentException("index and count exceed length of list");
			}
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x0001EFB4 File Offset: 0x0001D1B4
		private void AddCollection(ICollection<T> collection)
		{
			int count = collection.Count;
			if (count == 0)
			{
				return;
			}
			this.GrowIfNeeded(count);
			collection.CopyTo(this._items, this._size);
			this._size += count;
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x0001EFF8 File Offset: 0x0001D1F8
		private void AddEnumerable(IEnumerable<T> enumerable)
		{
			foreach (T t in enumerable)
			{
				this.Add(t);
			}
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x0001F04C File Offset: 0x0001D24C
		public void AddRange(IEnumerable<T> collection)
		{
			this.CheckCollection(collection);
			ICollection<T> collection2 = collection as ICollection<T>;
			if (collection2 != null)
			{
				this.AddCollection(collection2);
			}
			else
			{
				this.AddEnumerable(collection);
			}
			this._version++;
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x0001F090 File Offset: 0x0001D290
		public void Clear()
		{
			Array.Clear(this._items, 0, this._items.Length);
			this._size = 0;
			this._version++;
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x0001F0BC File Offset: 0x0001D2BC
		public bool Contains(T item)
		{
			return Array.IndexOf<T>(this._items, item, 0, this._size) != -1;
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x0001F0D8 File Offset: 0x0001D2D8
		public void CopyTo(T[] array, int arrayIndex)
		{
			Array.Copy(this._items, 0, array, arrayIndex, this._size);
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x0001F0F0 File Offset: 0x0001D2F0
		public List<T>.Enumerator GetEnumerator()
		{
			return new List<T>.Enumerator(this);
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x0001F0F8 File Offset: 0x0001D2F8
		public List<T> GetRange(int index, int count)
		{
			this.CheckRange(index, count);
			T[] array = new T[count];
			Array.Copy(this._items, index, array, 0, count);
			return new List<T>(array, count);
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x0001F12C File Offset: 0x0001D32C
		public int IndexOf(T item)
		{
			return Array.IndexOf<T>(this._items, item, 0, this._size);
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x0001F144 File Offset: 0x0001D344
		private void Shift(int start, int delta)
		{
			if (delta < 0)
			{
				start -= delta;
			}
			if (start < this._size)
			{
				Array.Copy(this._items, start, this._items, start + delta, this._size - start);
			}
			this._size += delta;
			if (delta < 0)
			{
				Array.Clear(this._items, this._size, -delta);
			}
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x0001F1B0 File Offset: 0x0001D3B0
		private void CheckIndex(int index)
		{
			if (index < 0 || index > this._size)
			{
				throw new ArgumentOutOfRangeException("index");
			}
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x0001F1D0 File Offset: 0x0001D3D0
		public void Insert(int index, T item)
		{
			this.CheckIndex(index);
			if (this._size == this._items.Length)
			{
				this.GrowIfNeeded(1);
			}
			this.Shift(index, 1);
			this._items[index] = item;
			this._version++;
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x0001F224 File Offset: 0x0001D424
		private void CheckCollection(IEnumerable<T> collection)
		{
			if (collection == null)
			{
				throw new ArgumentNullException("collection");
			}
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x0001F238 File Offset: 0x0001D438
		public void InsertRange(int index, IEnumerable<T> collection)
		{
			this.CheckCollection(collection);
			this.CheckIndex(index);
			if (collection == this)
			{
				T[] array = new T[this._size];
				this.CopyTo(array, 0);
				this.GrowIfNeeded(this._size);
				this.Shift(index, array.Length);
				Array.Copy(array, 0, this._items, index, array.Length);
			}
			else
			{
				ICollection<T> collection2 = collection as ICollection<T>;
				if (collection2 != null)
				{
					this.InsertCollection(index, collection2);
				}
				else
				{
					this.InsertEnumeration(index, collection);
				}
			}
			this._version++;
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x0001F2CC File Offset: 0x0001D4CC
		private void InsertCollection(int index, ICollection<T> collection)
		{
			int count = collection.Count;
			this.GrowIfNeeded(count);
			this.Shift(index, count);
			collection.CopyTo(this._items, index);
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x0001F2FC File Offset: 0x0001D4FC
		private void InsertEnumeration(int index, IEnumerable<T> enumerable)
		{
			foreach (T t in enumerable)
			{
				this.Insert(index++, t);
			}
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x0001F354 File Offset: 0x0001D554
		public bool Remove(T item)
		{
			int num = this.IndexOf(item);
			if (num != -1)
			{
				this.RemoveAt(num);
			}
			return num != -1;
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x0001F380 File Offset: 0x0001D580
		public void RemoveAt(int index)
		{
			if (index < 0 || index >= this._size)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			this.Shift(index, -1);
			Array.Clear(this._items, this._size, 1);
			this._version++;
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0001F3D4 File Offset: 0x0001D5D4
		public void RemoveRange(int index, int count)
		{
			this.CheckRange(index, count);
			if (count > 0)
			{
				this.Shift(index, -count);
				Array.Clear(this._items, this._size, count);
				this._version++;
			}
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0001F410 File Offset: 0x0001D610
		public void Reverse()
		{
			Array.Reverse(this._items, 0, this._size);
			this._version++;
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x0001F434 File Offset: 0x0001D634
		public void Sort(IComparer<T> comparer)
		{
			Array.Sort<T>(this._items, 0, this._size, comparer);
			this._version++;
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x0001F458 File Offset: 0x0001D658
		public void Sort(Comparison<T> comparison)
		{
			Array.Sort<T>(this._items, this._size, comparison);
			this._version++;
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x0001F47C File Offset: 0x0001D67C
		public T[] ToArray()
		{
			T[] array = new T[this._size];
			Array.Copy(this._items, array, this._size);
			return array;
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x060006A6 RID: 1702 RVA: 0x0001F4A8 File Offset: 0x0001D6A8
		// (set) Token: 0x060006A7 RID: 1703 RVA: 0x0001F4B4 File Offset: 0x0001D6B4
		public int Capacity
		{
			get
			{
				return this._items.Length;
			}
			set
			{
				if (value < this._size)
				{
					throw new ArgumentOutOfRangeException();
				}
				Array.Resize<T>(ref this._items, value);
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x060006A8 RID: 1704 RVA: 0x0001F4D4 File Offset: 0x0001D6D4
		public int Count
		{
			get
			{
				return this._size;
			}
		}

		// Token: 0x170000FA RID: 250
		public T this[int index]
		{
			get
			{
				if (index >= this._size)
				{
					throw new ArgumentOutOfRangeException("index");
				}
				return this._items[index];
			}
			set
			{
				this.CheckIndex(index);
				if (index == this._size)
				{
					throw new ArgumentOutOfRangeException("index");
				}
				this._items[index] = value;
			}
		}

		// Token: 0x040002B9 RID: 697
		private const int DefaultCapacity = 4;

		// Token: 0x040002BA RID: 698
		private T[] _items;

		// Token: 0x040002BB RID: 699
		private int _size;

		// Token: 0x040002BC RID: 700
		private int _version;

		// Token: 0x040002BD RID: 701
		private static readonly T[] EmptyArray = new T[0];

		// Token: 0x020000C2 RID: 194
		[Serializable]
		public struct Enumerator : IEnumerator<T>, IEnumerator, IDisposable
		{
			// Token: 0x060006AB RID: 1707 RVA: 0x0001F534 File Offset: 0x0001D734
			internal Enumerator(List<T> l)
			{
				this.l = l;
				this.ver = l._version;
			}

			// Token: 0x060006AC RID: 1708 RVA: 0x0001F54C File Offset: 0x0001D74C
			void IEnumerator.Reset()
			{
				this.VerifyState();
				this.next = 0;
			}

			// Token: 0x170000FB RID: 251
			// (get) Token: 0x060006AD RID: 1709 RVA: 0x0001F55C File Offset: 0x0001D75C
			object IEnumerator.Current
			{
				get
				{
					this.VerifyState();
					if (this.next <= 0)
					{
						throw new InvalidOperationException();
					}
					return this.current;
				}
			}

			// Token: 0x060006AE RID: 1710 RVA: 0x0001F584 File Offset: 0x0001D784
			public void Dispose()
			{
				this.l = null;
			}

			// Token: 0x060006AF RID: 1711 RVA: 0x0001F590 File Offset: 0x0001D790
			private void VerifyState()
			{
				if (this.l == null)
				{
					throw new ObjectDisposedException(base.GetType().FullName);
				}
				if (this.ver != this.l._version)
				{
					throw new InvalidOperationException("Collection was modified; enumeration operation may not execute.");
				}
			}

			// Token: 0x060006B0 RID: 1712 RVA: 0x0001F5E4 File Offset: 0x0001D7E4
			public bool MoveNext()
			{
				this.VerifyState();
				if (this.next < 0)
				{
					return false;
				}
				if (this.next < this.l._size)
				{
					this.current = this.l._items[this.next++];
					return true;
				}
				this.next = -1;
				return false;
			}

			// Token: 0x170000FC RID: 252
			// (get) Token: 0x060006B1 RID: 1713 RVA: 0x0001F64C File Offset: 0x0001D84C
			public T Current
			{
				get
				{
					return this.current;
				}
			}

			// Token: 0x040002BE RID: 702
			private List<T> l;

			// Token: 0x040002BF RID: 703
			private int next;

			// Token: 0x040002C0 RID: 704
			private int ver;

			// Token: 0x040002C1 RID: 705
			private T current;
		}
	}
}
