﻿using System;
using System.Diagnostics;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Collections
{
	// Token: 0x020000C3 RID: 195
	[DebuggerTypeProxy(typeof(CollectionDebuggerView))]
	[DebuggerDisplay("Count={Count}")]
	[ComVisible(true)]
	[Serializable]
	public class Hashtable : ICollection, IDictionary, IEnumerable, ICloneable, IDeserializationCallback, ISerializable
	{
		// Token: 0x060006B2 RID: 1714 RVA: 0x0001F654 File Offset: 0x0001D854
		public Hashtable()
			: this(0, 1f)
		{
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x0001F664 File Offset: 0x0001D864
		[Obsolete("Please use Hashtable(int, float, IEqualityComparer) instead")]
		public Hashtable(int capacity, float loadFactor, IHashCodeProvider hcp, IComparer comparer)
		{
			if (capacity < 0)
			{
				throw new ArgumentOutOfRangeException("capacity", "negative capacity");
			}
			if (loadFactor < 0.1f || loadFactor > 1f || float.IsNaN(loadFactor))
			{
				throw new ArgumentOutOfRangeException("loadFactor", "load factor");
			}
			if (capacity == 0)
			{
				capacity++;
			}
			this.loadFactor = 0.75f * loadFactor;
			double num = (double)((float)capacity / this.loadFactor);
			if (num > 2147483647.0)
			{
				throw new ArgumentException("Size is too big");
			}
			int num2 = (int)num;
			num2 = Hashtable.ToPrime(num2);
			this.SetTable(new Hashtable.Slot[num2], new int[num2]);
			this.hcp = hcp;
			this.comparer = comparer;
			this.inUse = 0;
			this.modificationCount = 0;
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x0001F738 File Offset: 0x0001D938
		public Hashtable(int capacity, float loadFactor)
			: this(capacity, loadFactor, null, null)
		{
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x0001F744 File Offset: 0x0001D944
		public Hashtable(int capacity)
			: this(capacity, 1f)
		{
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x0001F754 File Offset: 0x0001D954
		internal Hashtable(Hashtable source)
		{
			this.inUse = source.inUse;
			this.loadFactor = source.loadFactor;
			this.table = (Hashtable.Slot[])source.table.Clone();
			this.hashes = (int[])source.hashes.Clone();
			this.threshold = source.threshold;
			this.hcpRef = source.hcpRef;
			this.comparerRef = source.comparerRef;
			this.equalityComparer = source.equalityComparer;
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x0001F7DC File Offset: 0x0001D9DC
		[Obsolete("Please use Hashtable(int, IEqualityComparer) instead")]
		public Hashtable(int capacity, IHashCodeProvider hcp, IComparer comparer)
			: this(capacity, 1f, hcp, comparer)
		{
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x0001F7EC File Offset: 0x0001D9EC
		[Obsolete("Please use Hashtable(IDictionary, float, IEqualityComparer) instead")]
		public Hashtable(IDictionary d, float loadFactor, IHashCodeProvider hcp, IComparer comparer)
			: this((d == null) ? 0 : d.Count, loadFactor, hcp, comparer)
		{
			if (d == null)
			{
				throw new ArgumentNullException("dictionary");
			}
			IDictionaryEnumerator enumerator = d.GetEnumerator();
			while (enumerator.MoveNext())
			{
				this.Add(enumerator.Key, enumerator.Value);
			}
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x0001F850 File Offset: 0x0001DA50
		[Obsolete("Please use Hashtable(IDictionary, IEqualityComparer) instead")]
		public Hashtable(IDictionary d, IHashCodeProvider hcp, IComparer comparer)
			: this(d, 1f, hcp, comparer)
		{
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x0001F860 File Offset: 0x0001DA60
		[Obsolete("Please use Hashtable(IEqualityComparer) instead")]
		public Hashtable(IHashCodeProvider hcp, IComparer comparer)
			: this(1, 1f, hcp, comparer)
		{
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x0001F870 File Offset: 0x0001DA70
		public Hashtable(SerializationInfo info, StreamingContext context)
		{
			this.serializationInfo = info;
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x0001F880 File Offset: 0x0001DA80
		public Hashtable(int capacity, IEqualityComparer equalityComparer)
			: this(capacity, 1f, equalityComparer)
		{
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x0001F890 File Offset: 0x0001DA90
		public Hashtable(int capacity, float loadFactor, IEqualityComparer equalityComparer)
			: this(capacity, loadFactor)
		{
			this.equalityComparer = equalityComparer;
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x0001F8C0 File Offset: 0x0001DAC0
		IEnumerator IEnumerable.GetEnumerator()
		{
			return new Hashtable.Enumerator(this, Hashtable.EnumeratorMode.ENTRY_MODE);
		}

		// Token: 0x170000FD RID: 253
		// (set) Token: 0x060006C0 RID: 1728 RVA: 0x0001F8CC File Offset: 0x0001DACC
		[Obsolete("Please use EqualityComparer property.")]
		protected IComparer comparer
		{
			set
			{
				this.comparerRef = value;
			}
		}

		// Token: 0x170000FE RID: 254
		// (set) Token: 0x060006C1 RID: 1729 RVA: 0x0001F8D8 File Offset: 0x0001DAD8
		[Obsolete("Please use EqualityComparer property.")]
		protected IHashCodeProvider hcp
		{
			set
			{
				this.hcpRef = value;
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x060006C2 RID: 1730 RVA: 0x0001F8E4 File Offset: 0x0001DAE4
		public virtual int Count
		{
			get
			{
				return this.inUse;
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x060006C3 RID: 1731 RVA: 0x0001F8EC File Offset: 0x0001DAEC
		public virtual bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x060006C4 RID: 1732 RVA: 0x0001F8F0 File Offset: 0x0001DAF0
		public virtual object SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x060006C5 RID: 1733 RVA: 0x0001F8F4 File Offset: 0x0001DAF4
		public virtual bool IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x060006C6 RID: 1734 RVA: 0x0001F8F8 File Offset: 0x0001DAF8
		public virtual bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x060006C7 RID: 1735 RVA: 0x0001F8FC File Offset: 0x0001DAFC
		public virtual ICollection Keys
		{
			get
			{
				if (this.hashKeys == null)
				{
					this.hashKeys = new Hashtable.HashKeys(this);
				}
				return this.hashKeys;
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x060006C8 RID: 1736 RVA: 0x0001F91C File Offset: 0x0001DB1C
		public virtual ICollection Values
		{
			get
			{
				if (this.hashValues == null)
				{
					this.hashValues = new Hashtable.HashValues(this);
				}
				return this.hashValues;
			}
		}

		// Token: 0x17000106 RID: 262
		public virtual object this[object key]
		{
			get
			{
				if (key == null)
				{
					throw new ArgumentNullException("key", "null key");
				}
				Hashtable.Slot[] array = this.table;
				int[] array2 = this.hashes;
				uint num = (uint)array.Length;
				int num2 = this.GetHash(key) & int.MaxValue;
				uint num3 = (uint)num2;
				uint num4 = (uint)(((num2 >> 5) + 1) % (int)(num - 1U) + 1);
				for (uint num5 = num; num5 > 0U; num5 -= 1U)
				{
					num3 %= num;
					Hashtable.Slot slot = array[(int)((UIntPtr)num3)];
					int num6 = array2[(int)((UIntPtr)num3)];
					object key2 = slot.key;
					if (key2 == null)
					{
						break;
					}
					if (key2 == key || ((num6 & 2147483647) == num2 && this.KeyEquals(key, key2)))
					{
						return slot.value;
					}
					if ((num6 & -2147483648) == 0)
					{
						break;
					}
					num3 += num4;
				}
				return null;
			}
			set
			{
				this.PutImpl(key, value, true);
			}
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x0001FA2C File Offset: 0x0001DC2C
		public virtual void CopyTo(Array array, int arrayIndex)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (arrayIndex < 0)
			{
				throw new ArgumentOutOfRangeException("arrayIndex");
			}
			if (array.Rank > 1)
			{
				throw new ArgumentException("array is multidimensional");
			}
			if (array.Length > 0 && arrayIndex >= array.Length)
			{
				throw new ArgumentException("arrayIndex is equal to or greater than array.Length");
			}
			if (arrayIndex + this.inUse > array.Length)
			{
				throw new ArgumentException("Not enough room from arrayIndex to end of array for this Hashtable");
			}
			IDictionaryEnumerator enumerator = this.GetEnumerator();
			int num = arrayIndex;
			while (enumerator.MoveNext())
			{
				array.SetValue(enumerator.Entry, num++);
			}
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x0001FAE4 File Offset: 0x0001DCE4
		public virtual void Add(object key, object value)
		{
			this.PutImpl(key, value, false);
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x0001FAF0 File Offset: 0x0001DCF0
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public virtual void Clear()
		{
			for (int i = 0; i < this.table.Length; i++)
			{
				this.table[i].key = null;
				this.table[i].value = null;
				this.hashes[i] = 0;
			}
			this.inUse = 0;
			this.modificationCount++;
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x0001FB58 File Offset: 0x0001DD58
		public virtual bool Contains(object key)
		{
			return this.Find(key) >= 0;
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x0001FB68 File Offset: 0x0001DD68
		public virtual IDictionaryEnumerator GetEnumerator()
		{
			return new Hashtable.Enumerator(this, Hashtable.EnumeratorMode.ENTRY_MODE);
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x0001FB74 File Offset: 0x0001DD74
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]
		public virtual void Remove(object key)
		{
			int num = this.Find(key);
			if (num >= 0)
			{
				Hashtable.Slot[] array = this.table;
				int num2 = this.hashes[num];
				num2 &= int.MinValue;
				this.hashes[num] = num2;
				array[num].key = ((num2 == 0) ? null : Hashtable.KeyMarker.Removed);
				array[num].value = null;
				this.inUse--;
				this.modificationCount++;
			}
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x0001FBF8 File Offset: 0x0001DDF8
		public virtual bool ContainsKey(object key)
		{
			return this.Contains(key);
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x0001FC04 File Offset: 0x0001DE04
		public virtual object Clone()
		{
			return new Hashtable(this);
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x0001FC0C File Offset: 0x0001DE0C
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			info.AddValue("LoadFactor", this.loadFactor);
			info.AddValue("Version", this.modificationCount);
			if (this.equalityComparer != null)
			{
				info.AddValue("KeyComparer", this.equalityComparer);
			}
			else
			{
				info.AddValue("Comparer", this.comparerRef);
			}
			if (this.hcpRef != null)
			{
				info.AddValue("HashCodeProvider", this.hcpRef);
			}
			info.AddValue("HashSize", this.table.Length);
			object[] array = new object[this.inUse];
			this.CopyToArray(array, 0, Hashtable.EnumeratorMode.KEY_MODE);
			object[] array2 = new object[this.inUse];
			this.CopyToArray(array2, 0, Hashtable.EnumeratorMode.VALUE_MODE);
			info.AddValue("Keys", array);
			info.AddValue("Values", array2);
			info.AddValue("equalityComparer", this.equalityComparer);
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x0001FD00 File Offset: 0x0001DF00
		[MonoTODO("Serialize equalityComparer")]
		public virtual void OnDeserialization(object sender)
		{
			if (this.serializationInfo == null)
			{
				return;
			}
			this.loadFactor = (float)this.serializationInfo.GetValue("LoadFactor", typeof(float));
			this.modificationCount = (int)this.serializationInfo.GetValue("Version", typeof(int));
			try
			{
				this.equalityComparer = (IEqualityComparer)this.serializationInfo.GetValue("KeyComparer", typeof(object));
			}
			catch
			{
			}
			if (this.equalityComparer == null)
			{
				this.comparerRef = (IComparer)this.serializationInfo.GetValue("Comparer", typeof(object));
			}
			try
			{
				this.hcpRef = (IHashCodeProvider)this.serializationInfo.GetValue("HashCodeProvider", typeof(object));
			}
			catch
			{
			}
			int num = (int)this.serializationInfo.GetValue("HashSize", typeof(int));
			object[] array = (object[])this.serializationInfo.GetValue("Keys", typeof(object[]));
			object[] array2 = (object[])this.serializationInfo.GetValue("Values", typeof(object[]));
			if (array.Length != array2.Length)
			{
				throw new SerializationException("Keys and values of uneven size");
			}
			num = Hashtable.ToPrime(num);
			this.SetTable(new Hashtable.Slot[num], new int[num]);
			for (int i = 0; i < array.Length; i++)
			{
				this.Add(array[i], array2[i]);
			}
			this.AdjustThreshold();
			this.serializationInfo = null;
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x0001FECC File Offset: 0x0001E0CC
		public static Hashtable Synchronized(Hashtable table)
		{
			if (table == null)
			{
				throw new ArgumentNullException("table");
			}
			return new Hashtable.SyncHashtable(table);
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x0001FEE8 File Offset: 0x0001E0E8
		protected virtual int GetHash(object key)
		{
			if (this.equalityComparer != null)
			{
				return this.equalityComparer.GetHashCode(key);
			}
			if (this.hcpRef == null)
			{
				return key.GetHashCode();
			}
			return this.hcpRef.GetHashCode(key);
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x0001FF20 File Offset: 0x0001E120
		protected virtual bool KeyEquals(object item, object key)
		{
			if (key == Hashtable.KeyMarker.Removed)
			{
				return false;
			}
			if (this.equalityComparer != null)
			{
				return this.equalityComparer.Equals(item, key);
			}
			if (this.comparerRef == null)
			{
				return item.Equals(key);
			}
			return this.comparerRef.Compare(item, key) == 0;
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x0001FF78 File Offset: 0x0001E178
		private void AdjustThreshold()
		{
			int num = this.table.Length;
			this.threshold = (int)((float)num * this.loadFactor);
			if (this.threshold >= num)
			{
				this.threshold = num - 1;
			}
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x0001FFB4 File Offset: 0x0001E1B4
		private void SetTable(Hashtable.Slot[] table, int[] hashes)
		{
			if (table == null)
			{
				throw new ArgumentNullException("table");
			}
			this.table = table;
			this.hashes = hashes;
			this.AdjustThreshold();
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x0001FFDC File Offset: 0x0001E1DC
		private int Find(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key", "null key");
			}
			Hashtable.Slot[] array = this.table;
			int[] array2 = this.hashes;
			uint num = (uint)array.Length;
			int num2 = this.GetHash(key) & int.MaxValue;
			uint num3 = (uint)num2;
			uint num4 = (uint)(((num2 >> 5) + 1) % (int)(num - 1U) + 1);
			for (uint num5 = num; num5 > 0U; num5 -= 1U)
			{
				num3 %= num;
				Hashtable.Slot slot = array[(int)((UIntPtr)num3)];
				int num6 = array2[(int)((UIntPtr)num3)];
				object key2 = slot.key;
				if (key2 == null)
				{
					break;
				}
				if (key2 == key || ((num6 & 2147483647) == num2 && this.KeyEquals(key, key2)))
				{
					return (int)num3;
				}
				if ((num6 & -2147483648) == 0)
				{
					break;
				}
				num3 += num4;
			}
			return -1;
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x000200B8 File Offset: 0x0001E2B8
		private void Rehash()
		{
			int num = this.table.Length;
			uint num2 = (uint)Hashtable.ToPrime((num << 1) | 1);
			Hashtable.Slot[] array = new Hashtable.Slot[num2];
			Hashtable.Slot[] array2 = this.table;
			int[] array3 = new int[num2];
			int[] array4 = this.hashes;
			for (int i = 0; i < num; i++)
			{
				Hashtable.Slot slot = array2[i];
				if (slot.key != null)
				{
					int num3 = array4[i] & int.MaxValue;
					uint num4 = (uint)num3;
					uint num5 = (uint)(((num3 >> 5) + 1) % (int)(num2 - 1U) + 1);
					uint num6 = num4 % num2;
					while (array[(int)((UIntPtr)num6)].key != null)
					{
						array3[(int)((UIntPtr)num6)] |= int.MinValue;
						num4 += num5;
						num6 = num4 % num2;
					}
					array[(int)((UIntPtr)num6)].key = slot.key;
					array[(int)((UIntPtr)num6)].value = slot.value;
					array3[(int)((UIntPtr)num6)] |= num3;
				}
			}
			this.modificationCount++;
			this.SetTable(array, array3);
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x000201E4 File Offset: 0x0001E3E4
		private void PutImpl(object key, object value, bool overwrite)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key", "null key");
			}
			if (this.inUse >= this.threshold)
			{
				this.Rehash();
			}
			uint num = (uint)this.table.Length;
			int num2 = this.GetHash(key) & int.MaxValue;
			uint num3 = (uint)num2;
			uint num4 = ((num3 >> 5) + 1U) % (num - 1U) + 1U;
			Hashtable.Slot[] array = this.table;
			int[] array2 = this.hashes;
			int num5 = -1;
			int num6 = 0;
			while ((long)num6 < (long)((ulong)num))
			{
				int num7 = (int)(num3 % num);
				Hashtable.Slot slot = array[num7];
				int num8 = array2[num7];
				if (num5 == -1 && slot.key == Hashtable.KeyMarker.Removed && (num8 & -2147483648) != 0)
				{
					num5 = num7;
				}
				if (slot.key == null || (slot.key == Hashtable.KeyMarker.Removed && (num8 & -2147483648) == 0))
				{
					if (num5 == -1)
					{
						num5 = num7;
					}
					break;
				}
				if ((num8 & 2147483647) == num2 && this.KeyEquals(key, slot.key))
				{
					if (overwrite)
					{
						array[num7].value = value;
						this.modificationCount++;
						return;
					}
					throw new ArgumentException("Key duplication when adding: " + key);
				}
				else
				{
					if (num5 == -1)
					{
						array2[num7] |= int.MinValue;
					}
					num3 += num4;
					num6++;
				}
			}
			if (num5 != -1)
			{
				array[num5].key = key;
				array[num5].value = value;
				array2[num5] |= num2;
				this.inUse++;
				this.modificationCount++;
			}
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x000203B8 File Offset: 0x0001E5B8
		private void CopyToArray(Array arr, int i, Hashtable.EnumeratorMode mode)
		{
			IEnumerator enumerator = new Hashtable.Enumerator(this, mode);
			while (enumerator.MoveNext())
			{
				object obj = enumerator.Current;
				arr.SetValue(obj, i++);
			}
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x000203F0 File Offset: 0x0001E5F0
		internal static bool TestPrime(int x)
		{
			if ((x & 1) != 0)
			{
				int num = (int)Math.Sqrt((double)x);
				for (int i = 3; i < num; i += 2)
				{
					if (x % i == 0)
					{
						return false;
					}
				}
				return true;
			}
			return x == 2;
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x00020430 File Offset: 0x0001E630
		internal static int CalcPrime(int x)
		{
			for (int i = (x & -2) - 1; i < 2147483647; i += 2)
			{
				if (Hashtable.TestPrime(i))
				{
					return i;
				}
			}
			return x;
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x00020468 File Offset: 0x0001E668
		internal static int ToPrime(int x)
		{
			for (int i = 0; i < Hashtable.primeTbl.Length; i++)
			{
				if (x <= Hashtable.primeTbl[i])
				{
					return Hashtable.primeTbl[i];
				}
			}
			return Hashtable.CalcPrime(x);
		}

		// Token: 0x040002C2 RID: 706
		private const int CHAIN_MARKER = -2147483648;

		// Token: 0x040002C3 RID: 707
		private int inUse;

		// Token: 0x040002C4 RID: 708
		private int modificationCount;

		// Token: 0x040002C5 RID: 709
		private float loadFactor;

		// Token: 0x040002C6 RID: 710
		private Hashtable.Slot[] table;

		// Token: 0x040002C7 RID: 711
		private int[] hashes;

		// Token: 0x040002C8 RID: 712
		private int threshold;

		// Token: 0x040002C9 RID: 713
		private Hashtable.HashKeys hashKeys;

		// Token: 0x040002CA RID: 714
		private Hashtable.HashValues hashValues;

		// Token: 0x040002CB RID: 715
		private IHashCodeProvider hcpRef;

		// Token: 0x040002CC RID: 716
		private IComparer comparerRef;

		// Token: 0x040002CD RID: 717
		private SerializationInfo serializationInfo;

		// Token: 0x040002CE RID: 718
		private IEqualityComparer equalityComparer;

		// Token: 0x040002CF RID: 719
		private static readonly int[] primeTbl = new int[]
		{
			11, 19, 37, 73, 109, 163, 251, 367, 557, 823,
			1237, 1861, 2777, 4177, 6247, 9371, 14057, 21089, 31627, 47431,
			71143, 106721, 160073, 240101, 360163, 540217, 810343, 1215497, 1823231, 2734867,
			4102283, 6153409, 9230113, 13845163
		};

		// Token: 0x020000C4 RID: 196
		[Serializable]
		private sealed class Enumerator : IDictionaryEnumerator, IEnumerator
		{
			// Token: 0x060006E1 RID: 1761 RVA: 0x000204A8 File Offset: 0x0001E6A8
			public Enumerator(Hashtable host, Hashtable.EnumeratorMode mode)
			{
				this.host = host;
				this.stamp = host.modificationCount;
				this.size = host.table.Length;
				this.mode = mode;
				this.Reset();
			}

			// Token: 0x060006E3 RID: 1763 RVA: 0x000204EC File Offset: 0x0001E6EC
			private void FailFast()
			{
				if (this.host.modificationCount != this.stamp)
				{
					throw new InvalidOperationException(Hashtable.Enumerator.xstr);
				}
			}

			// Token: 0x060006E4 RID: 1764 RVA: 0x00020510 File Offset: 0x0001E710
			public void Reset()
			{
				this.FailFast();
				this.pos = -1;
				this.currentKey = null;
				this.currentValue = null;
			}

			// Token: 0x060006E5 RID: 1765 RVA: 0x00020530 File Offset: 0x0001E730
			public bool MoveNext()
			{
				this.FailFast();
				if (this.pos < this.size)
				{
					while (++this.pos < this.size)
					{
						Hashtable.Slot slot = this.host.table[this.pos];
						if (slot.key != null && slot.key != Hashtable.KeyMarker.Removed)
						{
							this.currentKey = slot.key;
							this.currentValue = slot.value;
							return true;
						}
					}
				}
				this.currentKey = null;
				this.currentValue = null;
				return false;
			}

			// Token: 0x17000107 RID: 263
			// (get) Token: 0x060006E6 RID: 1766 RVA: 0x000205DC File Offset: 0x0001E7DC
			public DictionaryEntry Entry
			{
				get
				{
					if (this.currentKey == null)
					{
						throw new InvalidOperationException();
					}
					this.FailFast();
					return new DictionaryEntry(this.currentKey, this.currentValue);
				}
			}

			// Token: 0x17000108 RID: 264
			// (get) Token: 0x060006E7 RID: 1767 RVA: 0x00020608 File Offset: 0x0001E808
			public object Key
			{
				get
				{
					if (this.currentKey == null)
					{
						throw new InvalidOperationException();
					}
					this.FailFast();
					return this.currentKey;
				}
			}

			// Token: 0x17000109 RID: 265
			// (get) Token: 0x060006E8 RID: 1768 RVA: 0x00020628 File Offset: 0x0001E828
			public object Value
			{
				get
				{
					if (this.currentKey == null)
					{
						throw new InvalidOperationException();
					}
					this.FailFast();
					return this.currentValue;
				}
			}

			// Token: 0x1700010A RID: 266
			// (get) Token: 0x060006E9 RID: 1769 RVA: 0x00020648 File Offset: 0x0001E848
			public object Current
			{
				get
				{
					if (this.currentKey == null)
					{
						throw new InvalidOperationException();
					}
					switch (this.mode)
					{
					case Hashtable.EnumeratorMode.KEY_MODE:
						return this.currentKey;
					case Hashtable.EnumeratorMode.VALUE_MODE:
						return this.currentValue;
					case Hashtable.EnumeratorMode.ENTRY_MODE:
						return new DictionaryEntry(this.currentKey, this.currentValue);
					default:
						throw new Exception("should never happen");
					}
				}
			}

			// Token: 0x040002D0 RID: 720
			private Hashtable host;

			// Token: 0x040002D1 RID: 721
			private int stamp;

			// Token: 0x040002D2 RID: 722
			private int pos;

			// Token: 0x040002D3 RID: 723
			private int size;

			// Token: 0x040002D4 RID: 724
			private Hashtable.EnumeratorMode mode;

			// Token: 0x040002D5 RID: 725
			private object currentKey;

			// Token: 0x040002D6 RID: 726
			private object currentValue;

			// Token: 0x040002D7 RID: 727
			private static readonly string xstr = "Hashtable.Enumerator: snapshot out of sync.";
		}

		// Token: 0x020000C5 RID: 197
		private enum EnumeratorMode
		{
			// Token: 0x040002D9 RID: 729
			KEY_MODE,
			// Token: 0x040002DA RID: 730
			VALUE_MODE,
			// Token: 0x040002DB RID: 731
			ENTRY_MODE
		}

		// Token: 0x020000C6 RID: 198
		[DebuggerDisplay("Count={Count}")]
		[DebuggerTypeProxy(typeof(CollectionDebuggerView))]
		[Serializable]
		private class HashKeys : ICollection, IEnumerable
		{
			// Token: 0x060006EA RID: 1770 RVA: 0x000206B4 File Offset: 0x0001E8B4
			public HashKeys(Hashtable host)
			{
				if (host == null)
				{
					throw new ArgumentNullException();
				}
				this.host = host;
			}

			// Token: 0x1700010B RID: 267
			// (get) Token: 0x060006EB RID: 1771 RVA: 0x000206D0 File Offset: 0x0001E8D0
			public virtual int Count
			{
				get
				{
					return this.host.Count;
				}
			}

			// Token: 0x1700010C RID: 268
			// (get) Token: 0x060006EC RID: 1772 RVA: 0x000206E0 File Offset: 0x0001E8E0
			public virtual bool IsSynchronized
			{
				get
				{
					return this.host.IsSynchronized;
				}
			}

			// Token: 0x1700010D RID: 269
			// (get) Token: 0x060006ED RID: 1773 RVA: 0x000206F0 File Offset: 0x0001E8F0
			public virtual object SyncRoot
			{
				get
				{
					return this.host.SyncRoot;
				}
			}

			// Token: 0x060006EE RID: 1774 RVA: 0x00020700 File Offset: 0x0001E900
			public virtual void CopyTo(Array array, int arrayIndex)
			{
				if (array == null)
				{
					throw new ArgumentNullException("array");
				}
				if (array.Rank != 1)
				{
					throw new ArgumentException("array");
				}
				if (arrayIndex < 0)
				{
					throw new ArgumentOutOfRangeException("arrayIndex");
				}
				if (array.Length - arrayIndex < this.Count)
				{
					throw new ArgumentException("not enough space");
				}
				this.host.CopyToArray(array, arrayIndex, Hashtable.EnumeratorMode.KEY_MODE);
			}

			// Token: 0x060006EF RID: 1775 RVA: 0x00020774 File Offset: 0x0001E974
			public virtual IEnumerator GetEnumerator()
			{
				return new Hashtable.Enumerator(this.host, Hashtable.EnumeratorMode.KEY_MODE);
			}

			// Token: 0x040002DC RID: 732
			private Hashtable host;
		}

		// Token: 0x020000C7 RID: 199
		[DebuggerDisplay("Count={Count}")]
		[DebuggerTypeProxy(typeof(CollectionDebuggerView))]
		[Serializable]
		private class HashValues : ICollection, IEnumerable
		{
			// Token: 0x060006F0 RID: 1776 RVA: 0x00020784 File Offset: 0x0001E984
			public HashValues(Hashtable host)
			{
				if (host == null)
				{
					throw new ArgumentNullException();
				}
				this.host = host;
			}

			// Token: 0x1700010E RID: 270
			// (get) Token: 0x060006F1 RID: 1777 RVA: 0x000207A0 File Offset: 0x0001E9A0
			public virtual int Count
			{
				get
				{
					return this.host.Count;
				}
			}

			// Token: 0x1700010F RID: 271
			// (get) Token: 0x060006F2 RID: 1778 RVA: 0x000207B0 File Offset: 0x0001E9B0
			public virtual bool IsSynchronized
			{
				get
				{
					return this.host.IsSynchronized;
				}
			}

			// Token: 0x17000110 RID: 272
			// (get) Token: 0x060006F3 RID: 1779 RVA: 0x000207C0 File Offset: 0x0001E9C0
			public virtual object SyncRoot
			{
				get
				{
					return this.host.SyncRoot;
				}
			}

			// Token: 0x060006F4 RID: 1780 RVA: 0x000207D0 File Offset: 0x0001E9D0
			public virtual void CopyTo(Array array, int arrayIndex)
			{
				if (array == null)
				{
					throw new ArgumentNullException("array");
				}
				if (array.Rank != 1)
				{
					throw new ArgumentException("array");
				}
				if (arrayIndex < 0)
				{
					throw new ArgumentOutOfRangeException("arrayIndex");
				}
				if (array.Length - arrayIndex < this.Count)
				{
					throw new ArgumentException("not enough space");
				}
				this.host.CopyToArray(array, arrayIndex, Hashtable.EnumeratorMode.VALUE_MODE);
			}

			// Token: 0x060006F5 RID: 1781 RVA: 0x00020844 File Offset: 0x0001EA44
			public virtual IEnumerator GetEnumerator()
			{
				return new Hashtable.Enumerator(this.host, Hashtable.EnumeratorMode.VALUE_MODE);
			}

			// Token: 0x040002DD RID: 733
			private Hashtable host;
		}

		// Token: 0x020000C8 RID: 200
		[Serializable]
		internal class KeyMarker
		{
			// Token: 0x040002DE RID: 734
			public static readonly Hashtable.KeyMarker Removed = new Hashtable.KeyMarker();
		}

		// Token: 0x020000C9 RID: 201
		[Serializable]
		internal struct Slot
		{
			// Token: 0x040002DF RID: 735
			internal object key;

			// Token: 0x040002E0 RID: 736
			internal object value;
		}

		// Token: 0x020000CA RID: 202
		[Serializable]
		private class SyncHashtable : Hashtable, IEnumerable
		{
			// Token: 0x060006F8 RID: 1784 RVA: 0x00020868 File Offset: 0x0001EA68
			public SyncHashtable(Hashtable host)
			{
				if (host == null)
				{
					throw new ArgumentNullException();
				}
				this.host = host;
			}

			// Token: 0x060006F9 RID: 1785 RVA: 0x00020884 File Offset: 0x0001EA84
			internal SyncHashtable(SerializationInfo info, StreamingContext context)
			{
				this.host = (Hashtable)info.GetValue("ParentTable", typeof(Hashtable));
			}

			// Token: 0x060006FA RID: 1786 RVA: 0x000208AC File Offset: 0x0001EAAC
			IEnumerator IEnumerable.GetEnumerator()
			{
				return new Hashtable.Enumerator(this.host, Hashtable.EnumeratorMode.ENTRY_MODE);
			}

			// Token: 0x060006FB RID: 1787 RVA: 0x000208BC File Offset: 0x0001EABC
			public override void GetObjectData(SerializationInfo info, StreamingContext context)
			{
				info.AddValue("ParentTable", this.host);
			}

			// Token: 0x17000111 RID: 273
			// (get) Token: 0x060006FC RID: 1788 RVA: 0x000208D0 File Offset: 0x0001EAD0
			public override int Count
			{
				get
				{
					return this.host.Count;
				}
			}

			// Token: 0x17000112 RID: 274
			// (get) Token: 0x060006FD RID: 1789 RVA: 0x000208E0 File Offset: 0x0001EAE0
			public override bool IsSynchronized
			{
				get
				{
					return true;
				}
			}

			// Token: 0x17000113 RID: 275
			// (get) Token: 0x060006FE RID: 1790 RVA: 0x000208E4 File Offset: 0x0001EAE4
			public override object SyncRoot
			{
				get
				{
					return this.host.SyncRoot;
				}
			}

			// Token: 0x17000114 RID: 276
			// (get) Token: 0x060006FF RID: 1791 RVA: 0x000208F4 File Offset: 0x0001EAF4
			public override bool IsFixedSize
			{
				get
				{
					return this.host.IsFixedSize;
				}
			}

			// Token: 0x17000115 RID: 277
			// (get) Token: 0x06000700 RID: 1792 RVA: 0x00020904 File Offset: 0x0001EB04
			public override bool IsReadOnly
			{
				get
				{
					return this.host.IsReadOnly;
				}
			}

			// Token: 0x17000116 RID: 278
			// (get) Token: 0x06000701 RID: 1793 RVA: 0x00020914 File Offset: 0x0001EB14
			public override ICollection Keys
			{
				get
				{
					ICollection collection = null;
					object syncRoot = this.host.SyncRoot;
					lock (syncRoot)
					{
						collection = this.host.Keys;
					}
					return collection;
				}
			}

			// Token: 0x17000117 RID: 279
			// (get) Token: 0x06000702 RID: 1794 RVA: 0x00020960 File Offset: 0x0001EB60
			public override ICollection Values
			{
				get
				{
					ICollection collection = null;
					object syncRoot = this.host.SyncRoot;
					lock (syncRoot)
					{
						collection = this.host.Values;
					}
					return collection;
				}
			}

			// Token: 0x17000118 RID: 280
			public override object this[object key]
			{
				get
				{
					return this.host[key];
				}
				set
				{
					object syncRoot = this.host.SyncRoot;
					lock (syncRoot)
					{
						this.host[key] = value;
					}
				}
			}

			// Token: 0x06000705 RID: 1797 RVA: 0x00020A04 File Offset: 0x0001EC04
			public override void CopyTo(Array array, int arrayIndex)
			{
				this.host.CopyTo(array, arrayIndex);
			}

			// Token: 0x06000706 RID: 1798 RVA: 0x00020A14 File Offset: 0x0001EC14
			public override void Add(object key, object value)
			{
				object syncRoot = this.host.SyncRoot;
				lock (syncRoot)
				{
					this.host.Add(key, value);
				}
			}

			// Token: 0x06000707 RID: 1799 RVA: 0x00020A5C File Offset: 0x0001EC5C
			public override void Clear()
			{
				object syncRoot = this.host.SyncRoot;
				lock (syncRoot)
				{
					this.host.Clear();
				}
			}

			// Token: 0x06000708 RID: 1800 RVA: 0x00020AA4 File Offset: 0x0001ECA4
			public override bool Contains(object key)
			{
				return this.host.Find(key) >= 0;
			}

			// Token: 0x06000709 RID: 1801 RVA: 0x00020AB8 File Offset: 0x0001ECB8
			public override IDictionaryEnumerator GetEnumerator()
			{
				return new Hashtable.Enumerator(this.host, Hashtable.EnumeratorMode.ENTRY_MODE);
			}

			// Token: 0x0600070A RID: 1802 RVA: 0x00020AC8 File Offset: 0x0001ECC8
			public override void Remove(object key)
			{
				object syncRoot = this.host.SyncRoot;
				lock (syncRoot)
				{
					this.host.Remove(key);
				}
			}

			// Token: 0x0600070B RID: 1803 RVA: 0x00020B10 File Offset: 0x0001ED10
			public override bool ContainsKey(object key)
			{
				return this.host.Contains(key);
			}

			// Token: 0x0600070C RID: 1804 RVA: 0x00020B20 File Offset: 0x0001ED20
			public override object Clone()
			{
				object syncRoot = this.host.SyncRoot;
				object obj;
				lock (syncRoot)
				{
					obj = new Hashtable.SyncHashtable((Hashtable)this.host.Clone());
				}
				return obj;
			}

			// Token: 0x040002E1 RID: 737
			private Hashtable host;
		}
	}
}
