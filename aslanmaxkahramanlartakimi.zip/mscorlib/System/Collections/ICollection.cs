﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000CB RID: 203
	[ComVisible(true)]
	public interface ICollection : IEnumerable
	{
		// Token: 0x17000119 RID: 281
		// (get) Token: 0x0600070D RID: 1805
		int Count { get; }

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x0600070E RID: 1806
		bool IsSynchronized { get; }

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x0600070F RID: 1807
		object SyncRoot { get; }

		// Token: 0x06000710 RID: 1808
		void CopyTo(Array array, int index);
	}
}
