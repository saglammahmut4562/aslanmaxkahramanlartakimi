﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000CC RID: 204
	[ComVisible(true)]
	public interface IComparer
	{
		// Token: 0x06000711 RID: 1809
		int Compare(object x, object y);
	}
}
