﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000CD RID: 205
	[ComVisible(true)]
	public interface IDictionary : ICollection, IEnumerable
	{
		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000712 RID: 1810
		bool IsFixedSize { get; }

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000713 RID: 1811
		bool IsReadOnly { get; }

		// Token: 0x1700011E RID: 286
		object this[object key] { get; set; }

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06000716 RID: 1814
		ICollection Keys { get; }

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000717 RID: 1815
		ICollection Values { get; }

		// Token: 0x06000718 RID: 1816
		void Add(object key, object value);

		// Token: 0x06000719 RID: 1817
		void Clear();

		// Token: 0x0600071A RID: 1818
		bool Contains(object key);

		// Token: 0x0600071B RID: 1819
		IDictionaryEnumerator GetEnumerator();

		// Token: 0x0600071C RID: 1820
		void Remove(object key);
	}
}
