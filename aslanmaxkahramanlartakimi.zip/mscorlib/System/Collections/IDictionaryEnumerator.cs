﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000CE RID: 206
	[ComVisible(true)]
	public interface IDictionaryEnumerator : IEnumerator
	{
		// Token: 0x17000121 RID: 289
		// (get) Token: 0x0600071D RID: 1821
		DictionaryEntry Entry { get; }

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x0600071E RID: 1822
		object Key { get; }

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x0600071F RID: 1823
		object Value { get; }
	}
}
