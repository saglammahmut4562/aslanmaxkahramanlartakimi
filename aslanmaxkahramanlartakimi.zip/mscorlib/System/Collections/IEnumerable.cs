﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000CF RID: 207
	[Guid("496B0ABE-CDEE-11d3-88E8-00902754C43A")]
	[ComVisible(true)]
	public interface IEnumerable
	{
		// Token: 0x06000720 RID: 1824
		[DispId(-4)]
		IEnumerator GetEnumerator();
	}
}
