﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000D0 RID: 208
	[Guid("496B0ABF-CDEE-11D3-88E8-00902754C43A")]
	[ComVisible(true)]
	public interface IEnumerator
	{
		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000721 RID: 1825
		object Current { get; }

		// Token: 0x06000722 RID: 1826
		bool MoveNext();

		// Token: 0x06000723 RID: 1827
		void Reset();
	}
}
