﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000D1 RID: 209
	[ComVisible(true)]
	public interface IEqualityComparer
	{
		// Token: 0x06000724 RID: 1828
		bool Equals(object x, object y);

		// Token: 0x06000725 RID: 1829
		int GetHashCode(object obj);
	}
}
