﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000D2 RID: 210
	[ComVisible(true)]
	[Obsolete("Please use IEqualityComparer instead.")]
	public interface IHashCodeProvider
	{
		// Token: 0x06000726 RID: 1830
		int GetHashCode(object obj);
	}
}
