﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000D3 RID: 211
	[ComVisible(true)]
	public interface IList : ICollection, IEnumerable
	{
		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000727 RID: 1831
		bool IsFixedSize { get; }

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000728 RID: 1832
		bool IsReadOnly { get; }

		// Token: 0x17000127 RID: 295
		object this[int index] { get; set; }

		// Token: 0x0600072B RID: 1835
		int Add(object value);

		// Token: 0x0600072C RID: 1836
		void Clear();

		// Token: 0x0600072D RID: 1837
		bool Contains(object value);

		// Token: 0x0600072E RID: 1838
		int IndexOf(object value);

		// Token: 0x0600072F RID: 1839
		void Insert(int index, object value);

		// Token: 0x06000730 RID: 1840
		void Remove(object value);

		// Token: 0x06000731 RID: 1841
		void RemoveAt(int index);
	}
}
