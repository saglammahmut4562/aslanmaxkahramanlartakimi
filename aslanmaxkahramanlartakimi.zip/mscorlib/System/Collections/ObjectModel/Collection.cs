﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace System.Collections.ObjectModel
{
	// Token: 0x020000D4 RID: 212
	[ComVisible(false)]
	[Serializable]
	public class Collection<T> : ICollection<T>, IEnumerable<T>, IList<T>, ICollection, IEnumerable, IList
	{
		// Token: 0x06000732 RID: 1842 RVA: 0x00020B78 File Offset: 0x0001ED78
		public Collection()
		{
			List<T> list = new List<T>();
			IList list2 = list;
			this.syncRoot = list2.SyncRoot;
			this.list = list;
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06000733 RID: 1843 RVA: 0x00020BA8 File Offset: 0x0001EDA8
		bool ICollection<T>.IsReadOnly
		{
			get
			{
				return this.list.IsReadOnly;
			}
		}

		// Token: 0x06000734 RID: 1844 RVA: 0x00020BB8 File Offset: 0x0001EDB8
		void ICollection.CopyTo(Array array, int index)
		{
			((ICollection)this.list).CopyTo(array, index);
		}

		// Token: 0x06000735 RID: 1845 RVA: 0x00020BCC File Offset: 0x0001EDCC
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.list.GetEnumerator();
		}

		// Token: 0x06000736 RID: 1846 RVA: 0x00020BDC File Offset: 0x0001EDDC
		int IList.Add(object value)
		{
			int count = this.list.Count;
			this.InsertItem(count, Collection<T>.ConvertItem(value));
			return count;
		}

		// Token: 0x06000737 RID: 1847 RVA: 0x00020C04 File Offset: 0x0001EE04
		bool IList.Contains(object value)
		{
			return Collection<T>.IsValidItem(value) && this.list.Contains((T)((object)value));
		}

		// Token: 0x06000738 RID: 1848 RVA: 0x00020C24 File Offset: 0x0001EE24
		int IList.IndexOf(object value)
		{
			if (Collection<T>.IsValidItem(value))
			{
				return this.list.IndexOf((T)((object)value));
			}
			return -1;
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x00020C44 File Offset: 0x0001EE44
		void IList.Insert(int index, object value)
		{
			this.InsertItem(index, Collection<T>.ConvertItem(value));
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x00020C54 File Offset: 0x0001EE54
		void IList.Remove(object value)
		{
			Collection<T>.CheckWritable(this.list);
			int num = this.IndexOf(Collection<T>.ConvertItem(value));
			this.RemoveItem(num);
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x0600073B RID: 1851 RVA: 0x00020C80 File Offset: 0x0001EE80
		bool ICollection.IsSynchronized
		{
			get
			{
				return Collection<T>.IsSynchronized(this.list);
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600073C RID: 1852 RVA: 0x00020C90 File Offset: 0x0001EE90
		object ICollection.SyncRoot
		{
			get
			{
				return this.syncRoot;
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x0600073D RID: 1853 RVA: 0x00020C98 File Offset: 0x0001EE98
		bool IList.IsFixedSize
		{
			get
			{
				return Collection<T>.IsFixedSize(this.list);
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x0600073E RID: 1854 RVA: 0x00020CA8 File Offset: 0x0001EEA8
		bool IList.IsReadOnly
		{
			get
			{
				return this.list.IsReadOnly;
			}
		}

		// Token: 0x1700012D RID: 301
		object IList.this[int index]
		{
			get
			{
				return this.list[index];
			}
			set
			{
				this.SetItem(index, Collection<T>.ConvertItem(value));
			}
		}

		// Token: 0x06000741 RID: 1857 RVA: 0x00020CDC File Offset: 0x0001EEDC
		public void Add(T item)
		{
			int count = this.list.Count;
			this.InsertItem(count, item);
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x00020D00 File Offset: 0x0001EF00
		public void Clear()
		{
			this.ClearItems();
		}

		// Token: 0x06000743 RID: 1859 RVA: 0x00020D08 File Offset: 0x0001EF08
		protected virtual void ClearItems()
		{
			this.list.Clear();
		}

		// Token: 0x06000744 RID: 1860 RVA: 0x00020D18 File Offset: 0x0001EF18
		public bool Contains(T item)
		{
			return this.list.Contains(item);
		}

		// Token: 0x06000745 RID: 1861 RVA: 0x00020D28 File Offset: 0x0001EF28
		public void CopyTo(T[] array, int index)
		{
			this.list.CopyTo(array, index);
		}

		// Token: 0x06000746 RID: 1862 RVA: 0x00020D38 File Offset: 0x0001EF38
		public IEnumerator<T> GetEnumerator()
		{
			return this.list.GetEnumerator();
		}

		// Token: 0x06000747 RID: 1863 RVA: 0x00020D48 File Offset: 0x0001EF48
		public int IndexOf(T item)
		{
			return this.list.IndexOf(item);
		}

		// Token: 0x06000748 RID: 1864 RVA: 0x00020D58 File Offset: 0x0001EF58
		public void Insert(int index, T item)
		{
			this.InsertItem(index, item);
		}

		// Token: 0x06000749 RID: 1865 RVA: 0x00020D64 File Offset: 0x0001EF64
		protected virtual void InsertItem(int index, T item)
		{
			this.list.Insert(index, item);
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x0600074A RID: 1866 RVA: 0x00020D74 File Offset: 0x0001EF74
		protected IList<T> Items
		{
			get
			{
				return this.list;
			}
		}

		// Token: 0x0600074B RID: 1867 RVA: 0x00020D7C File Offset: 0x0001EF7C
		public bool Remove(T item)
		{
			int num = this.IndexOf(item);
			if (num == -1)
			{
				return false;
			}
			this.RemoveItem(num);
			return true;
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x00020DA4 File Offset: 0x0001EFA4
		public void RemoveAt(int index)
		{
			this.RemoveItem(index);
		}

		// Token: 0x0600074D RID: 1869 RVA: 0x00020DB0 File Offset: 0x0001EFB0
		protected virtual void RemoveItem(int index)
		{
			this.list.RemoveAt(index);
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x0600074E RID: 1870 RVA: 0x00020DC0 File Offset: 0x0001EFC0
		public int Count
		{
			get
			{
				return this.list.Count;
			}
		}

		// Token: 0x17000130 RID: 304
		public T this[int index]
		{
			get
			{
				return this.list[index];
			}
			set
			{
				this.SetItem(index, value);
			}
		}

		// Token: 0x06000751 RID: 1873 RVA: 0x00020DEC File Offset: 0x0001EFEC
		protected virtual void SetItem(int index, T item)
		{
			this.list[index] = item;
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x00020DFC File Offset: 0x0001EFFC
		internal static bool IsValidItem(object item)
		{
			return item is T || (item == null && !typeof(T).IsValueType);
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x00020E28 File Offset: 0x0001F028
		internal static T ConvertItem(object item)
		{
			if (Collection<T>.IsValidItem(item))
			{
				return (T)((object)item);
			}
			throw new ArgumentException("item");
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x00020E48 File Offset: 0x0001F048
		internal static void CheckWritable(IList<T> list)
		{
			if (list.IsReadOnly)
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x00020E5C File Offset: 0x0001F05C
		internal static bool IsSynchronized(IList<T> list)
		{
			ICollection collection = list as ICollection;
			return collection != null && collection.IsSynchronized;
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x00020E84 File Offset: 0x0001F084
		internal static bool IsFixedSize(IList<T> list)
		{
			IList list2 = list as IList;
			return list2 != null && list2.IsFixedSize;
		}

		// Token: 0x040002E2 RID: 738
		private IList<T> list;

		// Token: 0x040002E3 RID: 739
		private object syncRoot;
	}
}
