﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace System.Collections.ObjectModel
{
	// Token: 0x020000D5 RID: 213
	[ComVisible(false)]
	[Serializable]
	public abstract class KeyedCollection<TKey, TItem> : Collection<TItem>
	{
		// Token: 0x06000757 RID: 1879 RVA: 0x00020EAC File Offset: 0x0001F0AC
		protected KeyedCollection()
			: this(null, 0)
		{
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x00020EB8 File Offset: 0x0001F0B8
		protected KeyedCollection(IEqualityComparer<TKey> comparer)
			: this(comparer, 0)
		{
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x00020EC4 File Offset: 0x0001F0C4
		protected KeyedCollection(IEqualityComparer<TKey> comparer, int dictionaryCreationThreshold)
		{
			if (comparer != null)
			{
				this.comparer = comparer;
			}
			else
			{
				this.comparer = EqualityComparer<TKey>.Default;
			}
			this.dictionaryCreationThreshold = dictionaryCreationThreshold;
			if (dictionaryCreationThreshold == 0)
			{
				this.dictionary = new Dictionary<TKey, TItem>(this.comparer);
			}
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x00020F14 File Offset: 0x0001F114
		public bool Contains(TKey key)
		{
			if (this.dictionary != null)
			{
				return this.dictionary.ContainsKey(key);
			}
			return this.IndexOfKey(key) >= 0;
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x00020F3C File Offset: 0x0001F13C
		private int IndexOfKey(TKey key)
		{
			for (int i = this.Count - 1; i >= 0; i--)
			{
				TKey keyForItem = this.GetKeyForItem(this[i]);
				if (this.comparer.Equals(key, keyForItem))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x17000131 RID: 305
		public TItem this[TKey key]
		{
			get
			{
				if (this.dictionary != null)
				{
					return this.dictionary[key];
				}
				int num = this.IndexOfKey(key);
				if (num >= 0)
				{
					return base[num];
				}
				throw new KeyNotFoundException();
			}
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x00020FCC File Offset: 0x0001F1CC
		protected override void ClearItems()
		{
			if (this.dictionary != null)
			{
				this.dictionary.Clear();
			}
			base.ClearItems();
		}

		// Token: 0x0600075E RID: 1886
		protected abstract TKey GetKeyForItem(TItem item);

		// Token: 0x0600075F RID: 1887 RVA: 0x00020FEC File Offset: 0x0001F1EC
		protected override void InsertItem(int index, TItem item)
		{
			TKey keyForItem = this.GetKeyForItem(item);
			if (keyForItem == null)
			{
				throw new ArgumentNullException("GetKeyForItem(item)");
			}
			if (this.dictionary != null && this.dictionary.ContainsKey(keyForItem))
			{
				throw new ArgumentException("An element with the same key already exists in the dictionary.");
			}
			if (this.dictionary == null)
			{
				for (int i = 0; i < this.Count; i++)
				{
					if (this.comparer.Equals(keyForItem, this.GetKeyForItem(this[i])))
					{
						throw new ArgumentException("An element with the same key already exists in the dictionary.");
					}
				}
			}
			base.InsertItem(index, item);
			if (this.dictionary != null)
			{
				this.dictionary.Add(keyForItem, item);
			}
			else if (this.dictionaryCreationThreshold != -1 && this.Count > this.dictionaryCreationThreshold)
			{
				this.dictionary = new Dictionary<TKey, TItem>(this.comparer);
				for (int j = 0; j < this.Count; j++)
				{
					TItem titem = this[j];
					this.dictionary.Add(this.GetKeyForItem(titem), titem);
				}
			}
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x00021110 File Offset: 0x0001F310
		protected override void RemoveItem(int index)
		{
			if (this.dictionary != null)
			{
				TKey keyForItem = this.GetKeyForItem(this[index]);
				this.dictionary.Remove(keyForItem);
			}
			base.RemoveItem(index);
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x0002114C File Offset: 0x0001F34C
		protected override void SetItem(int index, TItem item)
		{
			if (this.dictionary != null)
			{
				this.dictionary.Remove(this.GetKeyForItem(this[index]));
				this.dictionary.Add(this.GetKeyForItem(item), item);
			}
			base.SetItem(index, item);
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000762 RID: 1890 RVA: 0x00021198 File Offset: 0x0001F398
		protected IDictionary<TKey, TItem> Dictionary
		{
			get
			{
				return this.dictionary;
			}
		}

		// Token: 0x040002E4 RID: 740
		private Dictionary<TKey, TItem> dictionary;

		// Token: 0x040002E5 RID: 741
		private IEqualityComparer<TKey> comparer;

		// Token: 0x040002E6 RID: 742
		private int dictionaryCreationThreshold;
	}
}
