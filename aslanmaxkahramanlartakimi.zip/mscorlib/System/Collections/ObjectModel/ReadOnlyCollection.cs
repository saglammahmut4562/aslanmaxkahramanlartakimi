﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace System.Collections.ObjectModel
{
	// Token: 0x020000D6 RID: 214
	[ComVisible(false)]
	[Serializable]
	public class ReadOnlyCollection<T> : ICollection<T>, IEnumerable<T>, IList<T>, ICollection, IEnumerable, IList
	{
		// Token: 0x06000763 RID: 1891 RVA: 0x000211A0 File Offset: 0x0001F3A0
		public ReadOnlyCollection(IList<T> list)
		{
			if (list == null)
			{
				throw new ArgumentNullException("list");
			}
			this.list = list;
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x000211C0 File Offset: 0x0001F3C0
		void ICollection<T>.Add(T item)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x000211C8 File Offset: 0x0001F3C8
		void ICollection<T>.Clear()
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x000211D0 File Offset: 0x0001F3D0
		void IList<T>.Insert(int index, T item)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x000211D8 File Offset: 0x0001F3D8
		bool ICollection<T>.Remove(T item)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x000211E0 File Offset: 0x0001F3E0
		void IList<T>.RemoveAt(int index)
		{
			throw new NotSupportedException();
		}

		// Token: 0x17000133 RID: 307
		T IList<T>.this[int index]
		{
			get
			{
				return this[index];
			}
			set
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x0600076B RID: 1899 RVA: 0x000211FC File Offset: 0x0001F3FC
		bool ICollection<T>.IsReadOnly
		{
			get
			{
				return true;
			}
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x00021200 File Offset: 0x0001F400
		void ICollection.CopyTo(Array array, int index)
		{
			((ICollection)this.list).CopyTo(array, index);
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x00021214 File Offset: 0x0001F414
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.list.GetEnumerator();
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x00021224 File Offset: 0x0001F424
		int IList.Add(object value)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x0002122C File Offset: 0x0001F42C
		void IList.Clear()
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x00021234 File Offset: 0x0001F434
		bool IList.Contains(object value)
		{
			return Collection<T>.IsValidItem(value) && this.list.Contains((T)((object)value));
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00021254 File Offset: 0x0001F454
		int IList.IndexOf(object value)
		{
			if (Collection<T>.IsValidItem(value))
			{
				return this.list.IndexOf((T)((object)value));
			}
			return -1;
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x00021274 File Offset: 0x0001F474
		void IList.Insert(int index, object value)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x0002127C File Offset: 0x0001F47C
		void IList.Remove(object value)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x00021284 File Offset: 0x0001F484
		void IList.RemoveAt(int index)
		{
			throw new NotSupportedException();
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000775 RID: 1909 RVA: 0x0002128C File Offset: 0x0001F48C
		bool ICollection.IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000776 RID: 1910 RVA: 0x00021290 File Offset: 0x0001F490
		object ICollection.SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x06000777 RID: 1911 RVA: 0x00021294 File Offset: 0x0001F494
		bool IList.IsFixedSize
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x06000778 RID: 1912 RVA: 0x00021298 File Offset: 0x0001F498
		bool IList.IsReadOnly
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000139 RID: 313
		object IList.this[int index]
		{
			get
			{
				return this.list[index];
			}
			set
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x0600077B RID: 1915 RVA: 0x000212B8 File Offset: 0x0001F4B8
		public bool Contains(T value)
		{
			return this.list.Contains(value);
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x000212C8 File Offset: 0x0001F4C8
		public void CopyTo(T[] array, int index)
		{
			this.list.CopyTo(array, index);
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x000212D8 File Offset: 0x0001F4D8
		public IEnumerator<T> GetEnumerator()
		{
			return this.list.GetEnumerator();
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x000212E8 File Offset: 0x0001F4E8
		public int IndexOf(T value)
		{
			return this.list.IndexOf(value);
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x0600077F RID: 1919 RVA: 0x000212F8 File Offset: 0x0001F4F8
		public int Count
		{
			get
			{
				return this.list.Count;
			}
		}

		// Token: 0x1700013B RID: 315
		public T this[int index]
		{
			get
			{
				return this.list[index];
			}
		}

		// Token: 0x040002E7 RID: 743
		private IList<T> list;
	}
}
