﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000D7 RID: 215
	[DebuggerTypeProxy(typeof(CollectionDebuggerView))]
	[ComVisible(true)]
	[DebuggerDisplay("Count={Count}")]
	[Serializable]
	public class Queue : ICollection, IEnumerable, ICloneable
	{
		// Token: 0x06000781 RID: 1921 RVA: 0x00021318 File Offset: 0x0001F518
		public Queue()
			: this(32, 2f)
		{
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x00021328 File Offset: 0x0001F528
		public Queue(int capacity)
			: this(capacity, 2f)
		{
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x00021338 File Offset: 0x0001F538
		public Queue(ICollection col)
			: this((col != null) ? col.Count : 32)
		{
			if (col == null)
			{
				throw new ArgumentNullException("col");
			}
			foreach (object obj in col)
			{
				this.Enqueue(obj);
			}
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x000213BC File Offset: 0x0001F5BC
		public Queue(int capacity, float growFactor)
		{
			if (capacity < 0)
			{
				throw new ArgumentOutOfRangeException("capacity", "Needs a non-negative number");
			}
			if (growFactor < 1f || growFactor > 10f)
			{
				throw new ArgumentOutOfRangeException("growFactor", "Queue growth factor must be between 1.0 and 10.0, inclusive");
			}
			this._array = new object[capacity];
			this._growFactor = (int)(growFactor * 100f);
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000785 RID: 1925 RVA: 0x00021428 File Offset: 0x0001F628
		public virtual int Count
		{
			get
			{
				return this._size;
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x06000786 RID: 1926 RVA: 0x00021430 File Offset: 0x0001F630
		public virtual bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x06000787 RID: 1927 RVA: 0x00021434 File Offset: 0x0001F634
		public virtual object SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00021438 File Offset: 0x0001F638
		public virtual void CopyTo(Array array, int index)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (array.Rank > 1 || (index != 0 && index >= array.Length) || this._size > array.Length - index)
			{
				throw new ArgumentException();
			}
			int num = this._array.Length;
			int num2 = num - this._head;
			Array.Copy(this._array, this._head, array, index, Math.Min(this._size, num2));
			if (this._size > num2)
			{
				Array.Copy(this._array, 0, array, index + num2, this._size - num2);
			}
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x000214F4 File Offset: 0x0001F6F4
		public virtual IEnumerator GetEnumerator()
		{
			return new Queue.QueueEnumerator(this);
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x000214FC File Offset: 0x0001F6FC
		public virtual object Clone()
		{
			Queue queue = new Queue(this._array.Length);
			queue._growFactor = this._growFactor;
			Array.Copy(this._array, 0, queue._array, 0, this._array.Length);
			queue._head = this._head;
			queue._size = this._size;
			queue._tail = this._tail;
			return queue;
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x00021564 File Offset: 0x0001F764
		public virtual void Clear()
		{
			this._version++;
			this._head = 0;
			this._size = 0;
			this._tail = 0;
			for (int i = this._array.Length - 1; i >= 0; i--)
			{
				this._array[i] = null;
			}
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x000215B8 File Offset: 0x0001F7B8
		public virtual object Dequeue()
		{
			this._version++;
			if (this._size < 1)
			{
				throw new InvalidOperationException();
			}
			object obj = this._array[this._head];
			this._array[this._head] = null;
			this._head = (this._head + 1) % this._array.Length;
			this._size--;
			return obj;
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x00021628 File Offset: 0x0001F828
		public virtual void Enqueue(object obj)
		{
			this._version++;
			if (this._size == this._array.Length)
			{
				this.grow();
			}
			this._array[this._tail] = obj;
			this._tail = (this._tail + 1) % this._array.Length;
			this._size++;
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x00021690 File Offset: 0x0001F890
		public virtual object Peek()
		{
			if (this._size < 1)
			{
				throw new InvalidOperationException();
			}
			return this._array[this._head];
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x000216B4 File Offset: 0x0001F8B4
		public virtual object[] ToArray()
		{
			object[] array = new object[this._size];
			this.CopyTo(array, 0);
			return array;
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x000216D8 File Offset: 0x0001F8D8
		private void grow()
		{
			int num = this._array.Length * this._growFactor / 100;
			if (num < this._array.Length + 1)
			{
				num = this._array.Length + 1;
			}
			object[] array = new object[num];
			this.CopyTo(array, 0);
			this._array = array;
			this._head = 0;
			this._tail = this._head + this._size;
		}

		// Token: 0x040002E8 RID: 744
		private object[] _array;

		// Token: 0x040002E9 RID: 745
		private int _head;

		// Token: 0x040002EA RID: 746
		private int _size;

		// Token: 0x040002EB RID: 747
		private int _tail;

		// Token: 0x040002EC RID: 748
		private int _growFactor;

		// Token: 0x040002ED RID: 749
		private int _version;

		// Token: 0x020000D8 RID: 216
		[Serializable]
		private class QueueEnumerator : IEnumerator, ICloneable
		{
			// Token: 0x06000791 RID: 1937 RVA: 0x00021744 File Offset: 0x0001F944
			internal QueueEnumerator(Queue q)
			{
				this.queue = q;
				this._version = q._version;
				this.current = -1;
			}

			// Token: 0x06000792 RID: 1938 RVA: 0x00021768 File Offset: 0x0001F968
			public object Clone()
			{
				return new Queue.QueueEnumerator(this.queue)
				{
					_version = this._version,
					current = this.current
				};
			}

			// Token: 0x1700013F RID: 319
			// (get) Token: 0x06000793 RID: 1939 RVA: 0x0002179C File Offset: 0x0001F99C
			public virtual object Current
			{
				get
				{
					if (this._version != this.queue._version || this.current < 0 || this.current >= this.queue._size)
					{
						throw new InvalidOperationException();
					}
					return this.queue._array[(this.queue._head + this.current) % this.queue._array.Length];
				}
			}

			// Token: 0x06000794 RID: 1940 RVA: 0x00021814 File Offset: 0x0001FA14
			public virtual bool MoveNext()
			{
				if (this._version != this.queue._version)
				{
					throw new InvalidOperationException();
				}
				if (this.current >= this.queue._size - 1)
				{
					this.current = int.MaxValue;
					return false;
				}
				this.current++;
				return true;
			}

			// Token: 0x06000795 RID: 1941 RVA: 0x00021874 File Offset: 0x0001FA74
			public virtual void Reset()
			{
				if (this._version != this.queue._version)
				{
					throw new InvalidOperationException();
				}
				this.current = -1;
			}

			// Token: 0x040002EE RID: 750
			private Queue queue;

			// Token: 0x040002EF RID: 751
			private int _version;

			// Token: 0x040002F0 RID: 752
			private int current;
		}
	}
}
