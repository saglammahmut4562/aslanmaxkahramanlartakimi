﻿using System;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000D9 RID: 217
	[ComVisible(true)]
	[Serializable]
	public abstract class ReadOnlyCollectionBase : ICollection, IEnumerable
	{
		// Token: 0x06000796 RID: 1942 RVA: 0x0002189C File Offset: 0x0001FA9C
		protected ReadOnlyCollectionBase()
		{
			this.list = new ArrayList();
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x000218B0 File Offset: 0x0001FAB0
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x000218B8 File Offset: 0x0001FAB8
		void ICollection.CopyTo(Array array, int index)
		{
			ArrayList innerList = this.InnerList;
			lock (innerList)
			{
				this.InnerList.CopyTo(array, index);
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x06000799 RID: 1945 RVA: 0x000218FC File Offset: 0x0001FAFC
		object ICollection.SyncRoot
		{
			get
			{
				return this.InnerList.SyncRoot;
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x0600079A RID: 1946 RVA: 0x0002190C File Offset: 0x0001FB0C
		bool ICollection.IsSynchronized
		{
			get
			{
				return this.InnerList.IsSynchronized;
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x0600079B RID: 1947 RVA: 0x0002191C File Offset: 0x0001FB1C
		public virtual int Count
		{
			get
			{
				return this.InnerList.Count;
			}
		}

		// Token: 0x0600079C RID: 1948 RVA: 0x0002192C File Offset: 0x0001FB2C
		public virtual IEnumerator GetEnumerator()
		{
			return this.InnerList.GetEnumerator();
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x0600079D RID: 1949 RVA: 0x0002193C File Offset: 0x0001FB3C
		protected ArrayList InnerList
		{
			get
			{
				return this.list;
			}
		}

		// Token: 0x040002F1 RID: 753
		private ArrayList list;
	}
}
