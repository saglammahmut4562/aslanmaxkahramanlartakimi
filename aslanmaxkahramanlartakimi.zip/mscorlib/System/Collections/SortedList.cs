﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000DA RID: 218
	[ComVisible(true)]
	[DebuggerDisplay("Count={Count}")]
	[Serializable]
	public class SortedList : ICollection, IDictionary, IEnumerable, ICloneable
	{
		// Token: 0x0600079E RID: 1950 RVA: 0x00021944 File Offset: 0x0001FB44
		public SortedList()
			: this(null, SortedList.INITIAL_SIZE)
		{
		}

		// Token: 0x0600079F RID: 1951 RVA: 0x00021954 File Offset: 0x0001FB54
		public SortedList(int initialCapacity)
			: this(null, initialCapacity)
		{
		}

		// Token: 0x060007A0 RID: 1952 RVA: 0x00021960 File Offset: 0x0001FB60
		public SortedList(IComparer comparer, int capacity)
		{
			if (capacity < 0)
			{
				throw new ArgumentOutOfRangeException("capacity");
			}
			if (capacity == 0)
			{
				this.defaultCapacity = 0;
			}
			else
			{
				this.defaultCapacity = SortedList.INITIAL_SIZE;
			}
			this.comparer = comparer;
			this.InitTable(capacity, true);
		}

		// Token: 0x060007A1 RID: 1953 RVA: 0x000219B4 File Offset: 0x0001FBB4
		public SortedList(IDictionary d, IComparer comparer)
		{
			if (d == null)
			{
				throw new ArgumentNullException("dictionary");
			}
			this.InitTable(d.Count, true);
			this.comparer = comparer;
			IDictionaryEnumerator enumerator = d.GetEnumerator();
			while (enumerator.MoveNext())
			{
				this.Add(enumerator.Key, enumerator.Value);
			}
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x00021A24 File Offset: 0x0001FC24
		IEnumerator IEnumerable.GetEnumerator()
		{
			return new SortedList.Enumerator(this, SortedList.EnumeratorMode.ENTRY_MODE);
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060007A4 RID: 1956 RVA: 0x00021A30 File Offset: 0x0001FC30
		public virtual int Count
		{
			get
			{
				return this.inUse;
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060007A5 RID: 1957 RVA: 0x00021A38 File Offset: 0x0001FC38
		public virtual bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060007A6 RID: 1958 RVA: 0x00021A3C File Offset: 0x0001FC3C
		public virtual object SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060007A7 RID: 1959 RVA: 0x00021A40 File Offset: 0x0001FC40
		public virtual bool IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060007A8 RID: 1960 RVA: 0x00021A44 File Offset: 0x0001FC44
		public virtual bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060007A9 RID: 1961 RVA: 0x00021A48 File Offset: 0x0001FC48
		public virtual ICollection Keys
		{
			get
			{
				return new SortedList.ListKeys(this);
			}
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060007AA RID: 1962 RVA: 0x00021A50 File Offset: 0x0001FC50
		public virtual ICollection Values
		{
			get
			{
				return new SortedList.ListValues(this);
			}
		}

		// Token: 0x1700014B RID: 331
		public virtual object this[object key]
		{
			get
			{
				if (key == null)
				{
					throw new ArgumentNullException();
				}
				return this.GetImpl(key);
			}
			set
			{
				if (key == null)
				{
					throw new ArgumentNullException();
				}
				if (this.IsReadOnly)
				{
					throw new NotSupportedException("SortedList is Read Only.");
				}
				if (this.Find(key) < 0 && this.IsFixedSize)
				{
					throw new NotSupportedException("Key not found and SortedList is fixed size.");
				}
				this.PutImpl(key, value, true);
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060007AD RID: 1965 RVA: 0x00021ACC File Offset: 0x0001FCCC
		// (set) Token: 0x060007AE RID: 1966 RVA: 0x00021AD8 File Offset: 0x0001FCD8
		public virtual int Capacity
		{
			get
			{
				return this.table.Length;
			}
			set
			{
				int num = this.table.Length;
				if (this.inUse > value)
				{
					throw new ArgumentOutOfRangeException("capacity too small");
				}
				if (value == 0)
				{
					SortedList.Slot[] array = new SortedList.Slot[this.defaultCapacity];
					Array.Copy(this.table, array, this.inUse);
					this.table = array;
				}
				else if (value > this.inUse)
				{
					SortedList.Slot[] array2 = new SortedList.Slot[value];
					Array.Copy(this.table, array2, this.inUse);
					this.table = array2;
				}
				else if (value > num)
				{
					SortedList.Slot[] array3 = new SortedList.Slot[value];
					Array.Copy(this.table, array3, num);
					this.table = array3;
				}
			}
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x00021B88 File Offset: 0x0001FD88
		public virtual void Add(object key, object value)
		{
			this.PutImpl(key, value, false);
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x00021B94 File Offset: 0x0001FD94
		public virtual void Clear()
		{
			this.defaultCapacity = SortedList.INITIAL_SIZE;
			this.table = new SortedList.Slot[this.defaultCapacity];
			this.inUse = 0;
			this.modificationCount++;
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x00021BC8 File Offset: 0x0001FDC8
		public virtual bool Contains(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException();
			}
			bool flag;
			try
			{
				flag = this.Find(key) >= 0;
			}
			catch (Exception)
			{
				throw new InvalidOperationException();
			}
			return flag;
		}

		// Token: 0x060007B2 RID: 1970 RVA: 0x00021C18 File Offset: 0x0001FE18
		public virtual IDictionaryEnumerator GetEnumerator()
		{
			return new SortedList.Enumerator(this, SortedList.EnumeratorMode.ENTRY_MODE);
		}

		// Token: 0x060007B3 RID: 1971 RVA: 0x00021C24 File Offset: 0x0001FE24
		public virtual void Remove(object key)
		{
			int num = this.IndexOfKey(key);
			if (num >= 0)
			{
				this.RemoveAt(num);
			}
		}

		// Token: 0x060007B4 RID: 1972 RVA: 0x00021C48 File Offset: 0x0001FE48
		public virtual void CopyTo(Array array, int arrayIndex)
		{
			if (array == null)
			{
				throw new ArgumentNullException();
			}
			if (arrayIndex < 0)
			{
				throw new ArgumentOutOfRangeException();
			}
			if (array.Rank > 1)
			{
				throw new ArgumentException("array is multi-dimensional");
			}
			if (arrayIndex >= array.Length)
			{
				throw new ArgumentNullException("arrayIndex is greater than or equal to array.Length");
			}
			if (this.Count > array.Length - arrayIndex)
			{
				throw new ArgumentNullException("Not enough space in array from arrayIndex to end of array");
			}
			IDictionaryEnumerator enumerator = this.GetEnumerator();
			int num = arrayIndex;
			while (enumerator.MoveNext())
			{
				array.SetValue(enumerator.Entry, num++);
			}
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x00021CEC File Offset: 0x0001FEEC
		public virtual object Clone()
		{
			return new SortedList(this, this.comparer)
			{
				modificationCount = this.modificationCount
			};
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x00021D14 File Offset: 0x0001FF14
		public virtual IList GetValueList()
		{
			return new SortedList.ListValues(this);
		}

		// Token: 0x060007B7 RID: 1975 RVA: 0x00021D1C File Offset: 0x0001FF1C
		public virtual void RemoveAt(int index)
		{
			SortedList.Slot[] array = this.table;
			int count = this.Count;
			if (index >= 0 && index < count)
			{
				if (index != count - 1)
				{
					Array.Copy(array, index + 1, array, index, count - 1 - index);
				}
				else
				{
					array[index].key = null;
					array[index].value = null;
				}
				this.inUse--;
				this.modificationCount++;
				return;
			}
			throw new ArgumentOutOfRangeException("index out of range");
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x00021DAC File Offset: 0x0001FFAC
		public virtual int IndexOfKey(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException();
			}
			int num = 0;
			try
			{
				num = this.Find(key);
			}
			catch (Exception)
			{
				throw new InvalidOperationException();
			}
			return num | (num >> 31);
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x00021DF8 File Offset: 0x0001FFF8
		public virtual int IndexOfValue(object value)
		{
			if (this.inUse == 0)
			{
				return -1;
			}
			for (int i = 0; i < this.inUse; i++)
			{
				SortedList.Slot slot = this.table[i];
				if (object.Equals(value, slot.value))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x00021E50 File Offset: 0x00020050
		public virtual bool ContainsKey(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException();
			}
			bool flag;
			try
			{
				flag = this.Contains(key);
			}
			catch (Exception)
			{
				throw new InvalidOperationException();
			}
			return flag;
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x00021E98 File Offset: 0x00020098
		public virtual bool ContainsValue(object value)
		{
			return this.IndexOfValue(value) >= 0;
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x00021EA8 File Offset: 0x000200A8
		public virtual object GetByIndex(int index)
		{
			if (index >= 0 && index < this.Count)
			{
				return this.table[index].value;
			}
			throw new ArgumentOutOfRangeException("index out of range");
		}

		// Token: 0x060007BD RID: 1981 RVA: 0x00021EDC File Offset: 0x000200DC
		public virtual object GetKey(int index)
		{
			if (index >= 0 && index < this.Count)
			{
				return this.table[index].key;
			}
			throw new ArgumentOutOfRangeException("index out of range");
		}

		// Token: 0x060007BE RID: 1982 RVA: 0x00021F10 File Offset: 0x00020110
		private void EnsureCapacity(int n, int free)
		{
			SortedList.Slot[] array = this.table;
			SortedList.Slot[] array2 = null;
			int capacity = this.Capacity;
			bool flag = free >= 0 && free < this.Count;
			if (n > capacity)
			{
				array2 = new SortedList.Slot[n << 1];
			}
			if (array2 != null)
			{
				if (flag)
				{
					if (free > 0)
					{
						Array.Copy(array, 0, array2, 0, free);
					}
					int num = this.Count - free;
					if (num > 0)
					{
						Array.Copy(array, free, array2, free + 1, num);
					}
				}
				else
				{
					Array.Copy(array, array2, this.Count);
				}
				this.table = array2;
			}
			else if (flag)
			{
				Array.Copy(array, free, array, free + 1, this.Count - free);
			}
		}

		// Token: 0x060007BF RID: 1983 RVA: 0x00021FCC File Offset: 0x000201CC
		private void PutImpl(object key, object value, bool overwrite)
		{
			if (key == null)
			{
				throw new ArgumentNullException("null key");
			}
			SortedList.Slot[] array = this.table;
			int num = -1;
			try
			{
				num = this.Find(key);
			}
			catch (Exception)
			{
				throw new InvalidOperationException();
			}
			if (num >= 0)
			{
				if (!overwrite)
				{
					string text = Locale.GetText("Key '{0}' already exists in list.", new object[] { key });
					throw new ArgumentException(text);
				}
				array[num].value = value;
				this.modificationCount++;
				return;
			}
			else
			{
				num = ~num;
				if (num > this.Capacity + 1)
				{
					throw new Exception(string.Concat(new object[] { "SortedList::internal error (", key, ", ", value, ") at [", num, "]" }));
				}
				this.EnsureCapacity(this.Count + 1, num);
				array = this.table;
				array[num].key = key;
				array[num].value = value;
				this.inUse++;
				this.modificationCount++;
				return;
			}
		}

		// Token: 0x060007C0 RID: 1984 RVA: 0x00022100 File Offset: 0x00020300
		private object GetImpl(object key)
		{
			int num = this.Find(key);
			if (num >= 0)
			{
				return this.table[num].value;
			}
			return null;
		}

		// Token: 0x060007C1 RID: 1985 RVA: 0x00022130 File Offset: 0x00020330
		private void InitTable(int capacity, bool forceSize)
		{
			if (!forceSize && capacity < this.defaultCapacity)
			{
				capacity = this.defaultCapacity;
			}
			this.table = new SortedList.Slot[capacity];
			this.inUse = 0;
			this.modificationCount = 0;
		}

		// Token: 0x060007C2 RID: 1986 RVA: 0x00022168 File Offset: 0x00020368
		private void CopyToArray(Array arr, int i, SortedList.EnumeratorMode mode)
		{
			if (arr == null)
			{
				throw new ArgumentNullException("arr");
			}
			if (i < 0 || i + this.Count > arr.Length)
			{
				throw new ArgumentOutOfRangeException("i");
			}
			IEnumerator enumerator = new SortedList.Enumerator(this, mode);
			while (enumerator.MoveNext())
			{
				object obj = enumerator.Current;
				arr.SetValue(obj, i++);
			}
		}

		// Token: 0x060007C3 RID: 1987 RVA: 0x000221D8 File Offset: 0x000203D8
		private int Find(object key)
		{
			SortedList.Slot[] array = this.table;
			int count = this.Count;
			if (count == 0)
			{
				return -1;
			}
			IComparer comparer;
			if (this.comparer == null)
			{
				IComparer @default = Comparer.Default;
				comparer = @default;
			}
			else
			{
				comparer = this.comparer;
			}
			IComparer comparer2 = comparer;
			int i = 0;
			int num = count - 1;
			while (i <= num)
			{
				int num2 = i + num >> 1;
				int num3 = comparer2.Compare(array[num2].key, key);
				if (num3 == 0)
				{
					return num2;
				}
				if (num3 < 0)
				{
					i = num2 + 1;
				}
				else
				{
					num = num2 - 1;
				}
			}
			return ~i;
		}

		// Token: 0x040002F2 RID: 754
		private static readonly int INITIAL_SIZE = 16;

		// Token: 0x040002F3 RID: 755
		private int inUse;

		// Token: 0x040002F4 RID: 756
		private int modificationCount;

		// Token: 0x040002F5 RID: 757
		private SortedList.Slot[] table;

		// Token: 0x040002F6 RID: 758
		private IComparer comparer;

		// Token: 0x040002F7 RID: 759
		private int defaultCapacity;

		// Token: 0x020000DB RID: 219
		private sealed class Enumerator : IDictionaryEnumerator, IEnumerator, ICloneable
		{
			// Token: 0x060007C4 RID: 1988 RVA: 0x00022274 File Offset: 0x00020474
			public Enumerator(SortedList host, SortedList.EnumeratorMode mode)
			{
				this.host = host;
				this.stamp = host.modificationCount;
				this.size = host.Count;
				this.mode = mode;
				this.Reset();
			}

			// Token: 0x060007C6 RID: 1990 RVA: 0x000222B4 File Offset: 0x000204B4
			public void Reset()
			{
				if (this.host.modificationCount != this.stamp || this.invalid)
				{
					throw new InvalidOperationException(SortedList.Enumerator.xstr);
				}
				this.pos = -1;
				this.currentKey = null;
				this.currentValue = null;
			}

			// Token: 0x060007C7 RID: 1991 RVA: 0x00022304 File Offset: 0x00020504
			public bool MoveNext()
			{
				if (this.host.modificationCount != this.stamp || this.invalid)
				{
					throw new InvalidOperationException(SortedList.Enumerator.xstr);
				}
				SortedList.Slot[] table = this.host.table;
				if (++this.pos < this.size)
				{
					SortedList.Slot slot = table[this.pos];
					this.currentKey = slot.key;
					this.currentValue = slot.value;
					return true;
				}
				this.currentKey = null;
				this.currentValue = null;
				return false;
			}

			// Token: 0x1700014D RID: 333
			// (get) Token: 0x060007C8 RID: 1992 RVA: 0x000223A4 File Offset: 0x000205A4
			public DictionaryEntry Entry
			{
				get
				{
					if (this.invalid || this.pos >= this.size || this.pos == -1)
					{
						throw new InvalidOperationException(SortedList.Enumerator.xstr);
					}
					return new DictionaryEntry(this.currentKey, this.currentValue);
				}
			}

			// Token: 0x1700014E RID: 334
			// (get) Token: 0x060007C9 RID: 1993 RVA: 0x000223F8 File Offset: 0x000205F8
			public object Key
			{
				get
				{
					if (this.invalid || this.pos >= this.size || this.pos == -1)
					{
						throw new InvalidOperationException(SortedList.Enumerator.xstr);
					}
					return this.currentKey;
				}
			}

			// Token: 0x1700014F RID: 335
			// (get) Token: 0x060007CA RID: 1994 RVA: 0x00022434 File Offset: 0x00020634
			public object Value
			{
				get
				{
					if (this.invalid || this.pos >= this.size || this.pos == -1)
					{
						throw new InvalidOperationException(SortedList.Enumerator.xstr);
					}
					return this.currentValue;
				}
			}

			// Token: 0x17000150 RID: 336
			// (get) Token: 0x060007CB RID: 1995 RVA: 0x00022470 File Offset: 0x00020670
			public object Current
			{
				get
				{
					if (this.invalid || this.pos >= this.size || this.pos == -1)
					{
						throw new InvalidOperationException(SortedList.Enumerator.xstr);
					}
					switch (this.mode)
					{
					case SortedList.EnumeratorMode.KEY_MODE:
						return this.currentKey;
					case SortedList.EnumeratorMode.VALUE_MODE:
						return this.currentValue;
					case SortedList.EnumeratorMode.ENTRY_MODE:
						return this.Entry;
					default:
						throw new NotSupportedException(this.mode + " is not a supported mode.");
					}
				}
			}

			// Token: 0x060007CC RID: 1996 RVA: 0x00022504 File Offset: 0x00020704
			public object Clone()
			{
				return new SortedList.Enumerator(this.host, this.mode)
				{
					stamp = this.stamp,
					pos = this.pos,
					size = this.size,
					currentKey = this.currentKey,
					currentValue = this.currentValue,
					invalid = this.invalid
				};
			}

			// Token: 0x040002F8 RID: 760
			private SortedList host;

			// Token: 0x040002F9 RID: 761
			private int stamp;

			// Token: 0x040002FA RID: 762
			private int pos;

			// Token: 0x040002FB RID: 763
			private int size;

			// Token: 0x040002FC RID: 764
			private SortedList.EnumeratorMode mode;

			// Token: 0x040002FD RID: 765
			private object currentKey;

			// Token: 0x040002FE RID: 766
			private object currentValue;

			// Token: 0x040002FF RID: 767
			private bool invalid;

			// Token: 0x04000300 RID: 768
			private static readonly string xstr = "SortedList.Enumerator: snapshot out of sync.";
		}

		// Token: 0x020000DC RID: 220
		private enum EnumeratorMode
		{
			// Token: 0x04000302 RID: 770
			KEY_MODE,
			// Token: 0x04000303 RID: 771
			VALUE_MODE,
			// Token: 0x04000304 RID: 772
			ENTRY_MODE
		}

		// Token: 0x020000DD RID: 221
		[Serializable]
		private class ListKeys : ICollection, IEnumerable, IList
		{
			// Token: 0x060007CD RID: 1997 RVA: 0x0002256C File Offset: 0x0002076C
			public ListKeys(SortedList host)
			{
				if (host == null)
				{
					throw new ArgumentNullException();
				}
				this.host = host;
			}

			// Token: 0x17000151 RID: 337
			// (get) Token: 0x060007CE RID: 1998 RVA: 0x00022588 File Offset: 0x00020788
			public virtual int Count
			{
				get
				{
					return this.host.Count;
				}
			}

			// Token: 0x17000152 RID: 338
			// (get) Token: 0x060007CF RID: 1999 RVA: 0x00022598 File Offset: 0x00020798
			public virtual bool IsSynchronized
			{
				get
				{
					return this.host.IsSynchronized;
				}
			}

			// Token: 0x17000153 RID: 339
			// (get) Token: 0x060007D0 RID: 2000 RVA: 0x000225A8 File Offset: 0x000207A8
			public virtual object SyncRoot
			{
				get
				{
					return this.host.SyncRoot;
				}
			}

			// Token: 0x060007D1 RID: 2001 RVA: 0x000225B8 File Offset: 0x000207B8
			public virtual void CopyTo(Array array, int arrayIndex)
			{
				this.host.CopyToArray(array, arrayIndex, SortedList.EnumeratorMode.KEY_MODE);
			}

			// Token: 0x17000154 RID: 340
			// (get) Token: 0x060007D2 RID: 2002 RVA: 0x000225C8 File Offset: 0x000207C8
			public virtual bool IsFixedSize
			{
				get
				{
					return true;
				}
			}

			// Token: 0x17000155 RID: 341
			// (get) Token: 0x060007D3 RID: 2003 RVA: 0x000225CC File Offset: 0x000207CC
			public virtual bool IsReadOnly
			{
				get
				{
					return true;
				}
			}

			// Token: 0x17000156 RID: 342
			public virtual object this[int index]
			{
				get
				{
					return this.host.GetKey(index);
				}
				set
				{
					throw new NotSupportedException("attempt to modify a key");
				}
			}

			// Token: 0x060007D6 RID: 2006 RVA: 0x000225EC File Offset: 0x000207EC
			public virtual int Add(object value)
			{
				throw new NotSupportedException("IList::Add not supported");
			}

			// Token: 0x060007D7 RID: 2007 RVA: 0x000225F8 File Offset: 0x000207F8
			public virtual void Clear()
			{
				throw new NotSupportedException("IList::Clear not supported");
			}

			// Token: 0x060007D8 RID: 2008 RVA: 0x00022604 File Offset: 0x00020804
			public virtual bool Contains(object key)
			{
				return this.host.Contains(key);
			}

			// Token: 0x060007D9 RID: 2009 RVA: 0x00022614 File Offset: 0x00020814
			public virtual int IndexOf(object key)
			{
				return this.host.IndexOfKey(key);
			}

			// Token: 0x060007DA RID: 2010 RVA: 0x00022624 File Offset: 0x00020824
			public virtual void Insert(int index, object value)
			{
				throw new NotSupportedException("IList::Insert not supported");
			}

			// Token: 0x060007DB RID: 2011 RVA: 0x00022630 File Offset: 0x00020830
			public virtual void Remove(object value)
			{
				throw new NotSupportedException("IList::Remove not supported");
			}

			// Token: 0x060007DC RID: 2012 RVA: 0x0002263C File Offset: 0x0002083C
			public virtual void RemoveAt(int index)
			{
				throw new NotSupportedException("IList::RemoveAt not supported");
			}

			// Token: 0x060007DD RID: 2013 RVA: 0x00022648 File Offset: 0x00020848
			public virtual IEnumerator GetEnumerator()
			{
				return new SortedList.Enumerator(this.host, SortedList.EnumeratorMode.KEY_MODE);
			}

			// Token: 0x04000305 RID: 773
			private SortedList host;
		}

		// Token: 0x020000DE RID: 222
		[Serializable]
		private class ListValues : ICollection, IEnumerable, IList
		{
			// Token: 0x060007DE RID: 2014 RVA: 0x00022658 File Offset: 0x00020858
			public ListValues(SortedList host)
			{
				if (host == null)
				{
					throw new ArgumentNullException();
				}
				this.host = host;
			}

			// Token: 0x17000157 RID: 343
			// (get) Token: 0x060007DF RID: 2015 RVA: 0x00022674 File Offset: 0x00020874
			public virtual int Count
			{
				get
				{
					return this.host.Count;
				}
			}

			// Token: 0x17000158 RID: 344
			// (get) Token: 0x060007E0 RID: 2016 RVA: 0x00022684 File Offset: 0x00020884
			public virtual bool IsSynchronized
			{
				get
				{
					return this.host.IsSynchronized;
				}
			}

			// Token: 0x17000159 RID: 345
			// (get) Token: 0x060007E1 RID: 2017 RVA: 0x00022694 File Offset: 0x00020894
			public virtual object SyncRoot
			{
				get
				{
					return this.host.SyncRoot;
				}
			}

			// Token: 0x060007E2 RID: 2018 RVA: 0x000226A4 File Offset: 0x000208A4
			public virtual void CopyTo(Array array, int arrayIndex)
			{
				this.host.CopyToArray(array, arrayIndex, SortedList.EnumeratorMode.VALUE_MODE);
			}

			// Token: 0x1700015A RID: 346
			// (get) Token: 0x060007E3 RID: 2019 RVA: 0x000226B4 File Offset: 0x000208B4
			public virtual bool IsFixedSize
			{
				get
				{
					return true;
				}
			}

			// Token: 0x1700015B RID: 347
			// (get) Token: 0x060007E4 RID: 2020 RVA: 0x000226B8 File Offset: 0x000208B8
			public virtual bool IsReadOnly
			{
				get
				{
					return true;
				}
			}

			// Token: 0x1700015C RID: 348
			public virtual object this[int index]
			{
				get
				{
					return this.host.GetByIndex(index);
				}
				set
				{
					throw new NotSupportedException("This operation is not supported on GetValueList return");
				}
			}

			// Token: 0x060007E7 RID: 2023 RVA: 0x000226D8 File Offset: 0x000208D8
			public virtual int Add(object value)
			{
				throw new NotSupportedException("IList::Add not supported");
			}

			// Token: 0x060007E8 RID: 2024 RVA: 0x000226E4 File Offset: 0x000208E4
			public virtual void Clear()
			{
				throw new NotSupportedException("IList::Clear not supported");
			}

			// Token: 0x060007E9 RID: 2025 RVA: 0x000226F0 File Offset: 0x000208F0
			public virtual bool Contains(object value)
			{
				return this.host.ContainsValue(value);
			}

			// Token: 0x060007EA RID: 2026 RVA: 0x00022700 File Offset: 0x00020900
			public virtual int IndexOf(object value)
			{
				return this.host.IndexOfValue(value);
			}

			// Token: 0x060007EB RID: 2027 RVA: 0x00022710 File Offset: 0x00020910
			public virtual void Insert(int index, object value)
			{
				throw new NotSupportedException("IList::Insert not supported");
			}

			// Token: 0x060007EC RID: 2028 RVA: 0x0002271C File Offset: 0x0002091C
			public virtual void Remove(object value)
			{
				throw new NotSupportedException("IList::Remove not supported");
			}

			// Token: 0x060007ED RID: 2029 RVA: 0x00022728 File Offset: 0x00020928
			public virtual void RemoveAt(int index)
			{
				throw new NotSupportedException("IList::RemoveAt not supported");
			}

			// Token: 0x060007EE RID: 2030 RVA: 0x00022734 File Offset: 0x00020934
			public virtual IEnumerator GetEnumerator()
			{
				return new SortedList.Enumerator(this.host, SortedList.EnumeratorMode.VALUE_MODE);
			}

			// Token: 0x04000306 RID: 774
			private SortedList host;
		}

		// Token: 0x020000DF RID: 223
		[Serializable]
		internal struct Slot
		{
			// Token: 0x04000307 RID: 775
			internal object key;

			// Token: 0x04000308 RID: 776
			internal object value;
		}
	}
}
