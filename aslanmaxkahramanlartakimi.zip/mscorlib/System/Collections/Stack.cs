﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace System.Collections
{
	// Token: 0x020000E0 RID: 224
	[DebuggerTypeProxy(typeof(CollectionDebuggerView))]
	[ComVisible(true)]
	[DebuggerDisplay("Count={Count}")]
	[Serializable]
	public class Stack : ICollection, IEnumerable, ICloneable
	{
		// Token: 0x060007EF RID: 2031 RVA: 0x00022744 File Offset: 0x00020944
		public Stack()
		{
			this.contents = new object[16];
			this.capacity = 16;
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x00022768 File Offset: 0x00020968
		public Stack(ICollection col)
			: this((col != null) ? col.Count : 16)
		{
			if (col == null)
			{
				throw new ArgumentNullException("col");
			}
			foreach (object obj in col)
			{
				this.Push(obj);
			}
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x000227EC File Offset: 0x000209EC
		public Stack(int initialCapacity)
		{
			if (initialCapacity < 0)
			{
				throw new ArgumentOutOfRangeException("initialCapacity");
			}
			this.capacity = initialCapacity;
			this.contents = new object[this.capacity];
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x00022828 File Offset: 0x00020A28
		private void Resize(int ncapacity)
		{
			ncapacity = Math.Max(ncapacity, 16);
			object[] array = new object[ncapacity];
			Array.Copy(this.contents, array, this.count);
			this.capacity = ncapacity;
			this.contents = array;
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x060007F3 RID: 2035 RVA: 0x00022868 File Offset: 0x00020A68
		public virtual int Count
		{
			get
			{
				return this.count;
			}
		}

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x060007F4 RID: 2036 RVA: 0x00022870 File Offset: 0x00020A70
		public virtual bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x060007F5 RID: 2037 RVA: 0x00022874 File Offset: 0x00020A74
		public virtual object SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00022878 File Offset: 0x00020A78
		public virtual void Clear()
		{
			this.modCount++;
			for (int i = 0; i < this.count; i++)
			{
				this.contents[i] = null;
			}
			this.count = 0;
			this.current = -1;
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x000228C4 File Offset: 0x00020AC4
		public virtual object Clone()
		{
			return new Stack(this.contents)
			{
				current = this.current,
				count = this.count
			};
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x000228F8 File Offset: 0x00020AF8
		public virtual bool Contains(object obj)
		{
			if (this.count == 0)
			{
				return false;
			}
			if (obj == null)
			{
				for (int i = 0; i < this.count; i++)
				{
					if (this.contents[i] == null)
					{
						return true;
					}
				}
			}
			else
			{
				for (int j = 0; j < this.count; j++)
				{
					if (obj.Equals(this.contents[j]))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x00022970 File Offset: 0x00020B70
		public virtual void CopyTo(Array array, int index)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (array.Rank > 1 || (array.Length > 0 && index >= array.Length) || this.count > array.Length - index)
			{
				throw new ArgumentException();
			}
			for (int num = this.current; num != -1; num--)
			{
				array.SetValue(this.contents[num], this.count - (num + 1) + index);
			}
		}

		// Token: 0x060007FA RID: 2042 RVA: 0x00022A10 File Offset: 0x00020C10
		public virtual IEnumerator GetEnumerator()
		{
			return new Stack.Enumerator(this);
		}

		// Token: 0x060007FB RID: 2043 RVA: 0x00022A18 File Offset: 0x00020C18
		public virtual object Peek()
		{
			if (this.current == -1)
			{
				throw new InvalidOperationException();
			}
			return this.contents[this.current];
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x00022A3C File Offset: 0x00020C3C
		public virtual object Pop()
		{
			if (this.current == -1)
			{
				throw new InvalidOperationException();
			}
			this.modCount++;
			object obj = this.contents[this.current];
			this.contents[this.current] = null;
			this.count--;
			this.current--;
			if (this.count <= this.capacity / 4 && this.count > 16)
			{
				this.Resize(this.capacity / 2);
			}
			return obj;
		}

		// Token: 0x060007FD RID: 2045 RVA: 0x00022AD0 File Offset: 0x00020CD0
		public virtual void Push(object obj)
		{
			this.modCount++;
			if (this.capacity == this.count)
			{
				this.Resize(this.capacity * 2);
			}
			this.count++;
			this.current++;
			this.contents[this.current] = obj;
		}

		// Token: 0x060007FE RID: 2046 RVA: 0x00022B34 File Offset: 0x00020D34
		public virtual object[] ToArray()
		{
			object[] array = new object[this.count];
			Array.Copy(this.contents, array, this.count);
			Array.Reverse(array);
			return array;
		}

		// Token: 0x04000309 RID: 777
		private const int default_capacity = 16;

		// Token: 0x0400030A RID: 778
		private object[] contents;

		// Token: 0x0400030B RID: 779
		private int current = -1;

		// Token: 0x0400030C RID: 780
		private int count;

		// Token: 0x0400030D RID: 781
		private int capacity;

		// Token: 0x0400030E RID: 782
		private int modCount;

		// Token: 0x020000E1 RID: 225
		private class Enumerator : IEnumerator, ICloneable
		{
			// Token: 0x060007FF RID: 2047 RVA: 0x00022B68 File Offset: 0x00020D68
			internal Enumerator(Stack s)
			{
				this.stack = s;
				this.modCount = s.modCount;
				this.current = -2;
			}

			// Token: 0x06000800 RID: 2048 RVA: 0x00022B8C File Offset: 0x00020D8C
			public object Clone()
			{
				return base.MemberwiseClone();
			}

			// Token: 0x17000160 RID: 352
			// (get) Token: 0x06000801 RID: 2049 RVA: 0x00022B94 File Offset: 0x00020D94
			public virtual object Current
			{
				get
				{
					if (this.modCount != this.stack.modCount || this.current == -2 || this.current == -1 || this.current > this.stack.count)
					{
						throw new InvalidOperationException();
					}
					return this.stack.contents[this.current];
				}
			}

			// Token: 0x06000802 RID: 2050 RVA: 0x00022C00 File Offset: 0x00020E00
			public virtual bool MoveNext()
			{
				if (this.modCount != this.stack.modCount)
				{
					throw new InvalidOperationException();
				}
				int num = this.current;
				if (num == -2)
				{
					this.current = this.stack.current;
					return this.current != -1;
				}
				if (num != -1)
				{
					this.current--;
					return this.current != -1;
				}
				return false;
			}

			// Token: 0x06000803 RID: 2051 RVA: 0x00022C80 File Offset: 0x00020E80
			public virtual void Reset()
			{
				if (this.modCount != this.stack.modCount)
				{
					throw new InvalidOperationException();
				}
				this.current = -2;
			}

			// Token: 0x0400030F RID: 783
			private const int EOF = -1;

			// Token: 0x04000310 RID: 784
			private const int BOF = -2;

			// Token: 0x04000311 RID: 785
			private Stack stack;

			// Token: 0x04000312 RID: 786
			private int modCount;

			// Token: 0x04000313 RID: 787
			private int current;
		}
	}
}
