﻿using System;

namespace System
{
	// Token: 0x020000E2 RID: 226
	// (Invoke) Token: 0x06000805 RID: 2053
	public delegate int Comparison<T>(T x, T y);
}
