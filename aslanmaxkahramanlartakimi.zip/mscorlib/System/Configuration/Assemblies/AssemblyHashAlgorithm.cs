﻿using System;
using System.Runtime.InteropServices;

namespace System.Configuration.Assemblies
{
	// Token: 0x020000E3 RID: 227
	[ComVisible(true)]
	[Serializable]
	public enum AssemblyHashAlgorithm
	{
		// Token: 0x04000315 RID: 789
		None,
		// Token: 0x04000316 RID: 790
		MD5 = 32771,
		// Token: 0x04000317 RID: 791
		SHA1
	}
}
