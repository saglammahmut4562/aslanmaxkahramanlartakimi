﻿using System;
using System.Runtime.InteropServices;

namespace System.Configuration.Assemblies
{
	// Token: 0x020000E4 RID: 228
	[ComVisible(true)]
	[Serializable]
	public enum AssemblyVersionCompatibility
	{
		// Token: 0x04000319 RID: 793
		SameMachine = 1,
		// Token: 0x0400031A RID: 794
		SameProcess,
		// Token: 0x0400031B RID: 795
		SameDomain
	}
}
