﻿using System;
using System.IO;
using System.Text;

namespace System
{
	// Token: 0x020000E5 RID: 229
	public static class Console
	{
		// Token: 0x06000808 RID: 2056 RVA: 0x00022CA8 File Offset: 0x00020EA8
		static Console()
		{
			Encoding encoding2;
			Encoding encoding;
			if (Environment.IsRunningOnWindows)
			{
				encoding = (encoding2 = Encoding.Default);
			}
			else
			{
				int num = 0;
				Encoding.InternalCodePage(ref num);
				if (num != -1 && ((num & 268435455) == 3 || (num & 268435456) != 0))
				{
					encoding = (encoding2 = Encoding.UTF8Unmarked);
				}
				else
				{
					encoding = (encoding2 = Encoding.Default);
				}
			}
			Console.stderr = new UnexceptionalStreamWriter(Console.OpenStandardError(0), encoding);
			((StreamWriter)Console.stderr).AutoFlush = true;
			Console.stderr = TextWriter.Synchronized(Console.stderr, true);
			Console.stdout = new UnexceptionalStreamWriter(Console.OpenStandardOutput(0), encoding);
			((StreamWriter)Console.stdout).AutoFlush = true;
			Console.stdout = TextWriter.Synchronized(Console.stdout, true);
			Console.stdin = new UnexceptionalStreamReader(Console.OpenStandardInput(0), encoding2);
			Console.stdin = TextReader.Synchronized(Console.stdin);
			GC.SuppressFinalize(Console.stdout);
			GC.SuppressFinalize(Console.stderr);
			GC.SuppressFinalize(Console.stdin);
		}

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x06000809 RID: 2057 RVA: 0x00022DAC File Offset: 0x00020FAC
		public static TextWriter Error
		{
			get
			{
				return Console.stderr;
			}
		}

		// Token: 0x0600080A RID: 2058 RVA: 0x00022DB4 File Offset: 0x00020FB4
		private static Stream Open(IntPtr handle, FileAccess access, int bufferSize)
		{
			Stream stream;
			try
			{
				stream = new FileStream(handle, access, false, bufferSize, false, bufferSize == 0);
			}
			catch (IOException)
			{
				stream = new NullStream();
			}
			return stream;
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x00022DFC File Offset: 0x00020FFC
		public static Stream OpenStandardError(int bufferSize)
		{
			return Console.Open(MonoIO.ConsoleError, FileAccess.Write, bufferSize);
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x00022E0C File Offset: 0x0002100C
		public static Stream OpenStandardInput(int bufferSize)
		{
			return Console.Open(MonoIO.ConsoleInput, FileAccess.Read, bufferSize);
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x00022E1C File Offset: 0x0002101C
		public static Stream OpenStandardOutput(int bufferSize)
		{
			return Console.Open(MonoIO.ConsoleOutput, FileAccess.Write, bufferSize);
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x00022E2C File Offset: 0x0002102C
		public static void SetOut(TextWriter newOut)
		{
			if (newOut == null)
			{
				throw new ArgumentNullException("newOut");
			}
			Console.stdout = newOut;
		}

		// Token: 0x0600080F RID: 2063 RVA: 0x00022E48 File Offset: 0x00021048
		public static void WriteLine(string value)
		{
			Console.stdout.WriteLine(value);
		}

		// Token: 0x0400031C RID: 796
		internal static TextWriter stdout;

		// Token: 0x0400031D RID: 797
		private static TextWriter stderr;

		// Token: 0x0400031E RID: 798
		private static TextReader stdin;

		// Token: 0x0400031F RID: 799
		private static Encoding inputEncoding;

		// Token: 0x04000320 RID: 800
		private static Encoding outputEncoding;
	}
}
