﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x020000E6 RID: 230
	[ComVisible(true)]
	[Serializable]
	public abstract class ContextBoundObject : MarshalByRefObject
	{
	}
}
