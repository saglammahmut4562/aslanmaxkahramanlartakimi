﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace System
{
	// Token: 0x020000E7 RID: 231
	public static class Convert
	{
		// Token: 0x06000812 RID: 2066
		[MethodImpl(4096)]
		private static extern byte[] InternalFromBase64String(string str, bool allowWhitespaceOnly);

		// Token: 0x06000813 RID: 2067
		[MethodImpl(4096)]
		private static extern byte[] InternalFromBase64CharArray(char[] arr, int offset, int length);

		// Token: 0x06000814 RID: 2068 RVA: 0x00022F6C File Offset: 0x0002116C
		public static byte[] FromBase64CharArray(char[] inArray, int offset, int length)
		{
			if (inArray == null)
			{
				throw new ArgumentNullException("inArray");
			}
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset < 0");
			}
			if (length < 0)
			{
				throw new ArgumentOutOfRangeException("length < 0");
			}
			if (offset > inArray.Length - length)
			{
				throw new ArgumentOutOfRangeException("offset + length > array.Length");
			}
			return Convert.InternalFromBase64CharArray(inArray, offset, length);
		}

		// Token: 0x06000815 RID: 2069 RVA: 0x00022FCC File Offset: 0x000211CC
		public static byte[] FromBase64String(string s)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			if (s.Length == 0)
			{
				return new byte[0];
			}
			return Convert.InternalFromBase64String(s, true);
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x00022FF8 File Offset: 0x000211F8
		public static TypeCode GetTypeCode(object value)
		{
			if (value == null)
			{
				return TypeCode.Empty;
			}
			return Type.GetTypeCode(value.GetType());
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x00023010 File Offset: 0x00021210
		public static int ToBase64CharArray(byte[] inArray, int offsetIn, int length, char[] outArray, int offsetOut)
		{
			if (inArray == null)
			{
				throw new ArgumentNullException("inArray");
			}
			if (outArray == null)
			{
				throw new ArgumentNullException("outArray");
			}
			if (offsetIn < 0 || length < 0 || offsetOut < 0)
			{
				throw new ArgumentOutOfRangeException("offsetIn, length, offsetOut < 0");
			}
			if (offsetIn > inArray.Length - length)
			{
				throw new ArgumentOutOfRangeException("offsetIn + length > array.Length");
			}
			byte[] array = ToBase64Transform.InternalTransformFinalBlock(inArray, offsetIn, length);
			char[] chars = new ASCIIEncoding().GetChars(array);
			if (offsetOut > outArray.Length - chars.Length)
			{
				throw new ArgumentOutOfRangeException("offsetOut + cOutArr.Length > outArray.Length");
			}
			Array.Copy(chars, 0, outArray, offsetOut, chars.Length);
			return chars.Length;
		}

		// Token: 0x06000818 RID: 2072 RVA: 0x000230B4 File Offset: 0x000212B4
		public static string ToBase64String(byte[] inArray)
		{
			if (inArray == null)
			{
				throw new ArgumentNullException("inArray");
			}
			return Convert.ToBase64String(inArray, 0, inArray.Length);
		}

		// Token: 0x06000819 RID: 2073 RVA: 0x000230D4 File Offset: 0x000212D4
		public static string ToBase64String(byte[] inArray, int offset, int length)
		{
			if (inArray == null)
			{
				throw new ArgumentNullException("inArray");
			}
			if (offset < 0 || length < 0)
			{
				throw new ArgumentOutOfRangeException("offset < 0 || length < 0");
			}
			if (offset > inArray.Length - length)
			{
				throw new ArgumentOutOfRangeException("offset + length > array.Length");
			}
			byte[] array = ToBase64Transform.InternalTransformFinalBlock(inArray, offset, length);
			return new ASCIIEncoding().GetString(array);
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x00023138 File Offset: 0x00021338
		public static bool ToBoolean(byte value)
		{
			return value != 0;
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x00023144 File Offset: 0x00021344
		public static bool ToBoolean(decimal value)
		{
			return value != 0m;
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x00023154 File Offset: 0x00021354
		public static bool ToBoolean(double value)
		{
			return value != 0.0;
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x00023168 File Offset: 0x00021368
		public static bool ToBoolean(float value)
		{
			return value != 0f;
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x00023178 File Offset: 0x00021378
		public static bool ToBoolean(int value)
		{
			return value != 0;
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x00023184 File Offset: 0x00021384
		public static bool ToBoolean(long value)
		{
			return value != 0L;
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x00023190 File Offset: 0x00021390
		[CLSCompliant(false)]
		public static bool ToBoolean(sbyte value)
		{
			return (int)value != 0;
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x0002319C File Offset: 0x0002139C
		public static bool ToBoolean(short value)
		{
			return value != 0;
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x000231A8 File Offset: 0x000213A8
		public static bool ToBoolean(string value, IFormatProvider provider)
		{
			return value != null && bool.Parse(value);
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x000231B8 File Offset: 0x000213B8
		[CLSCompliant(false)]
		public static bool ToBoolean(uint value)
		{
			return value != 0U;
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x000231C4 File Offset: 0x000213C4
		[CLSCompliant(false)]
		public static bool ToBoolean(ulong value)
		{
			return value != 0UL;
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x000231D0 File Offset: 0x000213D0
		[CLSCompliant(false)]
		public static bool ToBoolean(ushort value)
		{
			return value != 0;
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x000231DC File Offset: 0x000213DC
		public static bool ToBoolean(object value)
		{
			return value != null && Convert.ToBoolean(value, null);
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x000231F0 File Offset: 0x000213F0
		public static bool ToBoolean(object value, IFormatProvider provider)
		{
			return value != null && ((IConvertible)value).ToBoolean(provider);
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x00023208 File Offset: 0x00021408
		public static byte ToByte(bool value)
		{
			return (!value) ? 0 : 1;
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00023218 File Offset: 0x00021418
		public static byte ToByte(char value)
		{
			if (value > 'ÿ')
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue"));
			}
			return (byte)value;
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x00023238 File Offset: 0x00021438
		public static byte ToByte(decimal value)
		{
			if (value > 255m || value < 0m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue or less than Byte.MinValue"));
			}
			return (byte)Math.Round(value);
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x00023288 File Offset: 0x00021488
		public static byte ToByte(double value)
		{
			if (value > 255.0 || value < 0.0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue or less than Byte.MinValue"));
			}
			if (double.IsNaN(value) || double.IsInfinity(value))
			{
				throw new OverflowException(Locale.GetText("Value is equal to Double.NaN, Double.PositiveInfinity, or Double.NegativeInfinity"));
			}
			return (byte)Math.Round(value);
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x000232F0 File Offset: 0x000214F0
		public static byte ToByte(float value)
		{
			if (value > 255f || value < 0f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue or less than Byte.Minalue"));
			}
			if (float.IsNaN(value) || float.IsInfinity(value))
			{
				throw new OverflowException(Locale.GetText("Value is equal to Single.NaN, Single.PositiveInfinity, or Single.NegativeInfinity"));
			}
			return (byte)Math.Round((double)value);
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x00023354 File Offset: 0x00021554
		public static byte ToByte(int value)
		{
			if (value > 255 || value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue or less than Byte.MinValue"));
			}
			return (byte)value;
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x0002337C File Offset: 0x0002157C
		public static byte ToByte(long value)
		{
			if (value > 255L || value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue or less than Byte.MinValue"));
			}
			return (byte)value;
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x000233A4 File Offset: 0x000215A4
		[CLSCompliant(false)]
		public static byte ToByte(sbyte value)
		{
			if ((int)value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is less than Byte.MinValue"));
			}
			return (byte)value;
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x000233C0 File Offset: 0x000215C0
		public static byte ToByte(short value)
		{
			if (value > 255 || value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue or less than Byte.MinValue"));
			}
			return (byte)value;
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x000233E8 File Offset: 0x000215E8
		public static byte ToByte(string value)
		{
			if (value == null)
			{
				return 0;
			}
			return byte.Parse(value);
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x000233F8 File Offset: 0x000215F8
		public static byte ToByte(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return byte.Parse(value, provider);
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x0002340C File Offset: 0x0002160C
		public static byte ToByte(string value, int fromBase)
		{
			int num = Convert.ConvertFromBase(value, fromBase, true);
			if (num < 0 || num > 255)
			{
				throw new OverflowException();
			}
			return (byte)num;
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x0002343C File Offset: 0x0002163C
		[CLSCompliant(false)]
		public static byte ToByte(uint value)
		{
			if (value > 255U)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue"));
			}
			return (byte)value;
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x0002345C File Offset: 0x0002165C
		[CLSCompliant(false)]
		public static byte ToByte(ulong value)
		{
			if (value > 255UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue"));
			}
			return (byte)value;
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x0002347C File Offset: 0x0002167C
		[CLSCompliant(false)]
		public static byte ToByte(ushort value)
		{
			if (value > 255)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Byte.MaxValue"));
			}
			return (byte)value;
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x0002349C File Offset: 0x0002169C
		public static byte ToByte(object value)
		{
			if (value == null)
			{
				return 0;
			}
			return Convert.ToByte(value, null);
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x000234B0 File Offset: 0x000216B0
		public static byte ToByte(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return ((IConvertible)value).ToByte(provider);
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x000234C8 File Offset: 0x000216C8
		public static char ToChar(byte value)
		{
			return (char)value;
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x000234CC File Offset: 0x000216CC
		public static char ToChar(int value)
		{
			if (value > 65535 || value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Char.MaxValue or less than Char.MinValue"));
			}
			return (char)value;
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x000234F4 File Offset: 0x000216F4
		public static char ToChar(long value)
		{
			if (value > 65535L || value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Char.MaxValue or less than Char.MinValue"));
			}
			return (char)value;
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x0002351C File Offset: 0x0002171C
		public static char ToChar(float value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x00023528 File Offset: 0x00021728
		[CLSCompliant(false)]
		public static char ToChar(sbyte value)
		{
			if ((int)value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is less than Char.MinValue"));
			}
			return (char)value;
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x00023544 File Offset: 0x00021744
		public static char ToChar(short value)
		{
			if (value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is less than Char.MinValue"));
			}
			return (char)value;
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x00023560 File Offset: 0x00021760
		public static char ToChar(string value, IFormatProvider provider)
		{
			return char.Parse(value);
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x00023568 File Offset: 0x00021768
		[CLSCompliant(false)]
		public static char ToChar(uint value)
		{
			if (value > 65535U)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Char.MaxValue"));
			}
			return (char)value;
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x00023588 File Offset: 0x00021788
		[CLSCompliant(false)]
		public static char ToChar(ulong value)
		{
			if (value > 65535UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Char.MaxValue"));
			}
			return (char)value;
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x000235A8 File Offset: 0x000217A8
		[CLSCompliant(false)]
		public static char ToChar(ushort value)
		{
			return (char)value;
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x000235AC File Offset: 0x000217AC
		public static char ToChar(object value)
		{
			if (value == null)
			{
				return '\0';
			}
			return Convert.ToChar(value, null);
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x000235C0 File Offset: 0x000217C0
		public static char ToChar(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return '\0';
			}
			return ((IConvertible)value).ToChar(provider);
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x000235D8 File Offset: 0x000217D8
		public static DateTime ToDateTime(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return DateTime.MinValue;
			}
			return DateTime.Parse(value, provider);
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x000235F0 File Offset: 0x000217F0
		public static DateTime ToDateTime(short value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x000235FC File Offset: 0x000217FC
		public static DateTime ToDateTime(int value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00023608 File Offset: 0x00021808
		public static DateTime ToDateTime(long value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00023614 File Offset: 0x00021814
		public static DateTime ToDateTime(float value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x00023620 File Offset: 0x00021820
		public static DateTime ToDateTime(object value)
		{
			if (value == null)
			{
				return DateTime.MinValue;
			}
			return Convert.ToDateTime(value, null);
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00023638 File Offset: 0x00021838
		public static DateTime ToDateTime(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return DateTime.MinValue;
			}
			return ((IConvertible)value).ToDateTime(provider);
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00023654 File Offset: 0x00021854
		[CLSCompliant(false)]
		public static DateTime ToDateTime(sbyte value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x00023660 File Offset: 0x00021860
		[CLSCompliant(false)]
		public static DateTime ToDateTime(ushort value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x0002366C File Offset: 0x0002186C
		[CLSCompliant(false)]
		public static DateTime ToDateTime(uint value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x00023678 File Offset: 0x00021878
		[CLSCompliant(false)]
		public static DateTime ToDateTime(ulong value)
		{
			throw new InvalidCastException("This conversion is not supported.");
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00023684 File Offset: 0x00021884
		public static decimal ToDecimal(bool value)
		{
			return (!value) ? 0 : 1;
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x00023698 File Offset: 0x00021898
		public static decimal ToDecimal(byte value)
		{
			return value;
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x000236A0 File Offset: 0x000218A0
		public static decimal ToDecimal(double value)
		{
			return (decimal)value;
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x000236A8 File Offset: 0x000218A8
		public static decimal ToDecimal(float value)
		{
			return (decimal)value;
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x000236B0 File Offset: 0x000218B0
		public static decimal ToDecimal(int value)
		{
			return value;
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x000236B8 File Offset: 0x000218B8
		public static decimal ToDecimal(long value)
		{
			return value;
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x000236C0 File Offset: 0x000218C0
		[CLSCompliant(false)]
		public static decimal ToDecimal(sbyte value)
		{
			return value;
		}

		// Token: 0x06000857 RID: 2135 RVA: 0x000236C8 File Offset: 0x000218C8
		public static decimal ToDecimal(short value)
		{
			return value;
		}

		// Token: 0x06000858 RID: 2136 RVA: 0x000236D0 File Offset: 0x000218D0
		public static decimal ToDecimal(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0m;
			}
			return decimal.Parse(value, provider);
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x000236E8 File Offset: 0x000218E8
		[CLSCompliant(false)]
		public static decimal ToDecimal(uint value)
		{
			return value;
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x000236F0 File Offset: 0x000218F0
		[CLSCompliant(false)]
		public static decimal ToDecimal(ulong value)
		{
			return value;
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x000236F8 File Offset: 0x000218F8
		[CLSCompliant(false)]
		public static decimal ToDecimal(ushort value)
		{
			return value;
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x00023700 File Offset: 0x00021900
		public static decimal ToDecimal(object value)
		{
			if (value == null)
			{
				return 0m;
			}
			return Convert.ToDecimal(value, null);
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x00023718 File Offset: 0x00021918
		public static decimal ToDecimal(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0m;
			}
			return ((IConvertible)value).ToDecimal(provider);
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x00023734 File Offset: 0x00021934
		public static double ToDouble(bool value)
		{
			return (double)((!value) ? 0 : 1);
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00023744 File Offset: 0x00021944
		public static double ToDouble(byte value)
		{
			return (double)value;
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x00023748 File Offset: 0x00021948
		public static double ToDouble(decimal value)
		{
			return (double)value;
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x00023750 File Offset: 0x00021950
		public static double ToDouble(double value)
		{
			return value;
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x00023754 File Offset: 0x00021954
		public static double ToDouble(float value)
		{
			return (double)value;
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x00023758 File Offset: 0x00021958
		public static double ToDouble(int value)
		{
			return (double)value;
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x0002375C File Offset: 0x0002195C
		public static double ToDouble(long value)
		{
			return (double)value;
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x00023760 File Offset: 0x00021960
		[CLSCompliant(false)]
		public static double ToDouble(sbyte value)
		{
			return (double)value;
		}

		// Token: 0x06000866 RID: 2150 RVA: 0x00023764 File Offset: 0x00021964
		public static double ToDouble(short value)
		{
			return (double)value;
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x00023768 File Offset: 0x00021968
		public static double ToDouble(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0.0;
			}
			return double.Parse(value, provider);
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x00023784 File Offset: 0x00021984
		[CLSCompliant(false)]
		public static double ToDouble(uint value)
		{
			return value;
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x0002378C File Offset: 0x0002198C
		[CLSCompliant(false)]
		public static double ToDouble(ulong value)
		{
			return value;
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x00023794 File Offset: 0x00021994
		[CLSCompliant(false)]
		public static double ToDouble(ushort value)
		{
			return (double)value;
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x00023798 File Offset: 0x00021998
		public static double ToDouble(object value)
		{
			if (value == null)
			{
				return 0.0;
			}
			return Convert.ToDouble(value, null);
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x000237B4 File Offset: 0x000219B4
		public static double ToDouble(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0.0;
			}
			return ((IConvertible)value).ToDouble(provider);
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x000237D4 File Offset: 0x000219D4
		public static short ToInt16(bool value)
		{
			return (!value) ? 0 : 1;
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x000237E4 File Offset: 0x000219E4
		public static short ToInt16(byte value)
		{
			return (short)value;
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x000237E8 File Offset: 0x000219E8
		public static short ToInt16(char value)
		{
			if (value > '翿')
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue"));
			}
			return (short)value;
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x00023808 File Offset: 0x00021A08
		public static short ToInt16(decimal value)
		{
			if (value > 32767m || value < -32768m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue or less than Int16.MinValue"));
			}
			return (short)Math.Round(value);
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x0002385C File Offset: 0x00021A5C
		public static short ToInt16(double value)
		{
			if (value > 32767.0 || value < -32768.0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue or less than Int16.MinValue"));
			}
			return (short)Math.Round(value);
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00023894 File Offset: 0x00021A94
		public static short ToInt16(float value)
		{
			if (value > 32767f || value < -32768f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue or less than Int16.MinValue"));
			}
			return (short)Math.Round((double)value);
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x000238C4 File Offset: 0x00021AC4
		public static short ToInt16(int value)
		{
			if (value > 32767 || value < -32768)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue or less than Int16.MinValue"));
			}
			return (short)value;
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x000238F0 File Offset: 0x00021AF0
		public static short ToInt16(long value)
		{
			if (value > 32767L || value < -32768L)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue or less than Int16.MinValue"));
			}
			return (short)value;
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x0002391C File Offset: 0x00021B1C
		[CLSCompliant(false)]
		public static short ToInt16(sbyte value)
		{
			return (short)value;
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x00023920 File Offset: 0x00021B20
		public static short ToInt16(short value)
		{
			return value;
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x00023924 File Offset: 0x00021B24
		public static short ToInt16(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return short.Parse(value, provider);
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x00023938 File Offset: 0x00021B38
		public static short ToInt16(string value, int fromBase)
		{
			int num = Convert.ConvertFromBase(value, fromBase, false);
			if (fromBase != 10)
			{
				if (num > 65535)
				{
					throw new OverflowException("Value was either too large or too small for an Int16.");
				}
				if (num > 32767)
				{
					return Convert.ToInt16(-(65536 - num));
				}
			}
			return Convert.ToInt16(num);
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x0002398C File Offset: 0x00021B8C
		[CLSCompliant(false)]
		public static short ToInt16(uint value)
		{
			if ((ulong)value > 32767UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue"));
			}
			return (short)value;
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x000239B0 File Offset: 0x00021BB0
		[CLSCompliant(false)]
		public static short ToInt16(ulong value)
		{
			if (value > 32767UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue"));
			}
			return (short)value;
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x000239D0 File Offset: 0x00021BD0
		[CLSCompliant(false)]
		public static short ToInt16(ushort value)
		{
			if (value > 32767)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int16.MaxValue"));
			}
			return (short)value;
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x000239F0 File Offset: 0x00021BF0
		public static short ToInt16(object value)
		{
			if (value == null)
			{
				return 0;
			}
			return Convert.ToInt16(value, null);
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00023A04 File Offset: 0x00021C04
		public static short ToInt16(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return ((IConvertible)value).ToInt16(provider);
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x00023A1C File Offset: 0x00021C1C
		public static int ToInt32(bool value)
		{
			return (!value) ? 0 : 1;
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x00023A2C File Offset: 0x00021C2C
		public static int ToInt32(byte value)
		{
			return (int)value;
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00023A30 File Offset: 0x00021C30
		public static int ToInt32(char value)
		{
			return (int)value;
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x00023A34 File Offset: 0x00021C34
		public static int ToInt32(decimal value)
		{
			if (value > 2147483647m || value < -2147483648m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int32.MaxValue or less than Int32.MinValue"));
			}
			return (int)Math.Round(value);
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x00023A88 File Offset: 0x00021C88
		public static int ToInt32(double value)
		{
			if (value > 2147483647.0 || value < -2147483648.0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int32.MaxValue or less than Int32.MinValue"));
			}
			return checked((int)Math.Round(value));
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x00023AC0 File Offset: 0x00021CC0
		public static int ToInt32(float value)
		{
			if (value > 2.1474836E+09f || value < -2.1474836E+09f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int32.MaxValue or less than Int32.MinValue"));
			}
			return checked((int)Math.Round((double)value));
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x00023AF0 File Offset: 0x00021CF0
		public static int ToInt32(long value)
		{
			if (value > 2147483647L || value < -2147483648L)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int32.MaxValue or less than Int32.MinValue"));
			}
			return (int)value;
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x00023B1C File Offset: 0x00021D1C
		[CLSCompliant(false)]
		public static int ToInt32(sbyte value)
		{
			return (int)value;
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x00023B20 File Offset: 0x00021D20
		public static int ToInt32(short value)
		{
			return (int)value;
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x00023B24 File Offset: 0x00021D24
		public static int ToInt32(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return int.Parse(value, provider);
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x00023B38 File Offset: 0x00021D38
		public static int ToInt32(string value, int fromBase)
		{
			return Convert.ConvertFromBase(value, fromBase, false);
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x00023B44 File Offset: 0x00021D44
		[CLSCompliant(false)]
		public static int ToInt32(uint value)
		{
			if (value > 2147483647U)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int32.MaxValue"));
			}
			return (int)value;
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x00023B64 File Offset: 0x00021D64
		[CLSCompliant(false)]
		public static int ToInt32(ulong value)
		{
			if (value > 2147483647UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int32.MaxValue"));
			}
			return (int)value;
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x00023B84 File Offset: 0x00021D84
		[CLSCompliant(false)]
		public static int ToInt32(ushort value)
		{
			return (int)value;
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x00023B88 File Offset: 0x00021D88
		public static int ToInt32(object value)
		{
			if (value == null)
			{
				return 0;
			}
			return Convert.ToInt32(value, null);
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x00023B9C File Offset: 0x00021D9C
		public static int ToInt32(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return ((IConvertible)value).ToInt32(provider);
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x00023BB4 File Offset: 0x00021DB4
		public static long ToInt64(bool value)
		{
			return (!value) ? 0L : 1L;
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x00023BC4 File Offset: 0x00021DC4
		public static long ToInt64(byte value)
		{
			return (long)((ulong)value);
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x00023BC8 File Offset: 0x00021DC8
		public static long ToInt64(char value)
		{
			return (long)value;
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x00023BCC File Offset: 0x00021DCC
		public static long ToInt64(decimal value)
		{
			if (value > 9223372036854775807m || value < -9223372036854775808m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int64.MaxValue or less than Int64.MinValue"));
			}
			return (long)Math.Round(value);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x00023C28 File Offset: 0x00021E28
		public static long ToInt64(double value)
		{
			if (value > 9.223372036854776E+18 || value < -9.223372036854776E+18)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int64.MaxValue or less than Int64.MinValue"));
			}
			return (long)Math.Round(value);
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x00023C60 File Offset: 0x00021E60
		public static long ToInt64(float value)
		{
			if (value > 9.223372E+18f || value < -9.223372E+18f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int64.MaxValue or less than Int64.MinValue"));
			}
			return (long)Math.Round((double)value);
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x00023C90 File Offset: 0x00021E90
		public static long ToInt64(int value)
		{
			return (long)value;
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x00023C94 File Offset: 0x00021E94
		public static long ToInt64(long value)
		{
			return value;
		}

		// Token: 0x06000896 RID: 2198 RVA: 0x00023C98 File Offset: 0x00021E98
		[CLSCompliant(false)]
		public static long ToInt64(sbyte value)
		{
			return (long)value;
		}

		// Token: 0x06000897 RID: 2199 RVA: 0x00023C9C File Offset: 0x00021E9C
		public static long ToInt64(short value)
		{
			return (long)value;
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x00023CA0 File Offset: 0x00021EA0
		public static long ToInt64(string value)
		{
			if (value == null)
			{
				return 0L;
			}
			return long.Parse(value);
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x00023CB4 File Offset: 0x00021EB4
		public static long ToInt64(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0L;
			}
			return long.Parse(value, provider);
		}

		// Token: 0x0600089A RID: 2202 RVA: 0x00023CC8 File Offset: 0x00021EC8
		public static long ToInt64(string value, int fromBase)
		{
			return Convert.ConvertFromBase64(value, fromBase, false);
		}

		// Token: 0x0600089B RID: 2203 RVA: 0x00023CD4 File Offset: 0x00021ED4
		[CLSCompliant(false)]
		public static long ToInt64(uint value)
		{
			return (long)((ulong)value);
		}

		// Token: 0x0600089C RID: 2204 RVA: 0x00023CD8 File Offset: 0x00021ED8
		[CLSCompliant(false)]
		public static long ToInt64(ulong value)
		{
			if (value > 9223372036854775807UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than Int64.MaxValue"));
			}
			return (long)value;
		}

		// Token: 0x0600089D RID: 2205 RVA: 0x00023CFC File Offset: 0x00021EFC
		[CLSCompliant(false)]
		public static long ToInt64(ushort value)
		{
			return (long)((ulong)value);
		}

		// Token: 0x0600089E RID: 2206 RVA: 0x00023D00 File Offset: 0x00021F00
		public static long ToInt64(object value)
		{
			if (value == null)
			{
				return 0L;
			}
			return Convert.ToInt64(value, null);
		}

		// Token: 0x0600089F RID: 2207 RVA: 0x00023D14 File Offset: 0x00021F14
		public static long ToInt64(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0L;
			}
			return ((IConvertible)value).ToInt64(provider);
		}

		// Token: 0x060008A0 RID: 2208 RVA: 0x00023D2C File Offset: 0x00021F2C
		[CLSCompliant(false)]
		public static sbyte ToSByte(bool value)
		{
			return (!value) ? 0 : 1;
		}

		// Token: 0x060008A1 RID: 2209 RVA: 0x00023D3C File Offset: 0x00021F3C
		[CLSCompliant(false)]
		public static sbyte ToSByte(byte value)
		{
			if (value > 127)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008A2 RID: 2210 RVA: 0x00023D58 File Offset: 0x00021F58
		[CLSCompliant(false)]
		public static sbyte ToSByte(char value)
		{
			if (value > '\u007f')
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008A3 RID: 2211 RVA: 0x00023D74 File Offset: 0x00021F74
		[CLSCompliant(false)]
		public static sbyte ToSByte(decimal value)
		{
			if (value > 127m || value < -128m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue or less than SByte.MinValue"));
			}
			return (sbyte)Math.Round(value);
		}

		// Token: 0x060008A4 RID: 2212 RVA: 0x00023DC0 File Offset: 0x00021FC0
		[CLSCompliant(false)]
		public static sbyte ToSByte(double value)
		{
			if (value > 127.0 || value < -128.0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue or less than SByte.MinValue"));
			}
			return (sbyte)Math.Round(value);
		}

		// Token: 0x060008A5 RID: 2213 RVA: 0x00023DF8 File Offset: 0x00021FF8
		[CLSCompliant(false)]
		public static sbyte ToSByte(float value)
		{
			if (value > 127f || value < -128f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue or less than SByte.Minalue"));
			}
			return (sbyte)Math.Round((double)value);
		}

		// Token: 0x060008A6 RID: 2214 RVA: 0x00023E28 File Offset: 0x00022028
		[CLSCompliant(false)]
		public static sbyte ToSByte(int value)
		{
			if (value > 127 || value < -128)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue or less than SByte.MinValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008A7 RID: 2215 RVA: 0x00023E4C File Offset: 0x0002204C
		[CLSCompliant(false)]
		public static sbyte ToSByte(long value)
		{
			if (value > 127L || value < -128L)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue or less than SByte.MinValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008A8 RID: 2216 RVA: 0x00023E74 File Offset: 0x00022074
		[CLSCompliant(false)]
		public static sbyte ToSByte(short value)
		{
			if (value > 127 || value < -128)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue or less than SByte.MinValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008A9 RID: 2217 RVA: 0x00023E98 File Offset: 0x00022098
		[CLSCompliant(false)]
		public static sbyte ToSByte(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			return sbyte.Parse(value, provider);
		}

		// Token: 0x060008AA RID: 2218 RVA: 0x00023EB4 File Offset: 0x000220B4
		[CLSCompliant(false)]
		public static sbyte ToSByte(string value, int fromBase)
		{
			int num = Convert.ConvertFromBase(value, fromBase, false);
			if (fromBase != 10 && num > 127)
			{
				return Convert.ToSByte(-(256 - num));
			}
			return Convert.ToSByte(num);
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x00023EF0 File Offset: 0x000220F0
		[CLSCompliant(false)]
		public static sbyte ToSByte(uint value)
		{
			if ((ulong)value > 127UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008AC RID: 2220 RVA: 0x00023F10 File Offset: 0x00022110
		[CLSCompliant(false)]
		public static sbyte ToSByte(ulong value)
		{
			if (value > 127UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x00023F30 File Offset: 0x00022130
		[CLSCompliant(false)]
		public static sbyte ToSByte(ushort value)
		{
			if (value > 127)
			{
				throw new OverflowException(Locale.GetText("Value is greater than SByte.MaxValue"));
			}
			return (sbyte)value;
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x00023F4C File Offset: 0x0002214C
		[CLSCompliant(false)]
		public static sbyte ToSByte(object value)
		{
			if (value == null)
			{
				return 0;
			}
			return Convert.ToSByte(value, null);
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x00023F60 File Offset: 0x00022160
		[CLSCompliant(false)]
		public static sbyte ToSByte(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return ((IConvertible)value).ToSByte(provider);
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x00023F78 File Offset: 0x00022178
		public static float ToSingle(bool value)
		{
			return (float)((!value) ? 0 : 1);
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x00023F88 File Offset: 0x00022188
		public static float ToSingle(byte value)
		{
			return (float)value;
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x00023F8C File Offset: 0x0002218C
		public static float ToSingle(decimal value)
		{
			return (float)value;
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x00023F94 File Offset: 0x00022194
		public static float ToSingle(double value)
		{
			return (float)value;
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x00023F98 File Offset: 0x00022198
		public static float ToSingle(float value)
		{
			return value;
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00023F9C File Offset: 0x0002219C
		public static float ToSingle(int value)
		{
			return (float)value;
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x00023FA0 File Offset: 0x000221A0
		public static float ToSingle(long value)
		{
			return (float)value;
		}

		// Token: 0x060008B7 RID: 2231 RVA: 0x00023FA4 File Offset: 0x000221A4
		[CLSCompliant(false)]
		public static float ToSingle(sbyte value)
		{
			return (float)value;
		}

		// Token: 0x060008B8 RID: 2232 RVA: 0x00023FA8 File Offset: 0x000221A8
		public static float ToSingle(short value)
		{
			return (float)value;
		}

		// Token: 0x060008B9 RID: 2233 RVA: 0x00023FAC File Offset: 0x000221AC
		public static float ToSingle(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0f;
			}
			return float.Parse(value, provider);
		}

		// Token: 0x060008BA RID: 2234 RVA: 0x00023FC4 File Offset: 0x000221C4
		[CLSCompliant(false)]
		public static float ToSingle(uint value)
		{
			return value;
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x00023FCC File Offset: 0x000221CC
		[CLSCompliant(false)]
		public static float ToSingle(ulong value)
		{
			return value;
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x00023FD4 File Offset: 0x000221D4
		[CLSCompliant(false)]
		public static float ToSingle(ushort value)
		{
			return (float)value;
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x00023FD8 File Offset: 0x000221D8
		public static float ToSingle(object value)
		{
			if (value == null)
			{
				return 0f;
			}
			return Convert.ToSingle(value, null);
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x00023FF0 File Offset: 0x000221F0
		public static float ToSingle(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0f;
			}
			return ((IConvertible)value).ToSingle(provider);
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x0002400C File Offset: 0x0002220C
		public static string ToString(object value)
		{
			return Convert.ToString(value, null);
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x00024018 File Offset: 0x00022218
		public static string ToString(object value, IFormatProvider provider)
		{
			if (value is IConvertible)
			{
				return ((IConvertible)value).ToString(provider);
			}
			if (value != null)
			{
				return value.ToString();
			}
			return string.Empty;
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x00024044 File Offset: 0x00022244
		[CLSCompliant(false)]
		public static ushort ToUInt16(bool value)
		{
			return (!value) ? 0 : 1;
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x00024054 File Offset: 0x00022254
		[CLSCompliant(false)]
		public static ushort ToUInt16(byte value)
		{
			return (ushort)value;
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x00024058 File Offset: 0x00022258
		[CLSCompliant(false)]
		public static ushort ToUInt16(char value)
		{
			return (ushort)value;
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x0002405C File Offset: 0x0002225C
		[CLSCompliant(false)]
		public static ushort ToUInt16(decimal value)
		{
			if (value > 65535m || value < 0m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt16.MaxValue or less than UInt16.MinValue"));
			}
			return (ushort)Math.Round(value);
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x000240AC File Offset: 0x000222AC
		[CLSCompliant(false)]
		public static ushort ToUInt16(double value)
		{
			if (value > 65535.0 || value < 0.0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt16.MaxValue or less than UInt16.MinValue"));
			}
			return (ushort)Math.Round(value);
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x000240E4 File Offset: 0x000222E4
		[CLSCompliant(false)]
		public static ushort ToUInt16(float value)
		{
			if (value > 65535f || value < 0f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt16.MaxValue or less than UInt16.MinValue"));
			}
			return (ushort)Math.Round((double)value);
		}

		// Token: 0x060008C7 RID: 2247 RVA: 0x00024114 File Offset: 0x00022314
		[CLSCompliant(false)]
		public static ushort ToUInt16(int value)
		{
			if (value > 65535 || value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt16.MaxValue or less than UInt16.MinValue"));
			}
			return (ushort)value;
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x0002413C File Offset: 0x0002233C
		[CLSCompliant(false)]
		public static ushort ToUInt16(long value)
		{
			if (value > 65535L || value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt16.MaxValue or less than UInt16.MinValue"));
			}
			return (ushort)value;
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x00024164 File Offset: 0x00022364
		[CLSCompliant(false)]
		public static ushort ToUInt16(sbyte value)
		{
			if ((int)value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt16.MinValue"));
			}
			return (ushort)value;
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x00024180 File Offset: 0x00022380
		[CLSCompliant(false)]
		public static ushort ToUInt16(short value)
		{
			if (value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt16.MinValue"));
			}
			return (ushort)value;
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x0002419C File Offset: 0x0002239C
		[CLSCompliant(false)]
		public static ushort ToUInt16(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return ushort.Parse(value, provider);
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x000241B0 File Offset: 0x000223B0
		[CLSCompliant(false)]
		public static ushort ToUInt16(string value, int fromBase)
		{
			return Convert.ToUInt16(Convert.ConvertFromBase(value, fromBase, true));
		}

		// Token: 0x060008CD RID: 2253 RVA: 0x000241C0 File Offset: 0x000223C0
		[CLSCompliant(false)]
		public static ushort ToUInt16(uint value)
		{
			if (value > 65535U)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt16.MaxValue"));
			}
			return (ushort)value;
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x000241E0 File Offset: 0x000223E0
		[CLSCompliant(false)]
		public static ushort ToUInt16(ulong value)
		{
			if (value > 65535UL)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt16.MaxValue"));
			}
			return (ushort)value;
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x00024200 File Offset: 0x00022400
		[CLSCompliant(false)]
		public static ushort ToUInt16(object value)
		{
			if (value == null)
			{
				return 0;
			}
			return Convert.ToUInt16(value, null);
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x00024214 File Offset: 0x00022414
		[CLSCompliant(false)]
		public static ushort ToUInt16(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0;
			}
			return ((IConvertible)value).ToUInt16(provider);
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x0002422C File Offset: 0x0002242C
		[CLSCompliant(false)]
		public static uint ToUInt32(bool value)
		{
			return (!value) ? 0U : 1U;
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x0002423C File Offset: 0x0002243C
		[CLSCompliant(false)]
		public static uint ToUInt32(byte value)
		{
			return (uint)value;
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x00024240 File Offset: 0x00022440
		[CLSCompliant(false)]
		public static uint ToUInt32(char value)
		{
			return (uint)value;
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00024244 File Offset: 0x00022444
		[CLSCompliant(false)]
		public static uint ToUInt32(decimal value)
		{
			if (value > 4294967295m || value < 0m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt32.MaxValue or less than UInt32.MinValue"));
			}
			return (uint)Math.Round(value);
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x00024294 File Offset: 0x00022494
		[CLSCompliant(false)]
		public static uint ToUInt32(double value)
		{
			if (value > 4294967295.0 || value < 0.0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt32.MaxValue or less than UInt32.MinValue"));
			}
			return (uint)Math.Round(value);
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x000242CC File Offset: 0x000224CC
		[CLSCompliant(false)]
		public static uint ToUInt32(float value)
		{
			if (value > 4.2949673E+09f || value < 0f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt32.MaxValue or less than UInt32.MinValue"));
			}
			return (uint)Math.Round((double)value);
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x000242FC File Offset: 0x000224FC
		[CLSCompliant(false)]
		public static uint ToUInt32(int value)
		{
			if ((long)value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt32.MinValue"));
			}
			return (uint)value;
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x00024318 File Offset: 0x00022518
		[CLSCompliant(false)]
		public static uint ToUInt32(long value)
		{
			if (value > (long)((ulong)(-1)) || value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt32.MaxValue or less than UInt32.MinValue"));
			}
			return (uint)value;
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x0002433C File Offset: 0x0002253C
		[CLSCompliant(false)]
		public static uint ToUInt32(sbyte value)
		{
			if ((long)value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt32.MinValue"));
			}
			return (uint)value;
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x0002435C File Offset: 0x0002255C
		[CLSCompliant(false)]
		public static uint ToUInt32(short value)
		{
			if ((long)value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt32.MinValue"));
			}
			return (uint)value;
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x0002437C File Offset: 0x0002257C
		[CLSCompliant(false)]
		public static uint ToUInt32(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0U;
			}
			return uint.Parse(value, provider);
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x00024390 File Offset: 0x00022590
		[CLSCompliant(false)]
		public static uint ToUInt32(string value, int fromBase)
		{
			return (uint)Convert.ConvertFromBase(value, fromBase, true);
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x0002439C File Offset: 0x0002259C
		[CLSCompliant(false)]
		public static uint ToUInt32(ulong value)
		{
			if (value > (ulong)(-1))
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt32.MaxValue"));
			}
			return (uint)value;
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x000243B8 File Offset: 0x000225B8
		[CLSCompliant(false)]
		public static uint ToUInt32(ushort value)
		{
			return (uint)value;
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x000243BC File Offset: 0x000225BC
		[CLSCompliant(false)]
		public static uint ToUInt32(object value)
		{
			if (value == null)
			{
				return 0U;
			}
			return Convert.ToUInt32(value, null);
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x000243D0 File Offset: 0x000225D0
		[CLSCompliant(false)]
		public static uint ToUInt32(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0U;
			}
			return ((IConvertible)value).ToUInt32(provider);
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x000243E8 File Offset: 0x000225E8
		[CLSCompliant(false)]
		public static ulong ToUInt64(bool value)
		{
			return (ulong)((!value) ? 0L : 1L);
		}

		// Token: 0x060008E2 RID: 2274 RVA: 0x000243F8 File Offset: 0x000225F8
		[CLSCompliant(false)]
		public static ulong ToUInt64(byte value)
		{
			return (ulong)value;
		}

		// Token: 0x060008E3 RID: 2275 RVA: 0x000243FC File Offset: 0x000225FC
		[CLSCompliant(false)]
		public static ulong ToUInt64(char value)
		{
			return (ulong)value;
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x00024400 File Offset: 0x00022600
		[CLSCompliant(false)]
		public static ulong ToUInt64(decimal value)
		{
			if (value > 18446744073709551615m || value < 0m)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt64.MaxValue or less than UInt64.MinValue"));
			}
			return (ulong)Math.Round(value);
		}

		// Token: 0x060008E5 RID: 2277 RVA: 0x00024450 File Offset: 0x00022650
		[CLSCompliant(false)]
		public static ulong ToUInt64(double value)
		{
			if (value > 1.8446744073709552E+19 || value < 0.0)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt64.MaxValue or less than UInt64.MinValue"));
			}
			return (ulong)Math.Round(value);
		}

		// Token: 0x060008E6 RID: 2278 RVA: 0x00024488 File Offset: 0x00022688
		[CLSCompliant(false)]
		public static ulong ToUInt64(float value)
		{
			if (value > 1.8446744E+19f || value < 0f)
			{
				throw new OverflowException(Locale.GetText("Value is greater than UInt64.MaxValue or less than UInt64.MinValue"));
			}
			return (ulong)Math.Round((double)value);
		}

		// Token: 0x060008E7 RID: 2279 RVA: 0x000244B8 File Offset: 0x000226B8
		[CLSCompliant(false)]
		public static ulong ToUInt64(int value)
		{
			if (value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt64.MinValue"));
			}
			return (ulong)((long)value);
		}

		// Token: 0x060008E8 RID: 2280 RVA: 0x000244D4 File Offset: 0x000226D4
		[CLSCompliant(false)]
		public static ulong ToUInt64(long value)
		{
			if (value < 0L)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt64.MinValue"));
			}
			return (ulong)value;
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x000244F0 File Offset: 0x000226F0
		[CLSCompliant(false)]
		public static ulong ToUInt64(sbyte value)
		{
			if ((int)value < 0)
			{
				throw new OverflowException("Value is less than UInt64.MinValue");
			}
			return (ulong)((long)value);
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x00024508 File Offset: 0x00022708
		[CLSCompliant(false)]
		public static ulong ToUInt64(short value)
		{
			if (value < 0)
			{
				throw new OverflowException(Locale.GetText("Value is less than UInt64.MinValue"));
			}
			return (ulong)((long)value);
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x00024524 File Offset: 0x00022724
		[CLSCompliant(false)]
		public static ulong ToUInt64(string value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0UL;
			}
			return ulong.Parse(value, provider);
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x00024538 File Offset: 0x00022738
		[CLSCompliant(false)]
		public static ulong ToUInt64(string value, int fromBase)
		{
			return (ulong)Convert.ConvertFromBase64(value, fromBase, true);
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x00024544 File Offset: 0x00022744
		[CLSCompliant(false)]
		public static ulong ToUInt64(uint value)
		{
			return (ulong)value;
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x00024548 File Offset: 0x00022748
		[CLSCompliant(false)]
		public static ulong ToUInt64(ushort value)
		{
			return (ulong)value;
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x0002454C File Offset: 0x0002274C
		[CLSCompliant(false)]
		public static ulong ToUInt64(object value)
		{
			if (value == null)
			{
				return 0UL;
			}
			return Convert.ToUInt64(value, null);
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x00024560 File Offset: 0x00022760
		[CLSCompliant(false)]
		public static ulong ToUInt64(object value, IFormatProvider provider)
		{
			if (value == null)
			{
				return 0UL;
			}
			return ((IConvertible)value).ToUInt64(provider);
		}

		// Token: 0x060008F1 RID: 2289 RVA: 0x00024578 File Offset: 0x00022778
		public static object ChangeType(object value, Type conversionType)
		{
			if (value != null && conversionType == null)
			{
				throw new ArgumentNullException("conversionType");
			}
			CultureInfo currentCulture = CultureInfo.CurrentCulture;
			IFormatProvider formatProvider;
			if (conversionType == typeof(DateTime))
			{
				formatProvider = currentCulture.DateTimeFormat;
			}
			else
			{
				formatProvider = currentCulture.NumberFormat;
			}
			return Convert.ToType(value, conversionType, formatProvider, true);
		}

		// Token: 0x060008F2 RID: 2290 RVA: 0x000245D0 File Offset: 0x000227D0
		public static object ChangeType(object value, TypeCode typeCode)
		{
			CultureInfo currentCulture = CultureInfo.CurrentCulture;
			Type type = Convert.conversionTable[(int)typeCode];
			IFormatProvider formatProvider;
			if (type == typeof(DateTime))
			{
				formatProvider = currentCulture.DateTimeFormat;
			}
			else
			{
				formatProvider = currentCulture.NumberFormat;
			}
			return Convert.ToType(value, type, formatProvider, true);
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x00024618 File Offset: 0x00022818
		public static object ChangeType(object value, Type conversionType, IFormatProvider provider)
		{
			if (value != null && conversionType == null)
			{
				throw new ArgumentNullException("conversionType");
			}
			return Convert.ToType(value, conversionType, provider, true);
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x0002463C File Offset: 0x0002283C
		public static object ChangeType(object value, TypeCode typeCode, IFormatProvider provider)
		{
			Type type = Convert.conversionTable[(int)typeCode];
			return Convert.ToType(value, type, provider, true);
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x0002465C File Offset: 0x0002285C
		private static bool NotValidBase(int value)
		{
			return value != 2 && value != 8 && value != 10 && value != 16;
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x00024680 File Offset: 0x00022880
		private static int ConvertFromBase(string value, int fromBase, bool unsigned)
		{
			if (Convert.NotValidBase(fromBase))
			{
				throw new ArgumentException("fromBase is not valid.");
			}
			if (value == null)
			{
				return 0;
			}
			int num = 0;
			int num2 = 0;
			int i = 0;
			int length = value.Length;
			bool flag = false;
			if (fromBase != 10)
			{
				if (fromBase != 16)
				{
					if (value.Substring(i, 1) == "-")
					{
						throw new ArgumentException("String cannot contain a minus sign if the base is not 10.");
					}
				}
				else
				{
					if (value.Substring(i, 1) == "-")
					{
						throw new ArgumentException("String cannot contain a minus sign if the base is not 10.");
					}
					if (length >= i + 2 && value[i] == '0' && (value[i + 1] == 'x' || value[i + 1] == 'X'))
					{
						i += 2;
					}
				}
			}
			else if (value.Substring(i, 1) == "-")
			{
				if (unsigned)
				{
					throw new OverflowException(Locale.GetText("The string was being parsed as an unsigned number and could not have a negative sign."));
				}
				flag = true;
				i++;
			}
			if (length == i)
			{
				throw new FormatException("Could not find any parsable digits.");
			}
			if (value[i] == '+')
			{
				i++;
			}
			while (i < length)
			{
				char c = value[i++];
				int num3;
				if (char.IsNumber(c))
				{
					num3 = (int)(c - '0');
				}
				else if (char.IsLetter(c))
				{
					num3 = (int)(char.ToLowerInvariant(c) - 'a' + '\n');
				}
				else
				{
					if (num > 0)
					{
						throw new FormatException("Additional unparsable characters are at the end of the string.");
					}
					throw new FormatException("Could not find any parsable digits.");
				}
				if (num3 >= fromBase)
				{
					if (num > 0)
					{
						throw new FormatException("Additional unparsable characters are at the end of the string.");
					}
					throw new FormatException("Could not find any parsable digits.");
				}
				else
				{
					num2 = fromBase * num2 + num3;
					num++;
				}
			}
			if (num == 0)
			{
				throw new FormatException("Could not find any parsable digits.");
			}
			if (flag)
			{
				return -num2;
			}
			return num2;
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x00024878 File Offset: 0x00022A78
		private static long ConvertFromBase64(string value, int fromBase, bool unsigned)
		{
			if (Convert.NotValidBase(fromBase))
			{
				throw new ArgumentException("fromBase is not valid.");
			}
			if (value == null)
			{
				return 0L;
			}
			int num = 0;
			long num2 = 0L;
			bool flag = false;
			int i = 0;
			int length = value.Length;
			if (fromBase != 10)
			{
				if (fromBase != 16)
				{
					if (value.Substring(i, 1) == "-")
					{
						throw new ArgumentException("String cannot contain a minus sign if the base is not 10.");
					}
				}
				else
				{
					if (value.Substring(i, 1) == "-")
					{
						throw new ArgumentException("String cannot contain a minus sign if the base is not 10.");
					}
					if (length >= i + 2 && value[i] == '0' && (value[i + 1] == 'x' || value[i + 1] == 'X'))
					{
						i += 2;
					}
				}
			}
			else if (value.Substring(i, 1) == "-")
			{
				if (unsigned)
				{
					throw new OverflowException(Locale.GetText("The string was being parsed as an unsigned number and could not have a negative sign."));
				}
				flag = true;
				i++;
			}
			if (length == i)
			{
				throw new FormatException("Could not find any parsable digits.");
			}
			if (value[i] == '+')
			{
				i++;
			}
			while (i < length)
			{
				char c = value[i++];
				int num3;
				if (char.IsNumber(c))
				{
					num3 = (int)(c - '0');
				}
				else if (char.IsLetter(c))
				{
					num3 = (int)(char.ToLowerInvariant(c) - 'a' + '\n');
				}
				else
				{
					if (num > 0)
					{
						throw new FormatException("Additional unparsable characters are at the end of the string.");
					}
					throw new FormatException("Could not find any parsable digits.");
				}
				if (num3 >= fromBase)
				{
					if (num > 0)
					{
						throw new FormatException("Additional unparsable characters are at the end of the string.");
					}
					throw new FormatException("Could not find any parsable digits.");
				}
				else
				{
					num2 = (long)fromBase * num2 + (long)num3;
					num++;
				}
			}
			if (num == 0)
			{
				throw new FormatException("Could not find any parsable digits.");
			}
			if (flag)
			{
				return -1L * num2;
			}
			return num2;
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x00024A88 File Offset: 0x00022C88
		internal static object ToType(object value, Type conversionType, IFormatProvider provider, bool try_target_to_type)
		{
			if (value == null)
			{
				if (conversionType != null && conversionType.IsValueType)
				{
					throw new InvalidCastException("Null object can not be converted to a value type.");
				}
				return null;
			}
			else
			{
				if (conversionType == null)
				{
					throw new InvalidCastException("Cannot cast to destination type.");
				}
				if (value.GetType() == conversionType)
				{
					return value;
				}
				if (value is IConvertible)
				{
					IConvertible convertible = (IConvertible)value;
					if (conversionType == Convert.conversionTable[0])
					{
						throw new ArgumentNullException();
					}
					if (conversionType == Convert.conversionTable[1])
					{
						return value;
					}
					if (conversionType == Convert.conversionTable[2])
					{
						throw new InvalidCastException("Cannot cast to DBNull, it's not IConvertible");
					}
					if (conversionType == Convert.conversionTable[3])
					{
						return convertible.ToBoolean(provider);
					}
					if (conversionType == Convert.conversionTable[4])
					{
						return convertible.ToChar(provider);
					}
					if (conversionType == Convert.conversionTable[5])
					{
						return convertible.ToSByte(provider);
					}
					if (conversionType == Convert.conversionTable[6])
					{
						return convertible.ToByte(provider);
					}
					if (conversionType == Convert.conversionTable[7])
					{
						return convertible.ToInt16(provider);
					}
					if (conversionType == Convert.conversionTable[8])
					{
						return convertible.ToUInt16(provider);
					}
					if (conversionType == Convert.conversionTable[9])
					{
						return convertible.ToInt32(provider);
					}
					if (conversionType == Convert.conversionTable[10])
					{
						return convertible.ToUInt32(provider);
					}
					if (conversionType == Convert.conversionTable[11])
					{
						return convertible.ToInt64(provider);
					}
					if (conversionType == Convert.conversionTable[12])
					{
						return convertible.ToUInt64(provider);
					}
					if (conversionType == Convert.conversionTable[13])
					{
						return convertible.ToSingle(provider);
					}
					if (conversionType == Convert.conversionTable[14])
					{
						return convertible.ToDouble(provider);
					}
					if (conversionType == Convert.conversionTable[15])
					{
						return convertible.ToDecimal(provider);
					}
					if (conversionType == Convert.conversionTable[16])
					{
						return convertible.ToDateTime(provider);
					}
					if (conversionType == Convert.conversionTable[18])
					{
						return convertible.ToString(provider);
					}
					if (try_target_to_type)
					{
						return convertible.ToType(conversionType, provider);
					}
				}
				throw new InvalidCastException(Locale.GetText("Value is not a convertible object: " + value.GetType().ToString() + " to " + conversionType.FullName));
			}
		}

		// Token: 0x04000321 RID: 801
		private const int MaxBytesPerLine = 57;

		// Token: 0x04000322 RID: 802
		public static readonly object DBNull = global::System.DBNull.Value;

		// Token: 0x04000323 RID: 803
		private static readonly Type[] conversionTable = new Type[]
		{
			null,
			typeof(object),
			typeof(DBNull),
			typeof(bool),
			typeof(char),
			typeof(sbyte),
			typeof(byte),
			typeof(short),
			typeof(ushort),
			typeof(int),
			typeof(uint),
			typeof(long),
			typeof(ulong),
			typeof(float),
			typeof(double),
			typeof(decimal),
			typeof(DateTime),
			null,
			typeof(string)
		};
	}
}
