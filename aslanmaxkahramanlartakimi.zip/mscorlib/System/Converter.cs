﻿using System;

namespace System
{
	// Token: 0x020000E8 RID: 232
	// (Invoke) Token: 0x060008FA RID: 2298
	public delegate TOutput Converter<TInput, TOutput>(TInput input);
}
