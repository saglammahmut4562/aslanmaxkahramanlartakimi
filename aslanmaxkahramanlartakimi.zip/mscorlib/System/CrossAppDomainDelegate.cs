﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x020000E9 RID: 233
	// (Invoke) Token: 0x060008FE RID: 2302
	[ComVisible(true)]
	public delegate void CrossAppDomainDelegate();
}
