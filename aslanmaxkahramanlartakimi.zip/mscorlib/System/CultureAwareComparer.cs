﻿using System;
using System.Globalization;

namespace System
{
	// Token: 0x020000EA RID: 234
	[Serializable]
	internal sealed class CultureAwareComparer : StringComparer
	{
		// Token: 0x06000901 RID: 2305 RVA: 0x00024CE8 File Offset: 0x00022EE8
		public CultureAwareComparer(CultureInfo ci, bool ignore_case)
		{
			this._compareInfo = ci.CompareInfo;
			this._ignoreCase = ignore_case;
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x00024D04 File Offset: 0x00022F04
		public override int Compare(string x, string y)
		{
			CompareOptions compareOptions = ((!this._ignoreCase) ? CompareOptions.None : CompareOptions.IgnoreCase);
			return this._compareInfo.Compare(x, y, compareOptions);
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x00024D34 File Offset: 0x00022F34
		public override bool Equals(string x, string y)
		{
			return this.Compare(x, y) == 0;
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x00024D44 File Offset: 0x00022F44
		public override int GetHashCode(string s)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			CompareOptions compareOptions = ((!this._ignoreCase) ? CompareOptions.None : CompareOptions.IgnoreCase);
			return this._compareInfo.GetSortKey(s, compareOptions).GetHashCode();
		}

		// Token: 0x04000324 RID: 804
		private readonly bool _ignoreCase;

		// Token: 0x04000325 RID: 805
		private readonly CompareInfo _compareInfo;
	}
}
