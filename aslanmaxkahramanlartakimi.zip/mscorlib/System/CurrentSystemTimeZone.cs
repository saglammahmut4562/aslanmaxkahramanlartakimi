﻿using System;
using System.Collections;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x020000EB RID: 235
	[Serializable]
	internal class CurrentSystemTimeZone : TimeZone, IDeserializationCallback
	{
		// Token: 0x06000905 RID: 2309 RVA: 0x00024D88 File Offset: 0x00022F88
		internal CurrentSystemTimeZone()
		{
		}

		// Token: 0x06000906 RID: 2310 RVA: 0x00024D9C File Offset: 0x00022F9C
		internal CurrentSystemTimeZone(long lnow)
		{
			DateTime dateTime = new DateTime(lnow);
			long[] array;
			string[] array2;
			if (!CurrentSystemTimeZone.GetTimeZoneData(dateTime.Year, out array, out array2))
			{
				throw new NotSupportedException(Locale.GetText("Can't get timezone name."));
			}
			this.m_standardName = Locale.GetText(array2[0]);
			this.m_daylightName = Locale.GetText(array2[1]);
			this.m_ticksOffset = array[2];
			DaylightTime daylightTimeFromData = this.GetDaylightTimeFromData(array);
			this.m_CachedDaylightChanges.Add(dateTime.Year, daylightTimeFromData);
			this.OnDeserialization(daylightTimeFromData);
		}

		// Token: 0x06000907 RID: 2311 RVA: 0x00024E34 File Offset: 0x00023034
		void IDeserializationCallback.OnDeserialization(object sender)
		{
			this.OnDeserialization(null);
		}

		// Token: 0x06000908 RID: 2312
		[MethodImpl(4096)]
		private static extern bool GetTimeZoneData(int year, out long[] data, out string[] names);

		// Token: 0x06000909 RID: 2313 RVA: 0x00024E40 File Offset: 0x00023040
		public override DaylightTime GetDaylightChanges(int year)
		{
			if (year < 1 || year > 9999)
			{
				throw new ArgumentOutOfRangeException("year", year + Locale.GetText(" is not in a range between 1 and 9999."));
			}
			if (year == CurrentSystemTimeZone.this_year)
			{
				return CurrentSystemTimeZone.this_year_dlt;
			}
			Hashtable cachedDaylightChanges = this.m_CachedDaylightChanges;
			DaylightTime daylightTime2;
			lock (cachedDaylightChanges)
			{
				DaylightTime daylightTime = (DaylightTime)this.m_CachedDaylightChanges[year];
				if (daylightTime == null)
				{
					long[] array;
					string[] array2;
					if (!CurrentSystemTimeZone.GetTimeZoneData(year, out array, out array2))
					{
						throw new ArgumentException(Locale.GetText("Can't get timezone data for " + year));
					}
					daylightTime = this.GetDaylightTimeFromData(array);
					this.m_CachedDaylightChanges.Add(year, daylightTime);
				}
				daylightTime2 = daylightTime;
			}
			return daylightTime2;
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x00024F24 File Offset: 0x00023124
		public override TimeSpan GetUtcOffset(DateTime time)
		{
			if (this.IsDaylightSavingTime(time))
			{
				return this.utcOffsetWithDLS;
			}
			return this.utcOffsetWithOutDLS;
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x00024F40 File Offset: 0x00023140
		private void OnDeserialization(DaylightTime dlt)
		{
			if (dlt == null)
			{
				CurrentSystemTimeZone.this_year = DateTime.Now.Year;
				long[] array;
				string[] array2;
				if (!CurrentSystemTimeZone.GetTimeZoneData(CurrentSystemTimeZone.this_year, out array, out array2))
				{
					throw new ArgumentException(Locale.GetText("Can't get timezone data for " + CurrentSystemTimeZone.this_year));
				}
				dlt = this.GetDaylightTimeFromData(array);
			}
			else
			{
				CurrentSystemTimeZone.this_year = dlt.Start.Year;
			}
			this.utcOffsetWithOutDLS = new TimeSpan(this.m_ticksOffset);
			this.utcOffsetWithDLS = new TimeSpan(this.m_ticksOffset + dlt.Delta.Ticks);
			CurrentSystemTimeZone.this_year_dlt = dlt;
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x00024FF0 File Offset: 0x000231F0
		private DaylightTime GetDaylightTimeFromData(long[] data)
		{
			return new DaylightTime(new DateTime(data[0]), new DateTime(data[1]), new TimeSpan(data[3]));
		}

		// Token: 0x04000326 RID: 806
		private string m_standardName;

		// Token: 0x04000327 RID: 807
		private string m_daylightName;

		// Token: 0x04000328 RID: 808
		private Hashtable m_CachedDaylightChanges = new Hashtable(1);

		// Token: 0x04000329 RID: 809
		private long m_ticksOffset;

		// Token: 0x0400032A RID: 810
		[NonSerialized]
		private TimeSpan utcOffsetWithOutDLS;

		// Token: 0x0400032B RID: 811
		[NonSerialized]
		private TimeSpan utcOffsetWithDLS;

		// Token: 0x0400032C RID: 812
		private static int this_year;

		// Token: 0x0400032D RID: 813
		private static DaylightTime this_year_dlt;
	}
}
