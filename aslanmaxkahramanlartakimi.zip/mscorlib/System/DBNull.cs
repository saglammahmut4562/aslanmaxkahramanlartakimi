﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x020000F2 RID: 242
	[ComVisible(true)]
	[Serializable]
	public sealed class DBNull : IConvertible, ISerializable
	{
		// Token: 0x06000991 RID: 2449 RVA: 0x0002962C File Offset: 0x0002782C
		private DBNull()
		{
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x00029634 File Offset: 0x00027834
		private DBNull(SerializationInfo info, StreamingContext context)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000994 RID: 2452 RVA: 0x00029650 File Offset: 0x00027850
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x00029658 File Offset: 0x00027858
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x00029660 File Offset: 0x00027860
		char IConvertible.ToChar(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x00029668 File Offset: 0x00027868
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x06000998 RID: 2456 RVA: 0x00029670 File Offset: 0x00027870
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x00029678 File Offset: 0x00027878
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x00029680 File Offset: 0x00027880
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x00029688 File Offset: 0x00027888
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x00029690 File Offset: 0x00027890
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x00029698 File Offset: 0x00027898
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600099E RID: 2462 RVA: 0x000296A0 File Offset: 0x000278A0
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x0600099F RID: 2463 RVA: 0x000296A8 File Offset: 0x000278A8
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == typeof(string))
			{
				return string.Empty;
			}
			if (targetType == typeof(DBNull))
			{
				return this;
			}
			throw new InvalidCastException();
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x000296D8 File Offset: 0x000278D8
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x000296E0 File Offset: 0x000278E0
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x000296E8 File Offset: 0x000278E8
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060009A3 RID: 2467 RVA: 0x000296F0 File Offset: 0x000278F0
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			UnitySerializationHolder.GetDBNullData(this, info, context);
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x000296FC File Offset: 0x000278FC
		public TypeCode GetTypeCode()
		{
			return TypeCode.DBNull;
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x00029700 File Offset: 0x00027900
		public override string ToString()
		{
			return string.Empty;
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x00029708 File Offset: 0x00027908
		public string ToString(IFormatProvider provider)
		{
			return string.Empty;
		}

		// Token: 0x0400035C RID: 860
		public static readonly DBNull Value = new DBNull();
	}
}
