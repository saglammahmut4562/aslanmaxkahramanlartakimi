﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x020000EE RID: 238
	[ComVisible(true)]
	[Serializable]
	public enum DateTimeKind
	{
		// Token: 0x0400034D RID: 845
		Unspecified,
		// Token: 0x0400034E RID: 846
		Utc,
		// Token: 0x0400034F RID: 847
		Local
	}
}
