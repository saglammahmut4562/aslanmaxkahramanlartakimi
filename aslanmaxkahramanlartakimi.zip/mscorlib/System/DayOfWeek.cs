﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x020000F1 RID: 241
	[ComVisible(true)]
	[Serializable]
	public enum DayOfWeek
	{
		// Token: 0x04000355 RID: 853
		Sunday,
		// Token: 0x04000356 RID: 854
		Monday,
		// Token: 0x04000357 RID: 855
		Tuesday,
		// Token: 0x04000358 RID: 856
		Wednesday,
		// Token: 0x04000359 RID: 857
		Thursday,
		// Token: 0x0400035A RID: 858
		Friday,
		// Token: 0x0400035B RID: 859
		Saturday
	}
}
