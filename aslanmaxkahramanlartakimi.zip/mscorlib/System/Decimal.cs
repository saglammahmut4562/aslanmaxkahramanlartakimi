﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Text;

namespace System
{
	// Token: 0x020000F3 RID: 243
	[ComVisible(true)]
	[Serializable]
	public struct Decimal : IComparable<decimal>, IEquatable<decimal>, IComparable, IConvertible, IFormattable
	{
		// Token: 0x060009A7 RID: 2471 RVA: 0x00029710 File Offset: 0x00027910
		public Decimal(int lo, int mid, int hi, bool isNegative, byte scale)
		{
			this.lo = (uint)lo;
			this.mid = (uint)mid;
			this.hi = (uint)hi;
			if (scale > 28)
			{
				throw new ArgumentOutOfRangeException(Locale.GetText("scale must be between 0 and 28"));
			}
			this.flags = (uint)scale;
			this.flags <<= 16;
			if (isNegative)
			{
				this.flags |= 2147483648U;
			}
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x0002977C File Offset: 0x0002797C
		public Decimal(int value)
		{
			this.hi = (this.mid = 0U);
			if (value < 0)
			{
				this.flags = 2147483648U;
				this.lo = (uint)(~value + 1);
			}
			else
			{
				this.flags = 0U;
				this.lo = (uint)value;
			}
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x000297C8 File Offset: 0x000279C8
		[CLSCompliant(false)]
		public Decimal(uint value)
		{
			this.lo = value;
			this.flags = (this.hi = (this.mid = 0U));
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x000297F8 File Offset: 0x000279F8
		public Decimal(long value)
		{
			this.hi = 0U;
			if (value < 0L)
			{
				this.flags = 2147483648U;
				ulong num = (ulong)(~value + 1L);
				this.lo = (uint)num;
				this.mid = (uint)(num >> 32);
			}
			else
			{
				this.flags = 0U;
				this.lo = (uint)value;
				this.mid = (uint)((ulong)value >> 32);
			}
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x0002985C File Offset: 0x00027A5C
		[CLSCompliant(false)]
		public Decimal(ulong value)
		{
			this.flags = (this.hi = 0U);
			this.lo = (uint)value;
			this.mid = (uint)(value >> 32);
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x0002988C File Offset: 0x00027A8C
		public Decimal(float value)
		{
			if (value > 7.9228163E+28f || value < -7.9228163E+28f || float.IsNaN(value) || float.IsNegativeInfinity(value) || float.IsPositiveInfinity(value))
			{
				throw new OverflowException(Locale.GetText("Value {0} is greater than Decimal.MaxValue or less than Decimal.MinValue", new object[] { value }));
			}
			decimal num = decimal.Parse(value.ToString(CultureInfo.InvariantCulture), NumberStyles.Float, CultureInfo.InvariantCulture);
			this.flags = num.flags;
			this.hi = num.hi;
			this.lo = num.lo;
			this.mid = num.mid;
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x00029940 File Offset: 0x00027B40
		public Decimal(double value)
		{
			if (value > 7.922816251426434E+28 || value < -7.922816251426434E+28 || double.IsNaN(value) || double.IsNegativeInfinity(value) || double.IsPositiveInfinity(value))
			{
				throw new OverflowException(Locale.GetText("Value {0} is greater than Decimal.MaxValue or less than Decimal.MinValue", new object[] { value }));
			}
			decimal num = decimal.Parse(value.ToString(CultureInfo.InvariantCulture), NumberStyles.Float, CultureInfo.InvariantCulture);
			this.flags = num.flags;
			this.hi = num.hi;
			this.lo = num.lo;
			this.mid = num.mid;
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x00029A4C File Offset: 0x00027C4C
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			return Convert.ToType(this, targetType, provider, false);
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x00029A74 File Offset: 0x00027C74
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return Convert.ToBoolean(this);
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x00029A84 File Offset: 0x00027C84
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this);
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x00029A94 File Offset: 0x00027C94
		char IConvertible.ToChar(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x00029A9C File Offset: 0x00027C9C
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x00029AA4 File Offset: 0x00027CA4
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return this;
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x00029AAC File Offset: 0x00027CAC
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this);
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x00029ABC File Offset: 0x00027CBC
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x060009B7 RID: 2487 RVA: 0x00029ACC File Offset: 0x00027CCC
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x00029ADC File Offset: 0x00027CDC
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x00029AEC File Offset: 0x00027CEC
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x060009BA RID: 2490 RVA: 0x00029AFC File Offset: 0x00027CFC
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return Convert.ToSingle(this);
		}

		// Token: 0x060009BB RID: 2491 RVA: 0x00029B0C File Offset: 0x00027D0C
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x00029B1C File Offset: 0x00027D1C
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x060009BD RID: 2493 RVA: 0x00029B2C File Offset: 0x00027D2C
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x00029B3C File Offset: 0x00027D3C
		public static int[] GetBits(decimal d)
		{
			return new int[]
			{
				(int)d.lo,
				(int)d.mid,
				(int)d.hi,
				(int)d.flags
			};
		}

		// Token: 0x060009BF RID: 2495 RVA: 0x00029B6C File Offset: 0x00027D6C
		public static decimal Add(decimal d1, decimal d2)
		{
			if (decimal.decimalIncr(ref d1, ref d2) == 0)
			{
				return d1;
			}
			throw new OverflowException(Locale.GetText("Overflow on adding decimal number"));
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x00029B90 File Offset: 0x00027D90
		public static decimal Subtract(decimal d1, decimal d2)
		{
			d2.flags ^= 2147483648U;
			int num = decimal.decimalIncr(ref d1, ref d2);
			if (num == 0)
			{
				return d1;
			}
			throw new OverflowException(Locale.GetText("Overflow on subtracting decimal numbers (" + num + ")"));
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x00029BE4 File Offset: 0x00027DE4
		public override int GetHashCode()
		{
			return (int)(this.flags ^ this.hi ^ this.lo ^ this.mid);
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x00029C04 File Offset: 0x00027E04
		private static ulong u64(decimal value)
		{
			decimal.decimalFloorAndTrunc(ref value, 0);
			ulong num;
			if (decimal.decimal2UInt64(ref value, out num) != 0)
			{
				throw new OverflowException();
			}
			return num;
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x00029C30 File Offset: 0x00027E30
		private static long s64(decimal value)
		{
			decimal.decimalFloorAndTrunc(ref value, 0);
			long num;
			if (decimal.decimal2Int64(ref value, out num) != 0)
			{
				throw new OverflowException();
			}
			return num;
		}

		// Token: 0x060009C4 RID: 2500 RVA: 0x00029C5C File Offset: 0x00027E5C
		public static bool Equals(decimal d1, decimal d2)
		{
			return decimal.Compare(d1, d2) == 0;
		}

		// Token: 0x060009C5 RID: 2501 RVA: 0x00029C68 File Offset: 0x00027E68
		public override bool Equals(object value)
		{
			return value is decimal && decimal.Equals((decimal)value, this);
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x00029C88 File Offset: 0x00027E88
		private bool IsZero()
		{
			return this.hi == 0U && this.lo == 0U && this.mid == 0U;
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x00029CAC File Offset: 0x00027EAC
		public static decimal Floor(decimal d)
		{
			decimal.decimalFloorAndTrunc(ref d, 1);
			return d;
		}

		// Token: 0x060009C8 RID: 2504 RVA: 0x00029CB8 File Offset: 0x00027EB8
		public static decimal Multiply(decimal d1, decimal d2)
		{
			if (d1.IsZero() || d2.IsZero())
			{
				return 0m;
			}
			if (decimal.decimalMult(ref d1, ref d2) != 0)
			{
				throw new OverflowException();
			}
			return d1;
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x00029CF0 File Offset: 0x00027EF0
		public static decimal Divide(decimal d1, decimal d2)
		{
			if (d2.IsZero())
			{
				throw new DivideByZeroException();
			}
			if (d1.IsZero())
			{
				return 0m;
			}
			d1.flags ^= 2147483648U;
			d1.flags ^= 2147483648U;
			decimal num;
			if (decimal.decimalDiv(out num, ref d1, ref d2) != 0)
			{
				throw new OverflowException();
			}
			return num;
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x00029D60 File Offset: 0x00027F60
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static int Compare(decimal d1, decimal d2)
		{
			return decimal.decimalCompare(ref d1, ref d2);
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x00029D6C File Offset: 0x00027F6C
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is decimal))
			{
				throw new ArgumentException(Locale.GetText("Value is not a System.Decimal"));
			}
			return decimal.Compare(this, (decimal)value);
		}

		// Token: 0x060009CC RID: 2508 RVA: 0x00029DA4 File Offset: 0x00027FA4
		public int CompareTo(decimal value)
		{
			return decimal.Compare(this, value);
		}

		// Token: 0x060009CD RID: 2509 RVA: 0x00029DB4 File Offset: 0x00027FB4
		public bool Equals(decimal value)
		{
			return decimal.Equals(value, this);
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x00029DC4 File Offset: 0x00027FC4
		public static decimal Parse(string s, IFormatProvider provider)
		{
			return decimal.Parse(s, NumberStyles.Number, provider);
		}

		// Token: 0x060009CF RID: 2511 RVA: 0x00029DD0 File Offset: 0x00027FD0
		private static void ThrowAtPos(int pos)
		{
			throw new FormatException(string.Format(Locale.GetText("Invalid character at position {0}"), pos));
		}

		// Token: 0x060009D0 RID: 2512 RVA: 0x00029DEC File Offset: 0x00027FEC
		private static void ThrowInvalidExp()
		{
			throw new FormatException(Locale.GetText("Invalid exponent"));
		}

		// Token: 0x060009D1 RID: 2513 RVA: 0x00029E00 File Offset: 0x00028000
		private static string stripStyles(string s, NumberStyles style, NumberFormatInfo nfi, out int decPos, out bool isNegative, out bool expFlag, out int exp, bool throwex)
		{
			isNegative = false;
			expFlag = false;
			exp = 0;
			decPos = -1;
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			bool flag4 = (style & NumberStyles.AllowLeadingWhite) != NumberStyles.None;
			bool flag5 = (style & NumberStyles.AllowTrailingWhite) != NumberStyles.None;
			bool flag6 = (style & NumberStyles.AllowLeadingSign) != NumberStyles.None;
			bool flag7 = (style & NumberStyles.AllowTrailingSign) != NumberStyles.None;
			bool flag8 = (style & NumberStyles.AllowParentheses) != NumberStyles.None;
			bool flag9 = (style & NumberStyles.AllowThousands) != NumberStyles.None;
			bool flag10 = (style & NumberStyles.AllowDecimalPoint) != NumberStyles.None;
			bool flag11 = (style & NumberStyles.AllowExponent) != NumberStyles.None;
			bool flag12 = false;
			if ((style & NumberStyles.AllowCurrencySymbol) != NumberStyles.None)
			{
				int num = s.IndexOf(nfi.CurrencySymbol);
				if (num >= 0)
				{
					s = s.Remove(num, nfi.CurrencySymbol.Length);
					flag12 = true;
				}
			}
			string text = ((!flag12) ? nfi.NumberDecimalSeparator : nfi.CurrencyDecimalSeparator);
			string text2 = ((!flag12) ? nfi.NumberGroupSeparator : nfi.CurrencyGroupSeparator);
			int i = 0;
			int length = s.Length;
			StringBuilder stringBuilder = new StringBuilder(length);
			while (i < length)
			{
				char c = s[i];
				if (char.IsDigit(c))
				{
					break;
				}
				if (flag4 && char.IsWhiteSpace(c))
				{
					i++;
				}
				else if (flag8 && c == '(' && !flag && !flag2)
				{
					flag2 = true;
					flag = true;
					isNegative = true;
					i++;
				}
				else if (flag6 && c == nfi.NegativeSign[0] && !flag)
				{
					int length2 = nfi.NegativeSign.Length;
					if (length2 == 1 || s.IndexOf(nfi.NegativeSign, i, length2) == i)
					{
						flag = true;
						isNegative = true;
						i += length2;
					}
				}
				else if (flag6 && c == nfi.PositiveSign[0] && !flag)
				{
					int length3 = nfi.PositiveSign.Length;
					if (length3 == 1 || s.IndexOf(nfi.PositiveSign, i, length3) == i)
					{
						flag = true;
						i += length3;
					}
				}
				else
				{
					if (flag10 && c == text[0])
					{
						int length4 = text.Length;
						if (length4 != 1 && s.IndexOf(text, i, length4) != i)
						{
							if (!throwex)
							{
								return null;
							}
							decimal.ThrowAtPos(i);
						}
						break;
					}
					if (!throwex)
					{
						return null;
					}
					decimal.ThrowAtPos(i);
				}
			}
			if (i == length)
			{
				if (throwex)
				{
					throw new FormatException(Locale.GetText("No digits found"));
				}
				return null;
			}
			else
			{
				while (i < length)
				{
					char c2 = s[i];
					if (char.IsDigit(c2))
					{
						stringBuilder.Append(c2);
						i++;
					}
					else if (flag9 && c2 == text2[0])
					{
						int length5 = text2.Length;
						if (length5 != 1 && s.IndexOf(text2, i, length5) != i)
						{
							if (!throwex)
							{
								return null;
							}
							decimal.ThrowAtPos(i);
						}
						i += length5;
					}
					else
					{
						if (!flag10 || c2 != text[0] || flag3)
						{
							break;
						}
						int length6 = text.Length;
						if (length6 == 1 || s.IndexOf(text, i, length6) == i)
						{
							decPos = stringBuilder.Length;
							flag3 = true;
							i += length6;
						}
					}
				}
				if (i < length)
				{
					char c3 = s[i];
					if (flag11 && char.ToUpperInvariant(c3) == 'E')
					{
						expFlag = true;
						i++;
						if (i >= length)
						{
							if (!throwex)
							{
								return null;
							}
							decimal.ThrowInvalidExp();
						}
						c3 = s[i];
						bool flag13 = false;
						if (c3 == nfi.PositiveSign[0])
						{
							int length7 = nfi.PositiveSign.Length;
							if (length7 == 1 || s.IndexOf(nfi.PositiveSign, i, length7) == i)
							{
								i += length7;
								if (i >= length)
								{
									if (!throwex)
									{
										return null;
									}
									decimal.ThrowInvalidExp();
								}
							}
						}
						else if (c3 == nfi.NegativeSign[0])
						{
							int length8 = nfi.NegativeSign.Length;
							if (length8 == 1 || s.IndexOf(nfi.NegativeSign, i, length8) == i)
							{
								i += length8;
								if (i >= length)
								{
									if (!throwex)
									{
										return null;
									}
									decimal.ThrowInvalidExp();
								}
								flag13 = true;
							}
						}
						c3 = s[i];
						if (!char.IsDigit(c3))
						{
							if (!throwex)
							{
								return null;
							}
							decimal.ThrowInvalidExp();
						}
						exp = (int)(c3 - '0');
						i++;
						while (i < length && char.IsDigit(s[i]))
						{
							exp *= 10;
							exp += (int)(s[i] - '0');
							i++;
						}
						if (flag13)
						{
							exp *= -1;
						}
					}
				}
				while (i < length)
				{
					char c4 = s[i];
					if (flag5 && char.IsWhiteSpace(c4))
					{
						i++;
					}
					else if (flag8 && c4 == ')' && flag2)
					{
						flag2 = false;
						i++;
					}
					else if (flag7 && c4 == nfi.NegativeSign[0] && !flag)
					{
						int length9 = nfi.NegativeSign.Length;
						if (length9 == 1 || s.IndexOf(nfi.NegativeSign, i, length9) == i)
						{
							flag = true;
							isNegative = true;
							i += length9;
						}
					}
					else if (flag7 && c4 == nfi.PositiveSign[0] && !flag)
					{
						int length10 = nfi.PositiveSign.Length;
						if (length10 == 1 || s.IndexOf(nfi.PositiveSign, i, length10) == i)
						{
							flag = true;
							i += length10;
						}
					}
					else
					{
						if (!throwex)
						{
							return null;
						}
						decimal.ThrowAtPos(i);
					}
				}
				if (!flag2)
				{
					if (!flag3)
					{
						decPos = stringBuilder.Length;
					}
					return stringBuilder.ToString();
				}
				if (throwex)
				{
					throw new FormatException(Locale.GetText("Closing Parentheses not found"));
				}
				return null;
			}
		}

		// Token: 0x060009D2 RID: 2514 RVA: 0x0002A4B8 File Offset: 0x000286B8
		public static decimal Parse(string s, NumberStyles style, IFormatProvider provider)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			if ((style & NumberStyles.AllowHexSpecifier) != NumberStyles.None)
			{
				throw new ArgumentException("Decimal.TryParse does not accept AllowHexSpecifier", "style");
			}
			decimal num;
			decimal.PerformParse(s, style, provider, out num, true);
			return num;
		}

		// Token: 0x060009D3 RID: 2515 RVA: 0x0002A500 File Offset: 0x00028700
		public static bool TryParse(string s, NumberStyles style, IFormatProvider provider, out decimal result)
		{
			if (s == null || (style & NumberStyles.AllowHexSpecifier) != NumberStyles.None)
			{
				result = 0m;
				return false;
			}
			return decimal.PerformParse(s, style, provider, out result, false);
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x0002A52C File Offset: 0x0002872C
		private static bool PerformParse(string s, NumberStyles style, IFormatProvider provider, out decimal res, bool throwex)
		{
			NumberFormatInfo instance = NumberFormatInfo.GetInstance(provider);
			int num;
			bool flag;
			bool flag2;
			int num2;
			s = decimal.stripStyles(s, style, instance, out num, out flag, out flag2, out num2, throwex);
			if (s == null)
			{
				res = 0m;
				return false;
			}
			if (num < 0)
			{
				if (throwex)
				{
					throw new Exception(Locale.GetText("Error in System.Decimal.Parse"));
				}
				res = 0m;
				return false;
			}
			else
			{
				int num3 = s.Length;
				int num4 = 0;
				while (num4 < num && s[num4] == '0')
				{
					num4++;
				}
				if (num4 > 1 && num3 > 1)
				{
					s = s.Substring(num4, num3 - num4);
					num -= num4;
				}
				int num5 = ((num != 0) ? 28 : 27);
				num3 = s.Length;
				if (num3 >= num5 + 1 && string.Compare(s, 0, "79228162514264337593543950335", 0, num5 + 1, false, CultureInfo.InvariantCulture) <= 0)
				{
					num5++;
				}
				if (num3 > num5 && num < num3)
				{
					int num6 = (int)(s[num5] - '0');
					s = s.Substring(0, num5);
					bool flag3 = false;
					if (num6 > 5)
					{
						flag3 = true;
					}
					else if (num6 == 5)
					{
						if (flag)
						{
							flag3 = true;
						}
						else
						{
							int num7 = (int)(s[num5 - 1] - '0');
							flag3 = (num7 & 1) == 1;
						}
					}
					if (flag3)
					{
						char[] array = s.ToCharArray();
						int i = num5 - 1;
						while (i >= 0)
						{
							int num8 = (int)(array[i] - '0');
							if (array[i] != '9')
							{
								array[i] = (char)(num8 + 49);
								break;
							}
							array[i--] = '0';
						}
						if (i == -1 && array[0] == '0')
						{
							num++;
							s = "1".PadRight(num, '0');
						}
						else
						{
							s = new string(array);
						}
					}
				}
				decimal num9;
				if (decimal.string2decimal(out num9, s, (uint)num, 0) != 0)
				{
					if (throwex)
					{
						throw new OverflowException();
					}
					res = 0m;
					return false;
				}
				else
				{
					if (!flag2 || decimal.decimalSetExponent(ref num9, num2) == 0)
					{
						if (flag)
						{
							num9.flags ^= 2147483648U;
						}
						res = num9;
						return true;
					}
					if (throwex)
					{
						throw new OverflowException();
					}
					res = 0m;
					return false;
				}
			}
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x0002A79C File Offset: 0x0002899C
		public TypeCode GetTypeCode()
		{
			return TypeCode.Decimal;
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x0002A7A0 File Offset: 0x000289A0
		public string ToString(string format, IFormatProvider provider)
		{
			return NumberFormatter.NumberToString(format, this, provider);
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0002A7B0 File Offset: 0x000289B0
		public override string ToString()
		{
			return this.ToString("G", null);
		}

		// Token: 0x060009D8 RID: 2520 RVA: 0x0002A7C0 File Offset: 0x000289C0
		public string ToString(IFormatProvider provider)
		{
			return this.ToString("G", provider);
		}

		// Token: 0x060009D9 RID: 2521
		[MethodImpl(4096)]
		private static extern int decimal2UInt64(ref decimal val, out ulong result);

		// Token: 0x060009DA RID: 2522
		[MethodImpl(4096)]
		private static extern int decimal2Int64(ref decimal val, out long result);

		// Token: 0x060009DB RID: 2523
		[MethodImpl(4096)]
		private static extern int decimalIncr(ref decimal d1, ref decimal d2);

		// Token: 0x060009DC RID: 2524
		[MethodImpl(4096)]
		internal static extern int string2decimal(out decimal val, string sDigits, uint decPos, int sign);

		// Token: 0x060009DD RID: 2525
		[MethodImpl(4096)]
		internal static extern int decimalSetExponent(ref decimal val, int exp);

		// Token: 0x060009DE RID: 2526
		[MethodImpl(4096)]
		private static extern double decimal2double(ref decimal val);

		// Token: 0x060009DF RID: 2527
		[MethodImpl(4096)]
		private static extern void decimalFloorAndTrunc(ref decimal val, int floorFlag);

		// Token: 0x060009E0 RID: 2528
		[MethodImpl(4096)]
		private static extern int decimalMult(ref decimal pd1, ref decimal pd2);

		// Token: 0x060009E1 RID: 2529
		[MethodImpl(4096)]
		private static extern int decimalDiv(out decimal pc, ref decimal pa, ref decimal pb);

		// Token: 0x060009E2 RID: 2530
		[MethodImpl(4096)]
		private static extern int decimalCompare(ref decimal d1, ref decimal d2);

		// Token: 0x060009E3 RID: 2531 RVA: 0x0002A7D0 File Offset: 0x000289D0
		public static decimal operator ++(decimal d)
		{
			return decimal.Add(d, 1m);
		}

		// Token: 0x060009E4 RID: 2532 RVA: 0x0002A7E0 File Offset: 0x000289E0
		public static decimal operator -(decimal d1, decimal d2)
		{
			return decimal.Subtract(d1, d2);
		}

		// Token: 0x060009E5 RID: 2533 RVA: 0x0002A7EC File Offset: 0x000289EC
		public static decimal operator *(decimal d1, decimal d2)
		{
			return decimal.Multiply(d1, d2);
		}

		// Token: 0x060009E6 RID: 2534 RVA: 0x0002A7F8 File Offset: 0x000289F8
		public static decimal operator /(decimal d1, decimal d2)
		{
			return decimal.Divide(d1, d2);
		}

		// Token: 0x060009E7 RID: 2535 RVA: 0x0002A804 File Offset: 0x00028A04
		public static explicit operator byte(decimal value)
		{
			ulong num = decimal.u64(value);
			return checked((byte)num);
		}

		// Token: 0x060009E8 RID: 2536 RVA: 0x0002A81C File Offset: 0x00028A1C
		[CLSCompliant(false)]
		public static explicit operator sbyte(decimal value)
		{
			long num = decimal.s64(value);
			return checked((sbyte)num);
		}

		// Token: 0x060009E9 RID: 2537 RVA: 0x0002A834 File Offset: 0x00028A34
		public static explicit operator short(decimal value)
		{
			long num = decimal.s64(value);
			return checked((short)num);
		}

		// Token: 0x060009EA RID: 2538 RVA: 0x0002A84C File Offset: 0x00028A4C
		[CLSCompliant(false)]
		public static explicit operator ushort(decimal value)
		{
			ulong num = decimal.u64(value);
			return checked((ushort)num);
		}

		// Token: 0x060009EB RID: 2539 RVA: 0x0002A864 File Offset: 0x00028A64
		public static explicit operator int(decimal value)
		{
			long num = decimal.s64(value);
			return checked((int)num);
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x0002A87C File Offset: 0x00028A7C
		[CLSCompliant(false)]
		public static explicit operator uint(decimal value)
		{
			ulong num = decimal.u64(value);
			return checked((uint)num);
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x0002A894 File Offset: 0x00028A94
		public static explicit operator long(decimal value)
		{
			return decimal.s64(value);
		}

		// Token: 0x060009EE RID: 2542 RVA: 0x0002A89C File Offset: 0x00028A9C
		[CLSCompliant(false)]
		public static explicit operator ulong(decimal value)
		{
			return decimal.u64(value);
		}

		// Token: 0x060009EF RID: 2543 RVA: 0x0002A8A4 File Offset: 0x00028AA4
		public static implicit operator decimal(byte value)
		{
			return new decimal((int)value);
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x0002A8AC File Offset: 0x00028AAC
		[CLSCompliant(false)]
		public static implicit operator decimal(sbyte value)
		{
			return new decimal((int)value);
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x0002A8B8 File Offset: 0x00028AB8
		public static implicit operator decimal(short value)
		{
			return new decimal((int)value);
		}

		// Token: 0x060009F2 RID: 2546 RVA: 0x0002A8C0 File Offset: 0x00028AC0
		[CLSCompliant(false)]
		public static implicit operator decimal(ushort value)
		{
			return new decimal((int)value);
		}

		// Token: 0x060009F3 RID: 2547 RVA: 0x0002A8C8 File Offset: 0x00028AC8
		public static implicit operator decimal(int value)
		{
			return new decimal(value);
		}

		// Token: 0x060009F4 RID: 2548 RVA: 0x0002A8D0 File Offset: 0x00028AD0
		[CLSCompliant(false)]
		public static implicit operator decimal(uint value)
		{
			return new decimal(value);
		}

		// Token: 0x060009F5 RID: 2549 RVA: 0x0002A8D8 File Offset: 0x00028AD8
		public static implicit operator decimal(long value)
		{
			return new decimal(value);
		}

		// Token: 0x060009F6 RID: 2550 RVA: 0x0002A8E0 File Offset: 0x00028AE0
		[CLSCompliant(false)]
		public static implicit operator decimal(ulong value)
		{
			return new decimal(value);
		}

		// Token: 0x060009F7 RID: 2551 RVA: 0x0002A8E8 File Offset: 0x00028AE8
		public static explicit operator decimal(float value)
		{
			return new decimal(value);
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0002A8F0 File Offset: 0x00028AF0
		public static explicit operator decimal(double value)
		{
			return new decimal(value);
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x0002A8F8 File Offset: 0x00028AF8
		public static explicit operator float(decimal value)
		{
			return (float)(double)value;
		}

		// Token: 0x060009FA RID: 2554 RVA: 0x0002A904 File Offset: 0x00028B04
		public static explicit operator double(decimal value)
		{
			return decimal.decimal2double(ref value);
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x0002A910 File Offset: 0x00028B10
		public static bool operator !=(decimal d1, decimal d2)
		{
			return !decimal.Equals(d1, d2);
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x0002A91C File Offset: 0x00028B1C
		public static bool operator ==(decimal d1, decimal d2)
		{
			return decimal.Equals(d1, d2);
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x0002A928 File Offset: 0x00028B28
		public static bool operator >(decimal d1, decimal d2)
		{
			return decimal.Compare(d1, d2) > 0;
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x0002A934 File Offset: 0x00028B34
		public static bool operator <(decimal d1, decimal d2)
		{
			return decimal.Compare(d1, d2) < 0;
		}

		// Token: 0x0400035D RID: 861
		public const decimal MinValue = -79228162514264337593543950335m;

		// Token: 0x0400035E RID: 862
		public const decimal MaxValue = 79228162514264337593543950335m;

		// Token: 0x0400035F RID: 863
		public const decimal MinusOne = -1m;

		// Token: 0x04000360 RID: 864
		public const decimal One = 1m;

		// Token: 0x04000361 RID: 865
		public const decimal Zero = 0m;

		// Token: 0x04000362 RID: 866
		private const int DECIMAL_DIVIDE_BY_ZERO = 5;

		// Token: 0x04000363 RID: 867
		private const uint MAX_SCALE = 28U;

		// Token: 0x04000364 RID: 868
		private const int iMAX_SCALE = 28;

		// Token: 0x04000365 RID: 869
		private const uint SIGN_FLAG = 2147483648U;

		// Token: 0x04000366 RID: 870
		private const uint SCALE_MASK = 16711680U;

		// Token: 0x04000367 RID: 871
		private const int SCALE_SHIFT = 16;

		// Token: 0x04000368 RID: 872
		private const uint RESERVED_SS32_BITS = 2130771967U;

		// Token: 0x04000369 RID: 873
		private static readonly decimal MaxValueDiv10 = 7922816251426433759354395033.5m;

		// Token: 0x0400036A RID: 874
		private uint flags;

		// Token: 0x0400036B RID: 875
		private uint hi;

		// Token: 0x0400036C RID: 876
		private uint lo;

		// Token: 0x0400036D RID: 877
		private uint mid;
	}
}
