﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x020000F4 RID: 244
	[ClassInterface(ClassInterfaceType.AutoDual)]
	[ComVisible(true)]
	[Serializable]
	public abstract class Delegate : ICloneable, ISerializable
	{
		// Token: 0x17000174 RID: 372
		// (get) Token: 0x060009FF RID: 2559 RVA: 0x0002A940 File Offset: 0x00028B40
		public MethodInfo Method
		{
			get
			{
				if (this.method_info != null)
				{
					return this.method_info;
				}
				if (this.method != IntPtr.Zero)
				{
					this.method_info = (MethodInfo)MethodBase.GetMethodFromHandleNoGenericCheck(new RuntimeMethodHandle(this.method));
				}
				return this.method_info;
			}
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000A00 RID: 2560 RVA: 0x0002A998 File Offset: 0x00028B98
		public object Target
		{
			get
			{
				return this.m_target;
			}
		}

		// Token: 0x06000A01 RID: 2561
		[MethodImpl(4096)]
		internal static extern Delegate CreateDelegate_internal(Type type, object target, MethodInfo info, bool throwOnBindFailure);

		// Token: 0x06000A02 RID: 2562
		[MethodImpl(4096)]
		internal extern void SetMulticastInvoke();

		// Token: 0x06000A03 RID: 2563 RVA: 0x0002A9A0 File Offset: 0x00028BA0
		private static bool arg_type_match(Type delArgType, Type argType)
		{
			bool flag = delArgType == argType;
			if (!flag && !argType.IsValueType && argType.IsAssignableFrom(delArgType))
			{
				flag = true;
			}
			return flag;
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x0002A9D4 File Offset: 0x00028BD4
		private static bool return_type_match(Type delReturnType, Type returnType)
		{
			bool flag = returnType == delReturnType;
			if (!flag && !returnType.IsValueType && delReturnType.IsAssignableFrom(returnType))
			{
				flag = true;
			}
			return flag;
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x0002AA08 File Offset: 0x00028C08
		public static Delegate CreateDelegate(Type type, object firstArgument, MethodInfo method, bool throwOnBindFailure)
		{
			if (type == null)
			{
				throw new ArgumentNullException("type");
			}
			if (method == null)
			{
				throw new ArgumentNullException("method");
			}
			if (!type.IsSubclassOf(typeof(MulticastDelegate)))
			{
				throw new ArgumentException("type is not a subclass of Multicastdelegate");
			}
			MethodInfo methodInfo = type.GetMethod("Invoke");
			if (!Delegate.return_type_match(methodInfo.ReturnType, method.ReturnType))
			{
				if (throwOnBindFailure)
				{
					throw new ArgumentException("method return type is incompatible");
				}
				return null;
			}
			else
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				ParameterInfo[] parameters2 = method.GetParameters();
				bool flag;
				if (firstArgument != null)
				{
					if (!method.IsStatic)
					{
						flag = parameters2.Length == parameters.Length;
					}
					else
					{
						flag = parameters2.Length == parameters.Length + 1;
					}
				}
				else if (!method.IsStatic)
				{
					flag = parameters2.Length + 1 == parameters.Length;
				}
				else
				{
					flag = parameters2.Length == parameters.Length;
					if (!flag)
					{
						flag = parameters2.Length == parameters.Length + 1;
					}
				}
				if (!flag)
				{
					if (throwOnBindFailure)
					{
						throw new ArgumentException("method argument length mismatch");
					}
					return null;
				}
				else
				{
					bool flag2;
					if (firstArgument != null)
					{
						if (!method.IsStatic)
						{
							flag2 = Delegate.arg_type_match(firstArgument.GetType(), method.DeclaringType);
							for (int i = 0; i < parameters2.Length; i++)
							{
								flag2 &= Delegate.arg_type_match(parameters[i].ParameterType, parameters2[i].ParameterType);
							}
						}
						else
						{
							flag2 = Delegate.arg_type_match(firstArgument.GetType(), parameters2[0].ParameterType);
							for (int j = 1; j < parameters2.Length; j++)
							{
								flag2 &= Delegate.arg_type_match(parameters[j - 1].ParameterType, parameters2[j].ParameterType);
							}
						}
					}
					else if (!method.IsStatic)
					{
						flag2 = Delegate.arg_type_match(parameters[0].ParameterType, method.DeclaringType);
						for (int k = 0; k < parameters2.Length; k++)
						{
							flag2 &= Delegate.arg_type_match(parameters[k + 1].ParameterType, parameters2[k].ParameterType);
						}
					}
					else if (parameters.Length + 1 == parameters2.Length)
					{
						flag2 = !parameters2[0].ParameterType.IsValueType;
						for (int l = 0; l < parameters.Length; l++)
						{
							flag2 &= Delegate.arg_type_match(parameters[l].ParameterType, parameters2[l + 1].ParameterType);
						}
					}
					else
					{
						flag2 = true;
						for (int m = 0; m < parameters2.Length; m++)
						{
							flag2 &= Delegate.arg_type_match(parameters[m].ParameterType, parameters2[m].ParameterType);
						}
					}
					if (flag2)
					{
						Delegate @delegate = Delegate.CreateDelegate_internal(type, firstArgument, method, throwOnBindFailure);
						if (@delegate != null)
						{
							@delegate.original_method_info = method;
						}
						return @delegate;
					}
					if (throwOnBindFailure)
					{
						throw new ArgumentException("method arguments are incompatible");
					}
					return null;
				}
			}
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x0002ACF0 File Offset: 0x00028EF0
		public static Delegate CreateDelegate(Type type, object firstArgument, MethodInfo method)
		{
			return Delegate.CreateDelegate(type, firstArgument, method, true);
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x0002ACFC File Offset: 0x00028EFC
		public static Delegate CreateDelegate(Type type, MethodInfo method, bool throwOnBindFailure)
		{
			return Delegate.CreateDelegate(type, null, method, throwOnBindFailure);
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x0002AD08 File Offset: 0x00028F08
		public static Delegate CreateDelegate(Type type, MethodInfo method)
		{
			return Delegate.CreateDelegate(type, method, true);
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x0002AD14 File Offset: 0x00028F14
		public static Delegate CreateDelegate(Type type, object target, string method)
		{
			return Delegate.CreateDelegate(type, target, method, false);
		}

		// Token: 0x06000A0A RID: 2570 RVA: 0x0002AD20 File Offset: 0x00028F20
		private static MethodInfo GetCandidateMethod(Type type, Type target, string method, BindingFlags bflags, bool ignoreCase, bool throwOnBindFailure)
		{
			if (type == null)
			{
				throw new ArgumentNullException("type");
			}
			if (method == null)
			{
				throw new ArgumentNullException("method");
			}
			if (!type.IsSubclassOf(typeof(MulticastDelegate)))
			{
				throw new ArgumentException("type is not subclass of MulticastDelegate.");
			}
			MethodInfo methodInfo = type.GetMethod("Invoke");
			ParameterInfo[] parameters = methodInfo.GetParameters();
			Type[] array = new Type[parameters.Length];
			for (int i = 0; i < parameters.Length; i++)
			{
				array[i] = parameters[i].ParameterType;
			}
			BindingFlags bindingFlags = BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.ExactBinding | bflags;
			if (ignoreCase)
			{
				bindingFlags |= BindingFlags.IgnoreCase;
			}
			MethodInfo methodInfo2 = null;
			for (Type type2 = target; type2 != null; type2 = type2.BaseType)
			{
				MethodInfo methodInfo3 = type2.GetMethod(method, bindingFlags, null, array, new ParameterModifier[0]);
				if (methodInfo3 != null && Delegate.return_type_match(methodInfo.ReturnType, methodInfo3.ReturnType))
				{
					methodInfo2 = methodInfo3;
					break;
				}
			}
			if (methodInfo2 != null)
			{
				return methodInfo2;
			}
			if (throwOnBindFailure)
			{
				throw new ArgumentException("Couldn't bind to method '" + method + "'.");
			}
			return null;
		}

		// Token: 0x06000A0B RID: 2571 RVA: 0x0002AE40 File Offset: 0x00029040
		public static Delegate CreateDelegate(Type type, Type target, string method, bool ignoreCase, bool throwOnBindFailure)
		{
			if (target == null)
			{
				throw new ArgumentNullException("target");
			}
			MethodInfo candidateMethod = Delegate.GetCandidateMethod(type, target, method, BindingFlags.Static, ignoreCase, throwOnBindFailure);
			if (candidateMethod == null)
			{
				return null;
			}
			return Delegate.CreateDelegate_internal(type, null, candidateMethod, throwOnBindFailure);
		}

		// Token: 0x06000A0C RID: 2572 RVA: 0x0002AE80 File Offset: 0x00029080
		public static Delegate CreateDelegate(Type type, Type target, string method)
		{
			return Delegate.CreateDelegate(type, target, method, false, true);
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x0002AE8C File Offset: 0x0002908C
		public static Delegate CreateDelegate(Type type, object target, string method, bool ignoreCase, bool throwOnBindFailure)
		{
			if (target == null)
			{
				throw new ArgumentNullException("target");
			}
			MethodInfo candidateMethod = Delegate.GetCandidateMethod(type, target.GetType(), method, BindingFlags.Instance, ignoreCase, throwOnBindFailure);
			if (candidateMethod == null)
			{
				return null;
			}
			return Delegate.CreateDelegate_internal(type, target, candidateMethod, throwOnBindFailure);
		}

		// Token: 0x06000A0E RID: 2574 RVA: 0x0002AED0 File Offset: 0x000290D0
		public static Delegate CreateDelegate(Type type, object target, string method, bool ignoreCase)
		{
			return Delegate.CreateDelegate(type, target, method, ignoreCase, true);
		}

		// Token: 0x06000A0F RID: 2575 RVA: 0x0002AEDC File Offset: 0x000290DC
		public object DynamicInvoke(params object[] args)
		{
			return this.DynamicInvokeImpl(args);
		}

		// Token: 0x06000A10 RID: 2576 RVA: 0x0002AEE8 File Offset: 0x000290E8
		protected virtual object DynamicInvokeImpl(object[] args)
		{
			if (this.Method == null)
			{
				Type[] array = new Type[args.Length];
				for (int i = 0; i < args.Length; i++)
				{
					array[i] = args[i].GetType();
				}
				this.method_info = this.m_target.GetType().GetMethod(this.data.method_name, array);
			}
			if (this.m_target != null && this.Method.IsStatic)
			{
				if (args != null)
				{
					object[] array2 = new object[args.Length + 1];
					args.CopyTo(array2, 1);
					array2[0] = this.m_target;
					args = array2;
				}
				else
				{
					args = new object[] { this.m_target };
				}
				return this.Method.Invoke(null, args);
			}
			return this.Method.Invoke(this.m_target, args);
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x0002AFC0 File Offset: 0x000291C0
		public virtual object Clone()
		{
			return base.MemberwiseClone();
		}

		// Token: 0x06000A12 RID: 2578 RVA: 0x0002AFC8 File Offset: 0x000291C8
		public override bool Equals(object obj)
		{
			Delegate @delegate = obj as Delegate;
			return @delegate != null && (@delegate.m_target == this.m_target && @delegate.method == this.method) && ((@delegate.data == null && this.data == null) || (@delegate.data != null && this.data != null && @delegate.data.target_type == this.data.target_type && @delegate.data.method_name == this.data.method_name));
		}

		// Token: 0x06000A13 RID: 2579 RVA: 0x0002B078 File Offset: 0x00029278
		public override int GetHashCode()
		{
			return this.method.GetHashCode() ^ ((this.m_target == null) ? 0 : this.m_target.GetHashCode());
		}

		// Token: 0x06000A14 RID: 2580 RVA: 0x0002B0A4 File Offset: 0x000292A4
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			DelegateSerializationHolder.GetDelegateData(this, info, context);
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x0002B0B0 File Offset: 0x000292B0
		public virtual Delegate[] GetInvocationList()
		{
			return new Delegate[] { this };
		}

		// Token: 0x06000A16 RID: 2582 RVA: 0x0002B0BC File Offset: 0x000292BC
		public static Delegate Combine(Delegate a, Delegate b)
		{
			if (a == null)
			{
				if (b == null)
				{
					return null;
				}
				return b;
			}
			else
			{
				if (b == null)
				{
					return a;
				}
				if (a.GetType() != b.GetType())
				{
					throw new ArgumentException(Locale.GetText("Incompatible Delegate Types."));
				}
				return a.CombineImpl(b);
			}
		}

		// Token: 0x06000A17 RID: 2583 RVA: 0x0002B10C File Offset: 0x0002930C
		[ComVisible(true)]
		public static Delegate Combine(params Delegate[] delegates)
		{
			if (delegates == null)
			{
				return null;
			}
			Delegate @delegate = null;
			foreach (Delegate delegate2 in delegates)
			{
				@delegate = Delegate.Combine(@delegate, delegate2);
			}
			return @delegate;
		}

		// Token: 0x06000A18 RID: 2584 RVA: 0x0002B148 File Offset: 0x00029348
		protected virtual Delegate CombineImpl(Delegate d)
		{
			throw new MulticastNotSupportedException(string.Empty);
		}

		// Token: 0x06000A19 RID: 2585 RVA: 0x0002B154 File Offset: 0x00029354
		public static Delegate Remove(Delegate source, Delegate value)
		{
			if (source == null)
			{
				return null;
			}
			return source.RemoveImpl(value);
		}

		// Token: 0x06000A1A RID: 2586 RVA: 0x0002B168 File Offset: 0x00029368
		protected virtual Delegate RemoveImpl(Delegate d)
		{
			if (this.Equals(d))
			{
				return null;
			}
			return this;
		}

		// Token: 0x06000A1B RID: 2587 RVA: 0x0002B17C File Offset: 0x0002937C
		public static bool operator ==(Delegate d1, Delegate d2)
		{
			if (d1 == null)
			{
				return d2 == null;
			}
			return d2 != null && d1.Equals(d2);
		}

		// Token: 0x0400036E RID: 878
		private IntPtr method_ptr;

		// Token: 0x0400036F RID: 879
		private IntPtr invoke_impl;

		// Token: 0x04000370 RID: 880
		private object m_target;

		// Token: 0x04000371 RID: 881
		private IntPtr method;

		// Token: 0x04000372 RID: 882
		private IntPtr delegate_trampoline;

		// Token: 0x04000373 RID: 883
		private IntPtr method_code;

		// Token: 0x04000374 RID: 884
		private MethodInfo method_info;

		// Token: 0x04000375 RID: 885
		private MethodInfo original_method_info;

		// Token: 0x04000376 RID: 886
		private DelegateData data;
	}
}
