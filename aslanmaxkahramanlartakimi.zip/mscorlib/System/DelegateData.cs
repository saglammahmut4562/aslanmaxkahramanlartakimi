﻿using System;

namespace System
{
	// Token: 0x020000F5 RID: 245
	internal class DelegateData
	{
		// Token: 0x04000377 RID: 887
		public Type target_type;

		// Token: 0x04000378 RID: 888
		public string method_name;
	}
}
