﻿using System;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x020000F6 RID: 246
	[Serializable]
	internal class DelegateSerializationHolder : IObjectReference, ISerializable
	{
		// Token: 0x06000A1C RID: 2588 RVA: 0x0002B1A0 File Offset: 0x000293A0
		private DelegateSerializationHolder(SerializationInfo info, StreamingContext ctx)
		{
			DelegateSerializationHolder.DelegateEntry delegateEntry = (DelegateSerializationHolder.DelegateEntry)info.GetValue("Delegate", typeof(DelegateSerializationHolder.DelegateEntry));
			int num = 0;
			DelegateSerializationHolder.DelegateEntry delegateEntry2 = delegateEntry;
			while (delegateEntry2 != null)
			{
				delegateEntry2 = delegateEntry2.delegateEntry;
				num++;
			}
			if (num == 1)
			{
				this._delegate = delegateEntry.DeserializeDelegate(info);
			}
			else
			{
				Delegate[] array = new Delegate[num];
				delegateEntry2 = delegateEntry;
				for (int i = 0; i < num; i++)
				{
					array[i] = delegateEntry2.DeserializeDelegate(info);
					delegateEntry2 = delegateEntry2.delegateEntry;
				}
				this._delegate = Delegate.Combine(array);
			}
		}

		// Token: 0x06000A1D RID: 2589 RVA: 0x0002B240 File Offset: 0x00029440
		public static void GetDelegateData(Delegate instance, SerializationInfo info, StreamingContext ctx)
		{
			Delegate[] invocationList = instance.GetInvocationList();
			DelegateSerializationHolder.DelegateEntry delegateEntry = null;
			for (int i = 0; i < invocationList.Length; i++)
			{
				Delegate @delegate = invocationList[i];
				string text = ((@delegate.Target == null) ? null : ("target" + i));
				DelegateSerializationHolder.DelegateEntry delegateEntry2 = new DelegateSerializationHolder.DelegateEntry(@delegate, text);
				if (delegateEntry == null)
				{
					info.AddValue("Delegate", delegateEntry2);
				}
				else
				{
					delegateEntry.delegateEntry = delegateEntry2;
				}
				delegateEntry = delegateEntry2;
				if (@delegate.Target != null)
				{
					info.AddValue(text, @delegate.Target);
				}
			}
			info.SetType(typeof(DelegateSerializationHolder));
		}

		// Token: 0x06000A1E RID: 2590 RVA: 0x0002B2E8 File Offset: 0x000294E8
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0002B2F0 File Offset: 0x000294F0
		public object GetRealObject(StreamingContext context)
		{
			return this._delegate;
		}

		// Token: 0x04000379 RID: 889
		private Delegate _delegate;

		// Token: 0x020000F7 RID: 247
		[Serializable]
		private class DelegateEntry
		{
			// Token: 0x06000A20 RID: 2592 RVA: 0x0002B2F8 File Offset: 0x000294F8
			public DelegateEntry(Delegate del, string targetLabel)
			{
				this.type = del.GetType().FullName;
				this.assembly = del.GetType().Assembly.FullName;
				this.target = targetLabel;
				this.targetTypeAssembly = del.Method.DeclaringType.Assembly.FullName;
				this.targetTypeName = del.Method.DeclaringType.FullName;
				this.methodName = del.Method.Name;
			}

			// Token: 0x06000A21 RID: 2593 RVA: 0x0002B37C File Offset: 0x0002957C
			public Delegate DeserializeDelegate(SerializationInfo info)
			{
				object obj = null;
				if (this.target != null)
				{
					obj = info.GetValue(this.target.ToString(), typeof(object));
				}
				Assembly assembly = Assembly.Load(this.assembly);
				Type type = assembly.GetType(this.type);
				Delegate @delegate;
				if (obj != null)
				{
					if (RemotingServices.IsTransparentProxy(obj))
					{
						Assembly assembly2 = Assembly.Load(this.targetTypeAssembly);
						Type type2 = assembly2.GetType(this.targetTypeName);
						if (!type2.IsInstanceOfType(obj))
						{
							throw new RemotingException("Unexpected proxy type.");
						}
					}
					@delegate = Delegate.CreateDelegate(type, obj, this.methodName);
				}
				else
				{
					Assembly assembly3 = Assembly.Load(this.targetTypeAssembly);
					Type type3 = assembly3.GetType(this.targetTypeName);
					@delegate = Delegate.CreateDelegate(type, type3, this.methodName);
				}
				return @delegate;
			}

			// Token: 0x0400037A RID: 890
			private string type;

			// Token: 0x0400037B RID: 891
			private string assembly;

			// Token: 0x0400037C RID: 892
			public object target;

			// Token: 0x0400037D RID: 893
			private string targetTypeAssembly;

			// Token: 0x0400037E RID: 894
			private string targetTypeName;

			// Token: 0x0400037F RID: 895
			private string methodName;

			// Token: 0x04000380 RID: 896
			public DelegateSerializationHolder.DelegateEntry delegateEntry;
		}
	}
}
