﻿using System;

namespace System.Diagnostics.CodeAnalysis
{
	// Token: 0x020000F8 RID: 248
	[AttributeUsage(AttributeTargets.All, Inherited = false, AllowMultiple = true)]
	[Conditional("CODE_ANALYSIS")]
	public sealed class SuppressMessageAttribute : Attribute
	{
		// Token: 0x06000A22 RID: 2594 RVA: 0x0002B450 File Offset: 0x00029650
		public SuppressMessageAttribute(string category, string checkId)
		{
			this.category = category;
			this.checkId = checkId;
		}

		// Token: 0x17000176 RID: 374
		// (set) Token: 0x06000A23 RID: 2595 RVA: 0x0002B468 File Offset: 0x00029668
		public string MessageId
		{
			set
			{
				this.messageId = value;
			}
		}

		// Token: 0x04000381 RID: 897
		private string category;

		// Token: 0x04000382 RID: 898
		private string checkId;

		// Token: 0x04000383 RID: 899
		private string justification;

		// Token: 0x04000384 RID: 900
		private string messageId;

		// Token: 0x04000385 RID: 901
		private string scope;

		// Token: 0x04000386 RID: 902
		private string target;
	}
}
