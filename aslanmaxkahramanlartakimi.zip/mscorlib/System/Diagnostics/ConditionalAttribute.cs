﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics
{
	// Token: 0x020000F9 RID: 249
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
	[Serializable]
	public sealed class ConditionalAttribute : Attribute
	{
		// Token: 0x06000A24 RID: 2596 RVA: 0x0002B474 File Offset: 0x00029674
		public ConditionalAttribute(string conditionString)
		{
			this.myCondition = conditionString;
		}

		// Token: 0x04000387 RID: 903
		private string myCondition;
	}
}
