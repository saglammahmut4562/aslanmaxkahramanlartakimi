﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics
{
	// Token: 0x020000FA RID: 250
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Module)]
	public sealed class DebuggableAttribute : Attribute
	{
		// Token: 0x06000A25 RID: 2597 RVA: 0x0002B484 File Offset: 0x00029684
		public DebuggableAttribute(DebuggableAttribute.DebuggingModes modes)
		{
			this.debuggingModes = modes;
			this.JITTrackingEnabledFlag = (this.debuggingModes & DebuggableAttribute.DebuggingModes.Default) != DebuggableAttribute.DebuggingModes.None;
			this.JITOptimizerDisabledFlag = (this.debuggingModes & DebuggableAttribute.DebuggingModes.DisableOptimizations) != DebuggableAttribute.DebuggingModes.None;
		}

		// Token: 0x04000388 RID: 904
		private bool JITTrackingEnabledFlag;

		// Token: 0x04000389 RID: 905
		private bool JITOptimizerDisabledFlag;

		// Token: 0x0400038A RID: 906
		private DebuggableAttribute.DebuggingModes debuggingModes;

		// Token: 0x020000FB RID: 251
		[ComVisible(true)]
		[Flags]
		public enum DebuggingModes
		{
			// Token: 0x0400038C RID: 908
			None = 0,
			// Token: 0x0400038D RID: 909
			Default = 1,
			// Token: 0x0400038E RID: 910
			IgnoreSymbolStoreSequencePoints = 2,
			// Token: 0x0400038F RID: 911
			EnableEditAndContinue = 4,
			// Token: 0x04000390 RID: 912
			DisableOptimizations = 256
		}
	}
}
