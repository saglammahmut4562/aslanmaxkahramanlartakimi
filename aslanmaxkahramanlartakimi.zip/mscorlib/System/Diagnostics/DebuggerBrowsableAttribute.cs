﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics
{
	// Token: 0x020000FC RID: 252
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
	public sealed class DebuggerBrowsableAttribute : Attribute
	{
		// Token: 0x06000A26 RID: 2598 RVA: 0x0002B4C0 File Offset: 0x000296C0
		public DebuggerBrowsableAttribute(DebuggerBrowsableState state)
		{
			this.state = state;
		}

		// Token: 0x04000391 RID: 913
		private DebuggerBrowsableState state;
	}
}
