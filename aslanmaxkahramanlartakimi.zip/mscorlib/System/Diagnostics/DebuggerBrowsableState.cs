﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics
{
	// Token: 0x020000FD RID: 253
	[ComVisible(true)]
	public enum DebuggerBrowsableState
	{
		// Token: 0x04000393 RID: 915
		Never,
		// Token: 0x04000394 RID: 916
		Collapsed = 2,
		// Token: 0x04000395 RID: 917
		RootHidden
	}
}
