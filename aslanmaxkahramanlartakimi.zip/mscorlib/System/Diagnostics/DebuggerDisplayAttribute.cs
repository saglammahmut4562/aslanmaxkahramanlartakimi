﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics
{
	// Token: 0x020000FE RID: 254
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Delegate, AllowMultiple = true)]
	public sealed class DebuggerDisplayAttribute : Attribute
	{
		// Token: 0x06000A27 RID: 2599 RVA: 0x0002B4D0 File Offset: 0x000296D0
		public DebuggerDisplayAttribute(string value)
		{
			if (value == null)
			{
				value = string.Empty;
			}
			this.value = value;
			this.type = string.Empty;
			this.name = string.Empty;
		}

		// Token: 0x17000177 RID: 375
		// (set) Token: 0x06000A28 RID: 2600 RVA: 0x0002B504 File Offset: 0x00029704
		public string Name
		{
			set
			{
				this.name = value;
			}
		}

		// Token: 0x04000396 RID: 918
		private string value;

		// Token: 0x04000397 RID: 919
		private string type;

		// Token: 0x04000398 RID: 920
		private string name;

		// Token: 0x04000399 RID: 921
		private string target_type_name;

		// Token: 0x0400039A RID: 922
		private Type target_type;
	}
}
