﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics
{
	// Token: 0x02000101 RID: 257
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class | AttributeTargets.Struct, AllowMultiple = true)]
	[ComVisible(true)]
	public sealed class DebuggerTypeProxyAttribute : Attribute
	{
		// Token: 0x06000A2B RID: 2603 RVA: 0x0002B520 File Offset: 0x00029720
		public DebuggerTypeProxyAttribute(Type type)
		{
			this.proxy_type_name = type.Name;
		}

		// Token: 0x0400039B RID: 923
		private string proxy_type_name;

		// Token: 0x0400039C RID: 924
		private string target_type_name;

		// Token: 0x0400039D RID: 925
		private Type target_type;
	}
}
