﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;

namespace System.Diagnostics
{
	// Token: 0x02000102 RID: 258
	[MonoTODO("Serialized objects are not compatible with MS.NET")]
	[ComVisible(true)]
	[Serializable]
	public class StackFrame
	{
		// Token: 0x06000A2C RID: 2604 RVA: 0x0002B534 File Offset: 0x00029734
		public StackFrame()
		{
			bool flag = StackFrame.get_frame_info(2, false, out this.methodBase, out this.ilOffset, out this.nativeOffset, out this.fileName, out this.lineNumber, out this.columnNumber);
		}

		// Token: 0x06000A2D RID: 2605 RVA: 0x0002B584 File Offset: 0x00029784
		public StackFrame(int skipFrames, bool fNeedFileInfo)
		{
			bool flag = StackFrame.get_frame_info(skipFrames + 2, fNeedFileInfo, out this.methodBase, out this.ilOffset, out this.nativeOffset, out this.fileName, out this.lineNumber, out this.columnNumber);
		}

		// Token: 0x06000A2E RID: 2606
		[MethodImpl(4096)]
		private static extern bool get_frame_info(int skip, bool needFileInfo, out MethodBase method, out int iloffset, out int native_offset, out string file, out int line, out int column);

		// Token: 0x06000A2F RID: 2607 RVA: 0x0002B5D4 File Offset: 0x000297D4
		public virtual int GetFileLineNumber()
		{
			return this.lineNumber;
		}

		// Token: 0x06000A30 RID: 2608 RVA: 0x0002B5DC File Offset: 0x000297DC
		public virtual string GetFileName()
		{
			return this.fileName;
		}

		// Token: 0x06000A31 RID: 2609 RVA: 0x0002B5E4 File Offset: 0x000297E4
		internal string GetSecureFileName()
		{
			string text = "<filename unknown>";
			if (this.fileName == null)
			{
				return text;
			}
			try
			{
				text = this.GetFileName();
			}
			catch (SecurityException)
			{
			}
			return text;
		}

		// Token: 0x06000A32 RID: 2610 RVA: 0x0002B628 File Offset: 0x00029828
		public virtual int GetILOffset()
		{
			return this.ilOffset;
		}

		// Token: 0x06000A33 RID: 2611 RVA: 0x0002B630 File Offset: 0x00029830
		public virtual MethodBase GetMethod()
		{
			return this.methodBase;
		}

		// Token: 0x06000A34 RID: 2612 RVA: 0x0002B638 File Offset: 0x00029838
		public virtual int GetNativeOffset()
		{
			return this.nativeOffset;
		}

		// Token: 0x06000A35 RID: 2613 RVA: 0x0002B640 File Offset: 0x00029840
		internal string GetInternalMethodName()
		{
			return this.internalMethodName;
		}

		// Token: 0x06000A36 RID: 2614 RVA: 0x0002B648 File Offset: 0x00029848
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			if (this.methodBase == null)
			{
				stringBuilder.Append(Locale.GetText("<unknown method>"));
			}
			else
			{
				stringBuilder.Append(this.methodBase.Name);
			}
			stringBuilder.Append(Locale.GetText(" at "));
			if (this.ilOffset == -1)
			{
				stringBuilder.Append(Locale.GetText("<unknown offset>"));
			}
			else
			{
				stringBuilder.Append(Locale.GetText("offset "));
				stringBuilder.Append(this.ilOffset);
			}
			stringBuilder.Append(Locale.GetText(" in file:line:column "));
			stringBuilder.Append(this.GetSecureFileName());
			stringBuilder.AppendFormat(":{0}:{1}", this.lineNumber, this.columnNumber);
			return stringBuilder.ToString();
		}

		// Token: 0x0400039E RID: 926
		public const int OFFSET_UNKNOWN = -1;

		// Token: 0x0400039F RID: 927
		private int ilOffset = -1;

		// Token: 0x040003A0 RID: 928
		private int nativeOffset = -1;

		// Token: 0x040003A1 RID: 929
		private MethodBase methodBase;

		// Token: 0x040003A2 RID: 930
		private string fileName;

		// Token: 0x040003A3 RID: 931
		private int lineNumber;

		// Token: 0x040003A4 RID: 932
		private int columnNumber;

		// Token: 0x040003A5 RID: 933
		private string internalMethodName;
	}
}
