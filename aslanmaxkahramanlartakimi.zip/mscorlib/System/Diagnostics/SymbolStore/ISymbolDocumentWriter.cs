﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics.SymbolStore
{
	// Token: 0x02000104 RID: 260
	[ComVisible(true)]
	public interface ISymbolDocumentWriter
	{
	}
}
