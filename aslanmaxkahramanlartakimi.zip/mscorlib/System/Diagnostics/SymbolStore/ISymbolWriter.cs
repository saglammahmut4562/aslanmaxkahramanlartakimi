﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics.SymbolStore
{
	// Token: 0x02000105 RID: 261
	[ComVisible(true)]
	public interface ISymbolWriter
	{
		// Token: 0x06000A41 RID: 2625
		void Initialize(IntPtr emitter, string filename, bool fFullBuild);
	}
}
