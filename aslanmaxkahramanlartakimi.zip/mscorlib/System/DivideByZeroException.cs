﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000106 RID: 262
	[ComVisible(true)]
	[Serializable]
	public class DivideByZeroException : ArithmeticException
	{
		// Token: 0x06000A42 RID: 2626 RVA: 0x0002BAF0 File Offset: 0x00029CF0
		public DivideByZeroException()
			: base(Locale.GetText("Division by zero"))
		{
			base.HResult = -2147352558;
		}

		// Token: 0x06000A43 RID: 2627 RVA: 0x0002BB10 File Offset: 0x00029D10
		public DivideByZeroException(string message)
			: base(message)
		{
			base.HResult = -2147352558;
		}

		// Token: 0x06000A44 RID: 2628 RVA: 0x0002BB24 File Offset: 0x00029D24
		public DivideByZeroException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2147352558;
		}

		// Token: 0x06000A45 RID: 2629 RVA: 0x0002BB3C File Offset: 0x00029D3C
		protected DivideByZeroException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x040003A9 RID: 937
		private const int Result = -2147352558;
	}
}
