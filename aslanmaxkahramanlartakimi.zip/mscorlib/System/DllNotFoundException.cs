﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000107 RID: 263
	[ComVisible(true)]
	[Serializable]
	public class DllNotFoundException : TypeLoadException
	{
		// Token: 0x06000A46 RID: 2630 RVA: 0x0002BB48 File Offset: 0x00029D48
		public DllNotFoundException()
			: base(Locale.GetText("DLL not found."))
		{
			base.HResult = -2146233052;
		}

		// Token: 0x06000A47 RID: 2631 RVA: 0x0002BB68 File Offset: 0x00029D68
		public DllNotFoundException(string message)
			: base(message)
		{
			base.HResult = -2146233052;
		}

		// Token: 0x06000A48 RID: 2632 RVA: 0x0002BB7C File Offset: 0x00029D7C
		protected DllNotFoundException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x06000A49 RID: 2633 RVA: 0x0002BB88 File Offset: 0x00029D88
		public DllNotFoundException(string message, Exception inner)
			: base(message, inner)
		{
			base.HResult = -2146233052;
		}

		// Token: 0x040003AA RID: 938
		private const int Result = -2146233052;
	}
}
