﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000108 RID: 264
	[ComVisible(true)]
	[Serializable]
	public struct Double : IComparable<double>, IEquatable<double>, IComparable, IConvertible, IFormattable
	{
		// Token: 0x06000A4A RID: 2634 RVA: 0x0002BBA0 File Offset: 0x00029DA0
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			return Convert.ToType(this, targetType, provider, false);
		}

		// Token: 0x06000A4B RID: 2635 RVA: 0x0002BBC4 File Offset: 0x00029DC4
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return Convert.ToBoolean(this);
		}

		// Token: 0x06000A4C RID: 2636 RVA: 0x0002BBD0 File Offset: 0x00029DD0
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this);
		}

		// Token: 0x06000A4D RID: 2637 RVA: 0x0002BBDC File Offset: 0x00029DDC
		char IConvertible.ToChar(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x06000A4E RID: 2638 RVA: 0x0002BBE4 File Offset: 0x00029DE4
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			throw new InvalidCastException();
		}

		// Token: 0x06000A4F RID: 2639 RVA: 0x0002BBEC File Offset: 0x00029DEC
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return Convert.ToDecimal(this);
		}

		// Token: 0x06000A50 RID: 2640 RVA: 0x0002BBF8 File Offset: 0x00029DF8
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this);
		}

		// Token: 0x06000A51 RID: 2641 RVA: 0x0002BC04 File Offset: 0x00029E04
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x06000A52 RID: 2642 RVA: 0x0002BC10 File Offset: 0x00029E10
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x06000A53 RID: 2643 RVA: 0x0002BC1C File Offset: 0x00029E1C
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x06000A54 RID: 2644 RVA: 0x0002BC28 File Offset: 0x00029E28
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x06000A55 RID: 2645 RVA: 0x0002BC34 File Offset: 0x00029E34
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return Convert.ToSingle(this);
		}

		// Token: 0x06000A56 RID: 2646 RVA: 0x0002BC40 File Offset: 0x00029E40
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x06000A57 RID: 2647 RVA: 0x0002BC4C File Offset: 0x00029E4C
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x06000A58 RID: 2648 RVA: 0x0002BC58 File Offset: 0x00029E58
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x06000A59 RID: 2649 RVA: 0x0002BC64 File Offset: 0x00029E64
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is double))
			{
				throw new ArgumentException(Locale.GetText("Value is not a System.Double"));
			}
			double num = (double)value;
			if (double.IsPositiveInfinity(this) && double.IsPositiveInfinity(num))
			{
				return 0;
			}
			if (double.IsNegativeInfinity(this) && double.IsNegativeInfinity(num))
			{
				return 0;
			}
			if (double.IsNaN(num))
			{
				if (double.IsNaN(this))
				{
					return 0;
				}
				return 1;
			}
			else if (double.IsNaN(this))
			{
				if (double.IsNaN(num))
				{
					return 0;
				}
				return -1;
			}
			else
			{
				if (this > num)
				{
					return 1;
				}
				if (this < num)
				{
					return -1;
				}
				return 0;
			}
		}

		// Token: 0x06000A5A RID: 2650 RVA: 0x0002BD18 File Offset: 0x00029F18
		public override bool Equals(object obj)
		{
			if (!(obj is double))
			{
				return false;
			}
			double num = (double)obj;
			if (double.IsNaN(num))
			{
				return double.IsNaN(this);
			}
			return num == this;
		}

		// Token: 0x06000A5B RID: 2651 RVA: 0x0002BD54 File Offset: 0x00029F54
		public int CompareTo(double value)
		{
			if (double.IsPositiveInfinity(this) && double.IsPositiveInfinity(value))
			{
				return 0;
			}
			if (double.IsNegativeInfinity(this) && double.IsNegativeInfinity(value))
			{
				return 0;
			}
			if (double.IsNaN(value))
			{
				if (double.IsNaN(this))
				{
					return 0;
				}
				return 1;
			}
			else if (double.IsNaN(this))
			{
				if (double.IsNaN(value))
				{
					return 0;
				}
				return -1;
			}
			else
			{
				if (this > value)
				{
					return 1;
				}
				if (this < value)
				{
					return -1;
				}
				return 0;
			}
		}

		// Token: 0x06000A5C RID: 2652 RVA: 0x0002BDE0 File Offset: 0x00029FE0
		public bool Equals(double obj)
		{
			if (double.IsNaN(obj))
			{
				return double.IsNaN(this);
			}
			return obj == this;
		}

		// Token: 0x06000A5D RID: 2653 RVA: 0x0002BE04 File Offset: 0x0002A004
		public override int GetHashCode()
		{
			double num = this;
			return num.GetHashCode();
		}

		// Token: 0x06000A5E RID: 2654 RVA: 0x0002BE1C File Offset: 0x0002A01C
		public static bool IsInfinity(double d)
		{
			return d == double.PositiveInfinity || d == double.NegativeInfinity;
		}

		// Token: 0x06000A5F RID: 2655 RVA: 0x0002BE3C File Offset: 0x0002A03C
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static bool IsNaN(double d)
		{
			return d != d;
		}

		// Token: 0x06000A60 RID: 2656 RVA: 0x0002BE48 File Offset: 0x0002A048
		public static bool IsNegativeInfinity(double d)
		{
			return d < 0.0 && (d == double.NegativeInfinity || d == double.PositiveInfinity);
		}

		// Token: 0x06000A61 RID: 2657 RVA: 0x0002BE7C File Offset: 0x0002A07C
		public static bool IsPositiveInfinity(double d)
		{
			return d > 0.0 && (d == double.NegativeInfinity || d == double.PositiveInfinity);
		}

		// Token: 0x06000A62 RID: 2658 RVA: 0x0002BEB0 File Offset: 0x0002A0B0
		public static double Parse(string s)
		{
			return double.Parse(s, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, null);
		}

		// Token: 0x06000A63 RID: 2659 RVA: 0x0002BEC0 File Offset: 0x0002A0C0
		public static double Parse(string s, IFormatProvider provider)
		{
			return double.Parse(s, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, provider);
		}

		// Token: 0x06000A64 RID: 2660 RVA: 0x0002BED0 File Offset: 0x0002A0D0
		public static double Parse(string s, NumberStyles style, IFormatProvider provider)
		{
			double num;
			Exception ex;
			if (!double.Parse(s, style, provider, false, out num, out ex))
			{
				throw ex;
			}
			return num;
		}

		// Token: 0x06000A65 RID: 2661 RVA: 0x0002BEF4 File Offset: 0x0002A0F4
		internal unsafe static bool Parse(string s, NumberStyles style, IFormatProvider provider, bool tryParse, out double result, out Exception exc)
		{
			result = 0.0;
			exc = null;
			if (s == null)
			{
				if (!tryParse)
				{
					exc = new ArgumentNullException("s");
				}
				return false;
			}
			if (s.Length == 0)
			{
				if (!tryParse)
				{
					exc = new FormatException();
				}
				return false;
			}
			if ((style & NumberStyles.AllowHexSpecifier) != NumberStyles.None)
			{
				string text = Locale.GetText("Double doesn't support parsing with '{0}'.", new object[] { "AllowHexSpecifier" });
				throw new ArgumentException(text);
			}
			if (style > NumberStyles.Any)
			{
				if (!tryParse)
				{
					exc = new ArgumentException();
				}
				return false;
			}
			NumberFormatInfo instance = NumberFormatInfo.GetInstance(provider);
			if (instance == null)
			{
				throw new Exception("How did this happen?");
			}
			int length = s.Length;
			int num = 0;
			int i = 0;
			bool flag = (style & NumberStyles.AllowLeadingWhite) != NumberStyles.None;
			bool flag2 = (style & NumberStyles.AllowTrailingWhite) != NumberStyles.None;
			if (flag)
			{
				while (i < length && char.IsWhiteSpace(s[i]))
				{
					i++;
				}
				if (i == length)
				{
					if (!tryParse)
					{
						exc = int.GetFormatException();
					}
					return false;
				}
			}
			int num2 = s.Length - 1;
			if (flag2)
			{
				while (char.IsWhiteSpace(s[num2]))
				{
					num2--;
				}
			}
			if (double.TryParseStringConstant(instance.NaNSymbol, s, i, num2))
			{
				result = double.NaN;
				return true;
			}
			if (double.TryParseStringConstant(instance.PositiveInfinitySymbol, s, i, num2))
			{
				result = double.PositiveInfinity;
				return true;
			}
			if (double.TryParseStringConstant(instance.NegativeInfinitySymbol, s, i, num2))
			{
				result = double.NegativeInfinity;
				return true;
			}
			byte[] array = new byte[length + 1];
			int num3 = 1;
			string text2 = null;
			string text3 = null;
			string text4 = null;
			int num4 = 0;
			int num5 = 0;
			int num6 = 0;
			if ((style & NumberStyles.AllowDecimalPoint) != NumberStyles.None)
			{
				text2 = instance.NumberDecimalSeparator;
				num4 = text2.Length;
			}
			if ((style & NumberStyles.AllowThousands) != NumberStyles.None)
			{
				text3 = instance.NumberGroupSeparator;
				num5 = text3.Length;
			}
			if ((style & NumberStyles.AllowCurrencySymbol) != NumberStyles.None)
			{
				text4 = instance.CurrencySymbol;
				num6 = text4.Length;
			}
			string positiveSign = instance.PositiveSign;
			string negativeSign = instance.NegativeSign;
			while (i < length)
			{
				char c = s[i];
				if (c == '\0')
				{
					i = length;
				}
				else
				{
					switch (num3)
					{
					case 1:
						if ((style & NumberStyles.AllowLeadingSign) != NumberStyles.None)
						{
							if (c == positiveSign[0] && s.Substring(i, positiveSign.Length) == positiveSign)
							{
								num3 = 2;
								i += positiveSign.Length - 1;
								goto IL_0624;
							}
							if (c == negativeSign[0] && s.Substring(i, negativeSign.Length) == negativeSign)
							{
								num3 = 2;
								array[num++] = 45;
								i += negativeSign.Length - 1;
								goto IL_0624;
							}
						}
						num3 = 2;
						goto IL_0304;
					case 2:
						goto IL_0304;
					case 3:
						goto IL_0429;
					case 4:
						if (char.IsDigit(c))
						{
							num3 = 5;
							goto IL_0599;
						}
						if (c == positiveSign[0] && s.Substring(i, positiveSign.Length) == positiveSign)
						{
							num3 = 2;
							i += positiveSign.Length - 1;
							goto IL_0624;
						}
						if (c == negativeSign[0] && s.Substring(i, negativeSign.Length) == negativeSign)
						{
							num3 = 2;
							array[num++] = 45;
							i += negativeSign.Length - 1;
							goto IL_0624;
						}
						if (char.IsWhiteSpace(c))
						{
							goto IL_05E7;
						}
						if (!tryParse)
						{
							exc = new FormatException("Unknown char: " + c);
						}
						return false;
					case 5:
						goto IL_0599;
					case 6:
						goto IL_05E7;
					}
					IL_0617:
					if (num3 == 7)
					{
						break;
					}
					goto IL_0624;
					IL_0429:
					if (char.IsDigit(c))
					{
						array[num++] = (byte)c;
						goto IL_0617;
					}
					if (c == 'e' || c == 'E')
					{
						if ((style & NumberStyles.AllowExponent) == NumberStyles.None)
						{
							if (!tryParse)
							{
								exc = new FormatException("Unknown char: " + c);
							}
							return false;
						}
						array[num++] = (byte)c;
						num3 = 4;
						goto IL_0617;
					}
					else
					{
						if (char.IsWhiteSpace(c))
						{
							goto IL_05E7;
						}
						if (!tryParse)
						{
							exc = new FormatException("Unknown char: " + c);
						}
						return false;
					}
					IL_0304:
					if (char.IsDigit(c))
					{
						array[num++] = (byte)c;
						goto IL_0617;
					}
					if (c == 'e' || c == 'E')
					{
						goto IL_0429;
					}
					if (num4 > 0 && text2[0] == c && string.CompareOrdinal(s, i, text2, 0, num4) == 0)
					{
						array[num++] = 46;
						i += num4 - 1;
						num3 = 3;
						goto IL_0617;
					}
					if (num5 > 0 && text3[0] == c && s.Substring(i, num5) == text3)
					{
						i += num5 - 1;
						num3 = 2;
						goto IL_0617;
					}
					if (num6 > 0 && text4[0] == c && s.Substring(i, num6) == text4)
					{
						i += num6 - 1;
						num3 = 2;
						goto IL_0617;
					}
					if (char.IsWhiteSpace(c))
					{
						goto IL_05E7;
					}
					if (!tryParse)
					{
						exc = new FormatException("Unknown char: " + c);
					}
					return false;
					IL_0599:
					if (char.IsDigit(c))
					{
						array[num++] = (byte)c;
						goto IL_0617;
					}
					if (!char.IsWhiteSpace(c))
					{
						if (!tryParse)
						{
							exc = new FormatException("Unknown char: " + c);
						}
						return false;
					}
					IL_05E7:
					if (flag2 && char.IsWhiteSpace(c))
					{
						num3 = 6;
						goto IL_0617;
					}
					if (!tryParse)
					{
						exc = new FormatException("Unknown char");
					}
					return false;
				}
				IL_0624:
				i++;
			}
			array[num] = 0;
			double num7;
			if (!double.ParseImpl(&array[0], out num7))
			{
				if (!tryParse)
				{
					exc = int.GetFormatException();
				}
				return false;
			}
			if (double.IsPositiveInfinity(num7) || double.IsNegativeInfinity(num7))
			{
				if (!tryParse)
				{
					exc = new OverflowException();
				}
				return false;
			}
			result = num7;
			return true;
		}

		// Token: 0x06000A66 RID: 2662 RVA: 0x0002C590 File Offset: 0x0002A790
		private static bool TryParseStringConstant(string format, string s, int start, int end)
		{
			return end - start + 1 == format.Length && string.CompareOrdinal(format, 0, s, start, format.Length) == 0;
		}

		// Token: 0x06000A67 RID: 2663
		[MethodImpl(4096)]
		private unsafe static extern bool ParseImpl(byte* byte_ptr, out double value);

		// Token: 0x06000A68 RID: 2664 RVA: 0x0002C5B8 File Offset: 0x0002A7B8
		public override string ToString()
		{
			return NumberFormatter.NumberToString(this, null);
		}

		// Token: 0x06000A69 RID: 2665 RVA: 0x0002C5C4 File Offset: 0x0002A7C4
		public string ToString(IFormatProvider provider)
		{
			return NumberFormatter.NumberToString(this, provider);
		}

		// Token: 0x06000A6A RID: 2666 RVA: 0x0002C5D0 File Offset: 0x0002A7D0
		public string ToString(string format, IFormatProvider provider)
		{
			return NumberFormatter.NumberToString(format, this, provider);
		}

		// Token: 0x06000A6B RID: 2667 RVA: 0x0002C5DC File Offset: 0x0002A7DC
		public TypeCode GetTypeCode()
		{
			return TypeCode.Double;
		}

		// Token: 0x040003AB RID: 939
		public const double Epsilon = 5E-324;

		// Token: 0x040003AC RID: 940
		public const double MaxValue = 1.7976931348623157E+308;

		// Token: 0x040003AD RID: 941
		public const double MinValue = -1.7976931348623157E+308;

		// Token: 0x040003AE RID: 942
		public const double NaN = double.NaN;

		// Token: 0x040003AF RID: 943
		public const double NegativeInfinity = double.NegativeInfinity;

		// Token: 0x040003B0 RID: 944
		public const double PositiveInfinity = double.PositiveInfinity;

		// Token: 0x040003B1 RID: 945
		private const int State_AllowSign = 1;

		// Token: 0x040003B2 RID: 946
		private const int State_Digits = 2;

		// Token: 0x040003B3 RID: 947
		private const int State_Decimal = 3;

		// Token: 0x040003B4 RID: 948
		private const int State_ExponentSign = 4;

		// Token: 0x040003B5 RID: 949
		private const int State_Exponent = 5;

		// Token: 0x040003B6 RID: 950
		private const int State_ConsumeWhiteSpace = 6;

		// Token: 0x040003B7 RID: 951
		private const int State_Exit = 7;

		// Token: 0x040003B8 RID: 952
		internal double m_value;
	}
}
