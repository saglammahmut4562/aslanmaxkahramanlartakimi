﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000109 RID: 265
	[ComVisible(true)]
	[Serializable]
	public class EntryPointNotFoundException : TypeLoadException
	{
		// Token: 0x06000A6C RID: 2668 RVA: 0x0002C5E0 File Offset: 0x0002A7E0
		public EntryPointNotFoundException()
			: base(Locale.GetText("Cannot load class because of missing entry method."))
		{
			base.HResult = -2146233053;
		}

		// Token: 0x06000A6D RID: 2669 RVA: 0x0002C600 File Offset: 0x0002A800
		public EntryPointNotFoundException(string message)
			: base(message)
		{
			base.HResult = -2146233053;
		}

		// Token: 0x06000A6E RID: 2670 RVA: 0x0002C614 File Offset: 0x0002A814
		protected EntryPointNotFoundException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x06000A6F RID: 2671 RVA: 0x0002C620 File Offset: 0x0002A820
		public EntryPointNotFoundException(string message, Exception inner)
			: base(message, inner)
		{
			base.HResult = -2146233053;
		}

		// Token: 0x040003B9 RID: 953
		private const int Result = -2146233053;
	}
}
