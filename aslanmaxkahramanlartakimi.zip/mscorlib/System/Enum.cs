﻿using System;
using System.Collections;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200010A RID: 266
	[ComVisible(true)]
	[Serializable]
	public abstract class Enum : ValueType, IComparable, IConvertible, IFormattable
	{
		// Token: 0x06000A72 RID: 2674 RVA: 0x0002C654 File Offset: 0x0002A854
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return Convert.ToBoolean(this.Value, provider);
		}

		// Token: 0x06000A73 RID: 2675 RVA: 0x0002C664 File Offset: 0x0002A864
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this.Value, provider);
		}

		// Token: 0x06000A74 RID: 2676 RVA: 0x0002C674 File Offset: 0x0002A874
		char IConvertible.ToChar(IFormatProvider provider)
		{
			return Convert.ToChar(this.Value, provider);
		}

		// Token: 0x06000A75 RID: 2677 RVA: 0x0002C684 File Offset: 0x0002A884
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			return Convert.ToDateTime(this.Value, provider);
		}

		// Token: 0x06000A76 RID: 2678 RVA: 0x0002C694 File Offset: 0x0002A894
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return Convert.ToDecimal(this.Value, provider);
		}

		// Token: 0x06000A77 RID: 2679 RVA: 0x0002C6A4 File Offset: 0x0002A8A4
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this.Value, provider);
		}

		// Token: 0x06000A78 RID: 2680 RVA: 0x0002C6B4 File Offset: 0x0002A8B4
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this.Value, provider);
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x0002C6C4 File Offset: 0x0002A8C4
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this.Value, provider);
		}

		// Token: 0x06000A7A RID: 2682 RVA: 0x0002C6D4 File Offset: 0x0002A8D4
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this.Value, provider);
		}

		// Token: 0x06000A7B RID: 2683 RVA: 0x0002C6E4 File Offset: 0x0002A8E4
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this.Value, provider);
		}

		// Token: 0x06000A7C RID: 2684 RVA: 0x0002C6F4 File Offset: 0x0002A8F4
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return Convert.ToSingle(this.Value, provider);
		}

		// Token: 0x06000A7D RID: 2685 RVA: 0x0002C704 File Offset: 0x0002A904
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			if (targetType == typeof(string))
			{
				return this.ToString(provider);
			}
			return Convert.ToType(this.Value, targetType, provider, false);
		}

		// Token: 0x06000A7E RID: 2686 RVA: 0x0002C740 File Offset: 0x0002A940
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this.Value, provider);
		}

		// Token: 0x06000A7F RID: 2687 RVA: 0x0002C750 File Offset: 0x0002A950
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this.Value, provider);
		}

		// Token: 0x06000A80 RID: 2688 RVA: 0x0002C760 File Offset: 0x0002A960
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this.Value, provider);
		}

		// Token: 0x06000A81 RID: 2689 RVA: 0x0002C770 File Offset: 0x0002A970
		public TypeCode GetTypeCode()
		{
			return Type.GetTypeCode(Enum.GetUnderlyingType(base.GetType()));
		}

		// Token: 0x06000A82 RID: 2690
		[MethodImpl(4096)]
		private extern object get_value();

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x06000A83 RID: 2691 RVA: 0x0002C784 File Offset: 0x0002A984
		private object Value
		{
			get
			{
				return this.get_value();
			}
		}

		// Token: 0x06000A84 RID: 2692 RVA: 0x0002C78C File Offset: 0x0002A98C
		[ComVisible(true)]
		public static Array GetValues(Type enumType)
		{
			if (enumType == null)
			{
				throw new ArgumentNullException("enumType");
			}
			if (!enumType.IsEnum)
			{
				throw new ArgumentException("enumType is not an Enum type.", "enumType");
			}
			MonoEnumInfo monoEnumInfo;
			MonoEnumInfo.GetInfo(enumType, out monoEnumInfo);
			return (Array)monoEnumInfo.values.Clone();
		}

		// Token: 0x06000A85 RID: 2693 RVA: 0x0002C7E0 File Offset: 0x0002A9E0
		private static int FindPosition(object value, Array values)
		{
			int[] array = values as int[];
			if (array != null)
			{
				return Array.BinarySearch(array, (int)value, MonoEnumInfo.int_comparer);
			}
			uint[] array2 = values as uint[];
			if (array2 != null)
			{
				return Array.BinarySearch<uint>(array2, (uint)value);
			}
			short[] array3 = values as short[];
			if (array3 != null)
			{
				return Array.BinarySearch(array3, (short)value, MonoEnumInfo.short_comparer);
			}
			ushort[] array4 = values as ushort[];
			if (array4 != null)
			{
				return Array.BinarySearch<ushort>(array4, (ushort)value);
			}
			sbyte[] array5 = values as sbyte[];
			if (array5 != null)
			{
				return Array.BinarySearch(array5, (sbyte)value, MonoEnumInfo.sbyte_comparer);
			}
			byte[] array6 = values as byte[];
			if (array6 != null)
			{
				return Array.BinarySearch<byte>(array6, (byte)value);
			}
			long[] array7 = values as long[];
			if (array7 != null)
			{
				return Array.BinarySearch(array7, (long)value, MonoEnumInfo.long_comparer);
			}
			ulong[] array8 = values as ulong[];
			if (array8 != null)
			{
				return Array.BinarySearch<ulong>(array8, (ulong)value);
			}
			return Array.BinarySearch(values, value);
		}

		// Token: 0x06000A86 RID: 2694 RVA: 0x0002C8F8 File Offset: 0x0002AAF8
		[ComVisible(true)]
		public static string GetName(Type enumType, object value)
		{
			if (enumType == null)
			{
				throw new ArgumentNullException("enumType");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (!enumType.IsEnum)
			{
				throw new ArgumentException("enumType is not an Enum type.", "enumType");
			}
			value = Enum.ToObject(enumType, value);
			MonoEnumInfo monoEnumInfo;
			MonoEnumInfo.GetInfo(enumType, out monoEnumInfo);
			int num = Enum.FindPosition(value, monoEnumInfo.values);
			return (num < 0) ? null : monoEnumInfo.names[num];
		}

		// Token: 0x06000A87 RID: 2695 RVA: 0x0002C978 File Offset: 0x0002AB78
		[ComVisible(true)]
		public static bool IsDefined(Type enumType, object value)
		{
			if (enumType == null)
			{
				throw new ArgumentNullException("enumType");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (!enumType.IsEnum)
			{
				throw new ArgumentException("enumType is not an Enum type.", "enumType");
			}
			MonoEnumInfo monoEnumInfo;
			MonoEnumInfo.GetInfo(enumType, out monoEnumInfo);
			Type type = value.GetType();
			if (type == typeof(string))
			{
				return ((IList)monoEnumInfo.names).Contains(value);
			}
			if (type == monoEnumInfo.utype || type == enumType)
			{
				value = Enum.ToObject(enumType, value);
				MonoEnumInfo.GetInfo(enumType, out monoEnumInfo);
				return Enum.FindPosition(value, monoEnumInfo.values) >= 0;
			}
			throw new ArgumentException("The value parameter is not the correct type.It must be type String or the same type as the underlying typeof the Enum.");
		}

		// Token: 0x06000A88 RID: 2696
		[MethodImpl(4096)]
		private static extern Type get_underlying_type(Type enumType);

		// Token: 0x06000A89 RID: 2697 RVA: 0x0002CA34 File Offset: 0x0002AC34
		[ComVisible(true)]
		public static Type GetUnderlyingType(Type enumType)
		{
			if (enumType == null)
			{
				throw new ArgumentNullException("enumType");
			}
			if (!enumType.IsEnum)
			{
				throw new ArgumentException("enumType is not an Enum type.", "enumType");
			}
			return Enum.get_underlying_type(enumType);
		}

		// Token: 0x06000A8A RID: 2698 RVA: 0x0002CA68 File Offset: 0x0002AC68
		[ComVisible(true)]
		public static object Parse(Type enumType, string value)
		{
			return Enum.Parse(enumType, value, false);
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x0002CA74 File Offset: 0x0002AC74
		private static int FindName(Hashtable name_hash, string[] names, string name, bool ignoreCase)
		{
			if (!ignoreCase)
			{
				if (name_hash != null)
				{
					object obj = name_hash[name];
					if (obj != null)
					{
						return (int)obj;
					}
				}
				else
				{
					for (int i = 0; i < names.Length; i++)
					{
						if (name == names[i])
						{
							return i;
						}
					}
				}
			}
			else
			{
				for (int j = 0; j < names.Length; j++)
				{
					if (string.Compare(name, names[j], ignoreCase, CultureInfo.InvariantCulture) == 0)
					{
						return j;
					}
				}
			}
			return -1;
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x0002CAFC File Offset: 0x0002ACFC
		private static ulong GetValue(object value, TypeCode typeCode)
		{
			switch (typeCode)
			{
			case TypeCode.SByte:
				return (ulong)((byte)((sbyte)value));
			case TypeCode.Byte:
				return (ulong)((byte)value);
			case TypeCode.Int16:
				return (ulong)((ushort)((short)value));
			case TypeCode.UInt16:
				return (ulong)((ushort)value);
			case TypeCode.Int32:
				return (ulong)((int)value);
			case TypeCode.UInt32:
				return (ulong)((uint)value);
			case TypeCode.Int64:
				return (ulong)((long)value);
			case TypeCode.UInt64:
				return (ulong)value;
			default:
				throw new ArgumentException("typeCode is not a valid type code for an Enum");
			}
		}

		// Token: 0x06000A8D RID: 2701 RVA: 0x0002CB84 File Offset: 0x0002AD84
		[ComVisible(true)]
		public static object Parse(Type enumType, string value, bool ignoreCase)
		{
			if (enumType == null)
			{
				throw new ArgumentNullException("enumType");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (!enumType.IsEnum)
			{
				throw new ArgumentException("enumType is not an Enum type.", "enumType");
			}
			value = value.Trim();
			if (value.Length == 0)
			{
				throw new ArgumentException("An empty string is not considered a valid value.");
			}
			MonoEnumInfo monoEnumInfo;
			MonoEnumInfo.GetInfo(enumType, out monoEnumInfo);
			int num = Enum.FindName(monoEnumInfo.name_hash, monoEnumInfo.names, value, ignoreCase);
			if (num >= 0)
			{
				return monoEnumInfo.values.GetValue(num);
			}
			TypeCode typeCode = ((Enum)monoEnumInfo.values.GetValue(0)).GetTypeCode();
			if (value.IndexOf(',') != -1)
			{
				string[] array = value.Split(Enum.split_char);
				ulong num2 = 0UL;
				for (int i = 0; i < array.Length; i++)
				{
					num = Enum.FindName(monoEnumInfo.name_hash, monoEnumInfo.names, array[i].Trim(), ignoreCase);
					if (num < 0)
					{
						throw new ArgumentException("The requested value was not found.");
					}
					num2 |= Enum.GetValue(monoEnumInfo.values.GetValue(num), typeCode);
				}
				return Enum.ToObject(enumType, num2);
			}
			switch (typeCode)
			{
			case TypeCode.SByte:
			{
				sbyte b;
				if (sbyte.TryParse(value, out b))
				{
					return Enum.ToObject(enumType, b);
				}
				break;
			}
			case TypeCode.Byte:
			{
				byte b2;
				if (byte.TryParse(value, out b2))
				{
					return Enum.ToObject(enumType, b2);
				}
				break;
			}
			case TypeCode.Int16:
			{
				short num3;
				if (short.TryParse(value, out num3))
				{
					return Enum.ToObject(enumType, num3);
				}
				break;
			}
			case TypeCode.UInt16:
			{
				ushort num4;
				if (ushort.TryParse(value, out num4))
				{
					return Enum.ToObject(enumType, num4);
				}
				break;
			}
			case TypeCode.Int32:
			{
				int num5;
				if (int.TryParse(value, out num5))
				{
					return Enum.ToObject(enumType, num5);
				}
				break;
			}
			case TypeCode.UInt32:
			{
				uint num6;
				if (uint.TryParse(value, out num6))
				{
					return Enum.ToObject(enumType, num6);
				}
				break;
			}
			case TypeCode.Int64:
			{
				long num7;
				if (long.TryParse(value, out num7))
				{
					return Enum.ToObject(enumType, num7);
				}
				break;
			}
			case TypeCode.UInt64:
			{
				ulong num8;
				if (ulong.TryParse(value, out num8))
				{
					return Enum.ToObject(enumType, num8);
				}
				break;
			}
			}
			throw new ArgumentException(string.Format("The requested value '{0}' was not found.", value));
		}

		// Token: 0x06000A8E RID: 2702
		[MethodImpl(4096)]
		private extern int compare_value_to(object other);

		// Token: 0x06000A8F RID: 2703 RVA: 0x0002CDDC File Offset: 0x0002AFDC
		public int CompareTo(object target)
		{
			if (target == null)
			{
				return 1;
			}
			Type type = base.GetType();
			if (target.GetType() != type)
			{
				throw new ArgumentException(string.Format("Object must be the same type as the enum. The type passed in was {0}; the enum type was {1}.", target.GetType(), type));
			}
			return this.compare_value_to(target);
		}

		// Token: 0x06000A90 RID: 2704 RVA: 0x0002CE24 File Offset: 0x0002B024
		public override string ToString()
		{
			return this.ToString("G");
		}

		// Token: 0x06000A91 RID: 2705 RVA: 0x0002CE34 File Offset: 0x0002B034
		[Obsolete("Provider is ignored, just use ToString")]
		public string ToString(IFormatProvider provider)
		{
			return this.ToString("G", provider);
		}

		// Token: 0x06000A92 RID: 2706 RVA: 0x0002CE44 File Offset: 0x0002B044
		public string ToString(string format)
		{
			if (format == string.Empty || format == null)
			{
				format = "G";
			}
			return Enum.Format(base.GetType(), this.Value, format);
		}

		// Token: 0x06000A93 RID: 2707 RVA: 0x0002CE78 File Offset: 0x0002B078
		[Obsolete("Provider is ignored, just use ToString")]
		public string ToString(string format, IFormatProvider provider)
		{
			if (format == string.Empty || format == null)
			{
				format = "G";
			}
			return Enum.Format(base.GetType(), this.Value, format);
		}

		// Token: 0x06000A94 RID: 2708 RVA: 0x0002CEAC File Offset: 0x0002B0AC
		[ComVisible(true)]
		public static object ToObject(Type enumType, byte value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A95 RID: 2709 RVA: 0x0002CEBC File Offset: 0x0002B0BC
		[ComVisible(true)]
		public static object ToObject(Type enumType, short value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A96 RID: 2710 RVA: 0x0002CECC File Offset: 0x0002B0CC
		[ComVisible(true)]
		public static object ToObject(Type enumType, int value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A97 RID: 2711 RVA: 0x0002CEDC File Offset: 0x0002B0DC
		[ComVisible(true)]
		public static object ToObject(Type enumType, long value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A98 RID: 2712
		[ComVisible(true)]
		[MethodImpl(4096)]
		public static extern object ToObject(Type enumType, object value);

		// Token: 0x06000A99 RID: 2713 RVA: 0x0002CEEC File Offset: 0x0002B0EC
		[CLSCompliant(false)]
		[ComVisible(true)]
		public static object ToObject(Type enumType, sbyte value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A9A RID: 2714 RVA: 0x0002CEFC File Offset: 0x0002B0FC
		[ComVisible(true)]
		[CLSCompliant(false)]
		public static object ToObject(Type enumType, ushort value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A9B RID: 2715 RVA: 0x0002CF0C File Offset: 0x0002B10C
		[ComVisible(true)]
		[CLSCompliant(false)]
		public static object ToObject(Type enumType, uint value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A9C RID: 2716 RVA: 0x0002CF1C File Offset: 0x0002B11C
		[CLSCompliant(false)]
		[ComVisible(true)]
		public static object ToObject(Type enumType, ulong value)
		{
			return Enum.ToObject(enumType, value);
		}

		// Token: 0x06000A9D RID: 2717 RVA: 0x0002CF2C File Offset: 0x0002B12C
		public override bool Equals(object obj)
		{
			return ValueType.DefaultEquals(this, obj);
		}

		// Token: 0x06000A9E RID: 2718
		[MethodImpl(4096)]
		private extern int get_hashcode();

		// Token: 0x06000A9F RID: 2719 RVA: 0x0002CF38 File Offset: 0x0002B138
		public override int GetHashCode()
		{
			return this.get_hashcode();
		}

		// Token: 0x06000AA0 RID: 2720 RVA: 0x0002CF40 File Offset: 0x0002B140
		private static string FormatSpecifier_X(Type enumType, object value, bool upper)
		{
			switch (Type.GetTypeCode(enumType))
			{
			case TypeCode.SByte:
				return ((sbyte)value).ToString((!upper) ? "x2" : "X2");
			case TypeCode.Byte:
				return ((byte)value).ToString((!upper) ? "x2" : "X2");
			case TypeCode.Int16:
				return ((short)value).ToString((!upper) ? "x4" : "X4");
			case TypeCode.UInt16:
				return ((ushort)value).ToString((!upper) ? "x4" : "X4");
			case TypeCode.Int32:
				return ((int)value).ToString((!upper) ? "x8" : "X8");
			case TypeCode.UInt32:
				return ((uint)value).ToString((!upper) ? "x8" : "X8");
			case TypeCode.Int64:
				return ((long)value).ToString((!upper) ? "x16" : "X16");
			case TypeCode.UInt64:
				return ((ulong)value).ToString((!upper) ? "x16" : "X16");
			default:
				throw new Exception("Invalid type code for enumeration.");
			}
		}

		// Token: 0x06000AA1 RID: 2721 RVA: 0x0002D0B0 File Offset: 0x0002B2B0
		private static string FormatFlags(Type enumType, object value)
		{
			string text = string.Empty;
			MonoEnumInfo monoEnumInfo;
			MonoEnumInfo.GetInfo(enumType, out monoEnumInfo);
			string text2 = value.ToString();
			if (text2 == "0")
			{
				text = Enum.GetName(enumType, value);
				if (text == null)
				{
					text = text2;
				}
				return text;
			}
			switch (((Enum)monoEnumInfo.values.GetValue(0)).GetTypeCode())
			{
			case TypeCode.SByte:
			{
				sbyte b = (sbyte)value;
				for (int i = monoEnumInfo.values.Length - 1; i >= 0; i--)
				{
					sbyte b2 = (sbyte)monoEnumInfo.values.GetValue(i);
					if ((int)b2 != 0)
					{
						if (((int)b & (int)b2) == (int)b2)
						{
							text = monoEnumInfo.names[i] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							b = (sbyte)((int)b - (int)b2);
						}
					}
				}
				if ((int)b != 0)
				{
					return text2;
				}
				break;
			}
			case TypeCode.Byte:
			{
				byte b3 = (byte)value;
				for (int j = monoEnumInfo.values.Length - 1; j >= 0; j--)
				{
					byte b4 = (byte)monoEnumInfo.values.GetValue(j);
					if (b4 != 0)
					{
						if ((b3 & b4) == b4)
						{
							text = monoEnumInfo.names[j] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							b3 -= b4;
						}
					}
				}
				if (b3 != 0)
				{
					return text2;
				}
				break;
			}
			case TypeCode.Int16:
			{
				short num = (short)value;
				for (int k = monoEnumInfo.values.Length - 1; k >= 0; k--)
				{
					short num2 = (short)monoEnumInfo.values.GetValue(k);
					if (num2 != 0)
					{
						if ((num & num2) == num2)
						{
							text = monoEnumInfo.names[k] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							num -= num2;
						}
					}
				}
				if (num != 0)
				{
					return text2;
				}
				break;
			}
			case TypeCode.UInt16:
			{
				ushort num3 = (ushort)value;
				for (int l = monoEnumInfo.values.Length - 1; l >= 0; l--)
				{
					ushort num4 = (ushort)monoEnumInfo.values.GetValue(l);
					if (num4 != 0)
					{
						if ((num3 & num4) == num4)
						{
							text = monoEnumInfo.names[l] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							num3 -= num4;
						}
					}
				}
				if (num3 != 0)
				{
					return text2;
				}
				break;
			}
			case TypeCode.Int32:
			{
				int num5 = (int)value;
				for (int m = monoEnumInfo.values.Length - 1; m >= 0; m--)
				{
					int num6 = (int)monoEnumInfo.values.GetValue(m);
					if (num6 != 0)
					{
						if ((num5 & num6) == num6)
						{
							text = monoEnumInfo.names[m] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							num5 -= num6;
						}
					}
				}
				if (num5 != 0)
				{
					return text2;
				}
				break;
			}
			case TypeCode.UInt32:
			{
				uint num7 = (uint)value;
				for (int n = monoEnumInfo.values.Length - 1; n >= 0; n--)
				{
					uint num8 = (uint)monoEnumInfo.values.GetValue(n);
					if (num8 != 0U)
					{
						if ((num7 & num8) == num8)
						{
							text = monoEnumInfo.names[n] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							num7 -= num8;
						}
					}
				}
				if (num7 != 0U)
				{
					return text2;
				}
				break;
			}
			case TypeCode.Int64:
			{
				long num9 = (long)value;
				for (int num10 = monoEnumInfo.values.Length - 1; num10 >= 0; num10--)
				{
					long num11 = (long)monoEnumInfo.values.GetValue(num10);
					if (num11 != 0L)
					{
						if ((num9 & num11) == num11)
						{
							text = monoEnumInfo.names[num10] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							num9 -= num11;
						}
					}
				}
				if (num9 != 0L)
				{
					return text2;
				}
				break;
			}
			case TypeCode.UInt64:
			{
				ulong num12 = (ulong)value;
				for (int num13 = monoEnumInfo.values.Length - 1; num13 >= 0; num13--)
				{
					ulong num14 = (ulong)monoEnumInfo.values.GetValue(num13);
					if (num14 != 0UL)
					{
						if ((num12 & num14) == num14)
						{
							text = monoEnumInfo.names[num13] + ((!(text == string.Empty)) ? ", " : string.Empty) + text;
							num12 -= num14;
						}
					}
				}
				if (num12 != 0UL)
				{
					return text2;
				}
				break;
			}
			}
			if (text == string.Empty)
			{
				return text2;
			}
			return text;
		}

		// Token: 0x06000AA2 RID: 2722 RVA: 0x0002D63C File Offset: 0x0002B83C
		[ComVisible(true)]
		public static string Format(Type enumType, object value, string format)
		{
			if (enumType == null)
			{
				throw new ArgumentNullException("enumType");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (format == null)
			{
				throw new ArgumentNullException("format");
			}
			if (!enumType.IsEnum)
			{
				throw new ArgumentException("enumType is not an Enum type.", "enumType");
			}
			Type type = value.GetType();
			Type underlyingType = Enum.GetUnderlyingType(enumType);
			if (type.IsEnum)
			{
				if (type != enumType)
				{
					throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, "Object must be the same type as the enum. The type passed in was {0}; the enum type was {1}.", new object[] { type.FullName, enumType.FullName }));
				}
			}
			else if (type != underlyingType)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, "Enum underlying type and the object must be the same type or object. Type passed in was {0}; the enum underlying type was {1}.", new object[] { type.FullName, underlyingType.FullName }));
			}
			if (format.Length != 1)
			{
				throw new FormatException("Format String can be only \"G\",\"g\",\"X\",\"x\",\"F\",\"f\",\"D\" or \"d\".");
			}
			char c = format[0];
			string text;
			if (c == 'G' || c == 'g')
			{
				if (!enumType.IsDefined(typeof(FlagsAttribute), false))
				{
					text = Enum.GetName(enumType, value);
					if (text == null)
					{
						text = value.ToString();
					}
					return text;
				}
				c = 'f';
			}
			if (c == 'f' || c == 'F')
			{
				return Enum.FormatFlags(enumType, value);
			}
			text = string.Empty;
			char c2 = c;
			if (c2 != 'D')
			{
				if (c2 == 'X')
				{
					return Enum.FormatSpecifier_X(enumType, value, true);
				}
				if (c2 != 'd')
				{
					if (c2 != 'x')
					{
						throw new FormatException("Format String can be only \"G\",\"g\",\"X\",\"x\",\"F\",\"f\",\"D\" or \"d\".");
					}
					return Enum.FormatSpecifier_X(enumType, value, false);
				}
			}
			if (underlyingType == typeof(ulong))
			{
				text = Convert.ToUInt64(value).ToString();
			}
			else
			{
				text = Convert.ToInt64(value).ToString();
			}
			return text;
		}

		// Token: 0x040003BA RID: 954
		private static char[] split_char = new char[] { ',' };
	}
}
