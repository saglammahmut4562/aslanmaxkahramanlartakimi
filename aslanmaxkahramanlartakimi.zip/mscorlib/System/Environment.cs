﻿using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;
using Microsoft.Win32;

namespace System
{
	// Token: 0x0200010B RID: 267
	[ComVisible(true)]
	public static class Environment
	{
		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000AA3 RID: 2723 RVA: 0x0002D828 File Offset: 0x0002BA28
		public static string CommandLine
		{
			get
			{
				return string.Join(" ", Environment.GetCommandLineArgs());
			}
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000AA4 RID: 2724 RVA: 0x0002D83C File Offset: 0x0002BA3C
		// (set) Token: 0x06000AA5 RID: 2725 RVA: 0x0002D844 File Offset: 0x0002BA44
		public static string CurrentDirectory
		{
			get
			{
				return Directory.GetCurrentDirectory();
			}
			set
			{
				Directory.SetCurrentDirectory(value);
			}
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000AA6 RID: 2726
		// (set) Token: 0x06000AA7 RID: 2727
		public static extern int ExitCode
		{
			[MethodImpl(4096)]
			get;
			[MethodImpl(4096)]
			set;
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000AA8 RID: 2728
		public static extern bool HasShutdownStarted
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000AA9 RID: 2729
		public static extern string EmbeddingHostName
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x06000AAA RID: 2730
		public static extern bool SocketSecurityEnabled
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x06000AAB RID: 2731 RVA: 0x0002D84C File Offset: 0x0002BA4C
		public static bool UnityWebSecurityEnabled
		{
			get
			{
				return Environment.SocketSecurityEnabled;
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000AAC RID: 2732
		public static extern string MachineName
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x06000AAD RID: 2733
		public static extern string NewLine
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x06000AAE RID: 2734
		internal static extern PlatformID Platform
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x06000AAF RID: 2735
		[MethodImpl(4096)]
		internal static extern string GetOSVersionString();

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x06000AB0 RID: 2736 RVA: 0x0002D854 File Offset: 0x0002BA54
		public static OperatingSystem OSVersion
		{
			get
			{
				if (Environment.os == null)
				{
					Version version = Version.CreateFromString(Environment.GetOSVersionString());
					PlatformID platform = Environment.Platform;
					Environment.os = new OperatingSystem(platform, version);
				}
				return Environment.os;
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000AB1 RID: 2737 RVA: 0x0002D890 File Offset: 0x0002BA90
		public static string StackTrace
		{
			get
			{
				StackTrace stackTrace = new StackTrace(0, true);
				return stackTrace.ToString();
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000AB2 RID: 2738
		public static extern int TickCount
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000AB3 RID: 2739 RVA: 0x0002D8AC File Offset: 0x0002BAAC
		public static string UserDomainName
		{
			get
			{
				return Environment.MachineName;
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x06000AB4 RID: 2740 RVA: 0x0002D8B4 File Offset: 0x0002BAB4
		[MonoTODO("Currently always returns false, regardless of interactive state")]
		public static bool UserInteractive
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x06000AB5 RID: 2741
		public static extern string UserName
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000AB6 RID: 2742 RVA: 0x0002D8B8 File Offset: 0x0002BAB8
		public static Version Version
		{
			get
			{
				return new Version("3.0.40818.0");
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000AB7 RID: 2743 RVA: 0x0002D8C4 File Offset: 0x0002BAC4
		[MonoTODO("Currently always returns zero")]
		public static long WorkingSet
		{
			get
			{
				return 0L;
			}
		}

		// Token: 0x06000AB8 RID: 2744
		[MethodImpl(4096)]
		public static extern void Exit(int exitCode);

		// Token: 0x06000AB9 RID: 2745 RVA: 0x0002D8C8 File Offset: 0x0002BAC8
		public static string ExpandEnvironmentVariables(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			int num = name.IndexOf('%');
			if (num == -1)
			{
				return name;
			}
			int length = name.Length;
			int num2;
			if (num == length - 1 || (num2 = name.IndexOf('%', num + 1)) == -1)
			{
				return name;
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(name, 0, num);
			Hashtable hashtable = null;
			do
			{
				string text = name.Substring(num + 1, num2 - num - 1);
				string text2 = Environment.GetEnvironmentVariable(text);
				if (text2 == null && Environment.IsRunningOnWindows)
				{
					if (hashtable == null)
					{
						hashtable = Environment.GetEnvironmentVariablesNoCase();
					}
					text2 = hashtable[text] as string;
				}
				if (text2 == null)
				{
					stringBuilder.Append('%');
					stringBuilder.Append(text);
					num2--;
				}
				else
				{
					stringBuilder.Append(text2);
				}
				int num3 = num2;
				num = name.IndexOf('%', num2 + 1);
				num2 = ((num != -1 && num2 <= length - 1) ? name.IndexOf('%', num + 1) : (-1));
				int num4;
				if (num == -1 || num2 == -1)
				{
					num4 = length - num3 - 1;
				}
				else if (text2 != null)
				{
					num4 = num - num3 - 1;
				}
				else
				{
					num4 = num - num3;
				}
				if (num >= num3 || num == -1)
				{
					stringBuilder.Append(name, num3 + 1, num4);
				}
			}
			while (num2 > -1 && num2 < length);
			return stringBuilder.ToString();
		}

		// Token: 0x06000ABA RID: 2746
		[MethodImpl(4096)]
		public static extern string[] GetCommandLineArgs();

		// Token: 0x06000ABB RID: 2747
		[MethodImpl(4096)]
		internal static extern string internalGetEnvironmentVariable(string variable);

		// Token: 0x06000ABC RID: 2748 RVA: 0x0002DA3C File Offset: 0x0002BC3C
		public static string GetEnvironmentVariable(string variable)
		{
			return Environment.internalGetEnvironmentVariable(variable);
		}

		// Token: 0x06000ABD RID: 2749 RVA: 0x0002DA44 File Offset: 0x0002BC44
		private static Hashtable GetEnvironmentVariablesNoCase()
		{
			Hashtable hashtable = new Hashtable(CaseInsensitiveHashCodeProvider.Default, CaseInsensitiveComparer.Default);
			foreach (string text in Environment.GetEnvironmentVariableNames())
			{
				hashtable[text] = Environment.internalGetEnvironmentVariable(text);
			}
			return hashtable;
		}

		// Token: 0x06000ABE RID: 2750 RVA: 0x0002DA90 File Offset: 0x0002BC90
		public static IDictionary GetEnvironmentVariables()
		{
			Hashtable hashtable = new Hashtable();
			foreach (string text in Environment.GetEnvironmentVariableNames())
			{
				hashtable[text] = Environment.internalGetEnvironmentVariable(text);
			}
			return hashtable;
		}

		// Token: 0x06000ABF RID: 2751
		[MethodImpl(4096)]
		private static extern string GetWindowsFolderPath(int folder);

		// Token: 0x06000AC0 RID: 2752 RVA: 0x0002DAD0 File Offset: 0x0002BCD0
		public static string GetFolderPath(Environment.SpecialFolder folder)
		{
			string text;
			if (Environment.IsRunningOnWindows)
			{
				text = Environment.GetWindowsFolderPath((int)folder);
			}
			else
			{
				text = Environment.InternalGetFolderPath(folder);
			}
			return text;
		}

		// Token: 0x06000AC1 RID: 2753 RVA: 0x0002DB00 File Offset: 0x0002BD00
		private static string ReadXdgUserDir(string config_dir, string home_dir, string key, string fallback)
		{
			string text = Environment.internalGetEnvironmentVariable(key);
			if (text != null && text != string.Empty)
			{
				return text;
			}
			string text2 = Path.Combine(config_dir, "user-dirs.dirs");
			if (!File.Exists(text2))
			{
				return Path.Combine(home_dir, fallback);
			}
			try
			{
				using (StreamReader streamReader = new StreamReader(text2))
				{
					string text3;
					while ((text3 = streamReader.ReadLine()) != null)
					{
						text3 = text3.Trim();
						int num = text3.IndexOf('=');
						if (num > 8 && text3.Substring(0, num) == key)
						{
							string text4 = text3.Substring(num + 1).Trim(new char[] { '"' });
							bool flag = false;
							if (text4.StartsWith("$HOME/"))
							{
								flag = true;
								text4 = text4.Substring(6);
							}
							else if (!text4.StartsWith("/"))
							{
								flag = true;
							}
							return (!flag) ? text4 : Path.Combine(home_dir, text4);
						}
					}
				}
			}
			catch (FileNotFoundException)
			{
			}
			return Path.Combine(home_dir, fallback);
		}

		// Token: 0x06000AC2 RID: 2754 RVA: 0x0002DC48 File Offset: 0x0002BE48
		internal static string InternalGetFolderPath(Environment.SpecialFolder folder)
		{
			string text = Environment.internalGetHome();
			string text2 = Environment.internalGetEnvironmentVariable("XDG_DATA_HOME");
			if (text2 == null || text2 == string.Empty)
			{
				text2 = Path.Combine(text, ".local");
				text2 = Path.Combine(text2, "share");
			}
			string text3 = Environment.internalGetEnvironmentVariable("XDG_CONFIG_HOME");
			if (text3 == null || text3 == string.Empty)
			{
				text3 = Path.Combine(text, ".config");
			}
			switch (folder)
			{
			case Environment.SpecialFolder.Desktop:
			case Environment.SpecialFolder.DesktopDirectory:
				return Environment.ReadXdgUserDir(text3, text, "XDG_DESKTOP_DIR", "Desktop");
			case Environment.SpecialFolder.Programs:
			case Environment.SpecialFolder.Favorites:
			case Environment.SpecialFolder.Startup:
			case Environment.SpecialFolder.Recent:
			case Environment.SpecialFolder.SendTo:
			case Environment.SpecialFolder.StartMenu:
			case Environment.SpecialFolder.Templates:
			case Environment.SpecialFolder.InternetCache:
			case Environment.SpecialFolder.Cookies:
			case Environment.SpecialFolder.History:
			case Environment.SpecialFolder.System:
			case Environment.SpecialFolder.ProgramFiles:
			case Environment.SpecialFolder.CommonProgramFiles:
				return string.Empty;
			case Environment.SpecialFolder.MyDocuments:
				return Path.Combine(text, "Documents");
			case Environment.SpecialFolder.MyMusic:
				return Environment.ReadXdgUserDir(text3, text, "XDG_MUSIC_DIR", "Music");
			case Environment.SpecialFolder.MyComputer:
				return string.Empty;
			case Environment.SpecialFolder.ApplicationData:
				return text3;
			case Environment.SpecialFolder.LocalApplicationData:
				return text2;
			case Environment.SpecialFolder.CommonApplicationData:
				return "/usr/share";
			case Environment.SpecialFolder.MyPictures:
				return Environment.ReadXdgUserDir(text3, text, "XDG_PICTURES_DIR", "Pictures");
			}
			throw new ArgumentException("Invalid SpecialFolder");
		}

		// Token: 0x06000AC3 RID: 2755 RVA: 0x0002DDE0 File Offset: 0x0002BFE0
		public static string[] GetLogicalDrives()
		{
			return Environment.GetLogicalDrivesInternal();
		}

		// Token: 0x06000AC4 RID: 2756
		[MethodImpl(4096)]
		private static extern void internalBroadcastSettingChange();

		// Token: 0x06000AC5 RID: 2757 RVA: 0x0002DDE8 File Offset: 0x0002BFE8
		public static string GetEnvironmentVariable(string variable, EnvironmentVariableTarget target)
		{
			switch (target)
			{
			case EnvironmentVariableTarget.Process:
				return Environment.GetEnvironmentVariable(variable);
			case EnvironmentVariableTarget.User:
				break;
			case EnvironmentVariableTarget.Machine:
			{
				new EnvironmentPermission(PermissionState.Unrestricted).Demand();
				if (!Environment.IsRunningOnWindows)
				{
					return null;
				}
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment"))
				{
					object value = registryKey.GetValue(variable);
					return (value != null) ? value.ToString() : null;
				}
				break;
			}
			default:
				goto IL_00D7;
			}
			new EnvironmentPermission(PermissionState.Unrestricted).Demand();
			if (!Environment.IsRunningOnWindows)
			{
				return null;
			}
			using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Environment", false))
			{
				object value2 = registryKey2.GetValue(variable);
				return (value2 != null) ? value2.ToString() : null;
			}
			IL_00D7:
			throw new ArgumentException("target");
		}

		// Token: 0x06000AC6 RID: 2758 RVA: 0x0002DEF8 File Offset: 0x0002C0F8
		public static IDictionary GetEnvironmentVariables(EnvironmentVariableTarget target)
		{
			IDictionary dictionary = new Hashtable();
			switch (target)
			{
			case EnvironmentVariableTarget.Process:
				dictionary = Environment.GetEnvironmentVariables();
				break;
			case EnvironmentVariableTarget.User:
				new EnvironmentPermission(PermissionState.Unrestricted).Demand();
				if (Environment.IsRunningOnWindows)
				{
					using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Environment"))
					{
						string[] valueNames = registryKey.GetValueNames();
						foreach (string text in valueNames)
						{
							dictionary.Add(text, registryKey.GetValue(text));
						}
					}
				}
				break;
			case EnvironmentVariableTarget.Machine:
				new EnvironmentPermission(PermissionState.Unrestricted).Demand();
				if (Environment.IsRunningOnWindows)
				{
					using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment"))
					{
						string[] valueNames2 = registryKey2.GetValueNames();
						foreach (string text2 in valueNames2)
						{
							dictionary.Add(text2, registryKey2.GetValue(text2));
						}
					}
				}
				break;
			default:
				throw new ArgumentException("target");
			}
			return dictionary;
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x0002E04C File Offset: 0x0002C24C
		public static void SetEnvironmentVariable(string variable, string value)
		{
			Environment.SetEnvironmentVariable(variable, value, EnvironmentVariableTarget.Process);
		}

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0002E058 File Offset: 0x0002C258
		public static void SetEnvironmentVariable(string variable, string value, EnvironmentVariableTarget target)
		{
			if (variable == null)
			{
				throw new ArgumentNullException("variable");
			}
			if (variable == string.Empty)
			{
				throw new ArgumentException("String cannot be of zero length.", "variable");
			}
			if (variable.IndexOf('=') != -1)
			{
				throw new ArgumentException("Environment variable name cannot contain an equal character.", "variable");
			}
			if (variable[0] == '\0')
			{
				throw new ArgumentException("The first char in the string is the null character.", "variable");
			}
			switch (target)
			{
			case EnvironmentVariableTarget.Process:
				Environment.InternalSetEnvironmentVariable(variable, value);
				break;
			case EnvironmentVariableTarget.User:
			{
				if (!Environment.IsRunningOnWindows)
				{
					return;
				}
				using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Environment", true))
				{
					if (string.IsNullOrEmpty(value))
					{
						registryKey.DeleteValue(variable, false);
					}
					else
					{
						registryKey.SetValue(variable, value);
					}
					Environment.internalBroadcastSettingChange();
				}
				break;
			}
			case EnvironmentVariableTarget.Machine:
			{
				if (!Environment.IsRunningOnWindows)
				{
					return;
				}
				using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment", true))
				{
					if (string.IsNullOrEmpty(value))
					{
						registryKey2.DeleteValue(variable, false);
					}
					else
					{
						registryKey2.SetValue(variable, value);
					}
					Environment.internalBroadcastSettingChange();
				}
				break;
			}
			default:
				throw new ArgumentException("target");
			}
		}

		// Token: 0x06000AC9 RID: 2761
		[MethodImpl(4096)]
		internal static extern void InternalSetEnvironmentVariable(string variable, string value);

		// Token: 0x06000ACA RID: 2762 RVA: 0x0002E1CC File Offset: 0x0002C3CC
		[MonoTODO("Not implemented")]
		public static void FailFast(string message)
		{
			throw new NotImplementedException();
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000ACB RID: 2763
		public static extern int ProcessorCount
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000ACC RID: 2764 RVA: 0x0002E1D4 File Offset: 0x0002C3D4
		internal static bool IsRunningOnWindows
		{
			get
			{
				return Environment.Platform < PlatformID.Unix;
			}
		}

		// Token: 0x06000ACD RID: 2765
		[MethodImpl(4096)]
		private static extern string[] GetLogicalDrivesInternal();

		// Token: 0x06000ACE RID: 2766
		[MethodImpl(4096)]
		private static extern string[] GetEnvironmentVariableNames();

		// Token: 0x06000ACF RID: 2767
		[MethodImpl(4096)]
		internal static extern string GetMachineConfigPath();

		// Token: 0x06000AD0 RID: 2768
		[MethodImpl(4096)]
		internal static extern string internalGetHome();

		// Token: 0x040003BB RID: 955
		private const int mono_corlib_version = 82;

		// Token: 0x040003BC RID: 956
		private static OperatingSystem os;

		// Token: 0x0200010C RID: 268
		[ComVisible(true)]
		public enum SpecialFolder
		{
			// Token: 0x040003BE RID: 958
			MyDocuments = 5,
			// Token: 0x040003BF RID: 959
			Desktop = 0,
			// Token: 0x040003C0 RID: 960
			MyComputer = 17,
			// Token: 0x040003C1 RID: 961
			Programs = 2,
			// Token: 0x040003C2 RID: 962
			Personal = 5,
			// Token: 0x040003C3 RID: 963
			Favorites,
			// Token: 0x040003C4 RID: 964
			Startup,
			// Token: 0x040003C5 RID: 965
			Recent,
			// Token: 0x040003C6 RID: 966
			SendTo,
			// Token: 0x040003C7 RID: 967
			StartMenu = 11,
			// Token: 0x040003C8 RID: 968
			MyMusic = 13,
			// Token: 0x040003C9 RID: 969
			DesktopDirectory = 16,
			// Token: 0x040003CA RID: 970
			Templates = 21,
			// Token: 0x040003CB RID: 971
			ApplicationData = 26,
			// Token: 0x040003CC RID: 972
			LocalApplicationData = 28,
			// Token: 0x040003CD RID: 973
			InternetCache = 32,
			// Token: 0x040003CE RID: 974
			Cookies,
			// Token: 0x040003CF RID: 975
			History,
			// Token: 0x040003D0 RID: 976
			CommonApplicationData,
			// Token: 0x040003D1 RID: 977
			System = 37,
			// Token: 0x040003D2 RID: 978
			ProgramFiles,
			// Token: 0x040003D3 RID: 979
			MyPictures,
			// Token: 0x040003D4 RID: 980
			CommonProgramFiles = 43
		}
	}
}
