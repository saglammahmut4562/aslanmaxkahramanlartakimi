﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200010D RID: 269
	[ComVisible(true)]
	public enum EnvironmentVariableTarget
	{
		// Token: 0x040003D6 RID: 982
		Process,
		// Token: 0x040003D7 RID: 983
		User,
		// Token: 0x040003D8 RID: 984
		Machine
	}
}
