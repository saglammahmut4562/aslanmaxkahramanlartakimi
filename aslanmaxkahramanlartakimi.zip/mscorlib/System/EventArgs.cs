﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200010E RID: 270
	[ComVisible(true)]
	[Serializable]
	public class EventArgs
	{
		// Token: 0x040003D9 RID: 985
		public static readonly EventArgs Empty = new EventArgs();
	}
}
