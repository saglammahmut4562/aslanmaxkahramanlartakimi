﻿using System;

namespace System
{
	// Token: 0x02000110 RID: 272
	// (Invoke) Token: 0x06000AD8 RID: 2776
	[Serializable]
	public delegate void EventHandler<TEventArgs>(object sender, TEventArgs e) where TEventArgs : EventArgs;
}
