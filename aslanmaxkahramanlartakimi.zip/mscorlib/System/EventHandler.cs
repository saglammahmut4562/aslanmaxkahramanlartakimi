﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200010F RID: 271
	// (Invoke) Token: 0x06000AD4 RID: 2772
	[ComVisible(true)]
	[Serializable]
	public delegate void EventHandler(object sender, EventArgs e);
}
