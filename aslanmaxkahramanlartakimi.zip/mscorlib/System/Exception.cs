﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;

namespace System
{
	// Token: 0x02000111 RID: 273
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_Exception))]
	[ClassInterface(ClassInterfaceType.None)]
	[Serializable]
	public class Exception : _Exception, ISerializable
	{
		// Token: 0x06000ADB RID: 2779 RVA: 0x0002E1F4 File Offset: 0x0002C3F4
		public Exception()
		{
		}

		// Token: 0x06000ADC RID: 2780 RVA: 0x0002E208 File Offset: 0x0002C408
		public Exception(string message)
		{
			this.message = message;
		}

		// Token: 0x06000ADD RID: 2781 RVA: 0x0002E224 File Offset: 0x0002C424
		protected Exception(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			this.class_name = info.GetString("ClassName");
			this.message = info.GetString("Message");
			this.help_link = info.GetString("HelpURL");
			this.stack_trace = info.GetString("StackTraceString");
			this._remoteStackTraceString = info.GetString("RemoteStackTraceString");
			this.remote_stack_index = info.GetInt32("RemoteStackIndex");
			this.hresult = info.GetInt32("HResult");
			this.source = info.GetString("Source");
			this.inner_exception = (Exception)info.GetValue("InnerException", typeof(Exception));
			try
			{
				this._data = (IDictionary)info.GetValue("Data", typeof(IDictionary));
			}
			catch (SerializationException)
			{
			}
		}

		// Token: 0x06000ADE RID: 2782 RVA: 0x0002E338 File Offset: 0x0002C538
		public Exception(string message, Exception innerException)
		{
			this.inner_exception = innerException;
			this.message = message;
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000ADF RID: 2783 RVA: 0x0002E35C File Offset: 0x0002C55C
		public Exception InnerException
		{
			get
			{
				return this.inner_exception;
			}
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x06000AE0 RID: 2784 RVA: 0x0002E364 File Offset: 0x0002C564
		// (set) Token: 0x06000AE1 RID: 2785 RVA: 0x0002E36C File Offset: 0x0002C56C
		protected int HResult
		{
			get
			{
				return this.hresult;
			}
			set
			{
				this.hresult = value;
			}
		}

		// Token: 0x06000AE2 RID: 2786 RVA: 0x0002E378 File Offset: 0x0002C578
		internal void SetMessage(string s)
		{
			this.message = s;
		}

		// Token: 0x06000AE3 RID: 2787 RVA: 0x0002E384 File Offset: 0x0002C584
		internal void SetStackTrace(string s)
		{
			this.stack_trace = s;
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x06000AE4 RID: 2788 RVA: 0x0002E390 File Offset: 0x0002C590
		private string ClassName
		{
			get
			{
				if (this.class_name == null)
				{
					this.class_name = this.GetType().ToString();
				}
				return this.class_name;
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000AE5 RID: 2789 RVA: 0x0002E3B4 File Offset: 0x0002C5B4
		public virtual string Message
		{
			get
			{
				if (this.message == null)
				{
					this.message = string.Format(Locale.GetText("Exception of type '{0}' was thrown."), this.ClassName);
				}
				return this.message;
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x06000AE6 RID: 2790 RVA: 0x0002E3E4 File Offset: 0x0002C5E4
		public virtual string Source
		{
			get
			{
				if (this.source == null)
				{
					StackTrace stackTrace = new StackTrace(this, true);
					if (stackTrace.FrameCount > 0)
					{
						StackFrame frame = stackTrace.GetFrame(0);
						if (stackTrace != null)
						{
							MethodBase method = frame.GetMethod();
							if (method != null)
							{
								this.source = method.DeclaringType.Assembly.UnprotectedGetName().Name;
							}
						}
					}
				}
				return this.source;
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x06000AE7 RID: 2791 RVA: 0x0002E44C File Offset: 0x0002C64C
		public virtual string StackTrace
		{
			get
			{
				if (this.stack_trace == null)
				{
					if (this.trace_ips == null)
					{
						return null;
					}
					StackTrace stackTrace = new StackTrace(this, 0, true, true);
					StringBuilder stringBuilder = new StringBuilder();
					string text = string.Format("{0}  {1} ", Environment.NewLine, Locale.GetText("at"));
					string text2 = Locale.GetText("<unknown method>");
					for (int i = 0; i < stackTrace.FrameCount; i++)
					{
						StackFrame frame = stackTrace.GetFrame(i);
						if (i == 0)
						{
							stringBuilder.AppendFormat("  {0} ", Locale.GetText("at"));
						}
						else
						{
							stringBuilder.Append(text);
						}
						if (frame.GetMethod() == null)
						{
							string internalMethodName = frame.GetInternalMethodName();
							if (internalMethodName != null)
							{
								stringBuilder.Append(internalMethodName);
							}
							else
							{
								stringBuilder.AppendFormat("<0x{0:x5}> {1}", frame.GetNativeOffset(), text2);
							}
						}
						else
						{
							this.GetFullNameForStackTrace(stringBuilder, frame.GetMethod());
							if (frame.GetILOffset() == -1)
							{
								stringBuilder.AppendFormat(" <0x{0:x5}> ", frame.GetNativeOffset());
							}
							else
							{
								stringBuilder.AppendFormat(" [0x{0:x5}] ", frame.GetILOffset());
							}
							stringBuilder.AppendFormat("in {0}:{1} ", frame.GetSecureFileName(), frame.GetFileLineNumber());
						}
					}
					this.stack_trace = stringBuilder.ToString();
				}
				return this.stack_trace;
			}
		}

		// Token: 0x06000AE8 RID: 2792 RVA: 0x0002E5C0 File Offset: 0x0002C7C0
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			info.AddValue("ClassName", this.ClassName);
			info.AddValue("Message", this.message);
			info.AddValue("InnerException", this.inner_exception);
			info.AddValue("HelpURL", this.help_link);
			info.AddValue("StackTraceString", this.StackTrace);
			info.AddValue("RemoteStackTraceString", this._remoteStackTraceString);
			info.AddValue("RemoteStackIndex", this.remote_stack_index);
			info.AddValue("HResult", this.hresult);
			info.AddValue("Source", this.Source);
			info.AddValue("ExceptionMethod", null);
			info.AddValue("Data", this._data, typeof(IDictionary));
		}

		// Token: 0x06000AE9 RID: 2793 RVA: 0x0002E6A0 File Offset: 0x0002C8A0
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(this.ClassName);
			stringBuilder.Append(": ").Append(this.Message);
			if (this._remoteStackTraceString != null)
			{
				stringBuilder.Append(this._remoteStackTraceString);
			}
			if (this.inner_exception != null)
			{
				stringBuilder.Append(" ---> ").Append(this.inner_exception.ToString());
				stringBuilder.Append(Environment.NewLine);
				stringBuilder.Append(Locale.GetText("  --- End of inner exception stack trace ---"));
			}
			if (this.StackTrace != null)
			{
				stringBuilder.Append(Environment.NewLine).Append(this.StackTrace);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000AEA RID: 2794 RVA: 0x0002E754 File Offset: 0x0002C954
		internal void GetFullNameForStackTrace(StringBuilder sb, MethodBase mi)
		{
			ParameterInfo[] parameters = mi.GetParameters();
			sb.Append(mi.DeclaringType.ToString());
			sb.Append(".");
			sb.Append(mi.Name);
			if (mi.IsGenericMethod)
			{
				Type[] genericArguments = mi.GetGenericArguments();
				sb.Append("[");
				for (int i = 0; i < genericArguments.Length; i++)
				{
					if (i > 0)
					{
						sb.Append(",");
					}
					sb.Append(genericArguments[i].Name);
				}
				sb.Append("]");
			}
			sb.Append(" (");
			for (int j = 0; j < parameters.Length; j++)
			{
				if (j > 0)
				{
					sb.Append(", ");
				}
				Type parameterType = parameters[j].ParameterType;
				if (parameterType.IsClass && parameterType.Namespace != string.Empty)
				{
					sb.Append(parameterType.Namespace);
					sb.Append(".");
				}
				sb.Append(parameterType.Name);
				if (parameters[j].Name != null)
				{
					sb.Append(" ");
					sb.Append(parameters[j].Name);
				}
			}
			sb.Append(")");
		}

		// Token: 0x06000AEB RID: 2795 RVA: 0x0002E8B0 File Offset: 0x0002CAB0
		public new Type GetType()
		{
			return base.GetType();
		}

		// Token: 0x040003DA RID: 986
		private IntPtr[] trace_ips;

		// Token: 0x040003DB RID: 987
		private Exception inner_exception;

		// Token: 0x040003DC RID: 988
		internal string message;

		// Token: 0x040003DD RID: 989
		private string help_link;

		// Token: 0x040003DE RID: 990
		private string class_name;

		// Token: 0x040003DF RID: 991
		private string stack_trace;

		// Token: 0x040003E0 RID: 992
		private string _remoteStackTraceString;

		// Token: 0x040003E1 RID: 993
		private int remote_stack_index;

		// Token: 0x040003E2 RID: 994
		internal int hresult = -2146233088;

		// Token: 0x040003E3 RID: 995
		private string source;

		// Token: 0x040003E4 RID: 996
		private IDictionary _data;
	}
}
