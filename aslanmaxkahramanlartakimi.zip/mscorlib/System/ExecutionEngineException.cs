﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000112 RID: 274
	[ComVisible(true)]
	[Serializable]
	public sealed class ExecutionEngineException : SystemException
	{
		// Token: 0x06000AEC RID: 2796 RVA: 0x0002E8B8 File Offset: 0x0002CAB8
		public ExecutionEngineException()
			: base(Locale.GetText("Internal error occurred."))
		{
		}

		// Token: 0x06000AED RID: 2797 RVA: 0x0002E8CC File Offset: 0x0002CACC
		public ExecutionEngineException(string message)
			: base(message)
		{
		}

		// Token: 0x06000AEE RID: 2798 RVA: 0x0002E8D8 File Offset: 0x0002CAD8
		internal ExecutionEngineException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
