﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000113 RID: 275
	[ComVisible(true)]
	[Serializable]
	public class FieldAccessException : MemberAccessException
	{
		// Token: 0x06000AEF RID: 2799 RVA: 0x0002E8E4 File Offset: 0x0002CAE4
		public FieldAccessException()
			: base(Locale.GetText("Attempt to access a private/protected field failed."))
		{
			base.HResult = -2146233081;
		}

		// Token: 0x06000AF0 RID: 2800 RVA: 0x0002E904 File Offset: 0x0002CB04
		public FieldAccessException(string message)
			: base(message)
		{
			base.HResult = -2146233081;
		}

		// Token: 0x06000AF1 RID: 2801 RVA: 0x0002E918 File Offset: 0x0002CB18
		protected FieldAccessException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x040003E5 RID: 997
		private const int Result = -2146233081;
	}
}
