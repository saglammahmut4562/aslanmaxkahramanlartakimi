﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000114 RID: 276
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Enum, Inherited = false)]
	[Serializable]
	public class FlagsAttribute : Attribute
	{
	}
}
