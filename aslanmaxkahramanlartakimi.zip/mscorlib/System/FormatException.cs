﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000115 RID: 277
	[ComVisible(true)]
	[Serializable]
	public class FormatException : SystemException
	{
		// Token: 0x06000AF3 RID: 2803 RVA: 0x0002E92C File Offset: 0x0002CB2C
		public FormatException()
			: base(Locale.GetText("Invalid format."))
		{
			base.HResult = -2146233033;
		}

		// Token: 0x06000AF4 RID: 2804 RVA: 0x0002E94C File Offset: 0x0002CB4C
		public FormatException(string message)
			: base(message)
		{
			base.HResult = -2146233033;
		}

		// Token: 0x06000AF5 RID: 2805 RVA: 0x0002E960 File Offset: 0x0002CB60
		public FormatException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2146233033;
		}

		// Token: 0x06000AF6 RID: 2806 RVA: 0x0002E978 File Offset: 0x0002CB78
		protected FormatException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x040003E6 RID: 998
		private const int Result = -2146233033;
	}
}
