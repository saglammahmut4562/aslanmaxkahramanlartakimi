﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;

namespace System
{
	// Token: 0x02000116 RID: 278
	public static class GC
	{
		// Token: 0x06000AF7 RID: 2807
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		[MethodImpl(4096)]
		public static extern void SuppressFinalize(object obj);
	}
}
