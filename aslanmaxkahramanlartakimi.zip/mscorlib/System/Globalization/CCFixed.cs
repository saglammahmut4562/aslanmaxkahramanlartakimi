﻿using System;

namespace System.Globalization
{
	// Token: 0x02000118 RID: 280
	internal class CCFixed
	{
		// Token: 0x06000B02 RID: 2818 RVA: 0x0002EA10 File Offset: 0x0002CC10
		public static int FromDateTime(DateTime time)
		{
			return 1 + (int)(time.Ticks / 864000000000L);
		}

		// Token: 0x06000B03 RID: 2819 RVA: 0x0002EA28 File Offset: 0x0002CC28
		public static DayOfWeek day_of_week(int date)
		{
			return (DayOfWeek)CCMath.mod(date, 7);
		}
	}
}
