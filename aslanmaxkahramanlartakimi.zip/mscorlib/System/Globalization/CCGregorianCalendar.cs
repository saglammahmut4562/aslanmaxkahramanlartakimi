﻿using System;

namespace System.Globalization
{
	// Token: 0x02000119 RID: 281
	internal class CCGregorianCalendar
	{
		// Token: 0x06000B04 RID: 2820 RVA: 0x0002EA34 File Offset: 0x0002CC34
		public static bool is_leap_year(int year)
		{
			if (CCMath.mod(year, 4) != 0)
			{
				return false;
			}
			int num = CCMath.mod(year, 400);
			return num != 100 && num != 200 && num != 300;
		}

		// Token: 0x06000B05 RID: 2821 RVA: 0x0002EA88 File Offset: 0x0002CC88
		public static int fixed_from_dmy(int day, int month, int year)
		{
			int num = 0;
			num += 365 * (year - 1);
			num += CCMath.div(year - 1, 4);
			num -= CCMath.div(year - 1, 100);
			num += CCMath.div(year - 1, 400);
			num += CCMath.div(367 * month - 362, 12);
			if (month > 2)
			{
				num += ((!CCGregorianCalendar.is_leap_year(year)) ? (-2) : (-1));
			}
			return num + day;
		}

		// Token: 0x06000B06 RID: 2822 RVA: 0x0002EB08 File Offset: 0x0002CD08
		public static int year_from_fixed(int date)
		{
			int num = date - 1;
			int num2 = CCMath.div_mod(out num, num, 146097);
			int num3 = CCMath.div_mod(out num, num, 36524);
			int num4 = CCMath.div_mod(out num, num, 1461);
			int num5 = CCMath.div(num, 365);
			int num6 = 400 * num2 + 100 * num3 + 4 * num4 + num5;
			return (num3 != 4 && num5 != 4) ? (num6 + 1) : num6;
		}

		// Token: 0x06000B07 RID: 2823 RVA: 0x0002EB80 File Offset: 0x0002CD80
		public static void my_from_fixed(out int month, out int year, int date)
		{
			year = CCGregorianCalendar.year_from_fixed(date);
			int num = date - CCGregorianCalendar.fixed_from_dmy(1, 1, year);
			int num2;
			if (date < CCGregorianCalendar.fixed_from_dmy(1, 3, year))
			{
				num2 = 0;
			}
			else if (CCGregorianCalendar.is_leap_year(year))
			{
				num2 = 1;
			}
			else
			{
				num2 = 2;
			}
			month = CCMath.div(12 * (num + num2) + 373, 367);
		}

		// Token: 0x06000B08 RID: 2824 RVA: 0x0002EBE4 File Offset: 0x0002CDE4
		public static void dmy_from_fixed(out int day, out int month, out int year, int date)
		{
			CCGregorianCalendar.my_from_fixed(out month, out year, date);
			day = date - CCGregorianCalendar.fixed_from_dmy(1, month, year) + 1;
		}

		// Token: 0x06000B09 RID: 2825 RVA: 0x0002EC00 File Offset: 0x0002CE00
		public static int month_from_fixed(int date)
		{
			int num;
			int num2;
			CCGregorianCalendar.my_from_fixed(out num, out num2, date);
			return num;
		}

		// Token: 0x06000B0A RID: 2826 RVA: 0x0002EC18 File Offset: 0x0002CE18
		public static int day_from_fixed(int date)
		{
			int num;
			int num2;
			int num3;
			CCGregorianCalendar.dmy_from_fixed(out num, out num2, out num3, date);
			return num;
		}

		// Token: 0x06000B0B RID: 2827 RVA: 0x0002EC34 File Offset: 0x0002CE34
		public static int GetDayOfMonth(DateTime time)
		{
			return CCGregorianCalendar.day_from_fixed(CCFixed.FromDateTime(time));
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x0002EC44 File Offset: 0x0002CE44
		public static int GetMonth(DateTime time)
		{
			return CCGregorianCalendar.month_from_fixed(CCFixed.FromDateTime(time));
		}

		// Token: 0x06000B0D RID: 2829 RVA: 0x0002EC54 File Offset: 0x0002CE54
		public static int GetYear(DateTime time)
		{
			return CCGregorianCalendar.year_from_fixed(CCFixed.FromDateTime(time));
		}

		// Token: 0x040003EE RID: 1006
		private const int epoch = 1;
	}
}
