﻿using System;
using System.Collections;

namespace System.Globalization
{
	// Token: 0x0200011A RID: 282
	[Serializable]
	internal class CCGregorianEraHandler
	{
		// Token: 0x06000B0E RID: 2830 RVA: 0x0002EC64 File Offset: 0x0002CE64
		public CCGregorianEraHandler()
		{
			this._Eras = new SortedList();
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000B0F RID: 2831 RVA: 0x0002EC78 File Offset: 0x0002CE78
		public int[] Eras
		{
			get
			{
				int[] array = new int[this._Eras.Count];
				for (int i = 0; i < this._Eras.Count; i++)
				{
					array[i] = ((CCGregorianEraHandler.Era)this._Eras.GetByIndex(i)).Nr;
				}
				return array;
			}
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x0002ECD0 File Offset: 0x0002CED0
		public void appendEra(int nr, int rd_start, int rd_end)
		{
			CCGregorianEraHandler.Era era = new CCGregorianEraHandler.Era(nr, rd_start, rd_end);
			this._Eras[nr] = era;
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x0002ED00 File Offset: 0x0002CF00
		public void appendEra(int nr, int rd_start)
		{
			this.appendEra(nr, rd_start, CCFixed.FromDateTime(DateTime.MaxValue));
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x0002ED14 File Offset: 0x0002CF14
		public int EraYear(out int era, int date)
		{
			IList valueList = this._Eras.GetValueList();
			foreach (object obj in valueList)
			{
				CCGregorianEraHandler.Era era2 = (CCGregorianEraHandler.Era)obj;
				if (era2.Covers(date))
				{
					return era2.EraYear(out era, date);
				}
			}
			throw new ArgumentOutOfRangeException("date", "Time value was out of era range.");
		}

		// Token: 0x040003EF RID: 1007
		private SortedList _Eras;

		// Token: 0x0200011B RID: 283
		[Serializable]
		private struct Era
		{
			// Token: 0x06000B13 RID: 2835 RVA: 0x0002EDA8 File Offset: 0x0002CFA8
			public Era(int nr, int start, int end)
			{
				if (nr == 0)
				{
					throw new ArgumentException("Era number shouldn't be zero.");
				}
				this._nr = nr;
				if (start > end)
				{
					throw new ArgumentException("Era should start before end.");
				}
				this._start = start;
				this._end = end;
				this._gregorianYearStart = CCGregorianCalendar.year_from_fixed(this._start);
				int num = CCGregorianCalendar.year_from_fixed(this._end);
				this._maxYear = num - this._gregorianYearStart + 1;
			}

			// Token: 0x17000197 RID: 407
			// (get) Token: 0x06000B14 RID: 2836 RVA: 0x0002EE1C File Offset: 0x0002D01C
			public int Nr
			{
				get
				{
					return this._nr;
				}
			}

			// Token: 0x06000B15 RID: 2837 RVA: 0x0002EE24 File Offset: 0x0002D024
			public bool Covers(int date)
			{
				return this._start <= date && date <= this._end;
			}

			// Token: 0x06000B16 RID: 2838 RVA: 0x0002EE44 File Offset: 0x0002D044
			public int EraYear(out int era, int date)
			{
				if (!this.Covers(date))
				{
					throw new ArgumentOutOfRangeException("date", "Time was out of Era range.");
				}
				int num = CCGregorianCalendar.year_from_fixed(date);
				era = this._nr;
				return num - this._gregorianYearStart + 1;
			}

			// Token: 0x040003F0 RID: 1008
			private int _nr;

			// Token: 0x040003F1 RID: 1009
			private int _start;

			// Token: 0x040003F2 RID: 1010
			private int _gregorianYearStart;

			// Token: 0x040003F3 RID: 1011
			private int _end;

			// Token: 0x040003F4 RID: 1012
			private int _maxYear;
		}
	}
}
