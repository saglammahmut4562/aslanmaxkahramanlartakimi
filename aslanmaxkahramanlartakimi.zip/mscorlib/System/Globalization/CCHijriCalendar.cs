﻿using System;

namespace System.Globalization
{
	// Token: 0x0200011C RID: 284
	internal class CCHijriCalendar
	{
		// Token: 0x06000B17 RID: 2839 RVA: 0x0002EE88 File Offset: 0x0002D088
		public static int fixed_from_dmy(int day, int month, int year)
		{
			int num = 227013;
			num += 354 * (year - 1);
			num += CCMath.div(3 + 11 * year, 30);
			num += (int)Math.Ceiling(29.5 * (double)(month - 1));
			return num + day;
		}

		// Token: 0x06000B18 RID: 2840 RVA: 0x0002EED4 File Offset: 0x0002D0D4
		public static int year_from_fixed(int date)
		{
			return CCMath.div(30 * (date - 227014) + 10646, 10631);
		}

		// Token: 0x06000B19 RID: 2841 RVA: 0x0002EEF0 File Offset: 0x0002D0F0
		public static void my_from_fixed(out int month, out int year, int date)
		{
			year = CCHijriCalendar.year_from_fixed(date);
			int num = 1 + (int)Math.Ceiling((double)(date - 29 - CCHijriCalendar.fixed_from_dmy(1, 1, year)) / 29.5);
			month = ((num >= 12) ? 12 : num);
		}

		// Token: 0x06000B1A RID: 2842 RVA: 0x0002EF3C File Offset: 0x0002D13C
		public static void dmy_from_fixed(out int day, out int month, out int year, int date)
		{
			CCHijriCalendar.my_from_fixed(out month, out year, date);
			day = date - CCHijriCalendar.fixed_from_dmy(1, month, year) + 1;
		}

		// Token: 0x06000B1B RID: 2843 RVA: 0x0002EF58 File Offset: 0x0002D158
		public static int month_from_fixed(int date)
		{
			int num;
			int num2;
			CCHijriCalendar.my_from_fixed(out num, out num2, date);
			return num;
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x0002EF70 File Offset: 0x0002D170
		public static int day_from_fixed(int date)
		{
			int num;
			int num2;
			int num3;
			CCHijriCalendar.dmy_from_fixed(out num, out num2, out num3, date);
			return num;
		}

		// Token: 0x040003F5 RID: 1013
		private const int epoch = 227014;
	}
}
