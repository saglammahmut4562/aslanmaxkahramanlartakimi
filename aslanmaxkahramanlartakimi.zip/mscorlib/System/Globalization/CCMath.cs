﻿using System;

namespace System.Globalization
{
	// Token: 0x0200011D RID: 285
	internal class CCMath
	{
		// Token: 0x06000B1D RID: 2845 RVA: 0x0002EF8C File Offset: 0x0002D18C
		public static int div(int x, int y)
		{
			return (int)Math.Floor((double)x / (double)y);
		}

		// Token: 0x06000B1E RID: 2846 RVA: 0x0002EF9C File Offset: 0x0002D19C
		public static int mod(int x, int y)
		{
			return x - y * CCMath.div(x, y);
		}

		// Token: 0x06000B1F RID: 2847 RVA: 0x0002EFAC File Offset: 0x0002D1AC
		public static int div_mod(out int remainder, int x, int y)
		{
			int num = CCMath.div(x, y);
			remainder = x - y * num;
			return num;
		}
	}
}
