﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x02000117 RID: 279
	[ComVisible(true)]
	[Serializable]
	public abstract class Calendar : ICloneable
	{
		// Token: 0x06000AF8 RID: 2808 RVA: 0x0002E984 File Offset: 0x0002CB84
		protected Calendar()
		{
			this.twoDigitYearMax = 99;
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000AF9 RID: 2809
		public abstract int[] Eras { get; }

		// Token: 0x06000AFA RID: 2810 RVA: 0x0002E994 File Offset: 0x0002CB94
		[ComVisible(false)]
		public virtual object Clone()
		{
			Calendar calendar = (Calendar)base.MemberwiseClone();
			calendar.m_isReadOnly = false;
			return calendar;
		}

		// Token: 0x06000AFB RID: 2811 RVA: 0x0002E9B8 File Offset: 0x0002CBB8
		internal void CheckReadOnly()
		{
			if (this.m_isReadOnly)
			{
				throw new InvalidOperationException("This Calendar is read-only.");
			}
		}

		// Token: 0x06000AFC RID: 2812
		public abstract int GetDayOfMonth(DateTime time);

		// Token: 0x06000AFD RID: 2813
		public abstract DayOfWeek GetDayOfWeek(DateTime time);

		// Token: 0x06000AFE RID: 2814
		public abstract int GetEra(DateTime time);

		// Token: 0x06000AFF RID: 2815
		public abstract int GetMonth(DateTime time);

		// Token: 0x06000B00 RID: 2816
		public abstract int GetYear(DateTime time);

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000B01 RID: 2817 RVA: 0x0002E9D0 File Offset: 0x0002CBD0
		internal string[] EraNames
		{
			get
			{
				if (this.M_EraNames == null || this.M_EraNames.Length != this.Eras.Length)
				{
					throw new Exception("Internal: M_EraNames not initialized!");
				}
				return (string[])this.M_EraNames.Clone();
			}
		}

		// Token: 0x040003E7 RID: 999
		public const int CurrentEra = 0;

		// Token: 0x040003E8 RID: 1000
		[NonSerialized]
		private bool m_isReadOnly;

		// Token: 0x040003E9 RID: 1001
		[NonSerialized]
		internal int twoDigitYearMax;

		// Token: 0x040003EA RID: 1002
		[NonSerialized]
		private int M_MaxYearValue;

		// Token: 0x040003EB RID: 1003
		[NonSerialized]
		internal string[] M_AbbrEraNames;

		// Token: 0x040003EC RID: 1004
		[NonSerialized]
		internal string[] M_EraNames;

		// Token: 0x040003ED RID: 1005
		internal int m_currentEraValue;
	}
}
