﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using Mono.Globalization.Unicode;

namespace System.Globalization
{
	// Token: 0x0200011E RID: 286
	[ComVisible(true)]
	[Serializable]
	public class CompareInfo : IDeserializationCallback
	{
		// Token: 0x06000B20 RID: 2848 RVA: 0x0002EFCC File Offset: 0x0002D1CC
		private CompareInfo()
		{
		}

		// Token: 0x06000B21 RID: 2849 RVA: 0x0002EFD4 File Offset: 0x0002D1D4
		internal CompareInfo(CultureInfo ci)
		{
			this.culture = ci.LCID;
			if (CompareInfo.UseManagedCollation)
			{
				object obj = CompareInfo.monitor;
				lock (obj)
				{
					if (CompareInfo.collators == null)
					{
						CompareInfo.collators = new Hashtable();
					}
					this.collator = (SimpleCollator)CompareInfo.collators[ci.LCID];
					if (this.collator == null)
					{
						this.collator = new SimpleCollator(ci);
						CompareInfo.collators[ci.LCID] = this.collator;
					}
				}
			}
			else
			{
				this.icu_name = ci.IcuName;
				this.construct_compareinfo(this.icu_name);
			}
		}

		// Token: 0x06000B23 RID: 2851 RVA: 0x0002F0DC File Offset: 0x0002D2DC
		void IDeserializationCallback.OnDeserialization(object sender)
		{
			if (CompareInfo.UseManagedCollation)
			{
				this.collator = new SimpleCollator(new CultureInfo(this.culture));
			}
			else
			{
				try
				{
					this.construct_compareinfo(this.icu_name);
				}
				catch
				{
				}
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000B24 RID: 2852 RVA: 0x0002F138 File Offset: 0x0002D338
		internal static bool UseManagedCollation
		{
			get
			{
				return CompareInfo.useManagedCollation;
			}
		}

		// Token: 0x06000B25 RID: 2853
		[MethodImpl(4096)]
		private extern void construct_compareinfo(string locale);

		// Token: 0x06000B26 RID: 2854
		[MethodImpl(4096)]
		private extern void free_internal_collator();

		// Token: 0x06000B27 RID: 2855
		[MethodImpl(4096)]
		private extern int internal_compare(string str1, int offset1, int length1, string str2, int offset2, int length2, CompareOptions options);

		// Token: 0x06000B28 RID: 2856
		[MethodImpl(4096)]
		private extern void assign_sortkey(object key, string source, CompareOptions options);

		// Token: 0x06000B29 RID: 2857
		[MethodImpl(4096)]
		private extern int internal_index(string source, int sindex, int count, string value, CompareOptions options, bool first);

		// Token: 0x06000B2A RID: 2858 RVA: 0x0002F140 File Offset: 0x0002D340
		~CompareInfo()
		{
			this.free_internal_collator();
		}

		// Token: 0x06000B2B RID: 2859 RVA: 0x0002F170 File Offset: 0x0002D370
		private int internal_compare_managed(string str1, int offset1, int length1, string str2, int offset2, int length2, CompareOptions options)
		{
			return this.collator.Compare(str1, offset1, length1, str2, offset2, length2, options);
		}

		// Token: 0x06000B2C RID: 2860 RVA: 0x0002F194 File Offset: 0x0002D394
		private int internal_compare_switch(string str1, int offset1, int length1, string str2, int offset2, int length2, CompareOptions options)
		{
			return (!CompareInfo.UseManagedCollation) ? this.internal_compare(str1, offset1, length1, str2, offset2, length2, options) : this.internal_compare_managed(str1, offset1, length1, str2, offset2, length2, options);
		}

		// Token: 0x06000B2D RID: 2861 RVA: 0x0002F1D4 File Offset: 0x0002D3D4
		public virtual int Compare(string string1, string string2)
		{
			return this.Compare(string1, string2, CompareOptions.None);
		}

		// Token: 0x06000B2E RID: 2862 RVA: 0x0002F1E0 File Offset: 0x0002D3E0
		public virtual int Compare(string string1, string string2, CompareOptions options)
		{
			if ((options & (CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace | CompareOptions.IgnoreSymbols | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.StringSort | CompareOptions.Ordinal | CompareOptions.OrdinalIgnoreCase)) != options)
			{
				throw new ArgumentException("options");
			}
			if (string1 == null)
			{
				if (string2 == null)
				{
					return 0;
				}
				return -1;
			}
			else
			{
				if (string2 == null)
				{
					return 1;
				}
				if (string1.Length == 0 && string2.Length == 0)
				{
					return 0;
				}
				return this.internal_compare_switch(string1, 0, string1.Length, string2, 0, string2.Length, options);
			}
		}

		// Token: 0x06000B2F RID: 2863 RVA: 0x0002F24C File Offset: 0x0002D44C
		public virtual int Compare(string string1, int offset1, int length1, string string2, int offset2, int length2, CompareOptions options)
		{
			if ((options & (CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace | CompareOptions.IgnoreSymbols | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.StringSort | CompareOptions.Ordinal | CompareOptions.OrdinalIgnoreCase)) != options)
			{
				throw new ArgumentException("options");
			}
			if (string1 == null)
			{
				if (string2 == null)
				{
					return 0;
				}
				return -1;
			}
			else
			{
				if (string2 == null)
				{
					return 1;
				}
				if ((string1.Length == 0 || offset1 == string1.Length || length1 == 0) && (string2.Length == 0 || offset2 == string2.Length || length2 == 0))
				{
					return 0;
				}
				if (offset1 < 0 || length1 < 0 || offset2 < 0 || length2 < 0)
				{
					throw new ArgumentOutOfRangeException("Offsets and lengths must not be less than zero");
				}
				if (offset1 > string1.Length)
				{
					throw new ArgumentOutOfRangeException("Offset1 is greater than or equal to the length of string1");
				}
				if (offset2 > string2.Length)
				{
					throw new ArgumentOutOfRangeException("Offset2 is greater than or equal to the length of string2");
				}
				if (length1 > string1.Length - offset1)
				{
					throw new ArgumentOutOfRangeException("Length1 is greater than the number of characters from offset1 to the end of string1");
				}
				if (length2 > string2.Length - offset2)
				{
					throw new ArgumentOutOfRangeException("Length2 is greater than the number of characters from offset2 to the end of string2");
				}
				return this.internal_compare_switch(string1, offset1, length1, string2, offset2, length2, options);
			}
		}

		// Token: 0x06000B30 RID: 2864 RVA: 0x0002F36C File Offset: 0x0002D56C
		public override bool Equals(object value)
		{
			CompareInfo compareInfo = value as CompareInfo;
			return compareInfo != null && compareInfo.culture == this.culture;
		}

		// Token: 0x06000B31 RID: 2865 RVA: 0x0002F398 File Offset: 0x0002D598
		public override int GetHashCode()
		{
			return this.LCID;
		}

		// Token: 0x06000B32 RID: 2866 RVA: 0x0002F3A0 File Offset: 0x0002D5A0
		public virtual SortKey GetSortKey(string source, CompareOptions options)
		{
			if (options == CompareOptions.OrdinalIgnoreCase || options == CompareOptions.Ordinal)
			{
				throw new ArgumentException("Now allowed CompareOptions.", "options");
			}
			if (CompareInfo.UseManagedCollation)
			{
				return this.collator.GetSortKey(source, options);
			}
			SortKey sortKey = new SortKey(this.culture, source, options);
			this.assign_sortkey(sortKey, source, options);
			return sortKey;
		}

		// Token: 0x06000B33 RID: 2867 RVA: 0x0002F40C File Offset: 0x0002D60C
		public virtual int IndexOf(string source, string value)
		{
			return this.IndexOf(source, value, 0, source.Length, CompareOptions.None);
		}

		// Token: 0x06000B34 RID: 2868 RVA: 0x0002F420 File Offset: 0x0002D620
		public virtual int IndexOf(string source, string value, int startIndex, int count)
		{
			return this.IndexOf(source, value, startIndex, count, CompareOptions.None);
		}

		// Token: 0x06000B35 RID: 2869 RVA: 0x0002F430 File Offset: 0x0002D630
		private int internal_index_managed(string s1, int sindex, int count, string s2, CompareOptions opt, bool first)
		{
			return (!first) ? this.collator.LastIndexOf(s1, s2, sindex, count, opt) : this.collator.IndexOf(s1, s2, sindex, count, opt);
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x0002F464 File Offset: 0x0002D664
		private int internal_index_switch(string s1, int sindex, int count, string s2, CompareOptions opt, bool first)
		{
			return (!CompareInfo.UseManagedCollation || (first && opt == CompareOptions.Ordinal)) ? this.internal_index(s1, sindex, count, s2, opt, first) : this.internal_index_managed(s1, sindex, count, s2, opt, first);
		}

		// Token: 0x06000B37 RID: 2871 RVA: 0x0002F4B4 File Offset: 0x0002D6B4
		public virtual int IndexOf(string source, string value, int startIndex, int count, CompareOptions options)
		{
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (startIndex < 0)
			{
				throw new ArgumentOutOfRangeException("startIndex");
			}
			if (count < 0 || source.Length - startIndex < count)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if ((options & (CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace | CompareOptions.IgnoreSymbols | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.Ordinal | CompareOptions.OrdinalIgnoreCase)) != options)
			{
				throw new ArgumentException("options");
			}
			if (value.Length == 0)
			{
				return startIndex;
			}
			if (count == 0)
			{
				return -1;
			}
			return this.internal_index_switch(source, startIndex, count, value, options, true);
		}

		// Token: 0x06000B38 RID: 2872 RVA: 0x0002F558 File Offset: 0x0002D758
		public virtual bool IsPrefix(string source, string prefix, CompareOptions options)
		{
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			if (prefix == null)
			{
				throw new ArgumentNullException("prefix");
			}
			if (CompareInfo.UseManagedCollation)
			{
				return this.collator.IsPrefix(source, prefix, options);
			}
			return source.Length >= prefix.Length && this.Compare(source, 0, prefix.Length, prefix, 0, prefix.Length, options) == 0;
		}

		// Token: 0x06000B39 RID: 2873 RVA: 0x0002F5D0 File Offset: 0x0002D7D0
		public virtual bool IsSuffix(string source, string suffix, CompareOptions options)
		{
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			if (suffix == null)
			{
				throw new ArgumentNullException("suffix");
			}
			if (CompareInfo.UseManagedCollation)
			{
				return this.collator.IsSuffix(source, suffix, options);
			}
			return source.Length >= suffix.Length && this.Compare(source, source.Length - suffix.Length, suffix.Length, suffix, 0, suffix.Length, options) == 0;
		}

		// Token: 0x06000B3A RID: 2874 RVA: 0x0002F654 File Offset: 0x0002D854
		public virtual int LastIndexOf(string source, string value, int startIndex, int count)
		{
			return this.LastIndexOf(source, value, startIndex, count, CompareOptions.None);
		}

		// Token: 0x06000B3B RID: 2875 RVA: 0x0002F664 File Offset: 0x0002D864
		public virtual int LastIndexOf(string source, string value, int startIndex, int count, CompareOptions options)
		{
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (startIndex < 0)
			{
				throw new ArgumentOutOfRangeException("startIndex");
			}
			if (count < 0 || startIndex - count < -1)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if ((options & (CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace | CompareOptions.IgnoreSymbols | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.Ordinal | CompareOptions.OrdinalIgnoreCase)) != options)
			{
				throw new ArgumentException("options");
			}
			if (count == 0)
			{
				return -1;
			}
			if (value.Length == 0)
			{
				return 0;
			}
			return this.internal_index_switch(source, startIndex, count, value, options, false);
		}

		// Token: 0x06000B3C RID: 2876 RVA: 0x0002F704 File Offset: 0x0002D904
		public override string ToString()
		{
			return "CompareInfo - " + this.culture;
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000B3D RID: 2877 RVA: 0x0002F71C File Offset: 0x0002D91C
		public int LCID
		{
			get
			{
				return this.culture;
			}
		}

		// Token: 0x040003F6 RID: 1014
		private const CompareOptions ValidCompareOptions_NoStringSort = CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace | CompareOptions.IgnoreSymbols | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.Ordinal | CompareOptions.OrdinalIgnoreCase;

		// Token: 0x040003F7 RID: 1015
		private const CompareOptions ValidCompareOptions = CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace | CompareOptions.IgnoreSymbols | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.StringSort | CompareOptions.Ordinal | CompareOptions.OrdinalIgnoreCase;

		// Token: 0x040003F8 RID: 1016
		private static readonly bool useManagedCollation = Environment.internalGetEnvironmentVariable("MONO_DISABLE_MANAGED_COLLATION") != "yes" && MSCompatUnicodeTable.IsReady;

		// Token: 0x040003F9 RID: 1017
		private int culture;

		// Token: 0x040003FA RID: 1018
		[NonSerialized]
		private string icu_name;

		// Token: 0x040003FB RID: 1019
		private int win32LCID;

		// Token: 0x040003FC RID: 1020
		private string m_name;

		// Token: 0x040003FD RID: 1021
		[NonSerialized]
		private SimpleCollator collator;

		// Token: 0x040003FE RID: 1022
		private static Hashtable collators;

		// Token: 0x040003FF RID: 1023
		[NonSerialized]
		private static object monitor = new object();
	}
}
