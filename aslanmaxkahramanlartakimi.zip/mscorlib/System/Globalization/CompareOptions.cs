﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x0200011F RID: 287
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum CompareOptions
	{
		// Token: 0x04000401 RID: 1025
		None = 0,
		// Token: 0x04000402 RID: 1026
		IgnoreCase = 1,
		// Token: 0x04000403 RID: 1027
		IgnoreNonSpace = 2,
		// Token: 0x04000404 RID: 1028
		IgnoreSymbols = 4,
		// Token: 0x04000405 RID: 1029
		IgnoreKanaType = 8,
		// Token: 0x04000406 RID: 1030
		IgnoreWidth = 16,
		// Token: 0x04000407 RID: 1031
		StringSort = 536870912,
		// Token: 0x04000408 RID: 1032
		Ordinal = 1073741824,
		// Token: 0x04000409 RID: 1033
		OrdinalIgnoreCase = 268435456
	}
}
