﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;

namespace System.Globalization
{
	// Token: 0x02000120 RID: 288
	[ComVisible(true)]
	[Serializable]
	public class CultureInfo : ICloneable, IFormatProvider
	{
		// Token: 0x06000B3E RID: 2878 RVA: 0x0002F724 File Offset: 0x0002D924
		public CultureInfo(int culture)
			: this(culture, true)
		{
		}

		// Token: 0x06000B3F RID: 2879 RVA: 0x0002F730 File Offset: 0x0002D930
		public CultureInfo(int culture, bool useUserOverride)
			: this(culture, useUserOverride, false)
		{
		}

		// Token: 0x06000B40 RID: 2880 RVA: 0x0002F73C File Offset: 0x0002D93C
		private CultureInfo(int culture, bool useUserOverride, bool read_only)
		{
			if (culture < 0)
			{
				throw new ArgumentOutOfRangeException("culture", "Positive number required.");
			}
			this.constructed = true;
			this.m_isReadOnly = read_only;
			this.m_useUserOverride = useUserOverride;
			if (culture == 127)
			{
				this.ConstructInvariant(read_only);
				return;
			}
			if (!this.ConstructInternalLocaleFromLcid(culture))
			{
				throw new ArgumentException(string.Format("Culture ID {0} (0x{0:X4}) is not a supported culture.", culture), "culture");
			}
		}

		// Token: 0x06000B41 RID: 2881 RVA: 0x0002F7B4 File Offset: 0x0002D9B4
		public CultureInfo(string name)
			: this(name, true)
		{
		}

		// Token: 0x06000B42 RID: 2882 RVA: 0x0002F7C0 File Offset: 0x0002D9C0
		public CultureInfo(string name, bool useUserOverride)
			: this(name, useUserOverride, false)
		{
		}

		// Token: 0x06000B43 RID: 2883 RVA: 0x0002F7CC File Offset: 0x0002D9CC
		private CultureInfo(string name, bool useUserOverride, bool read_only)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			this.constructed = true;
			this.m_isReadOnly = read_only;
			this.m_useUserOverride = useUserOverride;
			if (name.Length == 0)
			{
				this.ConstructInvariant(read_only);
				return;
			}
			if (!this.ConstructInternalLocaleFromName(name.ToLowerInvariant()))
			{
				throw new ArgumentException("Culture name " + name + " is not supported.", "name");
			}
		}

		// Token: 0x06000B44 RID: 2884 RVA: 0x0002F844 File Offset: 0x0002DA44
		private CultureInfo()
		{
			this.constructed = true;
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000B46 RID: 2886 RVA: 0x0002F87C File Offset: 0x0002DA7C
		public static CultureInfo InvariantCulture
		{
			get
			{
				return CultureInfo.invariant_culture_info;
			}
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x0002F888 File Offset: 0x0002DA88
		public static CultureInfo CreateSpecificCulture(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			if (name == string.Empty)
			{
				return CultureInfo.InvariantCulture;
			}
			CultureInfo cultureInfo = new CultureInfo();
			if (!CultureInfo.ConstructInternalLocaleFromSpecificName(cultureInfo, name.ToLowerInvariant()))
			{
				throw new ArgumentException("Culture name " + name + " is not supported.", name);
			}
			return cultureInfo;
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000B48 RID: 2888 RVA: 0x0002F8EC File Offset: 0x0002DAEC
		public static CultureInfo CurrentCulture
		{
			get
			{
				return Thread.CurrentThread.CurrentCulture;
			}
		}

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x06000B49 RID: 2889 RVA: 0x0002F8F8 File Offset: 0x0002DAF8
		public static CultureInfo CurrentUICulture
		{
			get
			{
				return Thread.CurrentThread.CurrentUICulture;
			}
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x0002F904 File Offset: 0x0002DB04
		internal static CultureInfo ConstructCurrentCulture()
		{
			CultureInfo cultureInfo = new CultureInfo();
			if (!CultureInfo.ConstructInternalLocaleFromCurrentLocale(cultureInfo))
			{
				cultureInfo = CultureInfo.InvariantCulture;
			}
			CultureInfo.BootstrapCultureID = cultureInfo.cultureID;
			return cultureInfo;
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x0002F934 File Offset: 0x0002DB34
		internal static CultureInfo ConstructCurrentUICulture()
		{
			return CultureInfo.ConstructCurrentCulture();
		}

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06000B4C RID: 2892 RVA: 0x0002F93C File Offset: 0x0002DB3C
		internal string Territory
		{
			get
			{
				return this.territory;
			}
		}

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000B4D RID: 2893 RVA: 0x0002F944 File Offset: 0x0002DB44
		public virtual int LCID
		{
			get
			{
				return this.cultureID;
			}
		}

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000B4E RID: 2894 RVA: 0x0002F94C File Offset: 0x0002DB4C
		public virtual string Name
		{
			get
			{
				return this.m_name;
			}
		}

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x06000B4F RID: 2895 RVA: 0x0002F954 File Offset: 0x0002DB54
		public virtual string NativeName
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.nativename;
			}
		}

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06000B50 RID: 2896 RVA: 0x0002F970 File Offset: 0x0002DB70
		public virtual Calendar Calendar
		{
			get
			{
				return this.DateTimeFormat.Calendar;
			}
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000B51 RID: 2897 RVA: 0x0002F980 File Offset: 0x0002DB80
		public virtual Calendar[] OptionalCalendars
		{
			get
			{
				if (this.optional_calendars == null)
				{
					lock (this)
					{
						if (this.optional_calendars == null)
						{
							this.ConstructCalendars();
						}
					}
				}
				return this.optional_calendars;
			}
		}

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x06000B52 RID: 2898 RVA: 0x0002F9D4 File Offset: 0x0002DBD4
		public virtual CultureInfo Parent
		{
			get
			{
				if (this.parent_culture == null)
				{
					if (!this.constructed)
					{
						this.Construct();
					}
					if (this.parent_lcid == this.cultureID)
					{
						return null;
					}
					if (this.parent_lcid == 127)
					{
						this.parent_culture = CultureInfo.InvariantCulture;
					}
					else if (this.cultureID == 127)
					{
						this.parent_culture = this;
					}
					else
					{
						this.parent_culture = new CultureInfo(this.parent_lcid);
					}
				}
				return this.parent_culture;
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06000B53 RID: 2899 RVA: 0x0002FA60 File Offset: 0x0002DC60
		public virtual TextInfo TextInfo
		{
			get
			{
				if (this.textInfo == null)
				{
					if (!this.constructed)
					{
						this.Construct();
					}
					lock (this)
					{
						if (this.textInfo == null)
						{
							this.textInfo = this.CreateTextInfo(this.m_isReadOnly);
						}
					}
				}
				return this.textInfo;
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x06000B54 RID: 2900 RVA: 0x0002FAD8 File Offset: 0x0002DCD8
		public virtual string ThreeLetterISOLanguageName
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.iso3lang;
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000B55 RID: 2901 RVA: 0x0002FAF4 File Offset: 0x0002DCF4
		public virtual string ThreeLetterWindowsLanguageName
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.win3lang;
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000B56 RID: 2902 RVA: 0x0002FB10 File Offset: 0x0002DD10
		public virtual string TwoLetterISOLanguageName
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.iso2lang;
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000B57 RID: 2903 RVA: 0x0002FB2C File Offset: 0x0002DD2C
		public bool UseUserOverride
		{
			get
			{
				return this.m_useUserOverride;
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000B58 RID: 2904 RVA: 0x0002FB34 File Offset: 0x0002DD34
		internal string IcuName
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.icu_name;
			}
		}

		// Token: 0x06000B59 RID: 2905 RVA: 0x0002FB50 File Offset: 0x0002DD50
		public void ClearCachedData()
		{
			Thread.CurrentThread.CurrentCulture = null;
			Thread.CurrentThread.CurrentUICulture = null;
		}

		// Token: 0x06000B5A RID: 2906 RVA: 0x0002FB68 File Offset: 0x0002DD68
		public virtual object Clone()
		{
			if (!this.constructed)
			{
				this.Construct();
			}
			CultureInfo cultureInfo = (CultureInfo)base.MemberwiseClone();
			cultureInfo.m_isReadOnly = false;
			cultureInfo.cached_serialized_form = null;
			if (!this.IsNeutralCulture)
			{
				cultureInfo.NumberFormat = (NumberFormatInfo)this.NumberFormat.Clone();
				cultureInfo.DateTimeFormat = (DateTimeFormatInfo)this.DateTimeFormat.Clone();
			}
			return cultureInfo;
		}

		// Token: 0x06000B5B RID: 2907 RVA: 0x0002FBD8 File Offset: 0x0002DDD8
		public override bool Equals(object value)
		{
			CultureInfo cultureInfo = value as CultureInfo;
			return cultureInfo != null && cultureInfo.cultureID == this.cultureID;
		}

		// Token: 0x06000B5C RID: 2908 RVA: 0x0002FC04 File Offset: 0x0002DE04
		public static CultureInfo[] GetCultures(CultureTypes types)
		{
			bool flag = (types & CultureTypes.NeutralCultures) != (CultureTypes)0;
			bool flag2 = (types & CultureTypes.SpecificCultures) != (CultureTypes)0;
			bool flag3 = (types & CultureTypes.InstalledWin32Cultures) != (CultureTypes)0;
			CultureInfo[] array = CultureInfo.internal_get_cultures(flag, flag2, flag3);
			if (flag && array.Length > 0 && array[0] == null)
			{
				array[0] = (CultureInfo)CultureInfo.InvariantCulture.Clone();
			}
			return array;
		}

		// Token: 0x06000B5D RID: 2909 RVA: 0x0002FC64 File Offset: 0x0002DE64
		public override int GetHashCode()
		{
			return this.cultureID;
		}

		// Token: 0x06000B5E RID: 2910 RVA: 0x0002FC6C File Offset: 0x0002DE6C
		public static CultureInfo ReadOnly(CultureInfo ci)
		{
			if (ci == null)
			{
				throw new ArgumentNullException("ci");
			}
			if (ci.m_isReadOnly)
			{
				return ci;
			}
			CultureInfo cultureInfo = (CultureInfo)ci.Clone();
			cultureInfo.m_isReadOnly = true;
			if (cultureInfo.numInfo != null)
			{
				cultureInfo.numInfo = NumberFormatInfo.ReadOnly(cultureInfo.numInfo);
			}
			if (cultureInfo.dateTimeInfo != null)
			{
				cultureInfo.dateTimeInfo = DateTimeFormatInfo.ReadOnly(cultureInfo.dateTimeInfo);
			}
			if (cultureInfo.textInfo != null)
			{
				cultureInfo.textInfo = TextInfo.ReadOnly(cultureInfo.textInfo);
			}
			return cultureInfo;
		}

		// Token: 0x06000B5F RID: 2911 RVA: 0x0002FD14 File Offset: 0x0002DF14
		public override string ToString()
		{
			return this.m_name;
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000B60 RID: 2912 RVA: 0x0002FD1C File Offset: 0x0002DF1C
		public virtual CompareInfo CompareInfo
		{
			get
			{
				if (this.compareInfo == null)
				{
					if (!this.constructed)
					{
						this.Construct();
					}
					lock (this)
					{
						if (this.compareInfo == null)
						{
							this.compareInfo = new CompareInfo(this);
						}
					}
				}
				return this.compareInfo;
			}
		}

		// Token: 0x06000B61 RID: 2913 RVA: 0x0002FD90 File Offset: 0x0002DF90
		internal static bool IsIDNeutralCulture(int lcid)
		{
			bool flag;
			if (!CultureInfo.internal_is_lcid_neutral(lcid, out flag))
			{
				throw new ArgumentException(string.Format("Culture id 0x{:x4} is not supported.", lcid));
			}
			return flag;
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x06000B62 RID: 2914 RVA: 0x0002FDC4 File Offset: 0x0002DFC4
		public virtual bool IsNeutralCulture
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.cultureID != 127 && ((this.cultureID & 65280) == 0 || this.specific_lcid == 0);
			}
		}

		// Token: 0x06000B63 RID: 2915 RVA: 0x0002FE04 File Offset: 0x0002E004
		internal void CheckNeutral()
		{
			if (this.IsNeutralCulture)
			{
				throw new NotSupportedException("Culture \"" + this.m_name + "\" is a neutral culture. It can not be used in formatting and parsing and therefore cannot be set as the thread's current culture.");
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x06000B64 RID: 2916 RVA: 0x0002FE2C File Offset: 0x0002E02C
		// (set) Token: 0x06000B65 RID: 2917 RVA: 0x0002FEB0 File Offset: 0x0002E0B0
		public virtual NumberFormatInfo NumberFormat
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				this.CheckNeutral();
				if (this.numInfo == null)
				{
					lock (this)
					{
						if (this.numInfo == null)
						{
							this.numInfo = new NumberFormatInfo(this.m_isReadOnly);
							this.construct_number_format();
						}
					}
				}
				return this.numInfo;
			}
			set
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				if (this.m_isReadOnly)
				{
					throw new InvalidOperationException(CultureInfo.MSG_READONLY);
				}
				if (value == null)
				{
					throw new ArgumentNullException("NumberFormat");
				}
				this.numInfo = value;
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x06000B66 RID: 2918 RVA: 0x0002FF00 File Offset: 0x0002E100
		// (set) Token: 0x06000B67 RID: 2919 RVA: 0x0002FFA4 File Offset: 0x0002E1A4
		public virtual DateTimeFormatInfo DateTimeFormat
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				this.CheckNeutral();
				if (this.dateTimeInfo == null)
				{
					lock (this)
					{
						if (this.dateTimeInfo == null)
						{
							this.dateTimeInfo = new DateTimeFormatInfo(this.m_isReadOnly);
							this.construct_datetime_format();
							if (this.optional_calendars != null)
							{
								this.dateTimeInfo.Calendar = this.optional_calendars[0];
							}
						}
					}
				}
				return this.dateTimeInfo;
			}
			set
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				if (this.m_isReadOnly)
				{
					throw new InvalidOperationException(CultureInfo.MSG_READONLY);
				}
				if (value == null)
				{
					throw new ArgumentNullException("DateTimeFormat");
				}
				this.dateTimeInfo = value;
			}
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000B68 RID: 2920 RVA: 0x0002FFF4 File Offset: 0x0002E1F4
		public virtual string DisplayName
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.displayname;
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000B69 RID: 2921 RVA: 0x00030010 File Offset: 0x0002E210
		public virtual string EnglishName
		{
			get
			{
				if (!this.constructed)
				{
					this.Construct();
				}
				return this.englishname;
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000B6A RID: 2922 RVA: 0x0003002C File Offset: 0x0002E22C
		public static CultureInfo InstalledUICulture
		{
			get
			{
				return CultureInfo.GetCultureInfo(CultureInfo.BootstrapCultureID);
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000B6B RID: 2923 RVA: 0x00030038 File Offset: 0x0002E238
		public bool IsReadOnly
		{
			get
			{
				return this.m_isReadOnly;
			}
		}

		// Token: 0x06000B6C RID: 2924 RVA: 0x00030040 File Offset: 0x0002E240
		public virtual object GetFormat(Type formatType)
		{
			object obj = null;
			if (formatType == typeof(NumberFormatInfo))
			{
				obj = this.NumberFormat;
			}
			else if (formatType == typeof(DateTimeFormatInfo))
			{
				obj = this.DateTimeFormat;
			}
			return obj;
		}

		// Token: 0x06000B6D RID: 2925 RVA: 0x00030084 File Offset: 0x0002E284
		private void Construct()
		{
			this.construct_internal_locale_from_lcid(this.cultureID);
			this.constructed = true;
		}

		// Token: 0x06000B6E RID: 2926 RVA: 0x0003009C File Offset: 0x0002E29C
		private bool ConstructInternalLocaleFromName(string locale)
		{
			string text = locale;
			if (text != null)
			{
				if (CultureInfo.<>f__switch$map19 == null)
				{
					CultureInfo.<>f__switch$map19 = new Dictionary<string, int>(2)
					{
						{ "zh-hans", 0 },
						{ "zh-hant", 1 }
					};
				}
				int num;
				if (CultureInfo.<>f__switch$map19.TryGetValue(text, out num))
				{
					if (num != 0)
					{
						if (num == 1)
						{
							locale = "zh-cht";
						}
					}
					else
					{
						locale = "zh-chs";
					}
				}
			}
			return this.construct_internal_locale_from_name(locale);
		}

		// Token: 0x06000B6F RID: 2927 RVA: 0x0003012C File Offset: 0x0002E32C
		private bool ConstructInternalLocaleFromLcid(int lcid)
		{
			return this.construct_internal_locale_from_lcid(lcid);
		}

		// Token: 0x06000B70 RID: 2928 RVA: 0x00030140 File Offset: 0x0002E340
		private static bool ConstructInternalLocaleFromSpecificName(CultureInfo ci, string name)
		{
			return CultureInfo.construct_internal_locale_from_specific_name(ci, name);
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x00030154 File Offset: 0x0002E354
		private static bool ConstructInternalLocaleFromCurrentLocale(CultureInfo ci)
		{
			return CultureInfo.construct_internal_locale_from_current_locale(ci);
		}

		// Token: 0x06000B72 RID: 2930
		[MethodImpl(4096)]
		private extern bool construct_internal_locale_from_lcid(int lcid);

		// Token: 0x06000B73 RID: 2931
		[MethodImpl(4096)]
		private extern bool construct_internal_locale_from_name(string name);

		// Token: 0x06000B74 RID: 2932
		[MethodImpl(4096)]
		private static extern bool construct_internal_locale_from_specific_name(CultureInfo ci, string name);

		// Token: 0x06000B75 RID: 2933
		[MethodImpl(4096)]
		private static extern bool construct_internal_locale_from_current_locale(CultureInfo ci);

		// Token: 0x06000B76 RID: 2934
		[MethodImpl(4096)]
		private static extern CultureInfo[] internal_get_cultures(bool neutral, bool specific, bool installed);

		// Token: 0x06000B77 RID: 2935
		[MethodImpl(4096)]
		private extern void construct_datetime_format();

		// Token: 0x06000B78 RID: 2936
		[MethodImpl(4096)]
		private extern void construct_number_format();

		// Token: 0x06000B79 RID: 2937
		[MethodImpl(4096)]
		private static extern bool internal_is_lcid_neutral(int lcid, out bool is_neutral);

		// Token: 0x06000B7A RID: 2938 RVA: 0x00030164 File Offset: 0x0002E364
		private void ConstructInvariant(bool read_only)
		{
			this.cultureID = 127;
			this.numInfo = NumberFormatInfo.InvariantInfo;
			this.dateTimeInfo = DateTimeFormatInfo.InvariantInfo;
			if (!read_only)
			{
				this.numInfo = (NumberFormatInfo)this.numInfo.Clone();
				this.dateTimeInfo = (DateTimeFormatInfo)this.dateTimeInfo.Clone();
			}
			this.textInfo = this.CreateTextInfo(read_only);
			this.m_name = string.Empty;
			this.displayname = (this.englishname = (this.nativename = "Invariant Language (Invariant Country)"));
			this.iso3lang = "IVL";
			this.iso2lang = "iv";
			this.icu_name = "en_US_POSIX";
			this.win3lang = "IVL";
		}

		// Token: 0x06000B7B RID: 2939 RVA: 0x00030230 File Offset: 0x0002E430
		private TextInfo CreateTextInfo(bool readOnly)
		{
			return new TextInfo(this, this.cultureID, this.textinfo_data, readOnly);
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x00030248 File Offset: 0x0002E448
		private static void insert_into_shared_tables(CultureInfo c)
		{
			if (CultureInfo.shared_by_number == null)
			{
				CultureInfo.shared_by_number = new Hashtable();
				CultureInfo.shared_by_name = new Hashtable();
			}
			CultureInfo.shared_by_number[c.cultureID] = c;
			CultureInfo.shared_by_name[c.m_name] = c;
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x0003029C File Offset: 0x0002E49C
		public static CultureInfo GetCultureInfo(int culture)
		{
			object obj = CultureInfo.shared_table_lock;
			CultureInfo cultureInfo2;
			lock (obj)
			{
				CultureInfo cultureInfo;
				if (CultureInfo.shared_by_number != null)
				{
					cultureInfo = CultureInfo.shared_by_number[culture] as CultureInfo;
					if (cultureInfo != null)
					{
						return cultureInfo;
					}
				}
				cultureInfo = new CultureInfo(culture, false, true);
				CultureInfo.insert_into_shared_tables(cultureInfo);
				cultureInfo2 = cultureInfo;
			}
			return cultureInfo2;
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x00030318 File Offset: 0x0002E518
		public static CultureInfo GetCultureInfo(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			object obj = CultureInfo.shared_table_lock;
			CultureInfo cultureInfo2;
			lock (obj)
			{
				CultureInfo cultureInfo;
				if (CultureInfo.shared_by_name != null)
				{
					cultureInfo = CultureInfo.shared_by_name[name] as CultureInfo;
					if (cultureInfo != null)
					{
						return cultureInfo;
					}
				}
				cultureInfo = new CultureInfo(name, false, true);
				CultureInfo.insert_into_shared_tables(cultureInfo);
				cultureInfo2 = cultureInfo;
			}
			return cultureInfo2;
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x000303A0 File Offset: 0x0002E5A0
		[MonoTODO("Currently it ignores the altName parameter")]
		public static CultureInfo GetCultureInfo(string name, string altName)
		{
			if (name == null)
			{
				throw new ArgumentNullException("null");
			}
			if (altName == null)
			{
				throw new ArgumentNullException("null");
			}
			return CultureInfo.GetCultureInfo(name);
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x000303CC File Offset: 0x0002E5CC
		public static CultureInfo GetCultureInfoByIetfLanguageTag(string name)
		{
			if (name != null)
			{
				if (CultureInfo.<>f__switch$map1A == null)
				{
					CultureInfo.<>f__switch$map1A = new Dictionary<string, int>(2)
					{
						{ "zh-Hans", 0 },
						{ "zh-Hant", 1 }
					};
				}
				int num;
				if (CultureInfo.<>f__switch$map1A.TryGetValue(name, out num))
				{
					if (num == 0)
					{
						return CultureInfo.GetCultureInfo("zh-CHS");
					}
					if (num == 1)
					{
						return CultureInfo.GetCultureInfo("zh-CHT");
					}
				}
			}
			return CultureInfo.GetCultureInfo(name);
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x00030450 File Offset: 0x0002E650
		internal static CultureInfo CreateCulture(string name, bool reference)
		{
			bool flag = name.Length == 0;
			bool flag2;
			bool flag3;
			if (reference)
			{
				flag2 = !flag;
				flag3 = false;
			}
			else
			{
				flag3 = false;
				flag2 = !flag;
			}
			return new CultureInfo(name, flag2, flag3);
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x0003049C File Offset: 0x0002E69C
		internal unsafe void ConstructCalendars()
		{
			if (this.calendar_data == null)
			{
				this.optional_calendars = new Calendar[]
				{
					new GregorianCalendar(GregorianCalendarTypes.Localized)
				};
				return;
			}
			this.optional_calendars = new Calendar[5];
			for (int i = 0; i < 5; i++)
			{
				int num = this.calendar_data[i];
				Calendar calendar;
				switch (num >> 24)
				{
				case 0:
				{
					GregorianCalendarTypes gregorianCalendarTypes = (GregorianCalendarTypes)(num & 16777215);
					calendar = new GregorianCalendar(gregorianCalendarTypes);
					break;
				}
				case 1:
					calendar = new HijriCalendar();
					break;
				case 2:
					calendar = new ThaiBuddhistCalendar();
					break;
				default:
					throw new Exception("invalid calendar type:  " + num);
				}
				this.optional_calendars[i] = calendar;
			}
		}

		// Token: 0x0400040A RID: 1034
		private const int NumOptionalCalendars = 5;

		// Token: 0x0400040B RID: 1035
		private const int GregorianTypeMask = 16777215;

		// Token: 0x0400040C RID: 1036
		private const int CalendarTypeBits = 24;

		// Token: 0x0400040D RID: 1037
		private const int InvariantCultureId = 127;

		// Token: 0x0400040E RID: 1038
		private static volatile CultureInfo invariant_culture_info = new CultureInfo(127, false, true);

		// Token: 0x0400040F RID: 1039
		private static object shared_table_lock = new object();

		// Token: 0x04000410 RID: 1040
		internal static int BootstrapCultureID;

		// Token: 0x04000411 RID: 1041
		private bool m_isReadOnly;

		// Token: 0x04000412 RID: 1042
		private int cultureID;

		// Token: 0x04000413 RID: 1043
		[NonSerialized]
		private int parent_lcid;

		// Token: 0x04000414 RID: 1044
		[NonSerialized]
		private int specific_lcid;

		// Token: 0x04000415 RID: 1045
		[NonSerialized]
		private int datetime_index;

		// Token: 0x04000416 RID: 1046
		[NonSerialized]
		private int number_index;

		// Token: 0x04000417 RID: 1047
		private bool m_useUserOverride;

		// Token: 0x04000418 RID: 1048
		[NonSerialized]
		private volatile NumberFormatInfo numInfo;

		// Token: 0x04000419 RID: 1049
		private volatile DateTimeFormatInfo dateTimeInfo;

		// Token: 0x0400041A RID: 1050
		private volatile TextInfo textInfo;

		// Token: 0x0400041B RID: 1051
		private string m_name;

		// Token: 0x0400041C RID: 1052
		[NonSerialized]
		private string displayname;

		// Token: 0x0400041D RID: 1053
		[NonSerialized]
		private string englishname;

		// Token: 0x0400041E RID: 1054
		[NonSerialized]
		private string nativename;

		// Token: 0x0400041F RID: 1055
		[NonSerialized]
		private string iso3lang;

		// Token: 0x04000420 RID: 1056
		[NonSerialized]
		private string iso2lang;

		// Token: 0x04000421 RID: 1057
		[NonSerialized]
		private string icu_name;

		// Token: 0x04000422 RID: 1058
		[NonSerialized]
		private string win3lang;

		// Token: 0x04000423 RID: 1059
		[NonSerialized]
		private string territory;

		// Token: 0x04000424 RID: 1060
		private volatile CompareInfo compareInfo;

		// Token: 0x04000425 RID: 1061
		[NonSerialized]
		private unsafe readonly int* calendar_data;

		// Token: 0x04000426 RID: 1062
		[NonSerialized]
		private unsafe readonly void* textinfo_data;

		// Token: 0x04000427 RID: 1063
		[NonSerialized]
		private Calendar[] optional_calendars;

		// Token: 0x04000428 RID: 1064
		[NonSerialized]
		private CultureInfo parent_culture;

		// Token: 0x04000429 RID: 1065
		private int m_dataItem;

		// Token: 0x0400042A RID: 1066
		private Calendar calendar;

		// Token: 0x0400042B RID: 1067
		[NonSerialized]
		private bool constructed;

		// Token: 0x0400042C RID: 1068
		[NonSerialized]
		internal byte[] cached_serialized_form;

		// Token: 0x0400042D RID: 1069
		private static readonly string MSG_READONLY = "This instance is read only";

		// Token: 0x0400042E RID: 1070
		private static Hashtable shared_by_number;

		// Token: 0x0400042F RID: 1071
		private static Hashtable shared_by_name;
	}
}
