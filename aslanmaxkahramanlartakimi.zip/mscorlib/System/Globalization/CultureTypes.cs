﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x02000121 RID: 289
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum CultureTypes
	{
		// Token: 0x04000433 RID: 1075
		NeutralCultures = 1,
		// Token: 0x04000434 RID: 1076
		SpecificCultures = 2,
		// Token: 0x04000435 RID: 1077
		InstalledWin32Cultures = 4,
		// Token: 0x04000436 RID: 1078
		AllCultures = 7,
		// Token: 0x04000437 RID: 1079
		UserCustomCulture = 8,
		// Token: 0x04000438 RID: 1080
		ReplacementCultures = 16,
		// Token: 0x04000439 RID: 1081
		WindowsOnlyCultures = 32,
		// Token: 0x0400043A RID: 1082
		FrameworkCultures = 64
	}
}
