﻿using System;

namespace System.Globalization
{
	// Token: 0x02000122 RID: 290
	[Flags]
	internal enum DateTimeFormatFlags
	{
		// Token: 0x0400043C RID: 1084
		Unused = 0,
		// Token: 0x0400043D RID: 1085
		But = 1,
		// Token: 0x0400043E RID: 1086
		Serialized = 2,
		// Token: 0x0400043F RID: 1087
		By = 3,
		// Token: 0x04000440 RID: 1088
		Microsoft = 4
	}
}
