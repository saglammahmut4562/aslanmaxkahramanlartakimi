﻿using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Threading;

namespace System.Globalization
{
	// Token: 0x02000123 RID: 291
	[ComVisible(true)]
	[Serializable]
	public sealed class DateTimeFormatInfo : ICloneable, IFormatProvider
	{
		// Token: 0x06000B83 RID: 2947 RVA: 0x00030564 File Offset: 0x0002E764
		internal DateTimeFormatInfo(bool read_only)
		{
			this.m_isReadOnly = read_only;
			this.amDesignator = "AM";
			this.pmDesignator = "PM";
			this.dateSeparator = "/";
			this.timeSeparator = ":";
			this.shortDatePattern = "MM/dd/yyyy";
			this.longDatePattern = "dddd, dd MMMM yyyy";
			this.shortTimePattern = "HH:mm";
			this.longTimePattern = "HH:mm:ss";
			this.monthDayPattern = "MMMM dd";
			this.yearMonthPattern = "yyyy MMMM";
			this.fullDateTimePattern = "dddd, dd MMMM yyyy HH:mm:ss";
			this._RFC1123Pattern = "ddd, dd MMM yyyy HH':'mm':'ss 'GMT'";
			this._SortableDateTimePattern = "yyyy'-'MM'-'dd'T'HH':'mm':'ss";
			this._UniversalSortableDateTimePattern = "yyyy'-'MM'-'dd HH':'mm':'ss'Z'";
			this.firstDayOfWeek = 0;
			this.calendar = new GregorianCalendar();
			this.calendarWeekRule = 0;
			this.abbreviatedDayNames = DateTimeFormatInfo.INVARIANT_ABBREVIATED_DAY_NAMES;
			this.dayNames = DateTimeFormatInfo.INVARIANT_DAY_NAMES;
			this.abbreviatedMonthNames = DateTimeFormatInfo.INVARIANT_ABBREVIATED_MONTH_NAMES;
			this.monthNames = DateTimeFormatInfo.INVARIANT_MONTH_NAMES;
			this.m_genitiveAbbreviatedMonthNames = DateTimeFormatInfo.INVARIANT_ABBREVIATED_MONTH_NAMES;
			this.genitiveMonthNames = DateTimeFormatInfo.INVARIANT_MONTH_NAMES;
			this.shortDayNames = DateTimeFormatInfo.INVARIANT_SHORT_DAY_NAMES;
		}

		// Token: 0x06000B84 RID: 2948 RVA: 0x00030680 File Offset: 0x0002E880
		public DateTimeFormatInfo()
			: this(false)
		{
		}

		// Token: 0x06000B86 RID: 2950 RVA: 0x00030870 File Offset: 0x0002EA70
		public static DateTimeFormatInfo GetInstance(IFormatProvider provider)
		{
			if (provider != null)
			{
				DateTimeFormatInfo dateTimeFormatInfo = (DateTimeFormatInfo)provider.GetFormat(typeof(DateTimeFormatInfo));
				if (dateTimeFormatInfo != null)
				{
					return dateTimeFormatInfo;
				}
			}
			return DateTimeFormatInfo.CurrentInfo;
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x06000B87 RID: 2951 RVA: 0x000308A8 File Offset: 0x0002EAA8
		public bool IsReadOnly
		{
			get
			{
				return this.m_isReadOnly;
			}
		}

		// Token: 0x06000B88 RID: 2952 RVA: 0x000308B0 File Offset: 0x0002EAB0
		public static DateTimeFormatInfo ReadOnly(DateTimeFormatInfo dtfi)
		{
			DateTimeFormatInfo dateTimeFormatInfo = (DateTimeFormatInfo)dtfi.Clone();
			dateTimeFormatInfo.m_isReadOnly = true;
			return dateTimeFormatInfo;
		}

		// Token: 0x06000B89 RID: 2953 RVA: 0x000308D4 File Offset: 0x0002EAD4
		public object Clone()
		{
			DateTimeFormatInfo dateTimeFormatInfo = (DateTimeFormatInfo)base.MemberwiseClone();
			dateTimeFormatInfo.m_isReadOnly = false;
			return dateTimeFormatInfo;
		}

		// Token: 0x06000B8A RID: 2954 RVA: 0x000308F8 File Offset: 0x0002EAF8
		public object GetFormat(Type formatType)
		{
			return (formatType != base.GetType()) ? null : this;
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x00030910 File Offset: 0x0002EB10
		public string GetAbbreviatedMonthName(int month)
		{
			if (month < 1 || month > 13)
			{
				throw new ArgumentOutOfRangeException();
			}
			return this.abbreviatedMonthNames[month - 1];
		}

		// Token: 0x06000B8C RID: 2956 RVA: 0x00030934 File Offset: 0x0002EB34
		public string GetEraName(int era)
		{
			if (era < 0 || era > this.calendar.EraNames.Length)
			{
				throw new ArgumentOutOfRangeException("era", era.ToString());
			}
			return this.calendar.EraNames[era - 1];
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x00030974 File Offset: 0x0002EB74
		public string GetMonthName(int month)
		{
			if (month < 1 || month > 13)
			{
				throw new ArgumentOutOfRangeException();
			}
			return this.monthNames[month - 1];
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000B8E RID: 2958 RVA: 0x00030998 File Offset: 0x0002EB98
		public string[] AbbreviatedDayNames
		{
			get
			{
				return (string[])this.RawAbbreviatedDayNames.Clone();
			}
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x06000B8F RID: 2959 RVA: 0x000309AC File Offset: 0x0002EBAC
		internal string[] RawAbbreviatedDayNames
		{
			get
			{
				return this.abbreviatedDayNames;
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x06000B90 RID: 2960 RVA: 0x000309B4 File Offset: 0x0002EBB4
		public string[] AbbreviatedMonthNames
		{
			get
			{
				return (string[])this.RawAbbreviatedMonthNames.Clone();
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x06000B91 RID: 2961 RVA: 0x000309C8 File Offset: 0x0002EBC8
		internal string[] RawAbbreviatedMonthNames
		{
			get
			{
				return this.abbreviatedMonthNames;
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x06000B92 RID: 2962 RVA: 0x000309D0 File Offset: 0x0002EBD0
		public string[] DayNames
		{
			get
			{
				return (string[])this.RawDayNames.Clone();
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x06000B93 RID: 2963 RVA: 0x000309E4 File Offset: 0x0002EBE4
		internal string[] RawDayNames
		{
			get
			{
				return this.dayNames;
			}
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x06000B94 RID: 2964 RVA: 0x000309EC File Offset: 0x0002EBEC
		public string[] MonthNames
		{
			get
			{
				return (string[])this.RawMonthNames.Clone();
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x06000B95 RID: 2965 RVA: 0x00030A00 File Offset: 0x0002EC00
		internal string[] RawMonthNames
		{
			get
			{
				return this.monthNames;
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x06000B96 RID: 2966 RVA: 0x00030A08 File Offset: 0x0002EC08
		public string AMDesignator
		{
			get
			{
				return this.amDesignator;
			}
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x06000B97 RID: 2967 RVA: 0x00030A10 File Offset: 0x0002EC10
		public string PMDesignator
		{
			get
			{
				return this.pmDesignator;
			}
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x06000B98 RID: 2968 RVA: 0x00030A18 File Offset: 0x0002EC18
		public string DateSeparator
		{
			get
			{
				return this.dateSeparator;
			}
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x06000B99 RID: 2969 RVA: 0x00030A20 File Offset: 0x0002EC20
		public string TimeSeparator
		{
			get
			{
				return this.timeSeparator;
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x06000B9A RID: 2970 RVA: 0x00030A28 File Offset: 0x0002EC28
		public string LongDatePattern
		{
			get
			{
				return this.longDatePattern;
			}
		}

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x06000B9B RID: 2971 RVA: 0x00030A30 File Offset: 0x0002EC30
		public string ShortDatePattern
		{
			get
			{
				return this.shortDatePattern;
			}
		}

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x06000B9C RID: 2972 RVA: 0x00030A38 File Offset: 0x0002EC38
		public string ShortTimePattern
		{
			get
			{
				return this.shortTimePattern;
			}
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x06000B9D RID: 2973 RVA: 0x00030A40 File Offset: 0x0002EC40
		public string LongTimePattern
		{
			get
			{
				return this.longTimePattern;
			}
		}

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x06000B9E RID: 2974 RVA: 0x00030A48 File Offset: 0x0002EC48
		public string MonthDayPattern
		{
			get
			{
				return this.monthDayPattern;
			}
		}

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x06000B9F RID: 2975 RVA: 0x00030A50 File Offset: 0x0002EC50
		public string YearMonthPattern
		{
			get
			{
				return this.yearMonthPattern;
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x06000BA0 RID: 2976 RVA: 0x00030A58 File Offset: 0x0002EC58
		public string FullDateTimePattern
		{
			get
			{
				if (this.fullDateTimePattern != null)
				{
					return this.fullDateTimePattern;
				}
				return this.longDatePattern + " " + this.longTimePattern;
			}
		}

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x06000BA1 RID: 2977 RVA: 0x00030A84 File Offset: 0x0002EC84
		public static DateTimeFormatInfo CurrentInfo
		{
			get
			{
				return Thread.CurrentThread.CurrentCulture.DateTimeFormat;
			}
		}

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x06000BA2 RID: 2978 RVA: 0x00030A98 File Offset: 0x0002EC98
		public static DateTimeFormatInfo InvariantInfo
		{
			get
			{
				if (DateTimeFormatInfo.theInvariantDateTimeFormatInfo == null)
				{
					DateTimeFormatInfo.theInvariantDateTimeFormatInfo = DateTimeFormatInfo.ReadOnly(new DateTimeFormatInfo());
					DateTimeFormatInfo.theInvariantDateTimeFormatInfo.FillInvariantPatterns();
				}
				return DateTimeFormatInfo.theInvariantDateTimeFormatInfo;
			}
		}

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x06000BA3 RID: 2979 RVA: 0x00030AC4 File Offset: 0x0002ECC4
		// (set) Token: 0x06000BA4 RID: 2980 RVA: 0x00030ACC File Offset: 0x0002ECCC
		public Calendar Calendar
		{
			get
			{
				return this.calendar;
			}
			set
			{
				if (this.IsReadOnly)
				{
					throw new InvalidOperationException(DateTimeFormatInfo.MSG_READONLY);
				}
				if (value == null)
				{
					throw new ArgumentNullException();
				}
				this.calendar = value;
			}
		}

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x06000BA5 RID: 2981 RVA: 0x00030AF8 File Offset: 0x0002ECF8
		public string RFC1123Pattern
		{
			get
			{
				return this._RFC1123Pattern;
			}
		}

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x06000BA6 RID: 2982 RVA: 0x00030B00 File Offset: 0x0002ED00
		internal string RoundtripPattern
		{
			get
			{
				return "yyyy'-'MM'-'dd'T'HH':'mm':'ss.fffffffK";
			}
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x00030B08 File Offset: 0x0002ED08
		public string SortableDateTimePattern
		{
			get
			{
				return this._SortableDateTimePattern;
			}
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000BA8 RID: 2984 RVA: 0x00030B10 File Offset: 0x0002ED10
		public string UniversalSortableDateTimePattern
		{
			get
			{
				return this._UniversalSortableDateTimePattern;
			}
		}

		// Token: 0x06000BA9 RID: 2985 RVA: 0x00030B18 File Offset: 0x0002ED18
		internal string[] GetAllDateTimePatternsInternal()
		{
			this.FillAllDateTimePatterns();
			return this.all_date_time_patterns;
		}

		// Token: 0x06000BAA RID: 2986 RVA: 0x00030B28 File Offset: 0x0002ED28
		private void FillAllDateTimePatterns()
		{
			if (this.all_date_time_patterns != null)
			{
				return;
			}
			ArrayList arrayList = new ArrayList();
			arrayList.AddRange(this.GetAllRawDateTimePatterns('d'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('D'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('g'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('G'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('f'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('F'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('m'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('M'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('r'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('R'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('s'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('t'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('T'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('u'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('U'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('y'));
			arrayList.AddRange(this.GetAllRawDateTimePatterns('Y'));
			this.all_date_time_patterns = (string[])arrayList.ToArray(typeof(string));
		}

		// Token: 0x06000BAB RID: 2987 RVA: 0x00030C54 File Offset: 0x0002EE54
		internal string[] GetAllRawDateTimePatterns(char format)
		{
			string[] array;
			switch (format)
			{
			case 'R':
				goto IL_02CB;
			default:
				switch (format)
				{
				case 'r':
					goto IL_02CB;
				case 's':
					return new string[] { this.SortableDateTimePattern };
				case 't':
					if (this.allShortTimePatterns != null && this.allShortTimePatterns.Length > 0)
					{
						return this.allShortTimePatterns;
					}
					return new string[] { this.ShortTimePattern };
				case 'u':
					return new string[] { this.UniversalSortableDateTimePattern };
				default:
					switch (format)
					{
					case 'D':
						if (this.allLongDatePatterns != null && this.allLongDatePatterns.Length > 0)
						{
							return this.allLongDatePatterns;
						}
						return new string[] { this.LongDatePattern };
					default:
						switch (format)
						{
						case 'd':
							if (this.allShortDatePatterns != null && this.allShortDatePatterns.Length > 0)
							{
								return this.allShortDatePatterns;
							}
							return new string[] { this.ShortDatePattern };
						default:
							if (format != 'M' && format != 'm')
							{
								throw new ArgumentException("Format specifier was invalid.");
							}
							if (this.monthDayPatterns != null && this.monthDayPatterns.Length > 0)
							{
								return this.monthDayPatterns;
							}
							return new string[] { this.MonthDayPattern };
						case 'f':
							array = this.PopulateCombinedList(this.allLongDatePatterns, this.allShortTimePatterns);
							if (array != null && array.Length > 0)
							{
								return array;
							}
							return new string[] { this.LongDatePattern + " " + this.ShortTimePattern };
						case 'g':
							array = this.PopulateCombinedList(this.allShortDatePatterns, this.allShortTimePatterns);
							if (array != null && array.Length > 0)
							{
								return array;
							}
							return new string[] { this.ShortDatePattern + " " + this.ShortTimePattern };
						}
						break;
					case 'F':
						break;
					case 'G':
						array = this.PopulateCombinedList(this.allShortDatePatterns, this.allLongTimePatterns);
						if (array != null && array.Length > 0)
						{
							return array;
						}
						return new string[] { this.ShortDatePattern + " " + this.LongTimePattern };
					}
					break;
				case 'y':
					goto IL_029B;
				}
				break;
			case 'T':
				if (this.allLongTimePatterns != null && this.allLongTimePatterns.Length > 0)
				{
					return this.allLongTimePatterns;
				}
				return new string[] { this.LongTimePattern };
			case 'U':
				break;
			case 'Y':
				goto IL_029B;
			}
			array = this.PopulateCombinedList(this.allLongDatePatterns, this.allLongTimePatterns);
			if (array != null && array.Length > 0)
			{
				return array;
			}
			return new string[] { this.LongDatePattern + " " + this.LongTimePattern };
			IL_029B:
			if (this.yearMonthPatterns != null && this.yearMonthPatterns.Length > 0)
			{
				return this.yearMonthPatterns;
			}
			return new string[] { this.YearMonthPattern };
			IL_02CB:
			return new string[] { this.RFC1123Pattern };
		}

		// Token: 0x06000BAC RID: 2988 RVA: 0x00030F68 File Offset: 0x0002F168
		public string GetDayName(DayOfWeek dayofweek)
		{
			if (dayofweek < DayOfWeek.Sunday || dayofweek > DayOfWeek.Saturday)
			{
				throw new ArgumentOutOfRangeException();
			}
			return this.dayNames[(int)dayofweek];
		}

		// Token: 0x06000BAD RID: 2989 RVA: 0x00030F94 File Offset: 0x0002F194
		public string GetAbbreviatedDayName(DayOfWeek dayofweek)
		{
			if (dayofweek < DayOfWeek.Sunday || dayofweek > DayOfWeek.Saturday)
			{
				throw new ArgumentOutOfRangeException();
			}
			return this.abbreviatedDayNames[(int)dayofweek];
		}

		// Token: 0x06000BAE RID: 2990 RVA: 0x00030FC0 File Offset: 0x0002F1C0
		private void FillInvariantPatterns()
		{
			this.allShortDatePatterns = new string[] { "MM/dd/yyyy" };
			this.allLongDatePatterns = new string[] { "dddd, dd MMMM yyyy" };
			this.allLongTimePatterns = new string[] { "HH:mm:ss" };
			this.allShortTimePatterns = new string[] { "HH:mm", "hh:mm tt", "H:mm", "h:mm tt" };
			this.monthDayPatterns = new string[] { "MMMM dd" };
			this.yearMonthPatterns = new string[] { "yyyy MMMM" };
		}

		// Token: 0x06000BAF RID: 2991 RVA: 0x00031060 File Offset: 0x0002F260
		private string[] PopulateCombinedList(string[] dates, string[] times)
		{
			if (dates != null && times != null)
			{
				string[] array = new string[dates.Length * times.Length];
				int num = 0;
				foreach (string text in dates)
				{
					foreach (string text2 in times)
					{
						array[num++] = text + " " + text2;
					}
				}
				return array;
			}
			return null;
		}

		// Token: 0x04000441 RID: 1089
		private const string _RoundtripPattern = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.fffffffK";

		// Token: 0x04000442 RID: 1090
		private static readonly string MSG_READONLY = "This instance is read only";

		// Token: 0x04000443 RID: 1091
		private static readonly string MSG_ARRAYSIZE_MONTH = "An array with exactly 13 elements is needed";

		// Token: 0x04000444 RID: 1092
		private static readonly string MSG_ARRAYSIZE_DAY = "An array with exactly 7 elements is needed";

		// Token: 0x04000445 RID: 1093
		private static readonly string[] INVARIANT_ABBREVIATED_DAY_NAMES = new string[] { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

		// Token: 0x04000446 RID: 1094
		private static readonly string[] INVARIANT_DAY_NAMES = new string[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

		// Token: 0x04000447 RID: 1095
		private static readonly string[] INVARIANT_ABBREVIATED_MONTH_NAMES = new string[]
		{
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec",
			string.Empty
		};

		// Token: 0x04000448 RID: 1096
		private static readonly string[] INVARIANT_MONTH_NAMES = new string[]
		{
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December",
			string.Empty
		};

		// Token: 0x04000449 RID: 1097
		private static readonly string[] INVARIANT_SHORT_DAY_NAMES = new string[] { "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa" };

		// Token: 0x0400044A RID: 1098
		private static DateTimeFormatInfo theInvariantDateTimeFormatInfo;

		// Token: 0x0400044B RID: 1099
		private bool m_isReadOnly;

		// Token: 0x0400044C RID: 1100
		private string amDesignator;

		// Token: 0x0400044D RID: 1101
		private string pmDesignator;

		// Token: 0x0400044E RID: 1102
		private string dateSeparator;

		// Token: 0x0400044F RID: 1103
		private string timeSeparator;

		// Token: 0x04000450 RID: 1104
		private string shortDatePattern;

		// Token: 0x04000451 RID: 1105
		private string longDatePattern;

		// Token: 0x04000452 RID: 1106
		private string shortTimePattern;

		// Token: 0x04000453 RID: 1107
		private string longTimePattern;

		// Token: 0x04000454 RID: 1108
		private string monthDayPattern;

		// Token: 0x04000455 RID: 1109
		private string yearMonthPattern;

		// Token: 0x04000456 RID: 1110
		private string fullDateTimePattern;

		// Token: 0x04000457 RID: 1111
		private string _RFC1123Pattern;

		// Token: 0x04000458 RID: 1112
		private string _SortableDateTimePattern;

		// Token: 0x04000459 RID: 1113
		private string _UniversalSortableDateTimePattern;

		// Token: 0x0400045A RID: 1114
		private int firstDayOfWeek;

		// Token: 0x0400045B RID: 1115
		private Calendar calendar;

		// Token: 0x0400045C RID: 1116
		private int calendarWeekRule;

		// Token: 0x0400045D RID: 1117
		private string[] abbreviatedDayNames;

		// Token: 0x0400045E RID: 1118
		private string[] dayNames;

		// Token: 0x0400045F RID: 1119
		private string[] monthNames;

		// Token: 0x04000460 RID: 1120
		private string[] abbreviatedMonthNames;

		// Token: 0x04000461 RID: 1121
		private string[] allShortDatePatterns;

		// Token: 0x04000462 RID: 1122
		private string[] allLongDatePatterns;

		// Token: 0x04000463 RID: 1123
		private string[] allShortTimePatterns;

		// Token: 0x04000464 RID: 1124
		private string[] allLongTimePatterns;

		// Token: 0x04000465 RID: 1125
		private string[] monthDayPatterns;

		// Token: 0x04000466 RID: 1126
		private string[] yearMonthPatterns;

		// Token: 0x04000467 RID: 1127
		private string[] shortDayNames;

		// Token: 0x04000468 RID: 1128
		private int nDataItem;

		// Token: 0x04000469 RID: 1129
		private bool m_useUserOverride;

		// Token: 0x0400046A RID: 1130
		private bool m_isDefaultCalendar;

		// Token: 0x0400046B RID: 1131
		private int CultureID;

		// Token: 0x0400046C RID: 1132
		private bool bUseCalendarInfo;

		// Token: 0x0400046D RID: 1133
		private string generalShortTimePattern;

		// Token: 0x0400046E RID: 1134
		private string generalLongTimePattern;

		// Token: 0x0400046F RID: 1135
		private string[] m_eraNames;

		// Token: 0x04000470 RID: 1136
		private string[] m_abbrevEraNames;

		// Token: 0x04000471 RID: 1137
		private string[] m_abbrevEnglishEraNames;

		// Token: 0x04000472 RID: 1138
		private string[] m_dateWords;

		// Token: 0x04000473 RID: 1139
		private int[] optionalCalendars;

		// Token: 0x04000474 RID: 1140
		private string[] m_superShortDayNames;

		// Token: 0x04000475 RID: 1141
		private string[] genitiveMonthNames;

		// Token: 0x04000476 RID: 1142
		private string[] m_genitiveAbbreviatedMonthNames;

		// Token: 0x04000477 RID: 1143
		private string[] leapYearMonthNames;

		// Token: 0x04000478 RID: 1144
		private DateTimeFormatFlags formatFlags;

		// Token: 0x04000479 RID: 1145
		private string m_name;

		// Token: 0x0400047A RID: 1146
		private volatile string[] all_date_time_patterns;
	}
}
