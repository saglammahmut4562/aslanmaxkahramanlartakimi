﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x02000124 RID: 292
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum DateTimeStyles
	{
		// Token: 0x0400047C RID: 1148
		None = 0,
		// Token: 0x0400047D RID: 1149
		AllowLeadingWhite = 1,
		// Token: 0x0400047E RID: 1150
		AllowTrailingWhite = 2,
		// Token: 0x0400047F RID: 1151
		AllowInnerWhite = 4,
		// Token: 0x04000480 RID: 1152
		AllowWhiteSpaces = 7,
		// Token: 0x04000481 RID: 1153
		NoCurrentDateDefault = 8,
		// Token: 0x04000482 RID: 1154
		AdjustToUniversal = 16,
		// Token: 0x04000483 RID: 1155
		AssumeLocal = 32,
		// Token: 0x04000484 RID: 1156
		AssumeUniversal = 64,
		// Token: 0x04000485 RID: 1157
		RoundtripKind = 128
	}
}
