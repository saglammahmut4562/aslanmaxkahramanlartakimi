﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x02000125 RID: 293
	[ComVisible(true)]
	[Serializable]
	public class DaylightTime
	{
		// Token: 0x06000BB0 RID: 2992 RVA: 0x000310E4 File Offset: 0x0002F2E4
		public DaylightTime(DateTime start, DateTime end, TimeSpan delta)
		{
			this.m_start = start;
			this.m_end = end;
			this.m_delta = delta;
		}

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000BB1 RID: 2993 RVA: 0x00031104 File Offset: 0x0002F304
		public DateTime Start
		{
			get
			{
				return this.m_start;
			}
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000BB2 RID: 2994 RVA: 0x0003110C File Offset: 0x0002F30C
		public DateTime End
		{
			get
			{
				return this.m_end;
			}
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000BB3 RID: 2995 RVA: 0x00031114 File Offset: 0x0002F314
		public TimeSpan Delta
		{
			get
			{
				return this.m_delta;
			}
		}

		// Token: 0x04000486 RID: 1158
		private DateTime m_start;

		// Token: 0x04000487 RID: 1159
		private DateTime m_end;

		// Token: 0x04000488 RID: 1160
		private TimeSpan m_delta;
	}
}
