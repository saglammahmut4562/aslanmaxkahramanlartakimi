﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x02000126 RID: 294
	[MonoTODO("Serialization format not compatible with .NET")]
	[ComVisible(true)]
	[Serializable]
	public class GregorianCalendar : Calendar
	{
		// Token: 0x06000BB4 RID: 2996 RVA: 0x0003111C File Offset: 0x0002F31C
		public GregorianCalendar(GregorianCalendarTypes type)
		{
			this.CalendarType = type;
			this.M_AbbrEraNames = new string[] { "AD" };
			this.M_EraNames = new string[] { "A.D." };
			if (this.twoDigitYearMax == 99)
			{
				this.twoDigitYearMax = 2029;
			}
		}

		// Token: 0x06000BB5 RID: 2997 RVA: 0x00031178 File Offset: 0x0002F378
		public GregorianCalendar()
			: this(GregorianCalendarTypes.Localized)
		{
		}

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x06000BB6 RID: 2998 RVA: 0x00031184 File Offset: 0x0002F384
		public override int[] Eras
		{
			get
			{
				return new int[] { 1 };
			}
		}

		// Token: 0x170001D1 RID: 465
		// (set) Token: 0x06000BB7 RID: 2999 RVA: 0x00031190 File Offset: 0x0002F390
		public virtual GregorianCalendarTypes CalendarType
		{
			set
			{
				base.CheckReadOnly();
				this.m_type = value;
			}
		}

		// Token: 0x06000BB8 RID: 3000 RVA: 0x000311A0 File Offset: 0x0002F3A0
		public override int GetDayOfMonth(DateTime time)
		{
			return CCGregorianCalendar.GetDayOfMonth(time);
		}

		// Token: 0x06000BB9 RID: 3001 RVA: 0x000311A8 File Offset: 0x0002F3A8
		public override DayOfWeek GetDayOfWeek(DateTime time)
		{
			int num = CCFixed.FromDateTime(time);
			return CCFixed.day_of_week(num);
		}

		// Token: 0x06000BBA RID: 3002 RVA: 0x000311C4 File Offset: 0x0002F3C4
		public override int GetEra(DateTime time)
		{
			return 1;
		}

		// Token: 0x06000BBB RID: 3003 RVA: 0x000311C8 File Offset: 0x0002F3C8
		public override int GetMonth(DateTime time)
		{
			return CCGregorianCalendar.GetMonth(time);
		}

		// Token: 0x06000BBC RID: 3004 RVA: 0x000311D0 File Offset: 0x0002F3D0
		public override int GetYear(DateTime time)
		{
			return CCGregorianCalendar.GetYear(time);
		}

		// Token: 0x04000489 RID: 1161
		public const int ADEra = 1;

		// Token: 0x0400048A RID: 1162
		[NonSerialized]
		internal GregorianCalendarTypes m_type;

		// Token: 0x0400048B RID: 1163
		private static DateTime? Min;

		// Token: 0x0400048C RID: 1164
		private static DateTime? Max;
	}
}
