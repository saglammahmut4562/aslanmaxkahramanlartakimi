﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x02000127 RID: 295
	[ComVisible(true)]
	[Serializable]
	public enum GregorianCalendarTypes
	{
		// Token: 0x0400048E RID: 1166
		Localized = 1,
		// Token: 0x0400048F RID: 1167
		USEnglish,
		// Token: 0x04000490 RID: 1168
		MiddleEastFrench = 9,
		// Token: 0x04000491 RID: 1169
		Arabic,
		// Token: 0x04000492 RID: 1170
		TransliteratedEnglish,
		// Token: 0x04000493 RID: 1171
		TransliteratedFrench
	}
}
