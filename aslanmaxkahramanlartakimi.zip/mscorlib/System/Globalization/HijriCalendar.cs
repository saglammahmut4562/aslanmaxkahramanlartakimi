﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x02000128 RID: 296
	[MonoTODO("Serialization format not compatible with .NET")]
	[ComVisible(true)]
	[Serializable]
	public class HijriCalendar : Calendar
	{
		// Token: 0x06000BBD RID: 3005 RVA: 0x000311D8 File Offset: 0x0002F3D8
		public HijriCalendar()
		{
			this.M_AbbrEraNames = new string[] { "A.H." };
			this.M_EraNames = new string[] { "Anno Hegirae" };
			if (this.twoDigitYearMax == 99)
			{
				this.twoDigitYearMax = 1451;
			}
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x06000BBF RID: 3007 RVA: 0x00031290 File Offset: 0x0002F490
		public override int[] Eras
		{
			get
			{
				return new int[] { HijriCalendar.HijriEra };
			}
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x06000BC0 RID: 3008 RVA: 0x000312A0 File Offset: 0x0002F4A0
		internal virtual int AddHijriDate
		{
			get
			{
				return this.M_AddHijriDate;
			}
		}

		// Token: 0x06000BC1 RID: 3009 RVA: 0x000312A8 File Offset: 0x0002F4A8
		internal void M_CheckFixedHijri(string param, int rdHijri)
		{
			if (rdHijri < HijriCalendar.M_MinFixed || rdHijri > HijriCalendar.M_MaxFixed - this.AddHijriDate)
			{
				StringWriter stringWriter = new StringWriter();
				int num;
				int num2;
				int num3;
				CCHijriCalendar.dmy_from_fixed(out num, out num2, out num3, HijriCalendar.M_MaxFixed - this.AddHijriDate);
				if (this.AddHijriDate != 0)
				{
					stringWriter.Write("This HijriCalendar (AddHijriDate {0}) allows dates from 1. 1. 1 to {1}. {2}. {3}.", new object[] { this.AddHijriDate, num, num2, num3 });
				}
				else
				{
					stringWriter.Write("HijriCalendar allows dates from 1.1.1 to {0}.{1}.{2}.", num, num2, num3);
				}
				throw new ArgumentOutOfRangeException(param, stringWriter.ToString());
			}
		}

		// Token: 0x06000BC2 RID: 3010 RVA: 0x00031364 File Offset: 0x0002F564
		internal void M_CheckDateTime(DateTime time)
		{
			int num = CCFixed.FromDateTime(time) - this.AddHijriDate;
			this.M_CheckFixedHijri("time", num);
		}

		// Token: 0x06000BC3 RID: 3011 RVA: 0x0003138C File Offset: 0x0002F58C
		internal int M_FromDateTime(DateTime time)
		{
			return CCFixed.FromDateTime(time) - this.AddHijriDate;
		}

		// Token: 0x06000BC4 RID: 3012 RVA: 0x0003139C File Offset: 0x0002F59C
		public override int GetDayOfMonth(DateTime time)
		{
			int num = this.M_FromDateTime(time);
			this.M_CheckFixedHijri("time", num);
			return CCHijriCalendar.day_from_fixed(num);
		}

		// Token: 0x06000BC5 RID: 3013 RVA: 0x000313C4 File Offset: 0x0002F5C4
		public override DayOfWeek GetDayOfWeek(DateTime time)
		{
			int num = this.M_FromDateTime(time);
			this.M_CheckFixedHijri("time", num);
			return CCFixed.day_of_week(num);
		}

		// Token: 0x06000BC6 RID: 3014 RVA: 0x000313EC File Offset: 0x0002F5EC
		public override int GetEra(DateTime time)
		{
			this.M_CheckDateTime(time);
			return HijriCalendar.HijriEra;
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x000313FC File Offset: 0x0002F5FC
		public override int GetMonth(DateTime time)
		{
			int num = this.M_FromDateTime(time);
			this.M_CheckFixedHijri("time", num);
			return CCHijriCalendar.month_from_fixed(num);
		}

		// Token: 0x06000BC8 RID: 3016 RVA: 0x00031424 File Offset: 0x0002F624
		public override int GetYear(DateTime time)
		{
			int num = this.M_FromDateTime(time);
			this.M_CheckFixedHijri("time", num);
			return CCHijriCalendar.year_from_fixed(num);
		}

		// Token: 0x04000494 RID: 1172
		public static readonly int HijriEra = 1;

		// Token: 0x04000495 RID: 1173
		internal static readonly int M_MinFixed = CCHijriCalendar.fixed_from_dmy(1, 1, 1);

		// Token: 0x04000496 RID: 1174
		internal static readonly int M_MaxFixed = CCGregorianCalendar.fixed_from_dmy(31, 12, 9999);

		// Token: 0x04000497 RID: 1175
		internal int M_AddHijriDate;

		// Token: 0x04000498 RID: 1176
		private static DateTime Min = new DateTime(622, 7, 18, 0, 0, 0);

		// Token: 0x04000499 RID: 1177
		private static DateTime Max = new DateTime(9999, 12, 31, 11, 59, 59);
	}
}
