﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace System.Globalization
{
	// Token: 0x02000129 RID: 297
	[ComVisible(true)]
	[Serializable]
	public sealed class NumberFormatInfo : ICloneable, IFormatProvider
	{
		// Token: 0x06000BC9 RID: 3017 RVA: 0x0003144C File Offset: 0x0002F64C
		internal NumberFormatInfo(int lcid, bool read_only)
		{
			this.isReadOnly = read_only;
			if (lcid != 127)
			{
				lcid = 127;
			}
			int num = lcid;
			if (num == 127)
			{
				this.isReadOnly = false;
				this.currencyDecimalDigits = 2;
				this.currencyDecimalSeparator = ".";
				this.currencyGroupSeparator = ",";
				this.currencyGroupSizes = new int[] { 3 };
				this.currencyNegativePattern = 0;
				this.currencyPositivePattern = 0;
				this.currencySymbol = "$";
				this.nanSymbol = "NaN";
				this.negativeInfinitySymbol = "-Infinity";
				this.negativeSign = "-";
				this.numberDecimalDigits = 2;
				this.numberDecimalSeparator = ".";
				this.numberGroupSeparator = ",";
				this.numberGroupSizes = new int[] { 3 };
				this.numberNegativePattern = 1;
				this.percentDecimalDigits = 2;
				this.percentDecimalSeparator = ".";
				this.percentGroupSeparator = ",";
				this.percentGroupSizes = new int[] { 3 };
				this.percentNegativePattern = 0;
				this.percentPositivePattern = 0;
				this.percentSymbol = "%";
				this.perMilleSymbol = "‰";
				this.positiveInfinitySymbol = "Infinity";
				this.positiveSign = "+";
			}
		}

		// Token: 0x06000BCA RID: 3018 RVA: 0x000315B8 File Offset: 0x0002F7B8
		internal NumberFormatInfo(bool read_only)
			: this(127, read_only)
		{
		}

		// Token: 0x06000BCB RID: 3019 RVA: 0x000315C4 File Offset: 0x0002F7C4
		public NumberFormatInfo()
			: this(false)
		{
		}

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x06000BCD RID: 3021 RVA: 0x0003163C File Offset: 0x0002F83C
		public int CurrencyDecimalDigits
		{
			get
			{
				return this.currencyDecimalDigits;
			}
		}

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06000BCE RID: 3022 RVA: 0x00031644 File Offset: 0x0002F844
		public string CurrencyDecimalSeparator
		{
			get
			{
				return this.currencyDecimalSeparator;
			}
		}

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x06000BCF RID: 3023 RVA: 0x0003164C File Offset: 0x0002F84C
		public string CurrencyGroupSeparator
		{
			get
			{
				return this.currencyGroupSeparator;
			}
		}

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x06000BD0 RID: 3024 RVA: 0x00031654 File Offset: 0x0002F854
		internal int[] RawCurrencyGroupSizes
		{
			get
			{
				return this.currencyGroupSizes;
			}
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x06000BD1 RID: 3025 RVA: 0x0003165C File Offset: 0x0002F85C
		public int CurrencyNegativePattern
		{
			get
			{
				return this.currencyNegativePattern;
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06000BD2 RID: 3026 RVA: 0x00031664 File Offset: 0x0002F864
		public int CurrencyPositivePattern
		{
			get
			{
				return this.currencyPositivePattern;
			}
		}

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x06000BD3 RID: 3027 RVA: 0x0003166C File Offset: 0x0002F86C
		public string CurrencySymbol
		{
			get
			{
				return this.currencySymbol;
			}
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x06000BD4 RID: 3028 RVA: 0x00031674 File Offset: 0x0002F874
		public static NumberFormatInfo CurrentInfo
		{
			get
			{
				NumberFormatInfo numberFormat = Thread.CurrentThread.CurrentCulture.NumberFormat;
				numberFormat.isReadOnly = true;
				return numberFormat;
			}
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06000BD5 RID: 3029 RVA: 0x0003169C File Offset: 0x0002F89C
		public static NumberFormatInfo InvariantInfo
		{
			get
			{
				return new NumberFormatInfo
				{
					NumberNegativePattern = 1,
					isReadOnly = true
				};
			}
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x06000BD6 RID: 3030 RVA: 0x000316C0 File Offset: 0x0002F8C0
		public string NaNSymbol
		{
			get
			{
				return this.nanSymbol;
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x06000BD7 RID: 3031 RVA: 0x000316C8 File Offset: 0x0002F8C8
		public string NegativeInfinitySymbol
		{
			get
			{
				return this.negativeInfinitySymbol;
			}
		}

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x06000BD8 RID: 3032 RVA: 0x000316D0 File Offset: 0x0002F8D0
		public string NegativeSign
		{
			get
			{
				return this.negativeSign;
			}
		}

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x06000BD9 RID: 3033 RVA: 0x000316D8 File Offset: 0x0002F8D8
		public int NumberDecimalDigits
		{
			get
			{
				return this.numberDecimalDigits;
			}
		}

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x06000BDA RID: 3034 RVA: 0x000316E0 File Offset: 0x0002F8E0
		public string NumberDecimalSeparator
		{
			get
			{
				return this.numberDecimalSeparator;
			}
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06000BDB RID: 3035 RVA: 0x000316E8 File Offset: 0x0002F8E8
		public string NumberGroupSeparator
		{
			get
			{
				return this.numberGroupSeparator;
			}
		}

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000BDC RID: 3036 RVA: 0x000316F0 File Offset: 0x0002F8F0
		internal int[] RawNumberGroupSizes
		{
			get
			{
				return this.numberGroupSizes;
			}
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x06000BDD RID: 3037 RVA: 0x000316F8 File Offset: 0x0002F8F8
		// (set) Token: 0x06000BDE RID: 3038 RVA: 0x00031700 File Offset: 0x0002F900
		public int NumberNegativePattern
		{
			get
			{
				return this.numberNegativePattern;
			}
			set
			{
				if (value < 0 || value > 4)
				{
					throw new ArgumentOutOfRangeException("The value specified for the property is less than 0 or greater than 15");
				}
				if (this.isReadOnly)
				{
					throw new InvalidOperationException("The current instance is read-only and a set operation was attempted");
				}
				this.numberNegativePattern = value;
			}
		}

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x06000BDF RID: 3039 RVA: 0x00031738 File Offset: 0x0002F938
		public int PercentDecimalDigits
		{
			get
			{
				return this.percentDecimalDigits;
			}
		}

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000BE0 RID: 3040 RVA: 0x00031740 File Offset: 0x0002F940
		public string PercentDecimalSeparator
		{
			get
			{
				return this.percentDecimalSeparator;
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000BE1 RID: 3041 RVA: 0x00031748 File Offset: 0x0002F948
		public string PercentGroupSeparator
		{
			get
			{
				return this.percentGroupSeparator;
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000BE2 RID: 3042 RVA: 0x00031750 File Offset: 0x0002F950
		internal int[] RawPercentGroupSizes
		{
			get
			{
				return this.percentGroupSizes;
			}
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000BE3 RID: 3043 RVA: 0x00031758 File Offset: 0x0002F958
		public int PercentNegativePattern
		{
			get
			{
				return this.percentNegativePattern;
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000BE4 RID: 3044 RVA: 0x00031760 File Offset: 0x0002F960
		public int PercentPositivePattern
		{
			get
			{
				return this.percentPositivePattern;
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06000BE5 RID: 3045 RVA: 0x00031768 File Offset: 0x0002F968
		public string PercentSymbol
		{
			get
			{
				return this.percentSymbol;
			}
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x06000BE6 RID: 3046 RVA: 0x00031770 File Offset: 0x0002F970
		public string PerMilleSymbol
		{
			get
			{
				return this.perMilleSymbol;
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x06000BE7 RID: 3047 RVA: 0x00031778 File Offset: 0x0002F978
		public string PositiveInfinitySymbol
		{
			get
			{
				return this.positiveInfinitySymbol;
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06000BE8 RID: 3048 RVA: 0x00031780 File Offset: 0x0002F980
		public string PositiveSign
		{
			get
			{
				return this.positiveSign;
			}
		}

		// Token: 0x06000BE9 RID: 3049 RVA: 0x00031788 File Offset: 0x0002F988
		public object GetFormat(Type formatType)
		{
			return (formatType != typeof(NumberFormatInfo)) ? null : this;
		}

		// Token: 0x06000BEA RID: 3050 RVA: 0x000317A4 File Offset: 0x0002F9A4
		public object Clone()
		{
			NumberFormatInfo numberFormatInfo = (NumberFormatInfo)base.MemberwiseClone();
			numberFormatInfo.isReadOnly = false;
			return numberFormatInfo;
		}

		// Token: 0x06000BEB RID: 3051 RVA: 0x000317C8 File Offset: 0x0002F9C8
		public static NumberFormatInfo ReadOnly(NumberFormatInfo nfi)
		{
			NumberFormatInfo numberFormatInfo = (NumberFormatInfo)nfi.Clone();
			numberFormatInfo.isReadOnly = true;
			return numberFormatInfo;
		}

		// Token: 0x06000BEC RID: 3052 RVA: 0x000317EC File Offset: 0x0002F9EC
		public static NumberFormatInfo GetInstance(IFormatProvider formatProvider)
		{
			if (formatProvider != null)
			{
				NumberFormatInfo numberFormatInfo = (NumberFormatInfo)formatProvider.GetFormat(typeof(NumberFormatInfo));
				if (numberFormatInfo != null)
				{
					return numberFormatInfo;
				}
			}
			return NumberFormatInfo.CurrentInfo;
		}

		// Token: 0x0400049A RID: 1178
		private bool isReadOnly;

		// Token: 0x0400049B RID: 1179
		private string decimalFormats;

		// Token: 0x0400049C RID: 1180
		private string currencyFormats;

		// Token: 0x0400049D RID: 1181
		private string percentFormats;

		// Token: 0x0400049E RID: 1182
		private string digitPattern = "#";

		// Token: 0x0400049F RID: 1183
		private string zeroPattern = "0";

		// Token: 0x040004A0 RID: 1184
		private int currencyDecimalDigits;

		// Token: 0x040004A1 RID: 1185
		private string currencyDecimalSeparator;

		// Token: 0x040004A2 RID: 1186
		private string currencyGroupSeparator;

		// Token: 0x040004A3 RID: 1187
		private int[] currencyGroupSizes;

		// Token: 0x040004A4 RID: 1188
		private int currencyNegativePattern;

		// Token: 0x040004A5 RID: 1189
		private int currencyPositivePattern;

		// Token: 0x040004A6 RID: 1190
		private string currencySymbol;

		// Token: 0x040004A7 RID: 1191
		private string nanSymbol;

		// Token: 0x040004A8 RID: 1192
		private string negativeInfinitySymbol;

		// Token: 0x040004A9 RID: 1193
		private string negativeSign;

		// Token: 0x040004AA RID: 1194
		private int numberDecimalDigits;

		// Token: 0x040004AB RID: 1195
		private string numberDecimalSeparator;

		// Token: 0x040004AC RID: 1196
		private string numberGroupSeparator;

		// Token: 0x040004AD RID: 1197
		private int[] numberGroupSizes;

		// Token: 0x040004AE RID: 1198
		private int numberNegativePattern;

		// Token: 0x040004AF RID: 1199
		private int percentDecimalDigits;

		// Token: 0x040004B0 RID: 1200
		private string percentDecimalSeparator;

		// Token: 0x040004B1 RID: 1201
		private string percentGroupSeparator;

		// Token: 0x040004B2 RID: 1202
		private int[] percentGroupSizes;

		// Token: 0x040004B3 RID: 1203
		private int percentNegativePattern;

		// Token: 0x040004B4 RID: 1204
		private int percentPositivePattern;

		// Token: 0x040004B5 RID: 1205
		private string percentSymbol;

		// Token: 0x040004B6 RID: 1206
		private string perMilleSymbol;

		// Token: 0x040004B7 RID: 1207
		private string positiveInfinitySymbol;

		// Token: 0x040004B8 RID: 1208
		private string positiveSign;

		// Token: 0x040004B9 RID: 1209
		private string ansiCurrencySymbol;

		// Token: 0x040004BA RID: 1210
		private int m_dataItem;

		// Token: 0x040004BB RID: 1211
		private bool m_useUserOverride;

		// Token: 0x040004BC RID: 1212
		private bool validForParseAsNumber;

		// Token: 0x040004BD RID: 1213
		private bool validForParseAsCurrency;

		// Token: 0x040004BE RID: 1214
		private string[] nativeDigits = NumberFormatInfo.invariantNativeDigits;

		// Token: 0x040004BF RID: 1215
		private int digitSubstitution = 1;

		// Token: 0x040004C0 RID: 1216
		private static readonly string[] invariantNativeDigits = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
	}
}
