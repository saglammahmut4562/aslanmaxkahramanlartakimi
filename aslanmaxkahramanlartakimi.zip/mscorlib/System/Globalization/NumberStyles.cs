﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x0200012A RID: 298
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum NumberStyles
	{
		// Token: 0x040004C2 RID: 1218
		None = 0,
		// Token: 0x040004C3 RID: 1219
		AllowLeadingWhite = 1,
		// Token: 0x040004C4 RID: 1220
		AllowTrailingWhite = 2,
		// Token: 0x040004C5 RID: 1221
		AllowLeadingSign = 4,
		// Token: 0x040004C6 RID: 1222
		AllowTrailingSign = 8,
		// Token: 0x040004C7 RID: 1223
		AllowParentheses = 16,
		// Token: 0x040004C8 RID: 1224
		AllowDecimalPoint = 32,
		// Token: 0x040004C9 RID: 1225
		AllowThousands = 64,
		// Token: 0x040004CA RID: 1226
		AllowExponent = 128,
		// Token: 0x040004CB RID: 1227
		AllowCurrencySymbol = 256,
		// Token: 0x040004CC RID: 1228
		AllowHexSpecifier = 512,
		// Token: 0x040004CD RID: 1229
		Integer = 7,
		// Token: 0x040004CE RID: 1230
		HexNumber = 515,
		// Token: 0x040004CF RID: 1231
		Number = 111,
		// Token: 0x040004D0 RID: 1232
		Float = 167,
		// Token: 0x040004D1 RID: 1233
		Currency = 383,
		// Token: 0x040004D2 RID: 1234
		Any = 511
	}
}
