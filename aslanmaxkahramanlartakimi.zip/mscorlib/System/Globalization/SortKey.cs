﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x0200012B RID: 299
	[ComVisible(true)]
	[Serializable]
	public class SortKey
	{
		// Token: 0x06000BED RID: 3053 RVA: 0x00031824 File Offset: 0x0002FA24
		internal SortKey(int lcid, string source, CompareOptions opt)
		{
			this.lcid = lcid;
			this.source = source;
			this.options = opt;
		}

		// Token: 0x06000BEE RID: 3054 RVA: 0x00031844 File Offset: 0x0002FA44
		internal SortKey(int lcid, string source, byte[] buffer, CompareOptions opt, int lv1Length, int lv2Length, int lv3Length, int kanaSmallLength, int markTypeLength, int katakanaLength, int kanaWidthLength, int identLength)
		{
			this.lcid = lcid;
			this.source = source;
			this.key = buffer;
			this.options = opt;
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x0003186C File Offset: 0x0002FA6C
		public static int Compare(SortKey sortkey1, SortKey sortkey2)
		{
			if (sortkey1 == null)
			{
				throw new ArgumentNullException("sortkey1");
			}
			if (sortkey2 == null)
			{
				throw new ArgumentNullException("sortkey2");
			}
			if (object.ReferenceEquals(sortkey1, sortkey2) || object.ReferenceEquals(sortkey1.OriginalString, sortkey2.OriginalString))
			{
				return 0;
			}
			byte[] keyData = sortkey1.KeyData;
			byte[] keyData2 = sortkey2.KeyData;
			int num = ((keyData.Length <= keyData2.Length) ? keyData.Length : keyData2.Length);
			for (int i = 0; i < num; i++)
			{
				if (keyData[i] != keyData2[i])
				{
					return (keyData[i] >= keyData2[i]) ? 1 : (-1);
				}
			}
			return (keyData.Length != keyData2.Length) ? ((keyData.Length >= keyData2.Length) ? 1 : (-1)) : 0;
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000BF0 RID: 3056 RVA: 0x00031938 File Offset: 0x0002FB38
		public virtual string OriginalString
		{
			get
			{
				return this.source;
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06000BF1 RID: 3057 RVA: 0x00031940 File Offset: 0x0002FB40
		public virtual byte[] KeyData
		{
			get
			{
				return this.key;
			}
		}

		// Token: 0x06000BF2 RID: 3058 RVA: 0x00031948 File Offset: 0x0002FB48
		public override bool Equals(object value)
		{
			SortKey sortKey = value as SortKey;
			return sortKey != null && this.lcid == sortKey.lcid && this.options == sortKey.options && SortKey.Compare(this, sortKey) == 0;
		}

		// Token: 0x06000BF3 RID: 3059 RVA: 0x00031994 File Offset: 0x0002FB94
		public override int GetHashCode()
		{
			if (this.key.Length == 0)
			{
				return 0;
			}
			int num = (int)this.key[0];
			for (int i = 1; i < this.key.Length; i++)
			{
				num ^= (int)this.key[i] << (i & 3);
			}
			return num;
		}

		// Token: 0x06000BF4 RID: 3060 RVA: 0x000319E8 File Offset: 0x0002FBE8
		public override string ToString()
		{
			return string.Concat(new object[] { "SortKey - ", this.lcid, ", ", this.options, ", ", this.source });
		}

		// Token: 0x040004D3 RID: 1235
		private readonly string source;

		// Token: 0x040004D4 RID: 1236
		private readonly CompareOptions options;

		// Token: 0x040004D5 RID: 1237
		private readonly byte[] key;

		// Token: 0x040004D6 RID: 1238
		private readonly int lcid;
	}
}
