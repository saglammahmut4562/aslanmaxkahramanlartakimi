﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Globalization
{
	// Token: 0x0200012C RID: 300
	[MonoTODO("IDeserializationCallback isn't implemented.")]
	[ComVisible(true)]
	[Serializable]
	public class TextInfo : ICloneable, IDeserializationCallback
	{
		// Token: 0x06000BF5 RID: 3061 RVA: 0x00031A40 File Offset: 0x0002FC40
		internal unsafe TextInfo(CultureInfo ci, int lcid, void* data, bool read_only)
		{
			this.m_isReadOnly = read_only;
			this.m_win32LangID = lcid;
			this.ci = ci;
			if (data != null)
			{
				this.data = *(TextInfo.Data*)data;
			}
			else
			{
				this.data = default(TextInfo.Data);
				this.data.list_sep = 44;
			}
			CultureInfo cultureInfo = ci;
			while (cultureInfo.Parent != null && cultureInfo.Parent.LCID != 127 && cultureInfo.Parent != cultureInfo)
			{
				cultureInfo = cultureInfo.Parent;
			}
			if (cultureInfo != null)
			{
				int lcid2 = cultureInfo.LCID;
				if (lcid2 == 31 || lcid2 == 44)
				{
					this.handleDotI = true;
				}
			}
		}

		// Token: 0x06000BF6 RID: 3062 RVA: 0x00031B04 File Offset: 0x0002FD04
		private TextInfo(TextInfo textInfo)
		{
			this.m_win32LangID = textInfo.m_win32LangID;
			this.m_nDataItem = textInfo.m_nDataItem;
			this.m_useUserOverride = textInfo.m_useUserOverride;
			this.m_listSeparator = textInfo.ListSeparator;
			this.customCultureName = textInfo.CultureName;
			this.ci = textInfo.ci;
			this.handleDotI = textInfo.handleDotI;
			this.data = textInfo.data;
		}

		// Token: 0x06000BF7 RID: 3063 RVA: 0x00031B78 File Offset: 0x0002FD78
		[MonoTODO]
		void IDeserializationCallback.OnDeserialization(object sender)
		{
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x06000BF8 RID: 3064 RVA: 0x00031B7C File Offset: 0x0002FD7C
		public virtual string ListSeparator
		{
			get
			{
				if (this.m_listSeparator == null)
				{
					this.m_listSeparator = ((char)this.data.list_sep).ToString();
				}
				return this.m_listSeparator;
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06000BF9 RID: 3065 RVA: 0x00031BB8 File Offset: 0x0002FDB8
		[ComVisible(false)]
		public string CultureName
		{
			get
			{
				if (this.customCultureName == null)
				{
					this.customCultureName = this.ci.Name;
				}
				return this.customCultureName;
			}
		}

		// Token: 0x06000BFA RID: 3066 RVA: 0x00031BDC File Offset: 0x0002FDDC
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			TextInfo textInfo = obj as TextInfo;
			return textInfo != null && textInfo.m_win32LangID == this.m_win32LangID && textInfo.ci == this.ci;
		}

		// Token: 0x06000BFB RID: 3067 RVA: 0x00031C28 File Offset: 0x0002FE28
		public override int GetHashCode()
		{
			return this.m_win32LangID;
		}

		// Token: 0x06000BFC RID: 3068 RVA: 0x00031C30 File Offset: 0x0002FE30
		public override string ToString()
		{
			return "TextInfo - " + this.m_win32LangID;
		}

		// Token: 0x06000BFD RID: 3069 RVA: 0x00031C48 File Offset: 0x0002FE48
		public virtual char ToLower(char c)
		{
			if (c < '@' || ('`' < c && c < '\u0080'))
			{
				return c;
			}
			if ('A' <= c && c <= 'Z' && (!this.handleDotI || c != 'I'))
			{
				return c + ' ';
			}
			if (this.ci == null || this.ci.LCID == 127)
			{
				return char.ToLowerInvariant(c);
			}
			switch (c)
			{
			case 'ǅ':
				return 'ǆ';
			default:
				switch (c)
				{
				case 'ϒ':
					return 'υ';
				case 'ϓ':
					return 'ύ';
				case 'ϔ':
					return 'ϋ';
				default:
					if (c != 'I')
					{
						if (c == 'İ')
						{
							return 'i';
						}
						if (c == 'ǋ')
						{
							return 'ǌ';
						}
						if (c == 'ǲ')
						{
							return 'ǳ';
						}
					}
					else if (this.handleDotI)
					{
						return 'ı';
					}
					return char.ToLowerInvariant(c);
				}
				break;
			case 'ǈ':
				return 'ǉ';
			}
		}

		// Token: 0x06000BFE RID: 3070 RVA: 0x00031D6C File Offset: 0x0002FF6C
		public virtual char ToUpper(char c)
		{
			if (c < '`')
			{
				return c;
			}
			if ('a' <= c && c <= 'z' && (!this.handleDotI || c != 'i'))
			{
				return c - ' ';
			}
			if (this.ci == null || this.ci.LCID == 127)
			{
				return char.ToUpperInvariant(c);
			}
			switch (c)
			{
			case 'ϐ':
				return 'Β';
			case 'ϑ':
				return 'Θ';
			default:
				switch (c)
				{
				case 'ǅ':
					return 'Ǆ';
				default:
					if (c == 'ϰ')
					{
						return 'Κ';
					}
					if (c != 'ϱ')
					{
						if (c != 'i')
						{
							if (c == 'ı')
							{
								return 'I';
							}
							if (c == 'ǋ')
							{
								return 'Ǌ';
							}
							if (c == 'ǲ')
							{
								return 'Ǳ';
							}
							if (c == 'ΐ')
							{
								return 'Ϊ';
							}
							if (c == 'ΰ')
							{
								return 'Ϋ';
							}
						}
						else if (this.handleDotI)
						{
							return 'İ';
						}
						return char.ToUpperInvariant(c);
					}
					return 'Ρ';
				case 'ǈ':
					return 'Ǉ';
				}
				break;
			case 'ϕ':
				return 'Φ';
			case 'ϖ':
				return 'Π';
			}
		}

		// Token: 0x06000BFF RID: 3071 RVA: 0x00031ED8 File Offset: 0x000300D8
		public unsafe virtual string ToLower(string str)
		{
			if (str == null)
			{
				throw new ArgumentNullException("str");
			}
			if (str.Length == 0)
			{
				return string.Empty;
			}
			string text = string.InternalAllocateStr(str.Length);
			fixed (string text2 = str)
			{
				fixed (char* ptr = text2 + RuntimeHelpers.OffsetToStringData / 2)
				{
					fixed (string text3 = text)
					{
						fixed (char* ptr2 = text3 + RuntimeHelpers.OffsetToStringData / 2)
						{
							char* ptr3 = ptr2;
							char* ptr4 = ptr;
							for (int i = 0; i < str.Length; i++)
							{
								*ptr3 = this.ToLower(*ptr4);
								ptr4++;
								ptr3++;
							}
							text2 = null;
							text3 = null;
							return text;
						}
					}
				}
			}
		}

		// Token: 0x06000C00 RID: 3072 RVA: 0x00031F6C File Offset: 0x0003016C
		public unsafe virtual string ToUpper(string str)
		{
			if (str == null)
			{
				throw new ArgumentNullException("str");
			}
			if (str.Length == 0)
			{
				return string.Empty;
			}
			string text = string.InternalAllocateStr(str.Length);
			fixed (string text2 = str)
			{
				fixed (char* ptr = text2 + RuntimeHelpers.OffsetToStringData / 2)
				{
					fixed (string text3 = text)
					{
						fixed (char* ptr2 = text3 + RuntimeHelpers.OffsetToStringData / 2)
						{
							char* ptr3 = ptr2;
							char* ptr4 = ptr;
							for (int i = 0; i < str.Length; i++)
							{
								*ptr3 = this.ToUpper(*ptr4);
								ptr4++;
								ptr3++;
							}
							text2 = null;
							text3 = null;
							return text;
						}
					}
				}
			}
		}

		// Token: 0x06000C01 RID: 3073 RVA: 0x00032000 File Offset: 0x00030200
		[ComVisible(false)]
		public static TextInfo ReadOnly(TextInfo textInfo)
		{
			if (textInfo == null)
			{
				throw new ArgumentNullException("textInfo");
			}
			return new TextInfo(textInfo)
			{
				m_isReadOnly = true
			};
		}

		// Token: 0x06000C02 RID: 3074 RVA: 0x00032030 File Offset: 0x00030230
		[ComVisible(false)]
		public virtual object Clone()
		{
			return new TextInfo(this);
		}

		// Token: 0x040004D7 RID: 1239
		private string m_listSeparator;

		// Token: 0x040004D8 RID: 1240
		private bool m_isReadOnly;

		// Token: 0x040004D9 RID: 1241
		private string customCultureName;

		// Token: 0x040004DA RID: 1242
		[NonSerialized]
		private int m_nDataItem;

		// Token: 0x040004DB RID: 1243
		private bool m_useUserOverride;

		// Token: 0x040004DC RID: 1244
		private int m_win32LangID;

		// Token: 0x040004DD RID: 1245
		[NonSerialized]
		private readonly CultureInfo ci;

		// Token: 0x040004DE RID: 1246
		[NonSerialized]
		private readonly bool handleDotI;

		// Token: 0x040004DF RID: 1247
		[NonSerialized]
		private readonly TextInfo.Data data;

		// Token: 0x0200012D RID: 301
		private struct Data
		{
			// Token: 0x040004E0 RID: 1248
			public int ansi;

			// Token: 0x040004E1 RID: 1249
			public int ebcdic;

			// Token: 0x040004E2 RID: 1250
			public int mac;

			// Token: 0x040004E3 RID: 1251
			public int oem;

			// Token: 0x040004E4 RID: 1252
			public byte list_sep;
		}
	}
}
