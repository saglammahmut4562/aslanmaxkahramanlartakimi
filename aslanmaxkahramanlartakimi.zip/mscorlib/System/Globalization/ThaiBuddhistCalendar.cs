﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x0200012E RID: 302
	[ComVisible(true)]
	[MonoTODO("Serialization format not compatible with.NET")]
	[Serializable]
	public class ThaiBuddhistCalendar : Calendar
	{
		// Token: 0x06000C03 RID: 3075 RVA: 0x00032038 File Offset: 0x00030238
		public ThaiBuddhistCalendar()
		{
			this.M_AbbrEraNames = new string[] { "T.B.C.E." };
			this.M_EraNames = new string[] { "ThaiBuddhist current era" };
			if (this.twoDigitYearMax == 99)
			{
				this.twoDigitYearMax = 2572;
			}
		}

		// Token: 0x06000C04 RID: 3076 RVA: 0x0003208C File Offset: 0x0003028C
		static ThaiBuddhistCalendar()
		{
			ThaiBuddhistCalendar.M_EraHandler.appendEra(1, CCGregorianCalendar.fixed_from_dmy(1, 1, -542));
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x06000C05 RID: 3077 RVA: 0x000320E4 File Offset: 0x000302E4
		public override int[] Eras
		{
			get
			{
				return (int[])ThaiBuddhistCalendar.M_EraHandler.Eras.Clone();
			}
		}

		// Token: 0x06000C06 RID: 3078 RVA: 0x000320FC File Offset: 0x000302FC
		public override int GetDayOfMonth(DateTime time)
		{
			return CCGregorianCalendar.GetDayOfMonth(time);
		}

		// Token: 0x06000C07 RID: 3079 RVA: 0x00032104 File Offset: 0x00030304
		public override DayOfWeek GetDayOfWeek(DateTime time)
		{
			int num = CCFixed.FromDateTime(time);
			return CCFixed.day_of_week(num);
		}

		// Token: 0x06000C08 RID: 3080 RVA: 0x00032120 File Offset: 0x00030320
		public override int GetEra(DateTime time)
		{
			int num = CCFixed.FromDateTime(time);
			int num2;
			ThaiBuddhistCalendar.M_EraHandler.EraYear(out num2, num);
			return num2;
		}

		// Token: 0x06000C09 RID: 3081 RVA: 0x00032144 File Offset: 0x00030344
		public override int GetMonth(DateTime time)
		{
			return CCGregorianCalendar.GetMonth(time);
		}

		// Token: 0x06000C0A RID: 3082 RVA: 0x0003214C File Offset: 0x0003034C
		public override int GetYear(DateTime time)
		{
			int num = CCFixed.FromDateTime(time);
			int num2;
			return ThaiBuddhistCalendar.M_EraHandler.EraYear(out num2, num);
		}

		// Token: 0x040004E5 RID: 1253
		public const int ThaiBuddhistEra = 1;

		// Token: 0x040004E6 RID: 1254
		internal static readonly CCGregorianEraHandler M_EraHandler = new CCGregorianEraHandler();

		// Token: 0x040004E7 RID: 1255
		private static DateTime ThaiMin = new DateTime(1, 1, 1, 0, 0, 0);

		// Token: 0x040004E8 RID: 1256
		private static DateTime ThaiMax = new DateTime(9999, 12, 31, 11, 59, 59);
	}
}
