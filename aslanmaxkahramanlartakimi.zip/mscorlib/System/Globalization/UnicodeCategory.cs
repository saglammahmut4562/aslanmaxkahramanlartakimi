﻿using System;
using System.Runtime.InteropServices;

namespace System.Globalization
{
	// Token: 0x0200012F RID: 303
	[ComVisible(true)]
	[Serializable]
	public enum UnicodeCategory
	{
		// Token: 0x040004EA RID: 1258
		UppercaseLetter,
		// Token: 0x040004EB RID: 1259
		LowercaseLetter,
		// Token: 0x040004EC RID: 1260
		TitlecaseLetter,
		// Token: 0x040004ED RID: 1261
		ModifierLetter,
		// Token: 0x040004EE RID: 1262
		OtherLetter,
		// Token: 0x040004EF RID: 1263
		NonSpacingMark,
		// Token: 0x040004F0 RID: 1264
		SpacingCombiningMark,
		// Token: 0x040004F1 RID: 1265
		EnclosingMark,
		// Token: 0x040004F2 RID: 1266
		DecimalDigitNumber,
		// Token: 0x040004F3 RID: 1267
		LetterNumber,
		// Token: 0x040004F4 RID: 1268
		OtherNumber,
		// Token: 0x040004F5 RID: 1269
		SpaceSeparator,
		// Token: 0x040004F6 RID: 1270
		LineSeparator,
		// Token: 0x040004F7 RID: 1271
		ParagraphSeparator,
		// Token: 0x040004F8 RID: 1272
		Control,
		// Token: 0x040004F9 RID: 1273
		Format,
		// Token: 0x040004FA RID: 1274
		Surrogate,
		// Token: 0x040004FB RID: 1275
		PrivateUse,
		// Token: 0x040004FC RID: 1276
		ConnectorPunctuation,
		// Token: 0x040004FD RID: 1277
		DashPunctuation,
		// Token: 0x040004FE RID: 1278
		OpenPunctuation,
		// Token: 0x040004FF RID: 1279
		ClosePunctuation,
		// Token: 0x04000500 RID: 1280
		InitialQuotePunctuation,
		// Token: 0x04000501 RID: 1281
		FinalQuotePunctuation,
		// Token: 0x04000502 RID: 1282
		OtherPunctuation,
		// Token: 0x04000503 RID: 1283
		MathSymbol,
		// Token: 0x04000504 RID: 1284
		CurrencySymbol,
		// Token: 0x04000505 RID: 1285
		ModifierSymbol,
		// Token: 0x04000506 RID: 1286
		OtherSymbol,
		// Token: 0x04000507 RID: 1287
		OtherNotAssigned
	}
}
