﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Mono.Security;

namespace System
{
	// Token: 0x02000130 RID: 304
	[ComVisible(true)]
	[Serializable]
	public struct Guid : IComparable<Guid>, IEquatable<Guid>, IComparable, IFormattable
	{
		// Token: 0x06000C0B RID: 3083 RVA: 0x00032170 File Offset: 0x00030370
		public Guid(byte[] b)
		{
			Guid.CheckArray(b, 16);
			this._a = BitConverterLE.ToInt32(b, 0);
			this._b = BitConverterLE.ToInt16(b, 4);
			this._c = BitConverterLE.ToInt16(b, 6);
			this._d = b[8];
			this._e = b[9];
			this._f = b[10];
			this._g = b[11];
			this._h = b[12];
			this._i = b[13];
			this._j = b[14];
			this._k = b[15];
		}

		// Token: 0x06000C0C RID: 3084 RVA: 0x000321FC File Offset: 0x000303FC
		public Guid(string g)
		{
			Guid.CheckNull(g);
			g = g.Trim();
			Guid.GuidParser guidParser = new Guid.GuidParser(g);
			Guid guid = guidParser.Parse();
			this = guid;
		}

		// Token: 0x06000C0D RID: 3085 RVA: 0x0003222C File Offset: 0x0003042C
		public Guid(int a, short b, short c, byte[] d)
		{
			Guid.CheckArray(d, 8);
			this._a = a;
			this._b = b;
			this._c = c;
			this._d = d[0];
			this._e = d[1];
			this._f = d[2];
			this._g = d[3];
			this._h = d[4];
			this._i = d[5];
			this._j = d[6];
			this._k = d[7];
		}

		// Token: 0x06000C0E RID: 3086 RVA: 0x000322A8 File Offset: 0x000304A8
		public Guid(int a, short b, short c, byte d, byte e, byte f, byte g, byte h, byte i, byte j, byte k)
		{
			this._a = a;
			this._b = b;
			this._c = c;
			this._d = d;
			this._e = e;
			this._f = f;
			this._g = g;
			this._h = h;
			this._i = i;
			this._j = j;
			this._k = k;
		}

		// Token: 0x06000C0F RID: 3087 RVA: 0x0003230C File Offset: 0x0003050C
		[CLSCompliant(false)]
		public Guid(uint a, ushort b, ushort c, byte d, byte e, byte f, byte g, byte h, byte i, byte j, byte k)
		{
			this = new Guid((int)a, (short)b, (short)c, d, e, f, g, h, i, j, k);
		}

		// Token: 0x06000C10 RID: 3088 RVA: 0x00032334 File Offset: 0x00030534
		static Guid()
		{
			if (MonoTouchAOTHelper.FalseFlag)
			{
				GenericComparer<Guid> genericComparer = new GenericComparer<Guid>();
				GenericEqualityComparer<Guid> genericEqualityComparer = new GenericEqualityComparer<Guid>();
			}
		}

		// Token: 0x06000C11 RID: 3089 RVA: 0x00032378 File Offset: 0x00030578
		private static void CheckNull(object o)
		{
			if (o == null)
			{
				throw new ArgumentNullException(Locale.GetText("Value cannot be null."));
			}
		}

		// Token: 0x06000C12 RID: 3090 RVA: 0x00032390 File Offset: 0x00030590
		private static void CheckLength(byte[] o, int l)
		{
			if (o.Length != l)
			{
				throw new ArgumentException(string.Format(Locale.GetText("Array should be exactly {0} bytes long."), l));
			}
		}

		// Token: 0x06000C13 RID: 3091 RVA: 0x000323B8 File Offset: 0x000305B8
		private static void CheckArray(byte[] o, int l)
		{
			Guid.CheckNull(o);
			Guid.CheckLength(o, l);
		}

		// Token: 0x06000C14 RID: 3092 RVA: 0x000323C8 File Offset: 0x000305C8
		private static int Compare(int x, int y)
		{
			if (x < y)
			{
				return -1;
			}
			return 1;
		}

		// Token: 0x06000C15 RID: 3093 RVA: 0x000323D4 File Offset: 0x000305D4
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is Guid))
			{
				throw new ArgumentException("value", Locale.GetText("Argument of System.Guid.CompareTo should be a Guid."));
			}
			return this.CompareTo((Guid)value);
		}

		// Token: 0x06000C16 RID: 3094 RVA: 0x0003240C File Offset: 0x0003060C
		public override bool Equals(object o)
		{
			return o is Guid && this.CompareTo((Guid)o) == 0;
		}

		// Token: 0x06000C17 RID: 3095 RVA: 0x0003242C File Offset: 0x0003062C
		public int CompareTo(Guid value)
		{
			if (this._a != value._a)
			{
				return Guid.Compare(this._a, value._a);
			}
			if (this._b != value._b)
			{
				return Guid.Compare((int)this._b, (int)value._b);
			}
			if (this._c != value._c)
			{
				return Guid.Compare((int)this._c, (int)value._c);
			}
			if (this._d != value._d)
			{
				return Guid.Compare((int)this._d, (int)value._d);
			}
			if (this._e != value._e)
			{
				return Guid.Compare((int)this._e, (int)value._e);
			}
			if (this._f != value._f)
			{
				return Guid.Compare((int)this._f, (int)value._f);
			}
			if (this._g != value._g)
			{
				return Guid.Compare((int)this._g, (int)value._g);
			}
			if (this._h != value._h)
			{
				return Guid.Compare((int)this._h, (int)value._h);
			}
			if (this._i != value._i)
			{
				return Guid.Compare((int)this._i, (int)value._i);
			}
			if (this._j != value._j)
			{
				return Guid.Compare((int)this._j, (int)value._j);
			}
			if (this._k != value._k)
			{
				return Guid.Compare((int)this._k, (int)value._k);
			}
			return 0;
		}

		// Token: 0x06000C18 RID: 3096 RVA: 0x000325D4 File Offset: 0x000307D4
		public bool Equals(Guid g)
		{
			return this.CompareTo(g) == 0;
		}

		// Token: 0x06000C19 RID: 3097 RVA: 0x000325E0 File Offset: 0x000307E0
		public override int GetHashCode()
		{
			int num = this._a;
			num ^= ((int)this._b << 16) | (int)this._c;
			num ^= (int)this._d << 24;
			num ^= (int)this._e << 16;
			num ^= (int)this._f << 8;
			num ^= (int)this._g;
			num ^= (int)this._h << 24;
			num ^= (int)this._i << 16;
			num ^= (int)this._j << 8;
			return num ^ (int)this._k;
		}

		// Token: 0x06000C1A RID: 3098 RVA: 0x00032660 File Offset: 0x00030860
		private static char ToHex(int b)
		{
			return (char)((b >= 10) ? (97 + b - 10) : (48 + b));
		}

		// Token: 0x06000C1B RID: 3099 RVA: 0x0003267C File Offset: 0x0003087C
		public static Guid NewGuid()
		{
			byte[] array = new byte[16];
			object rngAccess = Guid._rngAccess;
			lock (rngAccess)
			{
				if (Guid._rng == null)
				{
					Guid._rng = RandomNumberGenerator.Create();
				}
				Guid._rng.GetBytes(array);
			}
			Guid guid = new Guid(array);
			guid._d = (guid._d & 63) | 128;
			guid._c = (short)(((long)guid._c & 4095L) | 16384L);
			return guid;
		}

		// Token: 0x06000C1C RID: 3100 RVA: 0x00032718 File Offset: 0x00030918
		internal static byte[] FastNewGuidArray()
		{
			byte[] array = new byte[16];
			object rngAccess = Guid._rngAccess;
			lock (rngAccess)
			{
				if (Guid._rng != null)
				{
					Guid._fastRng = Guid._rng;
				}
				if (Guid._fastRng == null)
				{
					Guid._fastRng = new RNGCryptoServiceProvider();
				}
				Guid._fastRng.GetBytes(array);
			}
			array[8] = (array[8] & 63) | 128;
			array[7] = (array[7] & 15) | 64;
			return array;
		}

		// Token: 0x06000C1D RID: 3101 RVA: 0x000327A8 File Offset: 0x000309A8
		public byte[] ToByteArray()
		{
			byte[] array = new byte[16];
			int num = 0;
			byte[] array2 = BitConverterLE.GetBytes(this._a);
			for (int i = 0; i < 4; i++)
			{
				array[num++] = array2[i];
			}
			array2 = BitConverterLE.GetBytes(this._b);
			for (int i = 0; i < 2; i++)
			{
				array[num++] = array2[i];
			}
			array2 = BitConverterLE.GetBytes(this._c);
			for (int i = 0; i < 2; i++)
			{
				array[num++] = array2[i];
			}
			array[8] = this._d;
			array[9] = this._e;
			array[10] = this._f;
			array[11] = this._g;
			array[12] = this._h;
			array[13] = this._i;
			array[14] = this._j;
			array[15] = this._k;
			return array;
		}

		// Token: 0x06000C1E RID: 3102 RVA: 0x00032888 File Offset: 0x00030A88
		private static void AppendInt(StringBuilder builder, int value)
		{
			builder.Append(Guid.ToHex((value >> 28) & 15));
			builder.Append(Guid.ToHex((value >> 24) & 15));
			builder.Append(Guid.ToHex((value >> 20) & 15));
			builder.Append(Guid.ToHex((value >> 16) & 15));
			builder.Append(Guid.ToHex((value >> 12) & 15));
			builder.Append(Guid.ToHex((value >> 8) & 15));
			builder.Append(Guid.ToHex((value >> 4) & 15));
			builder.Append(Guid.ToHex(value & 15));
		}

		// Token: 0x06000C1F RID: 3103 RVA: 0x00032928 File Offset: 0x00030B28
		private static void AppendShort(StringBuilder builder, short value)
		{
			builder.Append(Guid.ToHex((value >> 12) & 15));
			builder.Append(Guid.ToHex((value >> 8) & 15));
			builder.Append(Guid.ToHex((value >> 4) & 15));
			builder.Append(Guid.ToHex((int)(value & 15)));
		}

		// Token: 0x06000C20 RID: 3104 RVA: 0x0003297C File Offset: 0x00030B7C
		private static void AppendByte(StringBuilder builder, byte value)
		{
			builder.Append(Guid.ToHex((value >> 4) & 15));
			builder.Append(Guid.ToHex((int)(value & 15)));
		}

		// Token: 0x06000C21 RID: 3105 RVA: 0x000329A0 File Offset: 0x00030BA0
		private string BaseToString(bool h, bool p, bool b)
		{
			StringBuilder stringBuilder = new StringBuilder(40);
			if (p)
			{
				stringBuilder.Append('(');
			}
			else if (b)
			{
				stringBuilder.Append('{');
			}
			Guid.AppendInt(stringBuilder, this._a);
			if (h)
			{
				stringBuilder.Append('-');
			}
			Guid.AppendShort(stringBuilder, this._b);
			if (h)
			{
				stringBuilder.Append('-');
			}
			Guid.AppendShort(stringBuilder, this._c);
			if (h)
			{
				stringBuilder.Append('-');
			}
			Guid.AppendByte(stringBuilder, this._d);
			Guid.AppendByte(stringBuilder, this._e);
			if (h)
			{
				stringBuilder.Append('-');
			}
			Guid.AppendByte(stringBuilder, this._f);
			Guid.AppendByte(stringBuilder, this._g);
			Guid.AppendByte(stringBuilder, this._h);
			Guid.AppendByte(stringBuilder, this._i);
			Guid.AppendByte(stringBuilder, this._j);
			Guid.AppendByte(stringBuilder, this._k);
			if (p)
			{
				stringBuilder.Append(')');
			}
			else if (b)
			{
				stringBuilder.Append('}');
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000C22 RID: 3106 RVA: 0x00032AC4 File Offset: 0x00030CC4
		public override string ToString()
		{
			return this.BaseToString(true, false, false);
		}

		// Token: 0x06000C23 RID: 3107 RVA: 0x00032AD0 File Offset: 0x00030CD0
		public string ToString(string format)
		{
			bool flag = true;
			bool flag2 = false;
			bool flag3 = false;
			if (format != null)
			{
				string text = format.ToLowerInvariant();
				if (text == "b")
				{
					flag3 = true;
				}
				else if (text == "p")
				{
					flag2 = true;
				}
				else if (text == "n")
				{
					flag = false;
				}
				else if (text != "d" && text != string.Empty)
				{
					throw new FormatException(Locale.GetText("Argument to Guid.ToString(string format) should be \"b\", \"B\", \"d\", \"D\", \"n\", \"N\", \"p\" or \"P\""));
				}
			}
			return this.BaseToString(flag, flag2, flag3);
		}

		// Token: 0x06000C24 RID: 3108 RVA: 0x00032B70 File Offset: 0x00030D70
		public string ToString(string format, IFormatProvider provider)
		{
			return this.ToString(format);
		}

		// Token: 0x06000C25 RID: 3109 RVA: 0x00032B7C File Offset: 0x00030D7C
		public static bool operator ==(Guid a, Guid b)
		{
			return a.Equals(b);
		}

		// Token: 0x06000C26 RID: 3110 RVA: 0x00032B88 File Offset: 0x00030D88
		public static bool operator !=(Guid a, Guid b)
		{
			return !a.Equals(b);
		}

		// Token: 0x04000508 RID: 1288
		private int _a;

		// Token: 0x04000509 RID: 1289
		private short _b;

		// Token: 0x0400050A RID: 1290
		private short _c;

		// Token: 0x0400050B RID: 1291
		private byte _d;

		// Token: 0x0400050C RID: 1292
		private byte _e;

		// Token: 0x0400050D RID: 1293
		private byte _f;

		// Token: 0x0400050E RID: 1294
		private byte _g;

		// Token: 0x0400050F RID: 1295
		private byte _h;

		// Token: 0x04000510 RID: 1296
		private byte _i;

		// Token: 0x04000511 RID: 1297
		private byte _j;

		// Token: 0x04000512 RID: 1298
		private byte _k;

		// Token: 0x04000513 RID: 1299
		public static readonly Guid Empty = new Guid(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

		// Token: 0x04000514 RID: 1300
		private static object _rngAccess = new object();

		// Token: 0x04000515 RID: 1301
		private static RandomNumberGenerator _rng;

		// Token: 0x04000516 RID: 1302
		private static RandomNumberGenerator _fastRng;

		// Token: 0x02000131 RID: 305
		internal class GuidParser
		{
			// Token: 0x06000C27 RID: 3111 RVA: 0x00032B98 File Offset: 0x00030D98
			public GuidParser(string src)
			{
				this._src = src;
				this.Reset();
			}

			// Token: 0x06000C28 RID: 3112 RVA: 0x00032BB0 File Offset: 0x00030DB0
			private void Reset()
			{
				this._cur = 0;
				this._length = this._src.Length;
			}

			// Token: 0x06000C29 RID: 3113 RVA: 0x00032BCC File Offset: 0x00030DCC
			private bool AtEnd()
			{
				return this._cur >= this._length;
			}

			// Token: 0x06000C2A RID: 3114 RVA: 0x00032BE0 File Offset: 0x00030DE0
			private void ThrowFormatException()
			{
				throw new FormatException(Locale.GetText("Invalid format for Guid.Guid(string)."));
			}

			// Token: 0x06000C2B RID: 3115 RVA: 0x00032BF4 File Offset: 0x00030DF4
			private ulong ParseHex(int length, bool strictLength)
			{
				ulong num = 0UL;
				bool flag = false;
				int num2 = 0;
				while (!flag && num2 < length)
				{
					if (this.AtEnd())
					{
						if (strictLength || num2 == 0)
						{
							this.ThrowFormatException();
						}
						else
						{
							flag = true;
						}
					}
					else
					{
						char c = char.ToLowerInvariant(this._src[this._cur]);
						if (char.IsDigit(c))
						{
							num = num * 16UL + (ulong)c - 48UL;
							this._cur++;
						}
						else if (c >= 'a' && c <= 'f')
						{
							num = num * 16UL + (ulong)c - 97UL + 10UL;
							this._cur++;
						}
						else if (strictLength || num2 == 0)
						{
							this.ThrowFormatException();
						}
						else
						{
							flag = true;
						}
					}
					num2++;
				}
				return num;
			}

			// Token: 0x06000C2C RID: 3116 RVA: 0x00032CD8 File Offset: 0x00030ED8
			private bool ParseOptChar(char c)
			{
				if (!this.AtEnd() && this._src[this._cur] == c)
				{
					this._cur++;
					return true;
				}
				return false;
			}

			// Token: 0x06000C2D RID: 3117 RVA: 0x00032D10 File Offset: 0x00030F10
			private void ParseChar(char c)
			{
				if (!this.ParseOptChar(c))
				{
					this.ThrowFormatException();
				}
			}

			// Token: 0x06000C2E RID: 3118 RVA: 0x00032D34 File Offset: 0x00030F34
			private Guid ParseGuid1()
			{
				bool flag = true;
				char c = '}';
				byte[] array = new byte[8];
				bool flag2 = this.ParseOptChar('{');
				if (!flag2)
				{
					flag2 = this.ParseOptChar('(');
					if (flag2)
					{
						c = ')';
					}
				}
				int num = (int)this.ParseHex(8, true);
				if (flag2)
				{
					this.ParseChar('-');
				}
				else
				{
					flag = this.ParseOptChar('-');
				}
				short num2 = (short)this.ParseHex(4, true);
				if (flag)
				{
					this.ParseChar('-');
				}
				short num3 = (short)this.ParseHex(4, true);
				if (flag)
				{
					this.ParseChar('-');
				}
				for (int i = 0; i < 8; i++)
				{
					array[i] = (byte)this.ParseHex(2, true);
					if (i == 1 && flag)
					{
						this.ParseChar('-');
					}
				}
				if (flag2 && !this.ParseOptChar(c))
				{
					this.ThrowFormatException();
				}
				return new Guid(num, num2, num3, array);
			}

			// Token: 0x06000C2F RID: 3119 RVA: 0x00032E28 File Offset: 0x00031028
			private void ParseHexPrefix()
			{
				this.ParseChar('0');
				this.ParseChar('x');
			}

			// Token: 0x06000C30 RID: 3120 RVA: 0x00032E3C File Offset: 0x0003103C
			private Guid ParseGuid2()
			{
				byte[] array = new byte[8];
				this.ParseChar('{');
				this.ParseHexPrefix();
				int num = (int)this.ParseHex(8, false);
				this.ParseChar(',');
				this.ParseHexPrefix();
				short num2 = (short)this.ParseHex(4, false);
				this.ParseChar(',');
				this.ParseHexPrefix();
				short num3 = (short)this.ParseHex(4, false);
				this.ParseChar(',');
				this.ParseChar('{');
				for (int i = 0; i < 8; i++)
				{
					this.ParseHexPrefix();
					array[i] = (byte)this.ParseHex(2, false);
					if (i != 7)
					{
						this.ParseChar(',');
					}
				}
				this.ParseChar('}');
				this.ParseChar('}');
				return new Guid(num, num2, num3, array);
			}

			// Token: 0x06000C31 RID: 3121 RVA: 0x00032EFC File Offset: 0x000310FC
			public Guid Parse()
			{
				Guid guid;
				try
				{
					guid = this.ParseGuid1();
				}
				catch (FormatException)
				{
					this.Reset();
					guid = this.ParseGuid2();
				}
				if (!this.AtEnd())
				{
					this.ThrowFormatException();
				}
				return guid;
			}

			// Token: 0x04000517 RID: 1303
			private string _src;

			// Token: 0x04000518 RID: 1304
			private int _length;

			// Token: 0x04000519 RID: 1305
			private int _cur;
		}
	}
}
