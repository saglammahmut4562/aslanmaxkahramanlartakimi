﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace System
{
	// Token: 0x02000132 RID: 306
	[ComVisible(true)]
	public interface IAsyncResult
	{
		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x06000C32 RID: 3122
		object AsyncState { get; }

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x06000C33 RID: 3123
		WaitHandle AsyncWaitHandle { get; }

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000C34 RID: 3124
		bool IsCompleted { get; }
	}
}
