﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000133 RID: 307
	[ComVisible(true)]
	public interface ICloneable
	{
		// Token: 0x06000C35 RID: 3125
		object Clone();
	}
}
