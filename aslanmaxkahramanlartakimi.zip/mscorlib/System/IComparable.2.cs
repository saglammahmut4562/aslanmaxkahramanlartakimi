﻿using System;

namespace System
{
	// Token: 0x02000135 RID: 309
	public interface IComparable<T>
	{
		// Token: 0x06000C37 RID: 3127
		int CompareTo(T other);
	}
}
