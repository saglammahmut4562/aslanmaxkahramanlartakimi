﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000134 RID: 308
	[ComVisible(true)]
	public interface IComparable
	{
		// Token: 0x06000C36 RID: 3126
		int CompareTo(object obj);
	}
}
