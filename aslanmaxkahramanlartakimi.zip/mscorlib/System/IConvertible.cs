﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000136 RID: 310
	[CLSCompliant(false)]
	[ComVisible(true)]
	public interface IConvertible
	{
		// Token: 0x06000C38 RID: 3128
		TypeCode GetTypeCode();

		// Token: 0x06000C39 RID: 3129
		bool ToBoolean(IFormatProvider provider);

		// Token: 0x06000C3A RID: 3130
		byte ToByte(IFormatProvider provider);

		// Token: 0x06000C3B RID: 3131
		char ToChar(IFormatProvider provider);

		// Token: 0x06000C3C RID: 3132
		DateTime ToDateTime(IFormatProvider provider);

		// Token: 0x06000C3D RID: 3133
		decimal ToDecimal(IFormatProvider provider);

		// Token: 0x06000C3E RID: 3134
		double ToDouble(IFormatProvider provider);

		// Token: 0x06000C3F RID: 3135
		short ToInt16(IFormatProvider provider);

		// Token: 0x06000C40 RID: 3136
		int ToInt32(IFormatProvider provider);

		// Token: 0x06000C41 RID: 3137
		long ToInt64(IFormatProvider provider);

		// Token: 0x06000C42 RID: 3138
		sbyte ToSByte(IFormatProvider provider);

		// Token: 0x06000C43 RID: 3139
		float ToSingle(IFormatProvider provider);

		// Token: 0x06000C44 RID: 3140
		string ToString(IFormatProvider provider);

		// Token: 0x06000C45 RID: 3141
		object ToType(Type conversionType, IFormatProvider provider);

		// Token: 0x06000C46 RID: 3142
		ushort ToUInt16(IFormatProvider provider);

		// Token: 0x06000C47 RID: 3143
		uint ToUInt32(IFormatProvider provider);

		// Token: 0x06000C48 RID: 3144
		ulong ToUInt64(IFormatProvider provider);
	}
}
