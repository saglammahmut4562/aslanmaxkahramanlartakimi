﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000137 RID: 311
	[ComVisible(true)]
	public interface ICustomFormatter
	{
		// Token: 0x06000C49 RID: 3145
		string Format(string format, object arg, IFormatProvider formatProvider);
	}
}
