﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000138 RID: 312
	[ComVisible(true)]
	public interface IDisposable
	{
		// Token: 0x06000C4A RID: 3146
		void Dispose();
	}
}
