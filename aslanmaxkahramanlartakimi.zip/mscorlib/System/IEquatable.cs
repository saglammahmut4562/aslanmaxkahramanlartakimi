﻿using System;

namespace System
{
	// Token: 0x02000139 RID: 313
	public interface IEquatable<T>
	{
		// Token: 0x06000C4B RID: 3147
		bool Equals(T other);
	}
}
