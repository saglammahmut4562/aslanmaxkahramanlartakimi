﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200013A RID: 314
	[ComVisible(true)]
	public interface IFormatProvider
	{
		// Token: 0x06000C4C RID: 3148
		object GetFormat(Type formatType);
	}
}
