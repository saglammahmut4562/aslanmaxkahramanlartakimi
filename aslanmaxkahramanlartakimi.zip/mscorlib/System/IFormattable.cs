﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200013B RID: 315
	[ComVisible(true)]
	public interface IFormattable
	{
		// Token: 0x06000C4D RID: 3149
		string ToString(string format, IFormatProvider formatProvider);
	}
}
