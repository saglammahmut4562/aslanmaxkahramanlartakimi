﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using Mono.Security;

namespace System.IO
{
	// Token: 0x02000143 RID: 323
	[ComVisible(true)]
	public class BinaryReader : IDisposable
	{
		// Token: 0x06000CD4 RID: 3284 RVA: 0x00034E70 File Offset: 0x00033070
		public BinaryReader(Stream input)
			: this(input, Encoding.UTF8UnmarkedUnsafe)
		{
		}

		// Token: 0x06000CD5 RID: 3285 RVA: 0x00034E80 File Offset: 0x00033080
		public BinaryReader(Stream input, Encoding encoding)
		{
			if (input == null || encoding == null)
			{
				throw new ArgumentNullException(Locale.GetText("Input or Encoding is a null reference."));
			}
			if (!input.CanRead)
			{
				throw new ArgumentException(Locale.GetText("The stream doesn't support reading."));
			}
			this.m_stream = input;
			this.m_encoding = encoding;
			this.decoder = encoding.GetDecoder();
			this.m_buffer = new byte[32];
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x00034EF4 File Offset: 0x000330F4
		void IDisposable.Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x06000CD7 RID: 3287 RVA: 0x00034F00 File Offset: 0x00033100
		public virtual Stream BaseStream
		{
			get
			{
				return this.m_stream;
			}
		}

		// Token: 0x06000CD8 RID: 3288 RVA: 0x00034F08 File Offset: 0x00033108
		public virtual void Close()
		{
			this.Dispose(true);
			this.m_disposed = true;
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x00034F18 File Offset: 0x00033118
		protected virtual void Dispose(bool disposing)
		{
			if (disposing && this.m_stream != null)
			{
				this.m_stream.Close();
			}
			this.m_disposed = true;
			this.m_buffer = null;
			this.m_encoding = null;
			this.m_stream = null;
			this.charBuffer = null;
		}

		// Token: 0x06000CDA RID: 3290 RVA: 0x00034F64 File Offset: 0x00033164
		protected virtual void FillBuffer(int numBytes)
		{
			if (this.m_disposed)
			{
				throw new ObjectDisposedException("BinaryReader", "Cannot read from a closed BinaryReader.");
			}
			if (this.m_stream == null)
			{
				throw new IOException("Stream is invalid");
			}
			this.CheckBuffer(numBytes);
			int num;
			for (int i = 0; i < numBytes; i += num)
			{
				num = this.m_stream.Read(this.m_buffer, i, numBytes - i);
				if (num == 0)
				{
					throw new EndOfStreamException();
				}
			}
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x00034FE0 File Offset: 0x000331E0
		public virtual int Read()
		{
			if (this.charBuffer == null)
			{
				this.charBuffer = new char[128];
			}
			if (this.Read(this.charBuffer, 0, 1) == 0)
			{
				return -1;
			}
			return (int)this.charBuffer[0];
		}

		// Token: 0x06000CDC RID: 3292 RVA: 0x00035028 File Offset: 0x00033228
		public virtual int Read(byte[] buffer, int index, int count)
		{
			if (this.m_stream == null)
			{
				if (this.m_disposed)
				{
					throw new ObjectDisposedException("BinaryReader", "Cannot read from a closed BinaryReader.");
				}
				throw new IOException("Stream is invalid");
			}
			else
			{
				if (buffer == null)
				{
					throw new ArgumentNullException("buffer is null");
				}
				if (index < 0)
				{
					throw new ArgumentOutOfRangeException("index is less than 0");
				}
				if (count < 0)
				{
					throw new ArgumentOutOfRangeException("count is less than 0");
				}
				if (buffer.Length - index < count)
				{
					throw new ArgumentException("buffer is too small");
				}
				return this.m_stream.Read(buffer, index, count);
			}
		}

		// Token: 0x06000CDD RID: 3293 RVA: 0x000350C4 File Offset: 0x000332C4
		public virtual int Read(char[] buffer, int index, int count)
		{
			if (this.m_stream == null)
			{
				if (this.m_disposed)
				{
					throw new ObjectDisposedException("BinaryReader", "Cannot read from a closed BinaryReader.");
				}
				throw new IOException("Stream is invalid");
			}
			else
			{
				if (buffer == null)
				{
					throw new ArgumentNullException("buffer is null");
				}
				if (index < 0)
				{
					throw new ArgumentOutOfRangeException("index is less than 0");
				}
				if (count < 0)
				{
					throw new ArgumentOutOfRangeException("count is less than 0");
				}
				if (buffer.Length - index < count)
				{
					throw new ArgumentException("buffer is too small");
				}
				int num;
				return this.ReadCharBytes(buffer, index, count, out num);
			}
		}

		// Token: 0x06000CDE RID: 3294 RVA: 0x00035158 File Offset: 0x00033358
		private int ReadCharBytes(char[] buffer, int index, int count, out int bytes_read)
		{
			int i = 0;
			bytes_read = 0;
			while (i < count)
			{
				int num = 0;
				int chars;
				do
				{
					this.CheckBuffer(num + 1);
					int num2 = this.m_stream.ReadByte();
					if (num2 == -1)
					{
						return i;
					}
					this.m_buffer[num++] = (byte)num2;
					bytes_read++;
					chars = this.m_encoding.GetChars(this.m_buffer, 0, num, buffer, index + i);
				}
				while (chars <= 0);
				i++;
			}
			return i;
		}

		// Token: 0x06000CDF RID: 3295 RVA: 0x000351DC File Offset: 0x000333DC
		protected int Read7BitEncodedInt()
		{
			int num = 0;
			int num2 = 0;
			int i;
			for (i = 0; i < 5; i++)
			{
				byte b = this.ReadByte();
				num |= (int)(b & 127) << num2;
				num2 += 7;
				if ((b & 128) == 0)
				{
					break;
				}
			}
			if (i < 5)
			{
				return num;
			}
			throw new FormatException("Too many bytes in what should have been a 7 bit encoded Int32.");
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x0003523C File Offset: 0x0003343C
		public virtual bool ReadBoolean()
		{
			return this.ReadByte() != 0;
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x0003524C File Offset: 0x0003344C
		public virtual byte ReadByte()
		{
			if (this.m_stream == null)
			{
				if (this.m_disposed)
				{
					throw new ObjectDisposedException("BinaryReader", "Cannot read from a closed BinaryReader.");
				}
				throw new IOException("Stream is invalid");
			}
			else
			{
				int num = this.m_stream.ReadByte();
				if (num != -1)
				{
					return (byte)num;
				}
				throw new EndOfStreamException();
			}
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x000352A8 File Offset: 0x000334A8
		public virtual byte[] ReadBytes(int count)
		{
			if (this.m_stream == null)
			{
				if (this.m_disposed)
				{
					throw new ObjectDisposedException("BinaryReader", "Cannot read from a closed BinaryReader.");
				}
				throw new IOException("Stream is invalid");
			}
			else
			{
				if (count < 0)
				{
					throw new ArgumentOutOfRangeException("count is less than 0");
				}
				byte[] array = new byte[count];
				int i;
				int num;
				for (i = 0; i < count; i += num)
				{
					num = this.m_stream.Read(array, i, count - i);
					if (num == 0)
					{
						break;
					}
				}
				if (i != count)
				{
					byte[] array2 = new byte[i];
					Buffer.BlockCopyInternal(array, 0, array2, 0, i);
					return array2;
				}
				return array;
			}
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x0003534C File Offset: 0x0003354C
		public virtual char ReadChar()
		{
			int num = this.Read();
			if (num == -1)
			{
				throw new EndOfStreamException();
			}
			return (char)num;
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x00035370 File Offset: 0x00033570
		public unsafe virtual decimal ReadDecimal()
		{
			this.FillBuffer(16);
			decimal num;
			if (BitConverter.IsLittleEndian)
			{
				for (int i = 0; i < 16; i++)
				{
					if (i < 4)
					{
						*((ref num) + (i + 8)) = this.m_buffer[i];
					}
					else if (i < 8)
					{
						*((ref num) + (i + 8)) = this.m_buffer[i];
					}
					else if (i < 12)
					{
						*((ref num) + (i - 4)) = this.m_buffer[i];
					}
					else if (i < 16)
					{
						*((ref num) + (i - 12)) = this.m_buffer[i];
					}
				}
			}
			else
			{
				for (int j = 0; j < 16; j++)
				{
					if (j < 4)
					{
						*((ref num) + (11 - j)) = this.m_buffer[j];
					}
					else if (j < 8)
					{
						*((ref num) + (19 - j)) = this.m_buffer[j];
					}
					else if (j < 12)
					{
						*((ref num) + (15 - j)) = this.m_buffer[j];
					}
					else if (j < 16)
					{
						*((ref num) + (15 - j)) = this.m_buffer[j];
					}
				}
			}
			return num;
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x00035490 File Offset: 0x00033690
		public virtual double ReadDouble()
		{
			this.FillBuffer(8);
			return BitConverterLE.ToDouble(this.m_buffer, 0);
		}

		// Token: 0x06000CE6 RID: 3302 RVA: 0x000354A8 File Offset: 0x000336A8
		public virtual short ReadInt16()
		{
			this.FillBuffer(2);
			return (short)((int)this.m_buffer[0] | ((int)this.m_buffer[1] << 8));
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x000354C8 File Offset: 0x000336C8
		public virtual int ReadInt32()
		{
			this.FillBuffer(4);
			return (int)this.m_buffer[0] | ((int)this.m_buffer[1] << 8) | ((int)this.m_buffer[2] << 16) | ((int)this.m_buffer[3] << 24);
		}

		// Token: 0x06000CE8 RID: 3304 RVA: 0x000354FC File Offset: 0x000336FC
		public virtual long ReadInt64()
		{
			this.FillBuffer(8);
			uint num = (uint)((int)this.m_buffer[0] | ((int)this.m_buffer[1] << 8) | ((int)this.m_buffer[2] << 16) | ((int)this.m_buffer[3] << 24));
			uint num2 = (uint)((int)this.m_buffer[4] | ((int)this.m_buffer[5] << 8) | ((int)this.m_buffer[6] << 16) | ((int)this.m_buffer[7] << 24));
			return (long)(((ulong)num2 << 32) | (ulong)num);
		}

		// Token: 0x06000CE9 RID: 3305 RVA: 0x00035570 File Offset: 0x00033770
		[CLSCompliant(false)]
		public virtual sbyte ReadSByte()
		{
			return (sbyte)this.ReadByte();
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x0003557C File Offset: 0x0003377C
		public virtual string ReadString()
		{
			int num = this.Read7BitEncodedInt();
			if (num < 0)
			{
				throw new IOException("Invalid binary file (string len < 0)");
			}
			if (num == 0)
			{
				return string.Empty;
			}
			if (this.charBuffer == null)
			{
				this.charBuffer = new char[128];
			}
			StringBuilder stringBuilder = null;
			int chars;
			for (;;)
			{
				int num2 = ((num <= 128) ? num : 128);
				this.FillBuffer(num2);
				chars = this.decoder.GetChars(this.m_buffer, 0, num2, this.charBuffer, 0);
				if (stringBuilder == null && num2 == num)
				{
					break;
				}
				if (stringBuilder == null)
				{
					stringBuilder = new StringBuilder(num);
				}
				stringBuilder.Append(this.charBuffer, 0, chars);
				num -= num2;
				if (num <= 0)
				{
					goto Block_8;
				}
			}
			return new string(this.charBuffer, 0, chars);
			Block_8:
			return stringBuilder.ToString();
		}

		// Token: 0x06000CEB RID: 3307 RVA: 0x0003564C File Offset: 0x0003384C
		public virtual float ReadSingle()
		{
			this.FillBuffer(4);
			return BitConverterLE.ToSingle(this.m_buffer, 0);
		}

		// Token: 0x06000CEC RID: 3308 RVA: 0x00035664 File Offset: 0x00033864
		[CLSCompliant(false)]
		public virtual ushort ReadUInt16()
		{
			this.FillBuffer(2);
			return (ushort)((int)this.m_buffer[0] | ((int)this.m_buffer[1] << 8));
		}

		// Token: 0x06000CED RID: 3309 RVA: 0x00035684 File Offset: 0x00033884
		[CLSCompliant(false)]
		public virtual uint ReadUInt32()
		{
			this.FillBuffer(4);
			return (uint)((int)this.m_buffer[0] | ((int)this.m_buffer[1] << 8) | ((int)this.m_buffer[2] << 16) | ((int)this.m_buffer[3] << 24));
		}

		// Token: 0x06000CEE RID: 3310 RVA: 0x000356B8 File Offset: 0x000338B8
		[CLSCompliant(false)]
		public virtual ulong ReadUInt64()
		{
			this.FillBuffer(8);
			uint num = (uint)((int)this.m_buffer[0] | ((int)this.m_buffer[1] << 8) | ((int)this.m_buffer[2] << 16) | ((int)this.m_buffer[3] << 24));
			uint num2 = (uint)((int)this.m_buffer[4] | ((int)this.m_buffer[5] << 8) | ((int)this.m_buffer[6] << 16) | ((int)this.m_buffer[7] << 24));
			return ((ulong)num2 << 32) | (ulong)num;
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x0003572C File Offset: 0x0003392C
		private void CheckBuffer(int length)
		{
			if (this.m_buffer.Length <= length)
			{
				byte[] array = new byte[length];
				Buffer.BlockCopyInternal(this.m_buffer, 0, array, 0, this.m_buffer.Length);
				this.m_buffer = array;
			}
		}

		// Token: 0x04000527 RID: 1319
		private const int MaxBufferSize = 128;

		// Token: 0x04000528 RID: 1320
		private Stream m_stream;

		// Token: 0x04000529 RID: 1321
		private Encoding m_encoding;

		// Token: 0x0400052A RID: 1322
		private byte[] m_buffer;

		// Token: 0x0400052B RID: 1323
		private Decoder decoder;

		// Token: 0x0400052C RID: 1324
		private char[] charBuffer;

		// Token: 0x0400052D RID: 1325
		private bool m_disposed;
	}
}
