﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using Mono.Security;

namespace System.IO
{
	// Token: 0x02000144 RID: 324
	[ComVisible(true)]
	[Serializable]
	public class BinaryWriter : IDisposable
	{
		// Token: 0x06000CF0 RID: 3312 RVA: 0x0003576C File Offset: 0x0003396C
		protected BinaryWriter()
			: this(Stream.Null, Encoding.UTF8UnmarkedUnsafe)
		{
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x00035780 File Offset: 0x00033980
		public BinaryWriter(Stream output)
			: this(output, Encoding.UTF8UnmarkedUnsafe)
		{
		}

		// Token: 0x06000CF2 RID: 3314 RVA: 0x00035790 File Offset: 0x00033990
		public BinaryWriter(Stream output, Encoding encoding)
		{
			if (output == null)
			{
				throw new ArgumentNullException("output");
			}
			if (encoding == null)
			{
				throw new ArgumentNullException("encoding");
			}
			if (!output.CanWrite)
			{
				throw new ArgumentException(Locale.GetText("Stream does not support writing or already closed."));
			}
			this.OutStream = output;
			this.m_encoding = encoding;
			this.buffer = new byte[16];
		}

		// Token: 0x06000CF4 RID: 3316 RVA: 0x00035808 File Offset: 0x00033A08
		void IDisposable.Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x00035814 File Offset: 0x00033A14
		public virtual void Close()
		{
			this.Dispose(true);
		}

		// Token: 0x06000CF6 RID: 3318 RVA: 0x00035820 File Offset: 0x00033A20
		protected virtual void Dispose(bool disposing)
		{
			if (disposing && this.OutStream != null)
			{
				this.OutStream.Close();
			}
			this.buffer = null;
			this.m_encoding = null;
			this.disposed = true;
		}

		// Token: 0x06000CF7 RID: 3319 RVA: 0x00035854 File Offset: 0x00033A54
		public virtual void Flush()
		{
			this.OutStream.Flush();
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x00035864 File Offset: 0x00033A64
		public virtual void Write(bool value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.buffer[0] = ((!value) ? 0 : 1);
			this.OutStream.Write(this.buffer, 0, 1);
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x000358B8 File Offset: 0x00033AB8
		public virtual void Write(byte value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.OutStream.WriteByte(value);
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x000358E4 File Offset: 0x00033AE4
		public virtual void Write(byte[] buffer)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			this.OutStream.Write(buffer, 0, buffer.Length);
		}

		// Token: 0x06000CFB RID: 3323 RVA: 0x00035924 File Offset: 0x00033B24
		public virtual void Write(byte[] buffer, int index, int count)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			this.OutStream.Write(buffer, index, count);
		}

		// Token: 0x06000CFC RID: 3324 RVA: 0x00035960 File Offset: 0x00033B60
		public virtual void Write(char ch)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			char[] array = new char[] { ch };
			byte[] bytes = this.m_encoding.GetBytes(array, 0, 1);
			this.OutStream.Write(bytes, 0, bytes.Length);
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x000359B4 File Offset: 0x00033BB4
		public virtual void Write(char[] chars)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			if (chars == null)
			{
				throw new ArgumentNullException("chars");
			}
			byte[] bytes = this.m_encoding.GetBytes(chars, 0, chars.Length);
			this.OutStream.Write(bytes, 0, bytes.Length);
		}

		// Token: 0x06000CFE RID: 3326 RVA: 0x00035A10 File Offset: 0x00033C10
		public unsafe virtual void Write(decimal value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			if (BitConverter.IsLittleEndian)
			{
				for (int i = 0; i < 16; i++)
				{
					if (i < 4)
					{
						this.buffer[i + 12] = *((ref value) + i);
					}
					else if (i < 8)
					{
						this.buffer[i + 4] = *((ref value) + i);
					}
					else if (i < 12)
					{
						this.buffer[i - 8] = *((ref value) + i);
					}
					else
					{
						this.buffer[i - 8] = *((ref value) + i);
					}
				}
			}
			else
			{
				for (int j = 0; j < 16; j++)
				{
					if (j < 4)
					{
						this.buffer[15 - j] = *((ref value) + j);
					}
					else if (j < 8)
					{
						this.buffer[15 - j] = *((ref value) + j);
					}
					else if (j < 12)
					{
						this.buffer[11 - j] = *((ref value) + j);
					}
					else
					{
						this.buffer[19 - j] = *((ref value) + j);
					}
				}
			}
			this.OutStream.Write(this.buffer, 0, 16);
		}

		// Token: 0x06000CFF RID: 3327 RVA: 0x00035B44 File Offset: 0x00033D44
		public virtual void Write(double value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.OutStream.Write(BitConverterLE.GetBytes(value), 0, 8);
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x00035B74 File Offset: 0x00033D74
		public virtual void Write(short value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.buffer[0] = (byte)value;
			this.buffer[1] = (byte)(value >> 8);
			this.OutStream.Write(this.buffer, 0, 2);
		}

		// Token: 0x06000D01 RID: 3329 RVA: 0x00035BC8 File Offset: 0x00033DC8
		public virtual void Write(int value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.buffer[0] = (byte)value;
			this.buffer[1] = (byte)(value >> 8);
			this.buffer[2] = (byte)(value >> 16);
			this.buffer[3] = (byte)(value >> 24);
			this.OutStream.Write(this.buffer, 0, 4);
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x00035C34 File Offset: 0x00033E34
		public virtual void Write(long value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			int i = 0;
			int num = 0;
			while (i < 8)
			{
				this.buffer[i] = (byte)(value >> num);
				i++;
				num += 8;
			}
			this.OutStream.Write(this.buffer, 0, 8);
		}

		// Token: 0x06000D03 RID: 3331 RVA: 0x00035C98 File Offset: 0x00033E98
		[CLSCompliant(false)]
		public virtual void Write(sbyte value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.buffer[0] = (byte)value;
			this.OutStream.Write(this.buffer, 0, 1);
		}

		// Token: 0x06000D04 RID: 3332 RVA: 0x00035CD4 File Offset: 0x00033ED4
		public virtual void Write(float value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.OutStream.Write(BitConverterLE.GetBytes(value), 0, 4);
		}

		// Token: 0x06000D05 RID: 3333 RVA: 0x00035D04 File Offset: 0x00033F04
		public virtual void Write(string value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			int byteCount = this.m_encoding.GetByteCount(value);
			this.Write7BitEncodedInt(byteCount);
			if (this.stringBuffer == null)
			{
				this.stringBuffer = new byte[512];
				this.maxCharsPerRound = 512 / this.m_encoding.GetMaxByteCount(1);
			}
			int num = 0;
			int num2;
			for (int i = value.Length; i > 0; i -= num2)
			{
				num2 = ((i <= this.maxCharsPerRound) ? i : this.maxCharsPerRound);
				int bytes = this.m_encoding.GetBytes(value, num, num2, this.stringBuffer, 0);
				this.OutStream.Write(this.stringBuffer, 0, bytes);
				num += num2;
			}
		}

		// Token: 0x06000D06 RID: 3334 RVA: 0x00035DD4 File Offset: 0x00033FD4
		[CLSCompliant(false)]
		public virtual void Write(ushort value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.buffer[0] = (byte)value;
			this.buffer[1] = (byte)(value >> 8);
			this.OutStream.Write(this.buffer, 0, 2);
		}

		// Token: 0x06000D07 RID: 3335 RVA: 0x00035E28 File Offset: 0x00034028
		[CLSCompliant(false)]
		public virtual void Write(uint value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			this.buffer[0] = (byte)value;
			this.buffer[1] = (byte)(value >> 8);
			this.buffer[2] = (byte)(value >> 16);
			this.buffer[3] = (byte)(value >> 24);
			this.OutStream.Write(this.buffer, 0, 4);
		}

		// Token: 0x06000D08 RID: 3336 RVA: 0x00035E94 File Offset: 0x00034094
		[CLSCompliant(false)]
		public virtual void Write(ulong value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("BinaryWriter", "Cannot write to a closed BinaryWriter");
			}
			int i = 0;
			int num = 0;
			while (i < 8)
			{
				this.buffer[i] = (byte)(value >> num);
				i++;
				num += 8;
			}
			this.OutStream.Write(this.buffer, 0, 8);
		}

		// Token: 0x06000D09 RID: 3337 RVA: 0x00035EF8 File Offset: 0x000340F8
		protected void Write7BitEncodedInt(int value)
		{
			do
			{
				int num = (value >> 7) & 33554431;
				byte b = (byte)(value & 127);
				if (num != 0)
				{
					b |= 128;
				}
				this.Write(b);
				value = num;
			}
			while (value != 0);
		}

		// Token: 0x0400052E RID: 1326
		public static readonly BinaryWriter Null = new BinaryWriter();

		// Token: 0x0400052F RID: 1327
		protected Stream OutStream;

		// Token: 0x04000530 RID: 1328
		private Encoding m_encoding;

		// Token: 0x04000531 RID: 1329
		private byte[] buffer;

		// Token: 0x04000532 RID: 1330
		private bool disposed;

		// Token: 0x04000533 RID: 1331
		private byte[] stringBuffer;

		// Token: 0x04000534 RID: 1332
		private int maxCharsPerRound;
	}
}
