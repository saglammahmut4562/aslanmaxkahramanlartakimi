﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.IO
{
	// Token: 0x02000146 RID: 326
	[ComVisible(true)]
	[Serializable]
	public sealed class DirectoryInfo : FileSystemInfo
	{
		// Token: 0x06000D11 RID: 3345 RVA: 0x00036280 File Offset: 0x00034480
		public DirectoryInfo(string path)
			: this(path, false)
		{
		}

		// Token: 0x06000D12 RID: 3346 RVA: 0x0003628C File Offset: 0x0003448C
		internal DirectoryInfo(string path, bool simpleOriginalPath)
		{
			base.CheckPath(path);
			this.FullPath = Path.GetFullPath(path);
			if (simpleOriginalPath)
			{
				this.OriginalPath = Path.GetFileName(path);
			}
			else
			{
				this.OriginalPath = path;
			}
			this.Initialize();
		}

		// Token: 0x06000D13 RID: 3347 RVA: 0x000362CC File Offset: 0x000344CC
		private DirectoryInfo(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
			this.Initialize();
		}

		// Token: 0x06000D14 RID: 3348 RVA: 0x000362DC File Offset: 0x000344DC
		private void Initialize()
		{
			int num = this.FullPath.Length - 1;
			if (num > 1 && this.FullPath[num] == Path.DirectorySeparatorChar)
			{
				num--;
			}
			int num2 = this.FullPath.LastIndexOf(Path.DirectorySeparatorChar, num);
			if (num2 == -1 || (num2 == 0 && num == 0))
			{
				this.current = this.FullPath;
				this.parent = null;
			}
			else
			{
				this.current = this.FullPath.Substring(num2 + 1, num - num2);
				if (num2 == 0 && !Environment.IsRunningOnWindows)
				{
					this.parent = Path.DirectorySeparatorStr;
				}
				else
				{
					this.parent = this.FullPath.Substring(0, num2);
				}
				if (Environment.IsRunningOnWindows && this.parent.Length == 2 && this.parent[1] == ':' && char.IsLetter(this.parent[0]))
				{
					this.parent += Path.DirectorySeparatorChar;
				}
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x06000D15 RID: 3349 RVA: 0x00036400 File Offset: 0x00034600
		public override bool Exists
		{
			get
			{
				base.Refresh(false);
				return this.stat.Attributes != MonoIO.InvalidFileAttributes && (this.stat.Attributes & FileAttributes.Directory) != (FileAttributes)0;
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x06000D16 RID: 3350 RVA: 0x00036438 File Offset: 0x00034638
		public DirectoryInfo Parent
		{
			get
			{
				if (this.parent == null || this.parent.Length == 0)
				{
					return null;
				}
				return new DirectoryInfo(this.parent);
			}
		}

		// Token: 0x06000D17 RID: 3351 RVA: 0x00036464 File Offset: 0x00034664
		public void Create()
		{
			Directory.CreateDirectory(this.FullPath);
		}

		// Token: 0x06000D18 RID: 3352 RVA: 0x00036474 File Offset: 0x00034674
		public override string ToString()
		{
			return this.OriginalPath;
		}

		// Token: 0x04000535 RID: 1333
		private string current;

		// Token: 0x04000536 RID: 1334
		private string parent;
	}
}
