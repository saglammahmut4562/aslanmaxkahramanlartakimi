﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.IO
{
	// Token: 0x02000147 RID: 327
	[ComVisible(true)]
	[Serializable]
	public class DirectoryNotFoundException : IOException
	{
		// Token: 0x06000D19 RID: 3353 RVA: 0x0003647C File Offset: 0x0003467C
		public DirectoryNotFoundException()
			: base("Directory not found")
		{
		}

		// Token: 0x06000D1A RID: 3354 RVA: 0x0003648C File Offset: 0x0003468C
		public DirectoryNotFoundException(string message)
			: base(message)
		{
		}

		// Token: 0x06000D1B RID: 3355 RVA: 0x00036498 File Offset: 0x00034698
		protected DirectoryNotFoundException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
