﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.IO
{
	// Token: 0x02000148 RID: 328
	[ComVisible(true)]
	[Serializable]
	public class EndOfStreamException : IOException
	{
		// Token: 0x06000D1C RID: 3356 RVA: 0x000364A4 File Offset: 0x000346A4
		public EndOfStreamException()
			: base(Locale.GetText("Failed to read past end of stream."))
		{
		}

		// Token: 0x06000D1D RID: 3357 RVA: 0x000364B8 File Offset: 0x000346B8
		public EndOfStreamException(string message)
			: base(message)
		{
		}

		// Token: 0x06000D1E RID: 3358 RVA: 0x000364C4 File Offset: 0x000346C4
		protected EndOfStreamException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
