﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x02000149 RID: 329
	[ComVisible(true)]
	public static class File
	{
		// Token: 0x06000D1F RID: 3359 RVA: 0x000364D0 File Offset: 0x000346D0
		public static void Copy(string sourceFileName, string destFileName)
		{
			File.Copy(sourceFileName, destFileName, false);
		}

		// Token: 0x06000D20 RID: 3360 RVA: 0x000364DC File Offset: 0x000346DC
		public static void Copy(string sourceFileName, string destFileName, bool overwrite)
		{
			if (sourceFileName == null)
			{
				throw new ArgumentNullException("sourceFileName");
			}
			if (destFileName == null)
			{
				throw new ArgumentNullException("destFileName");
			}
			if (sourceFileName.Length == 0)
			{
				throw new ArgumentException("An empty file name is not valid.", "sourceFileName");
			}
			if (sourceFileName.Trim().Length == 0 || sourceFileName.IndexOfAny(Path.InvalidPathChars) != -1)
			{
				throw new ArgumentException("The file name is not valid.");
			}
			if (destFileName.Length == 0)
			{
				throw new ArgumentException("An empty file name is not valid.", "destFileName");
			}
			if (destFileName.Trim().Length == 0 || destFileName.IndexOfAny(Path.InvalidPathChars) != -1)
			{
				throw new ArgumentException("The file name is not valid.");
			}
			MonoIOError monoIOError;
			if (!MonoIO.Exists(sourceFileName, out monoIOError))
			{
				throw new FileNotFoundException(Locale.GetText("{0} does not exist", new object[] { sourceFileName }), sourceFileName);
			}
			if ((File.GetAttributes(sourceFileName) & FileAttributes.Directory) == FileAttributes.Directory)
			{
				throw new ArgumentException(Locale.GetText("{0} is a directory", new object[] { sourceFileName }));
			}
			if (MonoIO.Exists(destFileName, out monoIOError))
			{
				if ((File.GetAttributes(destFileName) & FileAttributes.Directory) == FileAttributes.Directory)
				{
					throw new ArgumentException(Locale.GetText("{0} is a directory", new object[] { destFileName }));
				}
				if (!overwrite)
				{
					throw new IOException(Locale.GetText("{0} already exists", new object[] { destFileName }));
				}
			}
			string directoryName = Path.GetDirectoryName(destFileName);
			if (directoryName != string.Empty && !Directory.Exists(directoryName))
			{
				throw new DirectoryNotFoundException(Locale.GetText("Destination directory not found: {0}", new object[] { directoryName }));
			}
			if (!MonoIO.CopyFile(sourceFileName, destFileName, overwrite, out monoIOError))
			{
				string text = Locale.GetText("{0}\" or \"{1}", new object[] { sourceFileName, destFileName });
				throw MonoIO.GetException(text, monoIOError);
			}
		}

		// Token: 0x06000D21 RID: 3361 RVA: 0x000366B0 File Offset: 0x000348B0
		public static FileStream Create(string path)
		{
			return File.Create(path, 8192);
		}

		// Token: 0x06000D22 RID: 3362 RVA: 0x000366C0 File Offset: 0x000348C0
		public static FileStream Create(string path, int bufferSize)
		{
			return new FileStream(path, FileMode.Create, FileAccess.ReadWrite, FileShare.None, bufferSize);
		}

		// Token: 0x06000D23 RID: 3363 RVA: 0x000366CC File Offset: 0x000348CC
		public static void Delete(string path)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (path.Trim().Length == 0 || path.IndexOfAny(Path.InvalidPathChars) >= 0)
			{
				throw new ArgumentException("path");
			}
			if (Directory.Exists(path))
			{
				throw new UnauthorizedAccessException(Locale.GetText("{0} is a directory", new object[] { path }));
			}
			string directoryName = Path.GetDirectoryName(path);
			if (directoryName != string.Empty && !Directory.Exists(directoryName))
			{
				throw new DirectoryNotFoundException(Locale.GetText("Could not find a part of the path \"{0}\".", new object[] { path }));
			}
			MonoIOError monoIOError;
			if (!MonoIO.DeleteFile(path, out monoIOError) && monoIOError != MonoIOError.ERROR_FILE_NOT_FOUND)
			{
				throw MonoIO.GetException(path, monoIOError);
			}
		}

		// Token: 0x06000D24 RID: 3364 RVA: 0x00036794 File Offset: 0x00034994
		public static bool Exists(string path)
		{
			MonoIOError monoIOError;
			return path != null && path.Trim().Length != 0 && path.IndexOfAny(Path.InvalidPathChars) < 0 && MonoIO.ExistsFile(path, out monoIOError);
		}

		// Token: 0x06000D25 RID: 3365 RVA: 0x000367D4 File Offset: 0x000349D4
		public static FileAttributes GetAttributes(string path)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (path.Trim().Length == 0)
			{
				throw new ArgumentException(Locale.GetText("Path is empty"));
			}
			if (path.IndexOfAny(Path.InvalidPathChars) >= 0)
			{
				throw new ArgumentException(Locale.GetText("Path contains invalid chars"));
			}
			MonoIOError monoIOError;
			FileAttributes fileAttributes = MonoIO.GetFileAttributes(path, out monoIOError);
			if (monoIOError != MonoIOError.ERROR_SUCCESS)
			{
				throw MonoIO.GetException(path, monoIOError);
			}
			return fileAttributes;
		}

		// Token: 0x06000D26 RID: 3366 RVA: 0x0003684C File Offset: 0x00034A4C
		public static FileStream Open(string path, FileMode mode)
		{
			return new FileStream(path, mode, (mode != FileMode.Append) ? FileAccess.ReadWrite : FileAccess.Write, FileShare.None);
		}

		// Token: 0x06000D27 RID: 3367 RVA: 0x00036864 File Offset: 0x00034A64
		public static FileStream OpenRead(string path)
		{
			return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
		}

		// Token: 0x06000D28 RID: 3368 RVA: 0x00036870 File Offset: 0x00034A70
		public static StreamReader OpenText(string path)
		{
			return new StreamReader(path);
		}

		// Token: 0x04000537 RID: 1335
		private static DateTime? defaultLocalFileTime;
	}
}
