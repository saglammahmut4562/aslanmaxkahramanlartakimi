﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x0200014A RID: 330
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum FileAccess
	{
		// Token: 0x04000539 RID: 1337
		Read = 1,
		// Token: 0x0400053A RID: 1338
		Write = 2,
		// Token: 0x0400053B RID: 1339
		ReadWrite = 3
	}
}
