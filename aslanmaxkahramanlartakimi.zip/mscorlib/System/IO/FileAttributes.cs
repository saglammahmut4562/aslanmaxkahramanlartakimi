﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x0200014B RID: 331
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum FileAttributes
	{
		// Token: 0x0400053D RID: 1341
		Archive = 32,
		// Token: 0x0400053E RID: 1342
		Compressed = 2048,
		// Token: 0x0400053F RID: 1343
		Device = 64,
		// Token: 0x04000540 RID: 1344
		Directory = 16,
		// Token: 0x04000541 RID: 1345
		Encrypted = 16384,
		// Token: 0x04000542 RID: 1346
		Hidden = 2,
		// Token: 0x04000543 RID: 1347
		Normal = 128,
		// Token: 0x04000544 RID: 1348
		NotContentIndexed = 8192,
		// Token: 0x04000545 RID: 1349
		Offline = 4096,
		// Token: 0x04000546 RID: 1350
		ReadOnly = 1,
		// Token: 0x04000547 RID: 1351
		ReparsePoint = 1024,
		// Token: 0x04000548 RID: 1352
		SparseFile = 512,
		// Token: 0x04000549 RID: 1353
		System = 4,
		// Token: 0x0400054A RID: 1354
		Temporary = 256
	}
}
