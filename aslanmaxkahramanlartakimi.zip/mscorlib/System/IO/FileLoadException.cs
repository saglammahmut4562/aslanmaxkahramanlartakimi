﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;

namespace System.IO
{
	// Token: 0x0200014C RID: 332
	[ComVisible(true)]
	[Serializable]
	public class FileLoadException : IOException
	{
		// Token: 0x06000D29 RID: 3369 RVA: 0x00036878 File Offset: 0x00034A78
		public FileLoadException()
			: base(Locale.GetText("I/O Error"))
		{
			base.HResult = -2147024894;
			this.msg = Locale.GetText("I/O Error");
		}

		// Token: 0x06000D2A RID: 3370 RVA: 0x000368A8 File Offset: 0x00034AA8
		public FileLoadException(string message)
			: base(message)
		{
			base.HResult = -2147024894;
			this.msg = message;
		}

		// Token: 0x06000D2B RID: 3371 RVA: 0x000368C4 File Offset: 0x00034AC4
		protected FileLoadException(SerializationInfo info, StreamingContext context)
		{
			this.fileName = info.GetString("FileLoad_FileName");
			this.fusionLog = info.GetString("FileLoad_FusionLog");
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x06000D2C RID: 3372 RVA: 0x000368F0 File Offset: 0x00034AF0
		public override string Message
		{
			get
			{
				return this.msg;
			}
		}

		// Token: 0x06000D2D RID: 3373 RVA: 0x000368F8 File Offset: 0x00034AF8
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("FileLoad_FileName", this.fileName);
			info.AddValue("FileLoad_FusionLog", this.fusionLog);
		}

		// Token: 0x06000D2E RID: 3374 RVA: 0x00036924 File Offset: 0x00034B24
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(this.GetType().FullName);
			stringBuilder.AppendFormat(": {0}", this.msg);
			if (this.fileName != null)
			{
				stringBuilder.AppendFormat(" : {0}", this.fileName);
			}
			if (this.InnerException != null)
			{
				stringBuilder.AppendFormat(" ----> {0}", this.InnerException);
			}
			if (this.StackTrace != null)
			{
				stringBuilder.Append(Environment.NewLine);
				stringBuilder.Append(this.StackTrace);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0400054B RID: 1355
		private const int Result = -2147024894;

		// Token: 0x0400054C RID: 1356
		private string msg;

		// Token: 0x0400054D RID: 1357
		private string fileName;

		// Token: 0x0400054E RID: 1358
		private string fusionLog;
	}
}
