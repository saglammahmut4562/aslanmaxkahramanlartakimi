﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x0200014D RID: 333
	[ComVisible(true)]
	[Serializable]
	public enum FileMode
	{
		// Token: 0x04000550 RID: 1360
		CreateNew = 1,
		// Token: 0x04000551 RID: 1361
		Create,
		// Token: 0x04000552 RID: 1362
		Open,
		// Token: 0x04000553 RID: 1363
		OpenOrCreate,
		// Token: 0x04000554 RID: 1364
		Truncate,
		// Token: 0x04000555 RID: 1365
		Append
	}
}
