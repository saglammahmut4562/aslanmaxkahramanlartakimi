﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;

namespace System.IO
{
	// Token: 0x0200014E RID: 334
	[ComVisible(true)]
	[Serializable]
	public class FileNotFoundException : IOException
	{
		// Token: 0x06000D2F RID: 3375 RVA: 0x000369B8 File Offset: 0x00034BB8
		public FileNotFoundException()
			: base(Locale.GetText("Unable to find the specified file."))
		{
			base.HResult = -2146232799;
		}

		// Token: 0x06000D30 RID: 3376 RVA: 0x000369D8 File Offset: 0x00034BD8
		public FileNotFoundException(string message)
			: base(message)
		{
			base.HResult = -2146232799;
		}

		// Token: 0x06000D31 RID: 3377 RVA: 0x000369EC File Offset: 0x00034BEC
		public FileNotFoundException(string message, string fileName)
			: base(message)
		{
			base.HResult = -2146232799;
			this.fileName = fileName;
		}

		// Token: 0x06000D32 RID: 3378 RVA: 0x00036A08 File Offset: 0x00034C08
		protected FileNotFoundException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
			this.fileName = info.GetString("FileNotFound_FileName");
			this.fusionLog = info.GetString("FileNotFound_FusionLog");
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x06000D33 RID: 3379 RVA: 0x00036A34 File Offset: 0x00034C34
		public override string Message
		{
			get
			{
				if (this.message == null && this.fileName != null)
				{
					return string.Format(CultureInfo.CurrentCulture, "Could not load file or assembly '{0}' or one of its dependencies. The system cannot find the file specified.", new object[] { this.fileName });
				}
				return this.message;
			}
		}

		// Token: 0x06000D34 RID: 3380 RVA: 0x00036A80 File Offset: 0x00034C80
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("FileNotFound_FileName", this.fileName);
			info.AddValue("FileNotFound_FusionLog", this.fusionLog);
		}

		// Token: 0x06000D35 RID: 3381 RVA: 0x00036AAC File Offset: 0x00034CAC
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(this.GetType().FullName);
			stringBuilder.AppendFormat(": {0}", this.Message);
			if (this.fileName != null && this.fileName.Length > 0)
			{
				stringBuilder.Append(Environment.NewLine);
				stringBuilder.AppendFormat("File name: '{0}'", this.fileName);
			}
			if (this.InnerException != null)
			{
				stringBuilder.AppendFormat(" ---> {0}", this.InnerException);
			}
			if (this.StackTrace != null)
			{
				stringBuilder.Append(Environment.NewLine);
				stringBuilder.Append(this.StackTrace);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x04000556 RID: 1366
		private const int Result = -2146232799;

		// Token: 0x04000557 RID: 1367
		private string fileName;

		// Token: 0x04000558 RID: 1368
		private string fusionLog;
	}
}
