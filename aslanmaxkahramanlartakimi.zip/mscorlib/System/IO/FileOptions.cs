﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x0200014F RID: 335
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum FileOptions
	{
		// Token: 0x0400055A RID: 1370
		None = 0,
		// Token: 0x0400055B RID: 1371
		Encrypted = 16384,
		// Token: 0x0400055C RID: 1372
		DeleteOnClose = 67108864,
		// Token: 0x0400055D RID: 1373
		SequentialScan = 134217728,
		// Token: 0x0400055E RID: 1374
		RandomAccess = 268435456,
		// Token: 0x0400055F RID: 1375
		Asynchronous = 1073741824,
		// Token: 0x04000560 RID: 1376
		WriteThrough = -2147483648
	}
}
