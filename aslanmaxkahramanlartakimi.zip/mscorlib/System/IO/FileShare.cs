﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x02000150 RID: 336
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum FileShare
	{
		// Token: 0x04000562 RID: 1378
		None = 0,
		// Token: 0x04000563 RID: 1379
		Read = 1,
		// Token: 0x04000564 RID: 1380
		Write = 2,
		// Token: 0x04000565 RID: 1381
		ReadWrite = 3,
		// Token: 0x04000566 RID: 1382
		Delete = 4,
		// Token: 0x04000567 RID: 1383
		Inheritable = 16
	}
}
