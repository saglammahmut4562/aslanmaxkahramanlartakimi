﻿using System;
using System.IO.IsolatedStorage;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using Microsoft.Win32.SafeHandles;

namespace System.IO
{
	// Token: 0x02000151 RID: 337
	[ComVisible(true)]
	public class FileStream : Stream
	{
		// Token: 0x06000D36 RID: 3382 RVA: 0x00036B60 File Offset: 0x00034D60
		internal FileStream(IntPtr handle, FileAccess access, bool ownsHandle, int bufferSize, bool isAsync, bool noBuffering)
		{
			this.handle = MonoIO.InvalidHandle;
			if (handle == this.handle)
			{
				throw new ArgumentException("handle", Locale.GetText("Invalid."));
			}
			if (access < FileAccess.Read || access > FileAccess.ReadWrite)
			{
				throw new ArgumentOutOfRangeException("access");
			}
			MonoIOError monoIOError;
			MonoFileType fileType = MonoIO.GetFileType(handle, out monoIOError);
			if (monoIOError != MonoIOError.ERROR_SUCCESS)
			{
				throw MonoIO.GetException(this.name, monoIOError);
			}
			if (fileType == MonoFileType.Unknown)
			{
				throw new IOException("Invalid handle.");
			}
			if (fileType == MonoFileType.Disk)
			{
				this.canseek = true;
			}
			else
			{
				this.canseek = false;
			}
			this.handle = handle;
			this.access = access;
			this.owner = ownsHandle;
			this.async = isAsync;
			this.anonymous = false;
			this.InitBuffer(bufferSize, noBuffering);
			if (this.canseek)
			{
				this.buf_start = MonoIO.Seek(handle, 0L, SeekOrigin.Current, out monoIOError);
				if (monoIOError != MonoIOError.ERROR_SUCCESS)
				{
					throw MonoIO.GetException(this.name, monoIOError);
				}
			}
			this.append_startpos = 0L;
		}

		// Token: 0x06000D37 RID: 3383 RVA: 0x00036C74 File Offset: 0x00034E74
		public FileStream(string path, FileMode mode, FileAccess access)
			: this(path, mode, access, (access != FileAccess.Write) ? FileShare.Read : FileShare.None, 8192, false, false)
		{
		}

		// Token: 0x06000D38 RID: 3384 RVA: 0x00036CA0 File Offset: 0x00034EA0
		public FileStream(string path, FileMode mode, FileAccess access, FileShare share)
			: this(path, mode, access, share, 8192, false, FileOptions.None)
		{
		}

		// Token: 0x06000D39 RID: 3385 RVA: 0x00036CC0 File Offset: 0x00034EC0
		public FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize)
			: this(path, mode, access, share, bufferSize, false, FileOptions.None)
		{
		}

		// Token: 0x06000D3A RID: 3386 RVA: 0x00036CDC File Offset: 0x00034EDC
		internal FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize, bool isAsync, bool anonymous)
			: this(path, mode, access, share, bufferSize, anonymous, (!isAsync) ? FileOptions.None : FileOptions.Asynchronous)
		{
		}

		// Token: 0x06000D3B RID: 3387 RVA: 0x00036D0C File Offset: 0x00034F0C
		internal FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize, bool anonymous, FileOptions options)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (path.Length == 0)
			{
				throw new ArgumentException("Path is empty");
			}
			share &= ~FileShare.Inheritable;
			if (bufferSize <= 0)
			{
				throw new ArgumentOutOfRangeException("bufferSize", "Positive number required.");
			}
			if (mode < FileMode.CreateNew || mode > FileMode.Append)
			{
				if (anonymous)
				{
					throw new ArgumentException("mode", "Enum value was out of legal range.");
				}
				throw new ArgumentOutOfRangeException("mode", "Enum value was out of legal range.");
			}
			else if (access < FileAccess.Read || access > FileAccess.ReadWrite)
			{
				if (anonymous)
				{
					throw new IsolatedStorageException("Enum value for FileAccess was out of legal range.");
				}
				throw new ArgumentOutOfRangeException("access", "Enum value was out of legal range.");
			}
			else if ((share < FileShare.None) || share > (FileShare.Read | FileShare.Write | FileShare.Delete))
			{
				if (anonymous)
				{
					throw new IsolatedStorageException("Enum value for FileShare was out of legal range.");
				}
				throw new ArgumentOutOfRangeException("share", "Enum value was out of legal range.");
			}
			else
			{
				if (path.IndexOfAny(Path.InvalidPathChars) != -1)
				{
					throw new ArgumentException("Name has invalid chars");
				}
				if (Directory.Exists(path))
				{
					string text = Locale.GetText("Access to the path '{0}' is denied.");
					throw new UnauthorizedAccessException(string.Format(text, this.GetSecureFileName(path, false)));
				}
				if (mode == FileMode.Append && (access & FileAccess.Read) == FileAccess.Read)
				{
					throw new ArgumentException("Append access can be requested only in write-only mode.");
				}
				if ((access & FileAccess.Write) == (FileAccess)0 && mode != FileMode.Open && mode != FileMode.OpenOrCreate)
				{
					string text2 = Locale.GetText("Combining FileMode: {0} with FileAccess: {1} is invalid.");
					throw new ArgumentException(string.Format(text2, access, mode));
				}
				string text3;
				if (Path.DirectorySeparatorChar != '/' && path.IndexOf('/') >= 0)
				{
					text3 = Path.GetDirectoryName(Path.GetFullPath(path));
				}
				else
				{
					text3 = Path.GetDirectoryName(path);
				}
				if (text3.Length > 0)
				{
					string fullPath = Path.GetFullPath(text3);
					if (!Directory.Exists(fullPath))
					{
						string text4 = Locale.GetText("Could not find a part of the path \"{0}\".");
						string text5 = ((!anonymous) ? Path.GetFullPath(path) : text3);
						throw new IsolatedStorageException(string.Format(text4, text5));
					}
				}
				if (access == FileAccess.Read && mode != FileMode.Create && mode != FileMode.OpenOrCreate && mode != FileMode.CreateNew && !File.Exists(path))
				{
					string text6 = Locale.GetText("Could not find file \"{0}\".");
					string secureFileName = this.GetSecureFileName(path);
					throw new IsolatedStorageException(string.Format(text6, secureFileName));
				}
				if (!anonymous)
				{
					this.name = path;
				}
				MonoIOError monoIOError;
				this.handle = MonoIO.Open(path, mode, access, share, options, out monoIOError);
				if (this.handle == MonoIO.InvalidHandle)
				{
					throw MonoIO.GetException(this.GetSecureFileName(path), monoIOError);
				}
				this.access = access;
				this.owner = true;
				this.anonymous = anonymous;
				if (MonoIO.GetFileType(this.handle, out monoIOError) == MonoFileType.Disk)
				{
					this.canseek = true;
					this.async = (options & FileOptions.Asynchronous) != FileOptions.None;
				}
				else
				{
					this.canseek = false;
					this.async = false;
				}
				if (access == FileAccess.Read && this.canseek && bufferSize == 8192)
				{
					long length = this.Length;
					if ((long)bufferSize > length)
					{
						bufferSize = (int)((length >= 1000L) ? length : 1000L);
					}
				}
				this.InitBuffer(bufferSize, false);
				if (mode == FileMode.Append)
				{
					this.Seek(0L, SeekOrigin.End);
					this.append_startpos = this.Position;
				}
				else
				{
					this.append_startpos = 0L;
				}
				return;
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x06000D3C RID: 3388 RVA: 0x0003708C File Offset: 0x0003528C
		public override bool CanRead
		{
			get
			{
				return this.access == FileAccess.Read || this.access == FileAccess.ReadWrite;
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x06000D3D RID: 3389 RVA: 0x000370A8 File Offset: 0x000352A8
		public override bool CanWrite
		{
			get
			{
				return this.access == FileAccess.Write || this.access == FileAccess.ReadWrite;
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000D3E RID: 3390 RVA: 0x000370C4 File Offset: 0x000352C4
		public override bool CanSeek
		{
			get
			{
				return this.canseek;
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000D3F RID: 3391 RVA: 0x000370CC File Offset: 0x000352CC
		public override long Length
		{
			get
			{
				if (this.handle == MonoIO.InvalidHandle)
				{
					throw new ObjectDisposedException("Stream has been closed");
				}
				if (!this.CanSeek)
				{
					throw new NotSupportedException("The stream does not support seeking");
				}
				this.FlushBufferIfDirty();
				MonoIOError monoIOError;
				long length = MonoIO.GetLength(this.handle, out monoIOError);
				if (monoIOError != MonoIOError.ERROR_SUCCESS)
				{
					throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
				}
				return length;
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000D40 RID: 3392 RVA: 0x00037140 File Offset: 0x00035340
		// (set) Token: 0x06000D41 RID: 3393 RVA: 0x00037194 File Offset: 0x00035394
		public override long Position
		{
			get
			{
				if (this.handle == MonoIO.InvalidHandle)
				{
					throw new ObjectDisposedException("Stream has been closed");
				}
				if (!this.CanSeek)
				{
					throw new NotSupportedException("The stream does not support seeking");
				}
				return this.buf_start + (long)this.buf_offset;
			}
			set
			{
				if (this.handle == MonoIO.InvalidHandle)
				{
					throw new ObjectDisposedException("Stream has been closed");
				}
				if (!this.CanSeek)
				{
					throw new NotSupportedException("The stream does not support seeking");
				}
				if (value < 0L)
				{
					throw new ArgumentOutOfRangeException("Attempt to set the position to a negative value");
				}
				this.Seek(value, SeekOrigin.Begin);
			}
		}

		// Token: 0x06000D42 RID: 3394 RVA: 0x000371F4 File Offset: 0x000353F4
		public override int ReadByte()
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (!this.CanRead)
			{
				throw new NotSupportedException("Stream does not support reading");
			}
			if (this.buf_size != 0)
			{
				if (this.buf_offset >= this.buf_length)
				{
					this.RefillBuffer();
					if (this.buf_length == 0)
					{
						return -1;
					}
				}
				return (int)this.buf[this.buf_offset++];
			}
			if (this.ReadData(this.handle, this.buf, 0, 1) == 0)
			{
				return -1;
			}
			return (int)this.buf[0];
		}

		// Token: 0x06000D43 RID: 3395 RVA: 0x000372A4 File Offset: 0x000354A4
		public override void WriteByte(byte value)
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (!this.CanWrite)
			{
				throw new NotSupportedException("Stream does not support writing");
			}
			if (this.buf_offset == this.buf_size)
			{
				this.FlushBuffer();
			}
			if (this.buf_size == 0)
			{
				this.buf[0] = value;
				this.buf_dirty = true;
				this.buf_length = 1;
				this.FlushBuffer();
				return;
			}
			this.buf[this.buf_offset++] = value;
			if (this.buf_offset > this.buf_length)
			{
				this.buf_length = this.buf_offset;
			}
			this.buf_dirty = true;
		}

		// Token: 0x06000D44 RID: 3396 RVA: 0x00037364 File Offset: 0x00035564
		public override int Read([In] [Out] byte[] array, int offset, int count)
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (!this.CanRead)
			{
				throw new NotSupportedException("Stream does not support reading");
			}
			int num = array.Length;
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset", "< 0");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "< 0");
			}
			if (offset > num)
			{
				throw new ArgumentException("destination offset is beyond array size");
			}
			if (offset > num - count)
			{
				throw new ArgumentException("Reading would overrun buffer");
			}
			if (this.async)
			{
				IAsyncResult asyncResult = this.BeginRead(array, offset, count, null, null);
				return this.EndRead(asyncResult);
			}
			return this.ReadInternal(array, offset, count);
		}

		// Token: 0x06000D45 RID: 3397 RVA: 0x00037438 File Offset: 0x00035638
		private int ReadInternal(byte[] dest, int offset, int count)
		{
			int num = 0;
			int num2 = this.ReadSegment(dest, offset, count);
			num += num2;
			count -= num2;
			if (count == 0)
			{
				return num;
			}
			if (count > this.buf_size)
			{
				this.FlushBuffer();
				num2 = this.ReadData(this.handle, dest, offset + num, count);
				this.buf_start += (long)num2;
			}
			else
			{
				this.RefillBuffer();
				num2 = this.ReadSegment(dest, offset + num, count);
			}
			return num + num2;
		}

		// Token: 0x06000D46 RID: 3398 RVA: 0x000374B4 File Offset: 0x000356B4
		public override IAsyncResult BeginRead(byte[] array, int offset, int numBytes, AsyncCallback userCallback, object stateObject)
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (!this.CanRead)
			{
				throw new NotSupportedException("This stream does not support reading");
			}
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (numBytes < 0)
			{
				throw new ArgumentOutOfRangeException("numBytes", "Must be >= 0");
			}
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset", "Must be >= 0");
			}
			if (numBytes > array.Length - offset)
			{
				throw new ArgumentException("Buffer too small. numBytes/offset wrong.");
			}
			if (!this.async)
			{
				return base.BeginRead(array, offset, numBytes, userCallback, stateObject);
			}
			FileStream.ReadDelegate readDelegate = new FileStream.ReadDelegate(this.ReadInternal);
			return readDelegate.BeginInvoke(array, offset, numBytes, userCallback, stateObject);
		}

		// Token: 0x06000D47 RID: 3399 RVA: 0x00037580 File Offset: 0x00035780
		public override int EndRead(IAsyncResult asyncResult)
		{
			if (asyncResult == null)
			{
				throw new ArgumentNullException("asyncResult");
			}
			if (!this.async)
			{
				return base.EndRead(asyncResult);
			}
			AsyncResult asyncResult2 = asyncResult as AsyncResult;
			if (asyncResult2 == null)
			{
				throw new ArgumentException("Invalid IAsyncResult", "asyncResult");
			}
			FileStream.ReadDelegate readDelegate = asyncResult2.AsyncDelegate as FileStream.ReadDelegate;
			if (readDelegate == null)
			{
				throw new ArgumentException("Invalid IAsyncResult", "asyncResult");
			}
			return readDelegate.EndInvoke(asyncResult);
		}

		// Token: 0x06000D48 RID: 3400 RVA: 0x000375F8 File Offset: 0x000357F8
		public override void Write(byte[] array, int offset, int count)
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset", "< 0");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "< 0");
			}
			if (offset > array.Length - count)
			{
				throw new ArgumentException("Reading would overrun buffer");
			}
			if (!this.CanWrite)
			{
				throw new NotSupportedException("Stream does not support writing");
			}
			if (this.async)
			{
				IAsyncResult asyncResult = this.BeginWrite(array, offset, count, null, null);
				this.EndWrite(asyncResult);
				return;
			}
			this.WriteInternal(array, offset, count);
		}

		// Token: 0x06000D49 RID: 3401 RVA: 0x000376B8 File Offset: 0x000358B8
		private void WriteInternal(byte[] src, int offset, int count)
		{
			if (count > this.buf_size)
			{
				this.FlushBuffer();
				int i = count;
				while (i > 0)
				{
					MonoIOError monoIOError;
					int num = MonoIO.Write(this.handle, src, offset, i, out monoIOError);
					if (monoIOError != MonoIOError.ERROR_SUCCESS)
					{
						throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
					}
					i -= num;
					offset += num;
				}
				this.buf_start += (long)count;
			}
			else
			{
				int num2 = 0;
				while (count > 0)
				{
					int num3 = this.WriteSegment(src, offset + num2, count);
					num2 += num3;
					count -= num3;
					if (count == 0)
					{
						break;
					}
					this.FlushBuffer();
				}
			}
		}

		// Token: 0x06000D4A RID: 3402 RVA: 0x00037764 File Offset: 0x00035964
		public override IAsyncResult BeginWrite(byte[] array, int offset, int numBytes, AsyncCallback userCallback, object stateObject)
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (!this.CanWrite)
			{
				throw new NotSupportedException("This stream does not support writing");
			}
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (numBytes < 0)
			{
				throw new ArgumentOutOfRangeException("numBytes", "Must be >= 0");
			}
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset", "Must be >= 0");
			}
			if (numBytes > array.Length - offset)
			{
				throw new ArgumentException("array too small. numBytes/offset wrong.");
			}
			if (!this.async)
			{
				return base.BeginWrite(array, offset, numBytes, userCallback, stateObject);
			}
			FileStreamAsyncResult fileStreamAsyncResult = new FileStreamAsyncResult(userCallback, stateObject);
			fileStreamAsyncResult.BytesRead = -1;
			fileStreamAsyncResult.Count = numBytes;
			fileStreamAsyncResult.OriginalCount = numBytes;
			if (this.buf_dirty)
			{
				MemoryStream memoryStream = new MemoryStream();
				this.FlushBuffer(memoryStream);
				memoryStream.Write(array, offset, numBytes);
				offset = 0;
				numBytes = (int)memoryStream.Length;
			}
			FileStream.WriteDelegate writeDelegate = new FileStream.WriteDelegate(this.WriteInternal);
			return writeDelegate.BeginInvoke(array, offset, numBytes, userCallback, stateObject);
		}

		// Token: 0x06000D4B RID: 3403 RVA: 0x0003787C File Offset: 0x00035A7C
		public override void EndWrite(IAsyncResult asyncResult)
		{
			if (asyncResult == null)
			{
				throw new ArgumentNullException("asyncResult");
			}
			if (!this.async)
			{
				base.EndWrite(asyncResult);
				return;
			}
			AsyncResult asyncResult2 = asyncResult as AsyncResult;
			if (asyncResult2 == null)
			{
				throw new ArgumentException("Invalid IAsyncResult", "asyncResult");
			}
			FileStream.WriteDelegate writeDelegate = asyncResult2.AsyncDelegate as FileStream.WriteDelegate;
			if (writeDelegate == null)
			{
				throw new ArgumentException("Invalid IAsyncResult", "asyncResult");
			}
			writeDelegate.EndInvoke(asyncResult);
		}

		// Token: 0x06000D4C RID: 3404 RVA: 0x000378F4 File Offset: 0x00035AF4
		public override long Seek(long offset, SeekOrigin origin)
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (!this.CanSeek)
			{
				throw new NotSupportedException("The stream does not support seeking");
			}
			long num;
			switch (origin)
			{
			case SeekOrigin.Begin:
				num = offset;
				break;
			case SeekOrigin.Current:
				num = this.Position + offset;
				break;
			case SeekOrigin.End:
				num = this.Length + offset;
				break;
			default:
				throw new ArgumentException("origin", "Invalid SeekOrigin");
			}
			if (num < 0L)
			{
				throw new IOException("Attempted to Seek before the beginning of the stream");
			}
			if (num < this.append_startpos)
			{
				throw new IOException("Can't seek back over pre-existing data in append mode");
			}
			this.FlushBuffer();
			MonoIOError monoIOError;
			this.buf_start = MonoIO.Seek(this.handle, num, SeekOrigin.Begin, out monoIOError);
			if (monoIOError != MonoIOError.ERROR_SUCCESS)
			{
				throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
			}
			return this.buf_start;
		}

		// Token: 0x06000D4D RID: 3405 RVA: 0x000379E8 File Offset: 0x00035BE8
		public override void SetLength(long value)
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			if (!this.CanSeek)
			{
				throw new NotSupportedException("The stream does not support seeking");
			}
			if (!this.CanWrite)
			{
				throw new NotSupportedException("The stream does not support writing");
			}
			if (value < 0L)
			{
				throw new ArgumentOutOfRangeException("value is less than 0");
			}
			this.Flush();
			MonoIOError monoIOError;
			MonoIO.SetLength(this.handle, value, out monoIOError);
			if (monoIOError != MonoIOError.ERROR_SUCCESS)
			{
				throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
			}
			if (this.Position > value)
			{
				this.Position = value;
			}
		}

		// Token: 0x06000D4E RID: 3406 RVA: 0x00037A98 File Offset: 0x00035C98
		public override void Flush()
		{
			if (this.handle == MonoIO.InvalidHandle)
			{
				throw new ObjectDisposedException("Stream has been closed");
			}
			this.FlushBuffer();
		}

		// Token: 0x06000D4F RID: 3407 RVA: 0x00037AC0 File Offset: 0x00035CC0
		~FileStream()
		{
			this.Dispose(false);
		}

		// Token: 0x06000D50 RID: 3408 RVA: 0x00037AF0 File Offset: 0x00035CF0
		protected override void Dispose(bool disposing)
		{
			Exception ex = null;
			if (this.handle != MonoIO.InvalidHandle)
			{
				try
				{
					this.FlushBuffer();
				}
				catch (Exception ex2)
				{
					ex = ex2;
				}
				if (this.owner)
				{
					MonoIOError monoIOError;
					MonoIO.Close(this.handle, out monoIOError);
					if (monoIOError != MonoIOError.ERROR_SUCCESS)
					{
						throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
					}
					this.handle = MonoIO.InvalidHandle;
				}
			}
			this.canseek = false;
			this.access = (FileAccess)0;
			if (disposing)
			{
				this.buf = null;
			}
			if (disposing)
			{
				GC.SuppressFinalize(this);
			}
			if (ex != null)
			{
				throw ex;
			}
		}

		// Token: 0x06000D51 RID: 3409 RVA: 0x00037BA4 File Offset: 0x00035DA4
		private int ReadSegment(byte[] dest, int dest_offset, int count)
		{
			if (count > this.buf_length - this.buf_offset)
			{
				count = this.buf_length - this.buf_offset;
			}
			if (count > 0)
			{
				Buffer.BlockCopy(this.buf, this.buf_offset, dest, dest_offset, count);
				this.buf_offset += count;
			}
			return count;
		}

		// Token: 0x06000D52 RID: 3410 RVA: 0x00037C00 File Offset: 0x00035E00
		private int WriteSegment(byte[] src, int src_offset, int count)
		{
			if (count > this.buf_size - this.buf_offset)
			{
				count = this.buf_size - this.buf_offset;
			}
			if (count > 0)
			{
				Buffer.BlockCopy(src, src_offset, this.buf, this.buf_offset, count);
				this.buf_offset += count;
				if (this.buf_offset > this.buf_length)
				{
					this.buf_length = this.buf_offset;
				}
				this.buf_dirty = true;
			}
			return count;
		}

		// Token: 0x06000D53 RID: 3411 RVA: 0x00037C80 File Offset: 0x00035E80
		private void FlushBuffer(Stream st)
		{
			if (this.buf_dirty)
			{
				if (this.CanSeek)
				{
					MonoIOError monoIOError;
					MonoIO.Seek(this.handle, this.buf_start, SeekOrigin.Begin, out monoIOError);
					if (monoIOError != MonoIOError.ERROR_SUCCESS)
					{
						throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
					}
				}
				if (st == null)
				{
					MonoIOError monoIOError;
					MonoIO.Write(this.handle, this.buf, 0, this.buf_length, out monoIOError);
					if (monoIOError != MonoIOError.ERROR_SUCCESS)
					{
						throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
					}
				}
				else
				{
					st.Write(this.buf, 0, this.buf_length);
				}
			}
			this.buf_start += (long)this.buf_offset;
			this.buf_offset = (this.buf_length = 0);
			this.buf_dirty = false;
		}

		// Token: 0x06000D54 RID: 3412 RVA: 0x00037D50 File Offset: 0x00035F50
		private void FlushBuffer()
		{
			this.FlushBuffer(null);
		}

		// Token: 0x06000D55 RID: 3413 RVA: 0x00037D5C File Offset: 0x00035F5C
		private void FlushBufferIfDirty()
		{
			if (this.buf_dirty)
			{
				this.FlushBuffer(null);
			}
		}

		// Token: 0x06000D56 RID: 3414 RVA: 0x00037D70 File Offset: 0x00035F70
		private void RefillBuffer()
		{
			this.FlushBuffer(null);
			this.buf_length = this.ReadData(this.handle, this.buf, 0, this.buf_size);
		}

		// Token: 0x06000D57 RID: 3415 RVA: 0x00037D98 File Offset: 0x00035F98
		private int ReadData(IntPtr handle, byte[] buf, int offset, int count)
		{
			MonoIOError monoIOError;
			int num = MonoIO.Read(handle, buf, offset, count, out monoIOError);
			if (monoIOError == MonoIOError.ERROR_BROKEN_PIPE)
			{
				num = 0;
			}
			else if (monoIOError != MonoIOError.ERROR_SUCCESS)
			{
				throw MonoIO.GetException(this.GetSecureFileName(this.name), monoIOError);
			}
			if (num == -1)
			{
				throw new IOException();
			}
			return num;
		}

		// Token: 0x06000D58 RID: 3416 RVA: 0x00037DEC File Offset: 0x00035FEC
		private void InitBuffer(int size, bool noBuffering)
		{
			if (noBuffering)
			{
				size = 0;
				this.buf = new byte[1];
			}
			else
			{
				if (size <= 0)
				{
					throw new ArgumentOutOfRangeException("bufferSize", "Positive number required.");
				}
				if (size < 8)
				{
					size = 8;
				}
				this.buf = new byte[size];
			}
			this.buf_size = size;
			this.buf_start = 0L;
			this.buf_offset = (this.buf_length = 0);
			this.buf_dirty = false;
		}

		// Token: 0x06000D59 RID: 3417 RVA: 0x00037E68 File Offset: 0x00036068
		private string GetSecureFileName(string filename)
		{
			return (!this.anonymous) ? Path.GetFullPath(filename) : Path.GetFileName(filename);
		}

		// Token: 0x06000D5A RID: 3418 RVA: 0x00037E88 File Offset: 0x00036088
		private string GetSecureFileName(string filename, bool full)
		{
			return (!this.anonymous) ? ((!full) ? filename : Path.GetFullPath(filename)) : Path.GetFileName(filename);
		}

		// Token: 0x04000568 RID: 1384
		internal const int DefaultBufferSize = 8192;

		// Token: 0x04000569 RID: 1385
		private FileAccess access;

		// Token: 0x0400056A RID: 1386
		private bool owner;

		// Token: 0x0400056B RID: 1387
		private bool async;

		// Token: 0x0400056C RID: 1388
		private bool canseek;

		// Token: 0x0400056D RID: 1389
		private long append_startpos;

		// Token: 0x0400056E RID: 1390
		private bool anonymous;

		// Token: 0x0400056F RID: 1391
		private byte[] buf;

		// Token: 0x04000570 RID: 1392
		private int buf_size;

		// Token: 0x04000571 RID: 1393
		private int buf_length;

		// Token: 0x04000572 RID: 1394
		private int buf_offset;

		// Token: 0x04000573 RID: 1395
		private bool buf_dirty;

		// Token: 0x04000574 RID: 1396
		private long buf_start;

		// Token: 0x04000575 RID: 1397
		private string name = "[Unknown]";

		// Token: 0x04000576 RID: 1398
		private IntPtr handle;

		// Token: 0x04000577 RID: 1399
		private SafeFileHandle safeHandle;

		// Token: 0x02000152 RID: 338
		// (Invoke) Token: 0x06000D5C RID: 3420
		private delegate int ReadDelegate(byte[] buffer, int offset, int count);

		// Token: 0x02000153 RID: 339
		// (Invoke) Token: 0x06000D60 RID: 3424
		private delegate void WriteDelegate(byte[] buffer, int offset, int count);
	}
}
