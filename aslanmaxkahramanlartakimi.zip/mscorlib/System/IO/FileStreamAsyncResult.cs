﻿using System;
using System.Threading;

namespace System.IO
{
	// Token: 0x02000154 RID: 340
	internal class FileStreamAsyncResult : IAsyncResult
	{
		// Token: 0x06000D63 RID: 3427 RVA: 0x00037EB4 File Offset: 0x000360B4
		public FileStreamAsyncResult(AsyncCallback cb, object state)
		{
			this.state = state;
			this.realcb = cb;
			if (this.realcb != null)
			{
				this.cb = new AsyncCallback(FileStreamAsyncResult.CBWrapper);
			}
			this.wh = new ManualResetEvent(false);
		}

		// Token: 0x06000D64 RID: 3428 RVA: 0x00037EF4 File Offset: 0x000360F4
		private static void CBWrapper(IAsyncResult ares)
		{
			FileStreamAsyncResult fileStreamAsyncResult = (FileStreamAsyncResult)ares;
			fileStreamAsyncResult.realcb.BeginInvoke(ares, null, null);
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000D65 RID: 3429 RVA: 0x00037F18 File Offset: 0x00036118
		public object AsyncState
		{
			get
			{
				return this.state;
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000D66 RID: 3430 RVA: 0x00037F20 File Offset: 0x00036120
		public WaitHandle AsyncWaitHandle
		{
			get
			{
				return this.wh;
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000D67 RID: 3431 RVA: 0x00037F28 File Offset: 0x00036128
		public bool IsCompleted
		{
			get
			{
				return this.completed;
			}
		}

		// Token: 0x04000578 RID: 1400
		private object state;

		// Token: 0x04000579 RID: 1401
		private bool completed;

		// Token: 0x0400057A RID: 1402
		private bool done;

		// Token: 0x0400057B RID: 1403
		private Exception exc;

		// Token: 0x0400057C RID: 1404
		private ManualResetEvent wh;

		// Token: 0x0400057D RID: 1405
		private AsyncCallback cb;

		// Token: 0x0400057E RID: 1406
		private bool completedSynch;

		// Token: 0x0400057F RID: 1407
		public byte[] Buffer;

		// Token: 0x04000580 RID: 1408
		public int Offset;

		// Token: 0x04000581 RID: 1409
		public int Count;

		// Token: 0x04000582 RID: 1410
		public int OriginalCount;

		// Token: 0x04000583 RID: 1411
		public int BytesRead;

		// Token: 0x04000584 RID: 1412
		private AsyncCallback realcb;
	}
}
