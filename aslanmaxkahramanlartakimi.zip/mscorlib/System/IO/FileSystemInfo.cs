﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.IO
{
	// Token: 0x02000155 RID: 341
	[ComVisible(true)]
	[Serializable]
	public abstract class FileSystemInfo : MarshalByRefObject, ISerializable
	{
		// Token: 0x06000D68 RID: 3432 RVA: 0x00037F30 File Offset: 0x00036130
		protected FileSystemInfo()
		{
			this.valid = false;
			this.FullPath = null;
		}

		// Token: 0x06000D69 RID: 3433 RVA: 0x00037F48 File Offset: 0x00036148
		protected FileSystemInfo(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			this.FullPath = info.GetString("FullPath");
			this.OriginalPath = info.GetString("OriginalPath");
		}

		// Token: 0x06000D6A RID: 3434 RVA: 0x00037F84 File Offset: 0x00036184
		[ComVisible(false)]
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("OriginalPath", this.OriginalPath, typeof(string));
			info.AddValue("FullPath", this.FullPath, typeof(string));
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000D6B RID: 3435
		public abstract bool Exists { get; }

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000D6C RID: 3436 RVA: 0x00037FBC File Offset: 0x000361BC
		public virtual string FullName
		{
			get
			{
				return this.FullPath;
			}
		}

		// Token: 0x06000D6D RID: 3437 RVA: 0x00037FC4 File Offset: 0x000361C4
		internal void Refresh(bool force)
		{
			if (this.valid && !force)
			{
				return;
			}
			MonoIOError monoIOError;
			MonoIO.GetFileStat(this.FullName, out this.stat, out monoIOError);
			this.valid = true;
			this.InternalRefresh();
		}

		// Token: 0x06000D6E RID: 3438 RVA: 0x00038004 File Offset: 0x00036204
		internal virtual void InternalRefresh()
		{
		}

		// Token: 0x06000D6F RID: 3439 RVA: 0x00038008 File Offset: 0x00036208
		internal void CheckPath(string path)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (path.Length == 0)
			{
				throw new ArgumentException("An empty file name is not valid.");
			}
			if (path.IndexOfAny(Path.InvalidPathChars) != -1)
			{
				throw new ArgumentException("Illegal characters in path.");
			}
		}

		// Token: 0x04000585 RID: 1413
		protected string FullPath;

		// Token: 0x04000586 RID: 1414
		protected string OriginalPath;

		// Token: 0x04000587 RID: 1415
		internal MonoIOStat stat;

		// Token: 0x04000588 RID: 1416
		internal bool valid;
	}
}
