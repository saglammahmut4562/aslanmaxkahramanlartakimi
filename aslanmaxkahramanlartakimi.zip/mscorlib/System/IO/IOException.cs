﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.IO
{
	// Token: 0x02000156 RID: 342
	[ComVisible(true)]
	[Serializable]
	public class IOException : SystemException
	{
		// Token: 0x06000D70 RID: 3440 RVA: 0x00038058 File Offset: 0x00036258
		public IOException()
			: base("I/O Error")
		{
		}

		// Token: 0x06000D71 RID: 3441 RVA: 0x00038068 File Offset: 0x00036268
		public IOException(string message)
			: base(message)
		{
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x00038074 File Offset: 0x00036274
		public IOException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06000D73 RID: 3443 RVA: 0x00038080 File Offset: 0x00036280
		protected IOException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x06000D74 RID: 3444 RVA: 0x0003808C File Offset: 0x0003628C
		public IOException(string message, int hresult)
			: base(message)
		{
			base.HResult = hresult;
		}
	}
}
