﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.IO.IsolatedStorage
{
	// Token: 0x02000157 RID: 343
	[ComVisible(true)]
	[Serializable]
	public class IsolatedStorageException : Exception
	{
		// Token: 0x06000D75 RID: 3445 RVA: 0x0003809C File Offset: 0x0003629C
		public IsolatedStorageException()
			: base(Locale.GetText("An Isolated storage operation failed."))
		{
		}

		// Token: 0x06000D76 RID: 3446 RVA: 0x000380B0 File Offset: 0x000362B0
		public IsolatedStorageException(string message)
			: base(message)
		{
		}

		// Token: 0x06000D77 RID: 3447 RVA: 0x000380BC File Offset: 0x000362BC
		protected IsolatedStorageException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
