﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x02000158 RID: 344
	[MonoTODO("Serialization format not compatible with .NET")]
	[ComVisible(true)]
	[Serializable]
	public class MemoryStream : Stream
	{
		// Token: 0x06000D78 RID: 3448 RVA: 0x000380C8 File Offset: 0x000362C8
		public MemoryStream()
			: this(0)
		{
		}

		// Token: 0x06000D79 RID: 3449 RVA: 0x000380D4 File Offset: 0x000362D4
		public MemoryStream(int capacity)
		{
			if (capacity < 0)
			{
				throw new ArgumentOutOfRangeException("capacity");
			}
			this.canWrite = true;
			this.capacity = capacity;
			this.internalBuffer = new byte[capacity];
			this.expandable = true;
			this.allowGetBuffer = true;
		}

		// Token: 0x06000D7A RID: 3450 RVA: 0x00038124 File Offset: 0x00036324
		public MemoryStream(byte[] buffer)
		{
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			this.InternalConstructor(buffer, 0, buffer.Length, true, false);
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x0003814C File Offset: 0x0003634C
		private void InternalConstructor(byte[] buffer, int index, int count, bool writable, bool publicallyVisible)
		{
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (index < 0 || count < 0)
			{
				throw new ArgumentOutOfRangeException("index or count is less than 0.");
			}
			if (buffer.Length - index < count)
			{
				throw new ArgumentException("index+count", "The size of the buffer is less than index + count.");
			}
			this.canWrite = writable;
			this.internalBuffer = buffer;
			this.capacity = count + index;
			this.length = this.capacity;
			this.position = index;
			this.initialIndex = index;
			this.allowGetBuffer = publicallyVisible;
			this.expandable = false;
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x000381E0 File Offset: 0x000363E0
		private void CheckIfClosedThrowDisposed()
		{
			if (this.streamClosed)
			{
				throw new ObjectDisposedException("MemoryStream");
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000D7D RID: 3453 RVA: 0x000381F8 File Offset: 0x000363F8
		public override bool CanRead
		{
			get
			{
				return !this.streamClosed;
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000D7E RID: 3454 RVA: 0x00038204 File Offset: 0x00036404
		public override bool CanSeek
		{
			get
			{
				return !this.streamClosed;
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000D7F RID: 3455 RVA: 0x00038210 File Offset: 0x00036410
		public override bool CanWrite
		{
			get
			{
				return !this.streamClosed && this.canWrite;
			}
		}

		// Token: 0x1700020A RID: 522
		// (set) Token: 0x06000D80 RID: 3456 RVA: 0x00038228 File Offset: 0x00036428
		public virtual int Capacity
		{
			set
			{
				this.CheckIfClosedThrowDisposed();
				if (value == this.capacity)
				{
					return;
				}
				if (!this.expandable)
				{
					throw new NotSupportedException("Cannot expand this MemoryStream");
				}
				if (value < 0 || value < this.length)
				{
					throw new ArgumentOutOfRangeException("value", string.Concat(new object[] { "New capacity cannot be negative or less than the current capacity ", value, " ", this.capacity }));
				}
				byte[] array = null;
				if (value != 0)
				{
					array = new byte[value];
					Buffer.BlockCopy(this.internalBuffer, 0, array, 0, this.length);
				}
				this.dirty_bytes = 0;
				this.internalBuffer = array;
				this.capacity = value;
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000D81 RID: 3457 RVA: 0x000382E8 File Offset: 0x000364E8
		public override long Length
		{
			get
			{
				this.CheckIfClosedThrowDisposed();
				return (long)(this.length - this.initialIndex);
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x06000D82 RID: 3458 RVA: 0x00038300 File Offset: 0x00036500
		// (set) Token: 0x06000D83 RID: 3459 RVA: 0x00038318 File Offset: 0x00036518
		public override long Position
		{
			get
			{
				this.CheckIfClosedThrowDisposed();
				return (long)(this.position - this.initialIndex);
			}
			set
			{
				this.CheckIfClosedThrowDisposed();
				if (value < 0L)
				{
					throw new ArgumentOutOfRangeException("value", "Position cannot be negative");
				}
				if (value > 2147483647L)
				{
					throw new ArgumentOutOfRangeException("value", "Position must be non-negative and less than 2^31 - 1 - origin");
				}
				this.position = this.initialIndex + (int)value;
			}
		}

		// Token: 0x06000D84 RID: 3460 RVA: 0x00038370 File Offset: 0x00036570
		protected override void Dispose(bool disposing)
		{
			this.streamClosed = true;
			this.expandable = false;
		}

		// Token: 0x06000D85 RID: 3461 RVA: 0x00038380 File Offset: 0x00036580
		public override void Flush()
		{
		}

		// Token: 0x06000D86 RID: 3462 RVA: 0x00038384 File Offset: 0x00036584
		public virtual byte[] GetBuffer()
		{
			if (!this.allowGetBuffer)
			{
				throw new UnauthorizedAccessException();
			}
			return this.internalBuffer;
		}

		// Token: 0x06000D87 RID: 3463 RVA: 0x000383A0 File Offset: 0x000365A0
		public override int Read([In] [Out] byte[] buffer, int offset, int count)
		{
			this.CheckIfClosedThrowDisposed();
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (offset < 0 || count < 0)
			{
				throw new ArgumentOutOfRangeException("offset or count less than zero.");
			}
			if (buffer.Length - offset < count)
			{
				throw new ArgumentException("offset+count", "The size of the buffer is less than offset + count.");
			}
			if (this.position >= this.length || count == 0)
			{
				return 0;
			}
			if (this.position > this.length - count)
			{
				count = this.length - this.position;
			}
			Buffer.BlockCopy(this.internalBuffer, this.position, buffer, offset, count);
			this.position += count;
			return count;
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x00038458 File Offset: 0x00036658
		public override int ReadByte()
		{
			this.CheckIfClosedThrowDisposed();
			if (this.position >= this.length)
			{
				return -1;
			}
			return (int)this.internalBuffer[this.position++];
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x00038498 File Offset: 0x00036698
		public override long Seek(long offset, SeekOrigin loc)
		{
			this.CheckIfClosedThrowDisposed();
			if (offset > 2147483647L)
			{
				throw new ArgumentOutOfRangeException("Offset out of range. " + offset);
			}
			int num;
			switch (loc)
			{
			case SeekOrigin.Begin:
				if (offset < 0L)
				{
					throw new IOException("Attempted to seek before start of MemoryStream.");
				}
				num = this.initialIndex;
				break;
			case SeekOrigin.Current:
				num = this.position;
				break;
			case SeekOrigin.End:
				num = this.length;
				break;
			default:
				throw new ArgumentException("loc", "Invalid SeekOrigin");
			}
			num += (int)offset;
			if (num < this.initialIndex)
			{
				throw new IOException("Attempted to seek before start of MemoryStream.");
			}
			this.position = num;
			return (long)this.position;
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x00038558 File Offset: 0x00036758
		private int CalculateNewCapacity(int minimum)
		{
			if (minimum < 256)
			{
				minimum = 256;
			}
			if (minimum < this.capacity * 2)
			{
				minimum = this.capacity * 2;
			}
			return minimum;
		}

		// Token: 0x06000D8B RID: 3467 RVA: 0x00038588 File Offset: 0x00036788
		private void Expand(int newSize)
		{
			if (newSize > this.capacity)
			{
				this.Capacity = this.CalculateNewCapacity(newSize);
			}
			else if (this.dirty_bytes > 0)
			{
				Array.Clear(this.internalBuffer, this.length, this.dirty_bytes);
				this.dirty_bytes = 0;
			}
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x000385E0 File Offset: 0x000367E0
		public override void SetLength(long value)
		{
			if (!this.expandable && value > (long)this.capacity)
			{
				throw new NotSupportedException("Expanding this MemoryStream is not supported");
			}
			this.CheckIfClosedThrowDisposed();
			if (!this.canWrite)
			{
				throw new NotSupportedException(Locale.GetText("Cannot write to this MemoryStream"));
			}
			if (value < 0L || value + (long)this.initialIndex > 2147483647L)
			{
				throw new ArgumentOutOfRangeException();
			}
			int num = (int)value + this.initialIndex;
			if (num > this.length)
			{
				this.Expand(num);
			}
			else if (num < this.length)
			{
				this.dirty_bytes += this.length - num;
			}
			this.length = num;
			if (this.position > this.length)
			{
				this.position = this.length;
			}
		}

		// Token: 0x06000D8D RID: 3469 RVA: 0x000386BC File Offset: 0x000368BC
		public virtual byte[] ToArray()
		{
			int num = this.length - this.initialIndex;
			byte[] array = new byte[num];
			if (this.internalBuffer != null)
			{
				Buffer.BlockCopy(this.internalBuffer, this.initialIndex, array, 0, num);
			}
			return array;
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x00038700 File Offset: 0x00036900
		public override void Write(byte[] buffer, int offset, int count)
		{
			this.CheckIfClosedThrowDisposed();
			if (!this.canWrite)
			{
				throw new NotSupportedException("Cannot write to this stream.");
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (offset < 0 || count < 0)
			{
				throw new ArgumentOutOfRangeException();
			}
			if (buffer.Length - offset < count)
			{
				throw new ArgumentException("offset+count", "The size of the buffer is less than offset + count.");
			}
			if (this.position > this.length - count)
			{
				this.Expand(this.position + count);
			}
			Buffer.BlockCopy(buffer, offset, this.internalBuffer, this.position, count);
			this.position += count;
			if (this.position >= this.length)
			{
				this.length = this.position;
			}
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x000387CC File Offset: 0x000369CC
		public override void WriteByte(byte value)
		{
			this.CheckIfClosedThrowDisposed();
			if (!this.canWrite)
			{
				throw new NotSupportedException("Cannot write to this stream.");
			}
			if (this.position >= this.length)
			{
				this.Expand(this.position + 1);
				this.length = this.position + 1;
			}
			this.internalBuffer[this.position++] = value;
		}

		// Token: 0x04000589 RID: 1417
		private bool canWrite;

		// Token: 0x0400058A RID: 1418
		private bool allowGetBuffer;

		// Token: 0x0400058B RID: 1419
		private int capacity;

		// Token: 0x0400058C RID: 1420
		private int length;

		// Token: 0x0400058D RID: 1421
		private byte[] internalBuffer;

		// Token: 0x0400058E RID: 1422
		private int initialIndex;

		// Token: 0x0400058F RID: 1423
		private bool expandable;

		// Token: 0x04000590 RID: 1424
		private bool streamClosed;

		// Token: 0x04000591 RID: 1425
		private int position;

		// Token: 0x04000592 RID: 1426
		private int dirty_bytes;
	}
}
