﻿using System;

namespace System.IO
{
	// Token: 0x02000159 RID: 345
	internal enum MonoFileType
	{
		// Token: 0x04000594 RID: 1428
		Unknown,
		// Token: 0x04000595 RID: 1429
		Disk,
		// Token: 0x04000596 RID: 1430
		Char,
		// Token: 0x04000597 RID: 1431
		Pipe,
		// Token: 0x04000598 RID: 1432
		Remote = 32768
	}
}
