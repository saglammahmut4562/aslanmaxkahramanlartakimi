﻿using System;
using System.IO.IsolatedStorage;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x0200015A RID: 346
	internal sealed class MonoIO
	{
		// Token: 0x06000D91 RID: 3473 RVA: 0x00038850 File Offset: 0x00036A50
		public static Exception GetException(MonoIOError error)
		{
			if (error == MonoIOError.ERROR_ACCESS_DENIED)
			{
				return new UnauthorizedAccessException("Access to the path is denied.");
			}
			if (error != MonoIOError.ERROR_FILE_EXISTS)
			{
				return MonoIO.GetException(string.Empty, error);
			}
			string text = "Cannot create a file that already exist.";
			return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x000388A0 File Offset: 0x00036AA0
		public static Exception GetException(string path, MonoIOError error)
		{
			switch (error)
			{
			case MonoIOError.ERROR_FILE_NOT_FOUND:
			{
				string text = string.Format("Could not find file \"{0}\"", path);
				return new IsolatedStorageException(text);
			}
			case MonoIOError.ERROR_PATH_NOT_FOUND:
			{
				string text = string.Format("Could not find a part of the path \"{0}\"", path);
				return new IsolatedStorageException(text);
			}
			case MonoIOError.ERROR_TOO_MANY_OPEN_FILES:
				return new IOException("Too many open files", (int)((MonoIOError)(-2147024896) | error));
			case MonoIOError.ERROR_ACCESS_DENIED:
			{
				string text = string.Format("Access to the path \"{0}\" is denied.", path);
				return new UnauthorizedAccessException(text);
			}
			case MonoIOError.ERROR_INVALID_HANDLE:
			{
				string text = string.Format("Invalid handle to path \"{0}\"", path);
				return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
			}
			default:
				switch (error)
				{
				case MonoIOError.ERROR_WRITE_FAULT:
				{
					string text = string.Format("Write fault on path {0}", path);
					return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
				}
				default:
					switch (error)
					{
					case MonoIOError.ERROR_INVALID_DRIVE:
					{
						string text = string.Format("Could not find the drive  '{0}'. The drive might not be ready or might not be mapped.", path);
						return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
					}
					default:
						switch (error)
						{
						case MonoIOError.ERROR_FILE_EXISTS:
						{
							string text = string.Format("Could not create file \"{0}\". File already exists.", path);
							return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
						}
						default:
							if (error == MonoIOError.ERROR_HANDLE_DISK_FULL)
							{
								string text = string.Format("Disk full. Path {0}", path);
								return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
							}
							if (error == MonoIOError.ERROR_INVALID_PARAMETER)
							{
								string text = string.Format("Invalid parameter", new object[0]);
								return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
							}
							if (error == MonoIOError.ERROR_DIR_NOT_EMPTY)
							{
								string text = string.Format("Directory {0} is not empty", path);
								return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
							}
							if (error == MonoIOError.ERROR_FILENAME_EXCED_RANGE)
							{
								string text = string.Format("Path is too long. Path: {0}", path);
								return new PathTooLongException(text);
							}
							if (error != MonoIOError.ERROR_ENCRYPTION_FAILED)
							{
								string text = string.Format("Win32 IO returned {0}. Path: {1}", error, path);
								return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
							}
							return new IOException("Encryption failed", (int)((MonoIOError)(-2147024896) | error));
						case MonoIOError.ERROR_CANNOT_MAKE:
						{
							string text = string.Format("Path {0} is a directory", path);
							return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
						}
						}
						break;
					case MonoIOError.ERROR_NOT_SAME_DEVICE:
					{
						string text = "Source and destination are not on the same device";
						return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
					}
					}
					break;
				case MonoIOError.ERROR_SHARING_VIOLATION:
				{
					string text = string.Format("Sharing violation on path {0}", path);
					return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
				}
				case MonoIOError.ERROR_LOCK_VIOLATION:
				{
					string text = string.Format("Lock violation on path {0}", path);
					return new IOException(text, (int)((MonoIOError)(-2147024896) | error));
				}
				}
				break;
			}
		}

		// Token: 0x06000D93 RID: 3475
		[MethodImpl(4096)]
		public static extern bool CreateDirectory(string path, out MonoIOError error);

		// Token: 0x06000D94 RID: 3476
		[MethodImpl(4096)]
		public static extern string[] GetFileSystemEntries(string path, string path_with_pattern, int attrs, int mask, out MonoIOError error);

		// Token: 0x06000D95 RID: 3477
		[MethodImpl(4096)]
		public static extern string GetCurrentDirectory(out MonoIOError error);

		// Token: 0x06000D96 RID: 3478
		[MethodImpl(4096)]
		public static extern bool SetCurrentDirectory(string path, out MonoIOError error);

		// Token: 0x06000D97 RID: 3479
		[MethodImpl(4096)]
		public static extern bool CopyFile(string path, string dest, bool overwrite, out MonoIOError error);

		// Token: 0x06000D98 RID: 3480
		[MethodImpl(4096)]
		public static extern bool DeleteFile(string path, out MonoIOError error);

		// Token: 0x06000D99 RID: 3481
		[MethodImpl(4096)]
		public static extern FileAttributes GetFileAttributes(string path, out MonoIOError error);

		// Token: 0x06000D9A RID: 3482
		[MethodImpl(4096)]
		public static extern MonoFileType GetFileType(IntPtr handle, out MonoIOError error);

		// Token: 0x06000D9B RID: 3483 RVA: 0x00038AF4 File Offset: 0x00036CF4
		public static bool Exists(string path, out MonoIOError error)
		{
			FileAttributes fileAttributes = MonoIO.GetFileAttributes(path, out error);
			return fileAttributes != MonoIO.InvalidFileAttributes;
		}

		// Token: 0x06000D9C RID: 3484 RVA: 0x00038B18 File Offset: 0x00036D18
		public static bool ExistsFile(string path, out MonoIOError error)
		{
			FileAttributes fileAttributes = MonoIO.GetFileAttributes(path, out error);
			return fileAttributes != MonoIO.InvalidFileAttributes && (fileAttributes & FileAttributes.Directory) == (FileAttributes)0;
		}

		// Token: 0x06000D9D RID: 3485 RVA: 0x00038B48 File Offset: 0x00036D48
		public static bool ExistsDirectory(string path, out MonoIOError error)
		{
			FileAttributes fileAttributes = MonoIO.GetFileAttributes(path, out error);
			if (error == MonoIOError.ERROR_FILE_NOT_FOUND)
			{
				error = MonoIOError.ERROR_PATH_NOT_FOUND;
			}
			return fileAttributes != MonoIO.InvalidFileAttributes && (fileAttributes & FileAttributes.Directory) != (FileAttributes)0;
		}

		// Token: 0x06000D9E RID: 3486
		[MethodImpl(4096)]
		public static extern bool GetFileStat(string path, out MonoIOStat stat, out MonoIOError error);

		// Token: 0x06000D9F RID: 3487
		[MethodImpl(4096)]
		public static extern IntPtr Open(string filename, FileMode mode, FileAccess access, FileShare share, FileOptions options, out MonoIOError error);

		// Token: 0x06000DA0 RID: 3488
		[MethodImpl(4096)]
		public static extern bool Close(IntPtr handle, out MonoIOError error);

		// Token: 0x06000DA1 RID: 3489
		[MethodImpl(4096)]
		public static extern int Read(IntPtr handle, byte[] dest, int dest_offset, int count, out MonoIOError error);

		// Token: 0x06000DA2 RID: 3490
		[MethodImpl(4096)]
		public static extern int Write(IntPtr handle, [In] byte[] src, int src_offset, int count, out MonoIOError error);

		// Token: 0x06000DA3 RID: 3491
		[MethodImpl(4096)]
		public static extern long Seek(IntPtr handle, long offset, SeekOrigin origin, out MonoIOError error);

		// Token: 0x06000DA4 RID: 3492
		[MethodImpl(4096)]
		public static extern long GetLength(IntPtr handle, out MonoIOError error);

		// Token: 0x06000DA5 RID: 3493
		[MethodImpl(4096)]
		public static extern bool SetLength(IntPtr handle, long length, out MonoIOError error);

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x06000DA6 RID: 3494
		public static extern IntPtr ConsoleOutput
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000DA7 RID: 3495
		public static extern IntPtr ConsoleInput
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000DA8 RID: 3496
		public static extern IntPtr ConsoleError
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000DA9 RID: 3497
		public static extern char VolumeSeparatorChar
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000DAA RID: 3498
		public static extern char DirectorySeparatorChar
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000DAB RID: 3499
		public static extern char AltDirectorySeparatorChar
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000DAC RID: 3500
		public static extern char PathSeparator
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x04000599 RID: 1433
		public static readonly FileAttributes InvalidFileAttributes = (FileAttributes)(-1);

		// Token: 0x0400059A RID: 1434
		public static readonly IntPtr InvalidHandle = (IntPtr)(-1L);
	}
}
