﻿using System;

namespace System.IO
{
	// Token: 0x0200015C RID: 348
	internal struct MonoIOStat
	{
		// Token: 0x040005B4 RID: 1460
		public string Name;

		// Token: 0x040005B5 RID: 1461
		public FileAttributes Attributes;

		// Token: 0x040005B6 RID: 1462
		public long Length;

		// Token: 0x040005B7 RID: 1463
		public long CreationTime;

		// Token: 0x040005B8 RID: 1464
		public long LastAccessTime;

		// Token: 0x040005B9 RID: 1465
		public long LastWriteTime;
	}
}
