﻿using System;

namespace System.IO
{
	// Token: 0x0200015D RID: 349
	internal class NullStream : Stream
	{
		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000DAE RID: 3502 RVA: 0x00038B8C File Offset: 0x00036D8C
		public override bool CanRead
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000DAF RID: 3503 RVA: 0x00038B90 File Offset: 0x00036D90
		public override bool CanSeek
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000DB0 RID: 3504 RVA: 0x00038B94 File Offset: 0x00036D94
		public override bool CanWrite
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000DB1 RID: 3505 RVA: 0x00038B98 File Offset: 0x00036D98
		public override long Length
		{
			get
			{
				return 0L;
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000DB2 RID: 3506 RVA: 0x00038B9C File Offset: 0x00036D9C
		// (set) Token: 0x06000DB3 RID: 3507 RVA: 0x00038BA0 File Offset: 0x00036DA0
		public override long Position
		{
			get
			{
				return 0L;
			}
			set
			{
			}
		}

		// Token: 0x06000DB4 RID: 3508 RVA: 0x00038BA4 File Offset: 0x00036DA4
		public override void Flush()
		{
		}

		// Token: 0x06000DB5 RID: 3509 RVA: 0x00038BA8 File Offset: 0x00036DA8
		public override int Read(byte[] buffer, int offset, int count)
		{
			return 0;
		}

		// Token: 0x06000DB6 RID: 3510 RVA: 0x00038BAC File Offset: 0x00036DAC
		public override int ReadByte()
		{
			return -1;
		}

		// Token: 0x06000DB7 RID: 3511 RVA: 0x00038BB0 File Offset: 0x00036DB0
		public override long Seek(long offset, SeekOrigin origin)
		{
			return 0L;
		}

		// Token: 0x06000DB8 RID: 3512 RVA: 0x00038BB4 File Offset: 0x00036DB4
		public override void SetLength(long value)
		{
		}

		// Token: 0x06000DB9 RID: 3513 RVA: 0x00038BB8 File Offset: 0x00036DB8
		public override void Write(byte[] buffer, int offset, int count)
		{
		}

		// Token: 0x06000DBA RID: 3514 RVA: 0x00038BBC File Offset: 0x00036DBC
		public override void WriteByte(byte value)
		{
		}
	}
}
