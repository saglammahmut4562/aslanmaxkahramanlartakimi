﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.IO
{
	// Token: 0x0200015F RID: 351
	[ComVisible(true)]
	[Serializable]
	public class PathTooLongException : IOException
	{
		// Token: 0x06000DCE RID: 3534 RVA: 0x00039ACC File Offset: 0x00037CCC
		public PathTooLongException()
			: base(Locale.GetText("Pathname is longer than the maximum length"))
		{
		}

		// Token: 0x06000DCF RID: 3535 RVA: 0x00039AE0 File Offset: 0x00037CE0
		public PathTooLongException(string message)
			: base(message)
		{
		}

		// Token: 0x06000DD0 RID: 3536 RVA: 0x00039AEC File Offset: 0x00037CEC
		protected PathTooLongException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
