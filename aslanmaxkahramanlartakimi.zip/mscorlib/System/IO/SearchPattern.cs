﻿using System;

namespace System.IO
{
	// Token: 0x02000160 RID: 352
	internal class SearchPattern
	{
		// Token: 0x040005C2 RID: 1474
		private SearchPattern.Op ops;

		// Token: 0x040005C3 RID: 1475
		private bool ignore;

		// Token: 0x040005C4 RID: 1476
		internal static readonly char[] WildcardChars = new char[] { '*', '?' };

		// Token: 0x040005C5 RID: 1477
		internal static readonly char[] InvalidChars = new char[]
		{
			Path.DirectorySeparatorChar,
			Path.AltDirectorySeparatorChar
		};

		// Token: 0x02000161 RID: 353
		private class Op
		{
			// Token: 0x040005C6 RID: 1478
			public SearchPattern.OpCode Code;

			// Token: 0x040005C7 RID: 1479
			public string Argument;

			// Token: 0x040005C8 RID: 1480
			public SearchPattern.Op Next;
		}

		// Token: 0x02000162 RID: 354
		private enum OpCode
		{
			// Token: 0x040005CA RID: 1482
			ExactString,
			// Token: 0x040005CB RID: 1483
			AnyChar,
			// Token: 0x040005CC RID: 1484
			AnyString,
			// Token: 0x040005CD RID: 1485
			End,
			// Token: 0x040005CE RID: 1486
			True
		}
	}
}
