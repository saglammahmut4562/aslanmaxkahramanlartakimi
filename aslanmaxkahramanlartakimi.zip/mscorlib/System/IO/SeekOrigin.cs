﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x02000163 RID: 355
	[ComVisible(true)]
	[Serializable]
	public enum SeekOrigin
	{
		// Token: 0x040005D0 RID: 1488
		Begin,
		// Token: 0x040005D1 RID: 1489
		Current,
		// Token: 0x040005D2 RID: 1490
		End
	}
}
