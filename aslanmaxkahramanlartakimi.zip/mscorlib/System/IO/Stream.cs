﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x02000164 RID: 356
	[ComVisible(true)]
	[Serializable]
	public abstract class Stream : IDisposable
	{
		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000DD4 RID: 3540
		public abstract bool CanRead { get; }

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000DD5 RID: 3541
		public abstract bool CanSeek { get; }

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000DD6 RID: 3542
		public abstract bool CanWrite { get; }

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x06000DD7 RID: 3543
		public abstract long Length { get; }

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x06000DD8 RID: 3544
		// (set) Token: 0x06000DD9 RID: 3545
		public abstract long Position { get; set; }

		// Token: 0x06000DDA RID: 3546 RVA: 0x00039B40 File Offset: 0x00037D40
		public void Dispose()
		{
			this.Close();
		}

		// Token: 0x06000DDB RID: 3547 RVA: 0x00039B48 File Offset: 0x00037D48
		protected virtual void Dispose(bool disposing)
		{
		}

		// Token: 0x06000DDC RID: 3548 RVA: 0x00039B4C File Offset: 0x00037D4C
		public virtual void Close()
		{
			this.Dispose(true);
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000DDD RID: 3549 RVA: 0x00039B58 File Offset: 0x00037D58
		[ComVisible(false)]
		public virtual int ReadTimeout
		{
			get
			{
				throw new InvalidOperationException("Timeouts are not supported on this stream.");
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000DDE RID: 3550 RVA: 0x00039B64 File Offset: 0x00037D64
		[ComVisible(false)]
		public virtual int WriteTimeout
		{
			get
			{
				throw new InvalidOperationException("Timeouts are not supported on this stream.");
			}
		}

		// Token: 0x06000DDF RID: 3551
		public abstract void Flush();

		// Token: 0x06000DE0 RID: 3552
		public abstract int Read([In] [Out] byte[] buffer, int offset, int count);

		// Token: 0x06000DE1 RID: 3553 RVA: 0x00039B70 File Offset: 0x00037D70
		public virtual int ReadByte()
		{
			byte[] array = new byte[1];
			if (this.Read(array, 0, 1) == 1)
			{
				return (int)array[0];
			}
			return -1;
		}

		// Token: 0x06000DE2 RID: 3554
		public abstract long Seek(long offset, SeekOrigin origin);

		// Token: 0x06000DE3 RID: 3555
		public abstract void SetLength(long value);

		// Token: 0x06000DE4 RID: 3556
		public abstract void Write(byte[] buffer, int offset, int count);

		// Token: 0x06000DE5 RID: 3557 RVA: 0x00039B98 File Offset: 0x00037D98
		public virtual void WriteByte(byte value)
		{
			this.Write(new byte[] { value }, 0, 1);
		}

		// Token: 0x06000DE6 RID: 3558 RVA: 0x00039BBC File Offset: 0x00037DBC
		public virtual IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
		{
			if (!this.CanRead)
			{
				throw new NotSupportedException("This stream does not support reading");
			}
			StreamAsyncResult streamAsyncResult = new StreamAsyncResult(state);
			try
			{
				int num = this.Read(buffer, offset, count);
				streamAsyncResult.SetComplete(null, num);
			}
			catch (Exception ex)
			{
				streamAsyncResult.SetComplete(ex, 0);
			}
			if (callback != null)
			{
				callback(streamAsyncResult);
			}
			return streamAsyncResult;
		}

		// Token: 0x06000DE7 RID: 3559 RVA: 0x00039C2C File Offset: 0x00037E2C
		public virtual IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
		{
			if (!this.CanWrite)
			{
				throw new NotSupportedException("This stream does not support writing");
			}
			StreamAsyncResult streamAsyncResult = new StreamAsyncResult(state);
			try
			{
				this.Write(buffer, offset, count);
				streamAsyncResult.SetComplete(null);
			}
			catch (Exception ex)
			{
				streamAsyncResult.SetComplete(ex);
			}
			if (callback != null)
			{
				callback.BeginInvoke(streamAsyncResult, null, null);
			}
			return streamAsyncResult;
		}

		// Token: 0x06000DE8 RID: 3560 RVA: 0x00039C9C File Offset: 0x00037E9C
		public virtual int EndRead(IAsyncResult asyncResult)
		{
			if (asyncResult == null)
			{
				throw new ArgumentNullException("asyncResult");
			}
			StreamAsyncResult streamAsyncResult = asyncResult as StreamAsyncResult;
			if (streamAsyncResult == null || streamAsyncResult.NBytes == -1)
			{
				throw new ArgumentException("Invalid IAsyncResult", "asyncResult");
			}
			if (streamAsyncResult.Done)
			{
				throw new InvalidOperationException("EndRead already called.");
			}
			streamAsyncResult.Done = true;
			if (streamAsyncResult.Exception != null)
			{
				throw streamAsyncResult.Exception;
			}
			return streamAsyncResult.NBytes;
		}

		// Token: 0x06000DE9 RID: 3561 RVA: 0x00039D18 File Offset: 0x00037F18
		public virtual void EndWrite(IAsyncResult asyncResult)
		{
			if (asyncResult == null)
			{
				throw new ArgumentNullException("asyncResult");
			}
			StreamAsyncResult streamAsyncResult = asyncResult as StreamAsyncResult;
			if (streamAsyncResult == null || streamAsyncResult.NBytes != -1)
			{
				throw new ArgumentException("Invalid IAsyncResult", "asyncResult");
			}
			if (streamAsyncResult.Done)
			{
				throw new InvalidOperationException("EndWrite already called.");
			}
			streamAsyncResult.Done = true;
			if (streamAsyncResult.Exception != null)
			{
				throw streamAsyncResult.Exception;
			}
		}

		// Token: 0x040005D3 RID: 1491
		public static readonly Stream Null = new NullStream();
	}
}
