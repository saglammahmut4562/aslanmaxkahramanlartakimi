﻿using System;
using System.Threading;

namespace System.IO
{
	// Token: 0x02000165 RID: 357
	internal class StreamAsyncResult : IAsyncResult
	{
		// Token: 0x06000DEA RID: 3562 RVA: 0x00039D90 File Offset: 0x00037F90
		public StreamAsyncResult(object state)
		{
			this.state = state;
		}

		// Token: 0x06000DEB RID: 3563 RVA: 0x00039DA8 File Offset: 0x00037FA8
		public void SetComplete(Exception e)
		{
			this.exc = e;
			this.completed = true;
			lock (this)
			{
				if (this.wh != null)
				{
					this.wh.Set();
				}
			}
		}

		// Token: 0x06000DEC RID: 3564 RVA: 0x00039E00 File Offset: 0x00038000
		public void SetComplete(Exception e, int nbytes)
		{
			this.nbytes = nbytes;
			this.SetComplete(e);
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000DED RID: 3565 RVA: 0x00039E10 File Offset: 0x00038010
		public object AsyncState
		{
			get
			{
				return this.state;
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000DEE RID: 3566 RVA: 0x00039E18 File Offset: 0x00038018
		public WaitHandle AsyncWaitHandle
		{
			get
			{
				WaitHandle waitHandle;
				lock (this)
				{
					if (this.wh == null)
					{
						this.wh = new ManualResetEvent(this.completed);
					}
					waitHandle = this.wh;
				}
				return waitHandle;
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000DEF RID: 3567 RVA: 0x00039E74 File Offset: 0x00038074
		public bool IsCompleted
		{
			get
			{
				return this.completed;
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000DF0 RID: 3568 RVA: 0x00039E7C File Offset: 0x0003807C
		public Exception Exception
		{
			get
			{
				return this.exc;
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000DF1 RID: 3569 RVA: 0x00039E84 File Offset: 0x00038084
		public int NBytes
		{
			get
			{
				return this.nbytes;
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000DF2 RID: 3570 RVA: 0x00039E8C File Offset: 0x0003808C
		// (set) Token: 0x06000DF3 RID: 3571 RVA: 0x00039E94 File Offset: 0x00038094
		public bool Done
		{
			get
			{
				return this.done;
			}
			set
			{
				this.done = value;
			}
		}

		// Token: 0x040005D4 RID: 1492
		private object state;

		// Token: 0x040005D5 RID: 1493
		private bool completed;

		// Token: 0x040005D6 RID: 1494
		private bool done;

		// Token: 0x040005D7 RID: 1495
		private Exception exc;

		// Token: 0x040005D8 RID: 1496
		private int nbytes = -1;

		// Token: 0x040005D9 RID: 1497
		private ManualResetEvent wh;
	}
}
