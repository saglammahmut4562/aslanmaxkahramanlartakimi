﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace System.IO
{
	// Token: 0x02000166 RID: 358
	[ComVisible(true)]
	[Serializable]
	public class StreamReader : TextReader
	{
		// Token: 0x06000DF4 RID: 3572 RVA: 0x00039EA0 File Offset: 0x000380A0
		internal StreamReader()
		{
		}

		// Token: 0x06000DF5 RID: 3573 RVA: 0x00039EA8 File Offset: 0x000380A8
		public StreamReader(Stream stream)
			: this(stream, Encoding.UTF8Unmarked, true, 1024)
		{
		}

		// Token: 0x06000DF6 RID: 3574 RVA: 0x00039EBC File Offset: 0x000380BC
		public StreamReader(Stream stream, Encoding encoding)
			: this(stream, encoding, true, 1024)
		{
		}

		// Token: 0x06000DF7 RID: 3575 RVA: 0x00039ECC File Offset: 0x000380CC
		public StreamReader(Stream stream, Encoding encoding, bool detectEncodingFromByteOrderMarks, int bufferSize)
		{
			this.Initialize(stream, encoding, detectEncodingFromByteOrderMarks, bufferSize);
		}

		// Token: 0x06000DF8 RID: 3576 RVA: 0x00039EE0 File Offset: 0x000380E0
		public StreamReader(string path)
			: this(path, Encoding.UTF8Unmarked, true, 4096)
		{
		}

		// Token: 0x06000DF9 RID: 3577 RVA: 0x00039EF4 File Offset: 0x000380F4
		public StreamReader(string path, Encoding encoding, bool detectEncodingFromByteOrderMarks, int bufferSize)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (string.Empty == path)
			{
				throw new ArgumentException("Empty path not allowed");
			}
			if (path.IndexOfAny(Path.InvalidPathChars) != -1)
			{
				throw new ArgumentException("path contains invalid characters");
			}
			if (encoding == null)
			{
				throw new ArgumentNullException("encoding");
			}
			if (bufferSize <= 0)
			{
				throw new ArgumentOutOfRangeException("bufferSize", "The minimum size of the buffer must be positive");
			}
			Stream stream = File.OpenRead(path);
			this.Initialize(stream, encoding, detectEncodingFromByteOrderMarks, bufferSize);
		}

		// Token: 0x06000DFB RID: 3579 RVA: 0x00039F98 File Offset: 0x00038198
		internal void Initialize(Stream stream, Encoding encoding, bool detectEncodingFromByteOrderMarks, int bufferSize)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			if (encoding == null)
			{
				throw new ArgumentNullException("encoding");
			}
			if (!stream.CanRead)
			{
				throw new ArgumentException("Cannot read stream");
			}
			if (bufferSize <= 0)
			{
				throw new ArgumentOutOfRangeException("bufferSize", "The minimum size of the buffer must be positive");
			}
			if (bufferSize < 128)
			{
				bufferSize = 128;
			}
			this.base_stream = stream;
			this.input_buffer = new byte[bufferSize];
			this.buffer_size = bufferSize;
			this.encoding = encoding;
			this.decoder = encoding.GetDecoder();
			byte[] preamble = encoding.GetPreamble();
			this.do_checks = ((!detectEncodingFromByteOrderMarks) ? 0 : 1);
			this.do_checks += ((preamble.Length != 0) ? 2 : 0);
			this.decoded_buffer = new char[encoding.GetMaxCharCount(bufferSize) + 1];
			this.decoded_count = 0;
			this.pos = 0;
		}

		// Token: 0x06000DFC RID: 3580 RVA: 0x0003A090 File Offset: 0x00038290
		public override void Close()
		{
			this.Dispose(true);
		}

		// Token: 0x06000DFD RID: 3581 RVA: 0x0003A09C File Offset: 0x0003829C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.base_stream != null)
			{
				this.base_stream.Close();
			}
			this.input_buffer = null;
			this.decoded_buffer = null;
			this.encoding = null;
			this.decoder = null;
			this.base_stream = null;
			base.Dispose(disposing);
		}

		// Token: 0x06000DFE RID: 3582 RVA: 0x0003A0F0 File Offset: 0x000382F0
		private int DoChecks(int count)
		{
			if ((this.do_checks & 2) == 2)
			{
				byte[] preamble = this.encoding.GetPreamble();
				int num = preamble.Length;
				if (count >= num)
				{
					int i;
					for (i = 0; i < num; i++)
					{
						if (this.input_buffer[i] != preamble[i])
						{
							break;
						}
					}
					if (i == num)
					{
						return i;
					}
				}
			}
			if ((this.do_checks & 1) == 1)
			{
				if (count < 2)
				{
					return 0;
				}
				if (this.input_buffer[0] == 254 && this.input_buffer[1] == 255)
				{
					this.encoding = Encoding.BigEndianUnicode;
					return 2;
				}
				if (count < 3)
				{
					return 0;
				}
				if (this.input_buffer[0] == 239 && this.input_buffer[1] == 187 && this.input_buffer[2] == 191)
				{
					this.encoding = Encoding.UTF8Unmarked;
					return 3;
				}
				if (count < 4)
				{
					if (this.input_buffer[0] == 255 && this.input_buffer[1] == 254 && this.input_buffer[2] != 0)
					{
						this.encoding = Encoding.Unicode;
						return 2;
					}
					return 0;
				}
				else
				{
					if (this.input_buffer[0] == 0 && this.input_buffer[1] == 0 && this.input_buffer[2] == 254 && this.input_buffer[3] == 255)
					{
						this.encoding = Encoding.BigEndianUTF32;
						return 4;
					}
					if (this.input_buffer[0] == 255 && this.input_buffer[1] == 254)
					{
						if (this.input_buffer[2] == 0 && this.input_buffer[3] == 0)
						{
							this.encoding = Encoding.UTF32;
							return 4;
						}
						this.encoding = Encoding.Unicode;
						return 2;
					}
				}
			}
			return 0;
		}

		// Token: 0x06000DFF RID: 3583 RVA: 0x0003A2D4 File Offset: 0x000384D4
		private int ReadBuffer()
		{
			this.pos = 0;
			this.decoded_count = 0;
			int num = 0;
			for (;;)
			{
				int num2 = this.base_stream.Read(this.input_buffer, 0, this.buffer_size);
				if (num2 <= 0)
				{
					break;
				}
				this.mayBlock = num2 < this.buffer_size;
				if (this.do_checks > 0)
				{
					Encoding encoding = this.encoding;
					num = this.DoChecks(num2);
					if (encoding != this.encoding)
					{
						int num3 = encoding.GetMaxCharCount(this.buffer_size) + 1;
						int num4 = this.encoding.GetMaxCharCount(this.buffer_size) + 1;
						if (num3 != num4)
						{
							this.decoded_buffer = new char[num4];
						}
						this.decoder = this.encoding.GetDecoder();
					}
					this.do_checks = 0;
					num2 -= num;
				}
				this.decoded_count += this.decoder.GetChars(this.input_buffer, num, num2, this.decoded_buffer, 0);
				num = 0;
				if (this.decoded_count != 0)
				{
					goto Block_5;
				}
			}
			return 0;
			Block_5:
			return this.decoded_count;
		}

		// Token: 0x06000E00 RID: 3584 RVA: 0x0003A3DC File Offset: 0x000385DC
		public override int Peek()
		{
			if (this.base_stream == null)
			{
				throw new ObjectDisposedException("StreamReader", "Cannot read from a closed StreamReader");
			}
			if (this.pos >= this.decoded_count && this.ReadBuffer() == 0)
			{
				return -1;
			}
			return (int)this.decoded_buffer[this.pos];
		}

		// Token: 0x06000E01 RID: 3585 RVA: 0x0003A430 File Offset: 0x00038630
		public override int Read()
		{
			if (this.base_stream == null)
			{
				throw new ObjectDisposedException("StreamReader", "Cannot read from a closed StreamReader");
			}
			if (this.pos >= this.decoded_count && this.ReadBuffer() == 0)
			{
				return -1;
			}
			return (int)this.decoded_buffer[this.pos++];
		}

		// Token: 0x06000E02 RID: 3586 RVA: 0x0003A490 File Offset: 0x00038690
		public override int Read([In] [Out] char[] buffer, int index, int count)
		{
			if (this.base_stream == null)
			{
				throw new ObjectDisposedException("StreamReader", "Cannot read from a closed StreamReader");
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index", "< 0");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "< 0");
			}
			if (index > buffer.Length - count)
			{
				throw new ArgumentException("index + count > buffer.Length");
			}
			int num = 0;
			while (count > 0)
			{
				if (this.pos >= this.decoded_count && this.ReadBuffer() == 0)
				{
					return (num <= 0) ? 0 : num;
				}
				int num2 = Math.Min(this.decoded_count - this.pos, count);
				Array.Copy(this.decoded_buffer, this.pos, buffer, index, num2);
				this.pos += num2;
				index += num2;
				count -= num2;
				num += num2;
				if (this.mayBlock)
				{
					break;
				}
			}
			return num;
		}

		// Token: 0x06000E03 RID: 3587 RVA: 0x0003A59C File Offset: 0x0003879C
		private int FindNextEOL()
		{
			while (this.pos < this.decoded_count)
			{
				char c = this.decoded_buffer[this.pos];
				if (c == '\n')
				{
					this.pos++;
					int num = ((!this.foundCR) ? (this.pos - 1) : (this.pos - 2));
					if (num < 0)
					{
						num = 0;
					}
					this.foundCR = false;
					return num;
				}
				if (this.foundCR)
				{
					this.foundCR = false;
					if (this.pos == 0)
					{
						return -2;
					}
					return this.pos - 1;
				}
				else
				{
					this.foundCR = c == '\r';
					this.pos++;
				}
			}
			return -1;
		}

		// Token: 0x06000E04 RID: 3588 RVA: 0x0003A65C File Offset: 0x0003885C
		public override string ReadLine()
		{
			if (this.base_stream == null)
			{
				throw new ObjectDisposedException("StreamReader", "Cannot read from a closed StreamReader");
			}
			if (this.pos >= this.decoded_count && this.ReadBuffer() == 0)
			{
				return null;
			}
			int num = this.pos;
			int num2 = this.FindNextEOL();
			if (num2 < this.decoded_count && num2 >= num)
			{
				return new string(this.decoded_buffer, num, num2 - num);
			}
			if (num2 == -2)
			{
				return this.line_builder.ToString(0, this.line_builder.Length);
			}
			if (this.line_builder == null)
			{
				this.line_builder = new StringBuilder();
			}
			else
			{
				this.line_builder.Length = 0;
			}
			for (;;)
			{
				if (this.foundCR)
				{
					this.decoded_count--;
				}
				this.line_builder.Append(this.decoded_buffer, num, this.decoded_count - num);
				if (this.ReadBuffer() == 0)
				{
					break;
				}
				num = this.pos;
				num2 = this.FindNextEOL();
				if (num2 < this.decoded_count && num2 >= num)
				{
					goto Block_12;
				}
				if (num2 == -2)
				{
					goto Block_14;
				}
			}
			if (this.line_builder.Capacity > 32768)
			{
				StringBuilder stringBuilder = this.line_builder;
				this.line_builder = null;
				return stringBuilder.ToString(0, stringBuilder.Length);
			}
			return this.line_builder.ToString(0, this.line_builder.Length);
			Block_12:
			this.line_builder.Append(this.decoded_buffer, num, num2 - num);
			if (this.line_builder.Capacity > 32768)
			{
				StringBuilder stringBuilder2 = this.line_builder;
				this.line_builder = null;
				return stringBuilder2.ToString(0, stringBuilder2.Length);
			}
			return this.line_builder.ToString(0, this.line_builder.Length);
			Block_14:
			return this.line_builder.ToString(0, this.line_builder.Length);
		}

		// Token: 0x06000E05 RID: 3589 RVA: 0x0003A848 File Offset: 0x00038A48
		public override string ReadToEnd()
		{
			if (this.base_stream == null)
			{
				throw new ObjectDisposedException("StreamReader", "Cannot read from a closed StreamReader");
			}
			StringBuilder stringBuilder = new StringBuilder();
			int num = this.decoded_buffer.Length;
			char[] array = new char[num];
			int num2;
			while ((num2 = this.Read(array, 0, num)) > 0)
			{
				stringBuilder.Append(array, 0, num2);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x040005DA RID: 1498
		private const int DefaultBufferSize = 1024;

		// Token: 0x040005DB RID: 1499
		private const int DefaultFileBufferSize = 4096;

		// Token: 0x040005DC RID: 1500
		private const int MinimumBufferSize = 128;

		// Token: 0x040005DD RID: 1501
		private byte[] input_buffer;

		// Token: 0x040005DE RID: 1502
		private char[] decoded_buffer;

		// Token: 0x040005DF RID: 1503
		private int decoded_count;

		// Token: 0x040005E0 RID: 1504
		private int pos;

		// Token: 0x040005E1 RID: 1505
		private int buffer_size;

		// Token: 0x040005E2 RID: 1506
		private int do_checks;

		// Token: 0x040005E3 RID: 1507
		private Encoding encoding;

		// Token: 0x040005E4 RID: 1508
		private Decoder decoder;

		// Token: 0x040005E5 RID: 1509
		private Stream base_stream;

		// Token: 0x040005E6 RID: 1510
		private bool mayBlock;

		// Token: 0x040005E7 RID: 1511
		private StringBuilder line_builder;

		// Token: 0x040005E8 RID: 1512
		public new static readonly StreamReader Null = new StreamReader.NullStreamReader();

		// Token: 0x040005E9 RID: 1513
		private bool foundCR;

		// Token: 0x02000167 RID: 359
		private class NullStreamReader : StreamReader
		{
			// Token: 0x06000E07 RID: 3591 RVA: 0x0003A8B4 File Offset: 0x00038AB4
			public override int Peek()
			{
				return -1;
			}

			// Token: 0x06000E08 RID: 3592 RVA: 0x0003A8B8 File Offset: 0x00038AB8
			public override int Read()
			{
				return -1;
			}

			// Token: 0x06000E09 RID: 3593 RVA: 0x0003A8BC File Offset: 0x00038ABC
			public override int Read([In] [Out] char[] buffer, int index, int count)
			{
				return 0;
			}

			// Token: 0x06000E0A RID: 3594 RVA: 0x0003A8C0 File Offset: 0x00038AC0
			public override string ReadLine()
			{
				return null;
			}

			// Token: 0x06000E0B RID: 3595 RVA: 0x0003A8C4 File Offset: 0x00038AC4
			public override string ReadToEnd()
			{
				return string.Empty;
			}
		}
	}
}
