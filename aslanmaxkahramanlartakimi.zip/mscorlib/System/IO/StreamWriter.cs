﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace System.IO
{
	// Token: 0x02000168 RID: 360
	[ComVisible(true)]
	[Serializable]
	public class StreamWriter : TextWriter
	{
		// Token: 0x06000E0C RID: 3596 RVA: 0x0003A8CC File Offset: 0x00038ACC
		public StreamWriter(Stream stream)
			: this(stream, Encoding.UTF8Unmarked, 1024)
		{
		}

		// Token: 0x06000E0D RID: 3597 RVA: 0x0003A8E0 File Offset: 0x00038AE0
		public StreamWriter(Stream stream, Encoding encoding)
			: this(stream, encoding, 1024)
		{
		}

		// Token: 0x06000E0E RID: 3598 RVA: 0x0003A8F0 File Offset: 0x00038AF0
		public StreamWriter(Stream stream, Encoding encoding, int bufferSize)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			if (encoding == null)
			{
				throw new ArgumentNullException("encoding");
			}
			if (bufferSize <= 0)
			{
				throw new ArgumentOutOfRangeException("bufferSize");
			}
			if (!stream.CanWrite)
			{
				throw new ArgumentException("Can not write to stream");
			}
			this.internalStream = stream;
			this.Initialize(encoding, bufferSize);
		}

		// Token: 0x06000E0F RID: 3599 RVA: 0x0003A95C File Offset: 0x00038B5C
		public StreamWriter(string path)
			: this(path, false, Encoding.UTF8Unmarked, 4096)
		{
		}

		// Token: 0x06000E10 RID: 3600 RVA: 0x0003A970 File Offset: 0x00038B70
		public StreamWriter(string path, bool append, Encoding encoding, int bufferSize)
		{
			if (encoding == null)
			{
				throw new ArgumentNullException("encoding");
			}
			if (bufferSize <= 0)
			{
				throw new ArgumentOutOfRangeException("bufferSize");
			}
			FileMode fileMode;
			if (append)
			{
				fileMode = FileMode.Append;
			}
			else
			{
				fileMode = FileMode.Create;
			}
			this.internalStream = new FileStream(path, fileMode, FileAccess.Write, FileShare.Read);
			if (append)
			{
				this.internalStream.Position = this.internalStream.Length;
			}
			else
			{
				this.internalStream.SetLength(0L);
			}
			this.Initialize(encoding, bufferSize);
		}

		// Token: 0x06000E12 RID: 3602 RVA: 0x0003AA14 File Offset: 0x00038C14
		internal void Initialize(Encoding encoding, int bufferSize)
		{
			this.internalEncoding = encoding;
			this.decode_pos = (this.byte_pos = 0);
			int num = Math.Max(bufferSize, 256);
			this.decode_buf = new char[num];
			this.byte_buf = new byte[encoding.GetMaxByteCount(num)];
			if (this.internalStream.CanSeek && this.internalStream.Position > 0L)
			{
				this.preamble_done = true;
			}
		}

		// Token: 0x17000226 RID: 550
		// (set) Token: 0x06000E13 RID: 3603 RVA: 0x0003AA8C File Offset: 0x00038C8C
		public virtual bool AutoFlush
		{
			set
			{
				this.iflush = value;
				if (this.iflush)
				{
					this.Flush();
				}
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000E14 RID: 3604 RVA: 0x0003AAA8 File Offset: 0x00038CA8
		public virtual Stream BaseStream
		{
			get
			{
				return this.internalStream;
			}
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000E15 RID: 3605 RVA: 0x0003AAB0 File Offset: 0x00038CB0
		public override Encoding Encoding
		{
			get
			{
				return this.internalEncoding;
			}
		}

		// Token: 0x06000E16 RID: 3606 RVA: 0x0003AAB8 File Offset: 0x00038CB8
		protected override void Dispose(bool disposing)
		{
			Exception ex = null;
			if (!this.DisposedAlready && disposing && this.internalStream != null)
			{
				try
				{
					this.Flush();
				}
				catch (Exception ex2)
				{
					ex = ex2;
				}
				this.DisposedAlready = true;
				try
				{
					this.internalStream.Close();
				}
				catch (Exception ex3)
				{
					if (ex == null)
					{
						ex = ex3;
					}
				}
			}
			this.internalStream = null;
			this.byte_buf = null;
			this.internalEncoding = null;
			this.decode_buf = null;
			if (ex != null)
			{
				throw ex;
			}
		}

		// Token: 0x06000E17 RID: 3607 RVA: 0x0003AB5C File Offset: 0x00038D5C
		public override void Flush()
		{
			if (this.DisposedAlready)
			{
				throw new ObjectDisposedException("StreamWriter");
			}
			this.Decode();
			if (this.byte_pos > 0)
			{
				this.FlushBytes();
				this.internalStream.Flush();
			}
		}

		// Token: 0x06000E18 RID: 3608 RVA: 0x0003AB98 File Offset: 0x00038D98
		private void FlushBytes()
		{
			if (!this.preamble_done && this.byte_pos > 0)
			{
				byte[] preamble = this.internalEncoding.GetPreamble();
				if (preamble.Length > 0)
				{
					this.internalStream.Write(preamble, 0, preamble.Length);
				}
				this.preamble_done = true;
			}
			this.internalStream.Write(this.byte_buf, 0, this.byte_pos);
			this.byte_pos = 0;
		}

		// Token: 0x06000E19 RID: 3609 RVA: 0x0003AC08 File Offset: 0x00038E08
		private void Decode()
		{
			if (this.byte_pos > 0)
			{
				this.FlushBytes();
			}
			if (this.decode_pos > 0)
			{
				int bytes = this.internalEncoding.GetBytes(this.decode_buf, 0, this.decode_pos, this.byte_buf, this.byte_pos);
				this.byte_pos += bytes;
				this.decode_pos = 0;
			}
		}

		// Token: 0x06000E1A RID: 3610 RVA: 0x0003AC70 File Offset: 0x00038E70
		public override void Write(char[] buffer, int index, int count)
		{
			if (this.DisposedAlready)
			{
				throw new ObjectDisposedException("StreamWriter");
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index", "< 0");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "< 0");
			}
			if (index > buffer.Length - count)
			{
				throw new ArgumentException("index + count > buffer.Length");
			}
			this.LowLevelWrite(buffer, index, count);
			if (this.iflush)
			{
				this.Flush();
			}
		}

		// Token: 0x06000E1B RID: 3611 RVA: 0x0003AD04 File Offset: 0x00038F04
		private void LowLevelWrite(char[] buffer, int index, int count)
		{
			while (count > 0)
			{
				int num = this.decode_buf.Length - this.decode_pos;
				if (num == 0)
				{
					this.Decode();
					num = this.decode_buf.Length;
				}
				if (num > count)
				{
					num = count;
				}
				Buffer.BlockCopy(buffer, index * 2, this.decode_buf, this.decode_pos * 2, num * 2);
				count -= num;
				index += num;
				this.decode_pos += num;
			}
		}

		// Token: 0x06000E1C RID: 3612 RVA: 0x0003AD80 File Offset: 0x00038F80
		private void LowLevelWrite(string s)
		{
			int i = s.Length;
			int num = 0;
			while (i > 0)
			{
				int num2 = this.decode_buf.Length - this.decode_pos;
				if (num2 == 0)
				{
					this.Decode();
					num2 = this.decode_buf.Length;
				}
				if (num2 > i)
				{
					num2 = i;
				}
				for (int j = 0; j < num2; j++)
				{
					this.decode_buf[j + this.decode_pos] = s[j + num];
				}
				i -= num2;
				num += num2;
				this.decode_pos += num2;
			}
		}

		// Token: 0x06000E1D RID: 3613 RVA: 0x0003AE10 File Offset: 0x00039010
		public override void Write(char value)
		{
			if (this.DisposedAlready)
			{
				throw new ObjectDisposedException("StreamWriter");
			}
			if (this.decode_pos >= this.decode_buf.Length)
			{
				this.Decode();
			}
			this.decode_buf[this.decode_pos++] = value;
			if (this.iflush)
			{
				this.Flush();
			}
		}

		// Token: 0x06000E1E RID: 3614 RVA: 0x0003AE78 File Offset: 0x00039078
		public override void Write(char[] buffer)
		{
			if (this.DisposedAlready)
			{
				throw new ObjectDisposedException("StreamWriter");
			}
			if (buffer != null)
			{
				this.LowLevelWrite(buffer, 0, buffer.Length);
			}
			if (this.iflush)
			{
				this.Flush();
			}
		}

		// Token: 0x06000E1F RID: 3615 RVA: 0x0003AEB4 File Offset: 0x000390B4
		public override void Write(string value)
		{
			if (this.DisposedAlready)
			{
				throw new ObjectDisposedException("StreamWriter");
			}
			if (value != null)
			{
				this.LowLevelWrite(value);
			}
			if (this.iflush)
			{
				this.Flush();
			}
		}

		// Token: 0x06000E20 RID: 3616 RVA: 0x0003AEEC File Offset: 0x000390EC
		public override void Close()
		{
			this.Dispose(true);
		}

		// Token: 0x06000E21 RID: 3617 RVA: 0x0003AEF8 File Offset: 0x000390F8
		~StreamWriter()
		{
			this.Dispose(false);
		}

		// Token: 0x040005EA RID: 1514
		private const int DefaultBufferSize = 1024;

		// Token: 0x040005EB RID: 1515
		private const int DefaultFileBufferSize = 4096;

		// Token: 0x040005EC RID: 1516
		private const int MinimumBufferSize = 256;

		// Token: 0x040005ED RID: 1517
		private Encoding internalEncoding;

		// Token: 0x040005EE RID: 1518
		private Stream internalStream;

		// Token: 0x040005EF RID: 1519
		private bool iflush;

		// Token: 0x040005F0 RID: 1520
		private byte[] byte_buf;

		// Token: 0x040005F1 RID: 1521
		private int byte_pos;

		// Token: 0x040005F2 RID: 1522
		private char[] decode_buf;

		// Token: 0x040005F3 RID: 1523
		private int decode_pos;

		// Token: 0x040005F4 RID: 1524
		private bool DisposedAlready;

		// Token: 0x040005F5 RID: 1525
		private bool preamble_done;

		// Token: 0x040005F6 RID: 1526
		public new static readonly StreamWriter Null = new StreamWriter(Stream.Null, Encoding.UTF8Unmarked, 1);
	}
}
