﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x02000169 RID: 361
	[ComVisible(true)]
	[Serializable]
	public class StringReader : TextReader
	{
		// Token: 0x06000E22 RID: 3618 RVA: 0x0003AF28 File Offset: 0x00039128
		public StringReader(string s)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			this.source = s;
			this.nextChar = 0;
			this.sourceLength = s.Length;
		}

		// Token: 0x06000E23 RID: 3619 RVA: 0x0003AF5C File Offset: 0x0003915C
		public override void Close()
		{
			this.Dispose(true);
		}

		// Token: 0x06000E24 RID: 3620 RVA: 0x0003AF68 File Offset: 0x00039168
		protected override void Dispose(bool disposing)
		{
			this.source = null;
			base.Dispose(disposing);
		}

		// Token: 0x06000E25 RID: 3621 RVA: 0x0003AF78 File Offset: 0x00039178
		public override int Peek()
		{
			this.CheckObjectDisposedException();
			if (this.nextChar >= this.sourceLength)
			{
				return -1;
			}
			return (int)this.source[this.nextChar];
		}

		// Token: 0x06000E26 RID: 3622 RVA: 0x0003AFA4 File Offset: 0x000391A4
		public override int Read()
		{
			this.CheckObjectDisposedException();
			if (this.nextChar >= this.sourceLength)
			{
				return -1;
			}
			return (int)this.source[this.nextChar++];
		}

		// Token: 0x06000E27 RID: 3623 RVA: 0x0003AFE8 File Offset: 0x000391E8
		public override int Read([In] [Out] char[] buffer, int index, int count)
		{
			this.CheckObjectDisposedException();
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (buffer.Length - index < count)
			{
				throw new ArgumentException();
			}
			if (index < 0 || count < 0)
			{
				throw new ArgumentOutOfRangeException();
			}
			int num;
			if (this.nextChar > this.sourceLength - count)
			{
				num = this.sourceLength - this.nextChar;
			}
			else
			{
				num = count;
			}
			this.source.CopyTo(this.nextChar, buffer, index, num);
			this.nextChar += num;
			return num;
		}

		// Token: 0x06000E28 RID: 3624 RVA: 0x0003B07C File Offset: 0x0003927C
		public override string ReadLine()
		{
			this.CheckObjectDisposedException();
			if (this.nextChar >= this.source.Length)
			{
				return null;
			}
			int num = this.source.IndexOf('\r', this.nextChar);
			int num2 = this.source.IndexOf('\n', this.nextChar);
			bool flag = false;
			int num3;
			if (num == -1)
			{
				if (num2 == -1)
				{
					return this.ReadToEnd();
				}
				num3 = num2;
			}
			else if (num2 == -1)
			{
				num3 = num;
			}
			else
			{
				num3 = ((num <= num2) ? num : num2);
				flag = num + 1 == num2;
			}
			string text = this.source.Substring(this.nextChar, num3 - this.nextChar);
			this.nextChar = num3 + ((!flag) ? 1 : 2);
			return text;
		}

		// Token: 0x06000E29 RID: 3625 RVA: 0x0003B144 File Offset: 0x00039344
		public override string ReadToEnd()
		{
			this.CheckObjectDisposedException();
			string text = this.source.Substring(this.nextChar, this.sourceLength - this.nextChar);
			this.nextChar = this.sourceLength;
			return text;
		}

		// Token: 0x06000E2A RID: 3626 RVA: 0x0003B184 File Offset: 0x00039384
		private void CheckObjectDisposedException()
		{
			if (this.source == null)
			{
				throw new ObjectDisposedException("StringReader", Locale.GetText("Cannot read from a closed StringReader"));
			}
		}

		// Token: 0x040005F7 RID: 1527
		private string source;

		// Token: 0x040005F8 RID: 1528
		private int nextChar;

		// Token: 0x040005F9 RID: 1529
		private int sourceLength;
	}
}
