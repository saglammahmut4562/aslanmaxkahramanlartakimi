﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace System.IO
{
	// Token: 0x0200016A RID: 362
	[ComVisible(true)]
	[MonoTODO("Serialization format not compatible with .NET")]
	[Serializable]
	public class StringWriter : TextWriter
	{
		// Token: 0x06000E2B RID: 3627 RVA: 0x0003B1A8 File Offset: 0x000393A8
		public StringWriter()
			: this(new StringBuilder())
		{
		}

		// Token: 0x06000E2C RID: 3628 RVA: 0x0003B1B8 File Offset: 0x000393B8
		public StringWriter(IFormatProvider formatProvider)
			: this(new StringBuilder(), formatProvider)
		{
		}

		// Token: 0x06000E2D RID: 3629 RVA: 0x0003B1C8 File Offset: 0x000393C8
		public StringWriter(StringBuilder sb)
			: this(sb, null)
		{
		}

		// Token: 0x06000E2E RID: 3630 RVA: 0x0003B1D4 File Offset: 0x000393D4
		public StringWriter(StringBuilder sb, IFormatProvider formatProvider)
		{
			if (sb == null)
			{
				throw new ArgumentNullException("sb");
			}
			this.internalString = sb;
			this.internalFormatProvider = formatProvider;
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000E2F RID: 3631 RVA: 0x0003B1FC File Offset: 0x000393FC
		public override Encoding Encoding
		{
			get
			{
				return Encoding.Unicode;
			}
		}

		// Token: 0x06000E30 RID: 3632 RVA: 0x0003B204 File Offset: 0x00039404
		public override void Close()
		{
			this.Dispose(true);
			this.disposed = true;
		}

		// Token: 0x06000E31 RID: 3633 RVA: 0x0003B214 File Offset: 0x00039414
		protected override void Dispose(bool disposing)
		{
			base.Dispose(disposing);
			this.disposed = true;
		}

		// Token: 0x06000E32 RID: 3634 RVA: 0x0003B224 File Offset: 0x00039424
		public virtual StringBuilder GetStringBuilder()
		{
			return this.internalString;
		}

		// Token: 0x06000E33 RID: 3635 RVA: 0x0003B22C File Offset: 0x0003942C
		public override string ToString()
		{
			return this.internalString.ToString();
		}

		// Token: 0x06000E34 RID: 3636 RVA: 0x0003B23C File Offset: 0x0003943C
		public override void Write(char value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("StringReader", Locale.GetText("Cannot write to a closed StringWriter"));
			}
			this.internalString.Append(value);
		}

		// Token: 0x06000E35 RID: 3637 RVA: 0x0003B26C File Offset: 0x0003946C
		public override void Write(string value)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("StringReader", Locale.GetText("Cannot write to a closed StringWriter"));
			}
			this.internalString.Append(value);
		}

		// Token: 0x06000E36 RID: 3638 RVA: 0x0003B29C File Offset: 0x0003949C
		public override void Write(char[] buffer, int index, int count)
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("StringReader", Locale.GetText("Cannot write to a closed StringWriter"));
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index", "< 0");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "< 0");
			}
			if (index > buffer.Length - count)
			{
				throw new ArgumentException("index + count > buffer.Length");
			}
			this.internalString.Append(buffer, index, count);
		}

		// Token: 0x040005FA RID: 1530
		private StringBuilder internalString;

		// Token: 0x040005FB RID: 1531
		private bool disposed;
	}
}
