﻿using System;

namespace System.IO
{
	// Token: 0x0200016B RID: 363
	[Serializable]
	internal class SynchronizedReader : TextReader
	{
		// Token: 0x06000E37 RID: 3639 RVA: 0x0003B330 File Offset: 0x00039530
		public SynchronizedReader(TextReader reader)
		{
			this.reader = reader;
		}

		// Token: 0x06000E38 RID: 3640 RVA: 0x0003B340 File Offset: 0x00039540
		public override void Close()
		{
			lock (this)
			{
				this.reader.Close();
			}
		}

		// Token: 0x06000E39 RID: 3641 RVA: 0x0003B37C File Offset: 0x0003957C
		public override int Peek()
		{
			int num;
			lock (this)
			{
				num = this.reader.Peek();
			}
			return num;
		}

		// Token: 0x06000E3A RID: 3642 RVA: 0x0003B3C0 File Offset: 0x000395C0
		public override string ReadLine()
		{
			string text;
			lock (this)
			{
				text = this.reader.ReadLine();
			}
			return text;
		}

		// Token: 0x06000E3B RID: 3643 RVA: 0x0003B404 File Offset: 0x00039604
		public override string ReadToEnd()
		{
			string text;
			lock (this)
			{
				text = this.reader.ReadToEnd();
			}
			return text;
		}

		// Token: 0x06000E3C RID: 3644 RVA: 0x0003B448 File Offset: 0x00039648
		public override int Read()
		{
			int num;
			lock (this)
			{
				num = this.reader.Read();
			}
			return num;
		}

		// Token: 0x06000E3D RID: 3645 RVA: 0x0003B48C File Offset: 0x0003968C
		public override int Read(char[] buffer, int index, int count)
		{
			int num;
			lock (this)
			{
				num = this.reader.Read(buffer, index, count);
			}
			return num;
		}

		// Token: 0x040005FC RID: 1532
		private TextReader reader;
	}
}
