﻿using System;
using System.Text;

namespace System.IO
{
	// Token: 0x0200016C RID: 364
	[Serializable]
	internal class SynchronizedWriter : TextWriter
	{
		// Token: 0x06000E3E RID: 3646 RVA: 0x0003B4D4 File Offset: 0x000396D4
		public SynchronizedWriter(TextWriter writer, bool neverClose)
		{
			this.writer = writer;
			this.neverClose = neverClose;
		}

		// Token: 0x06000E3F RID: 3647 RVA: 0x0003B4EC File Offset: 0x000396EC
		public override void Close()
		{
			if (this.neverClose)
			{
				return;
			}
			lock (this)
			{
				this.writer.Close();
			}
		}

		// Token: 0x06000E40 RID: 3648 RVA: 0x0003B534 File Offset: 0x00039734
		public override void Flush()
		{
			lock (this)
			{
				this.writer.Flush();
			}
		}

		// Token: 0x06000E41 RID: 3649 RVA: 0x0003B570 File Offset: 0x00039770
		public override void Write(char value)
		{
			lock (this)
			{
				this.writer.Write(value);
			}
		}

		// Token: 0x06000E42 RID: 3650 RVA: 0x0003B5B0 File Offset: 0x000397B0
		public override void Write(char[] value)
		{
			lock (this)
			{
				this.writer.Write(value);
			}
		}

		// Token: 0x06000E43 RID: 3651 RVA: 0x0003B5F0 File Offset: 0x000397F0
		public override void Write(int value)
		{
			lock (this)
			{
				this.writer.Write(value);
			}
		}

		// Token: 0x06000E44 RID: 3652 RVA: 0x0003B630 File Offset: 0x00039830
		public override void Write(long value)
		{
			lock (this)
			{
				this.writer.Write(value);
			}
		}

		// Token: 0x06000E45 RID: 3653 RVA: 0x0003B670 File Offset: 0x00039870
		public override void Write(string value)
		{
			lock (this)
			{
				this.writer.Write(value);
			}
		}

		// Token: 0x06000E46 RID: 3654 RVA: 0x0003B6B0 File Offset: 0x000398B0
		public override void Write(string format, object value)
		{
			lock (this)
			{
				this.writer.Write(format, value);
			}
		}

		// Token: 0x06000E47 RID: 3655 RVA: 0x0003B6F0 File Offset: 0x000398F0
		public override void Write(string format, object[] value)
		{
			lock (this)
			{
				this.writer.Write(format, value);
			}
		}

		// Token: 0x06000E48 RID: 3656 RVA: 0x0003B730 File Offset: 0x00039930
		public override void Write(char[] buffer, int index, int count)
		{
			lock (this)
			{
				this.writer.Write(buffer, index, count);
			}
		}

		// Token: 0x06000E49 RID: 3657 RVA: 0x0003B770 File Offset: 0x00039970
		public override void Write(string format, object arg0, object arg1)
		{
			lock (this)
			{
				this.writer.Write(format, arg0, arg1);
			}
		}

		// Token: 0x06000E4A RID: 3658 RVA: 0x0003B7B0 File Offset: 0x000399B0
		public override void Write(string format, object arg0, object arg1, object arg2)
		{
			lock (this)
			{
				this.writer.Write(format, arg0, arg1, arg2);
			}
		}

		// Token: 0x06000E4B RID: 3659 RVA: 0x0003B7F4 File Offset: 0x000399F4
		public override void WriteLine()
		{
			lock (this)
			{
				this.writer.WriteLine();
			}
		}

		// Token: 0x06000E4C RID: 3660 RVA: 0x0003B830 File Offset: 0x00039A30
		public override void WriteLine(string value)
		{
			lock (this)
			{
				this.writer.WriteLine(value);
			}
		}

		// Token: 0x06000E4D RID: 3661 RVA: 0x0003B870 File Offset: 0x00039A70
		public override void WriteLine(string format, object value)
		{
			lock (this)
			{
				this.writer.WriteLine(format, value);
			}
		}

		// Token: 0x06000E4E RID: 3662 RVA: 0x0003B8B0 File Offset: 0x00039AB0
		public override void WriteLine(string format, object arg0, object arg1)
		{
			lock (this)
			{
				this.writer.WriteLine(format, arg0, arg1);
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000E4F RID: 3663 RVA: 0x0003B8F0 File Offset: 0x00039AF0
		public override Encoding Encoding
		{
			get
			{
				Encoding encoding;
				lock (this)
				{
					encoding = this.writer.Encoding;
				}
				return encoding;
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000E50 RID: 3664 RVA: 0x0003B934 File Offset: 0x00039B34
		public override string NewLine
		{
			get
			{
				string newLine;
				lock (this)
				{
					newLine = this.writer.NewLine;
				}
				return newLine;
			}
		}

		// Token: 0x040005FD RID: 1533
		private TextWriter writer;

		// Token: 0x040005FE RID: 1534
		private bool neverClose;
	}
}
