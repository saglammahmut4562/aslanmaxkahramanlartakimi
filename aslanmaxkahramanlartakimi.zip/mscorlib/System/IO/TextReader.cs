﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x0200016D RID: 365
	[ComVisible(true)]
	[Serializable]
	public abstract class TextReader : IDisposable
	{
		// Token: 0x06000E53 RID: 3667 RVA: 0x0003B98C File Offset: 0x00039B8C
		public virtual void Close()
		{
			this.Dispose(true);
		}

		// Token: 0x06000E54 RID: 3668 RVA: 0x0003B998 File Offset: 0x00039B98
		public void Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x06000E55 RID: 3669 RVA: 0x0003B9A4 File Offset: 0x00039BA4
		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				GC.SuppressFinalize(this);
			}
		}

		// Token: 0x06000E56 RID: 3670 RVA: 0x0003B9B4 File Offset: 0x00039BB4
		public virtual int Peek()
		{
			return -1;
		}

		// Token: 0x06000E57 RID: 3671 RVA: 0x0003B9B8 File Offset: 0x00039BB8
		public virtual int Read()
		{
			return -1;
		}

		// Token: 0x06000E58 RID: 3672 RVA: 0x0003B9BC File Offset: 0x00039BBC
		public virtual int Read([In] [Out] char[] buffer, int index, int count)
		{
			int i;
			for (i = 0; i < count; i++)
			{
				int num;
				if ((num = this.Read()) == -1)
				{
					return i;
				}
				buffer[index + i] = (char)num;
			}
			return i;
		}

		// Token: 0x06000E59 RID: 3673 RVA: 0x0003B9F4 File Offset: 0x00039BF4
		public virtual string ReadLine()
		{
			return string.Empty;
		}

		// Token: 0x06000E5A RID: 3674 RVA: 0x0003B9FC File Offset: 0x00039BFC
		public virtual string ReadToEnd()
		{
			return string.Empty;
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x0003BA04 File Offset: 0x00039C04
		public static TextReader Synchronized(TextReader reader)
		{
			if (reader == null)
			{
				throw new ArgumentNullException("reader is null");
			}
			if (reader is SynchronizedReader)
			{
				return reader;
			}
			return new SynchronizedReader(reader);
		}

		// Token: 0x040005FF RID: 1535
		public static readonly TextReader Null = new TextReader.NullTextReader();

		// Token: 0x0200016E RID: 366
		private class NullTextReader : TextReader
		{
			// Token: 0x06000E5D RID: 3677 RVA: 0x0003BA34 File Offset: 0x00039C34
			public override string ReadLine()
			{
				return null;
			}
		}
	}
}
