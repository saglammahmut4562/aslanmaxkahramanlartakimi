﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace System.IO
{
	// Token: 0x0200016F RID: 367
	[ComVisible(true)]
	[Serializable]
	public abstract class TextWriter : IDisposable
	{
		// Token: 0x06000E5E RID: 3678 RVA: 0x0003BA38 File Offset: 0x00039C38
		protected TextWriter()
		{
			this.CoreNewLine = Environment.NewLine.ToCharArray();
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000E60 RID: 3680
		public abstract Encoding Encoding { get; }

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000E61 RID: 3681 RVA: 0x0003BA5C File Offset: 0x00039C5C
		public virtual string NewLine
		{
			get
			{
				return new string(this.CoreNewLine);
			}
		}

		// Token: 0x06000E62 RID: 3682 RVA: 0x0003BA6C File Offset: 0x00039C6C
		public virtual void Close()
		{
			this.Dispose(true);
		}

		// Token: 0x06000E63 RID: 3683 RVA: 0x0003BA78 File Offset: 0x00039C78
		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				GC.SuppressFinalize(this);
			}
		}

		// Token: 0x06000E64 RID: 3684 RVA: 0x0003BA88 File Offset: 0x00039C88
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000E65 RID: 3685 RVA: 0x0003BA98 File Offset: 0x00039C98
		public virtual void Flush()
		{
		}

		// Token: 0x06000E66 RID: 3686 RVA: 0x0003BA9C File Offset: 0x00039C9C
		internal static TextWriter Synchronized(TextWriter writer, bool neverClose)
		{
			if (writer == null)
			{
				throw new ArgumentNullException("writer is null");
			}
			if (writer is SynchronizedWriter)
			{
				return writer;
			}
			return new SynchronizedWriter(writer, neverClose);
		}

		// Token: 0x06000E67 RID: 3687 RVA: 0x0003BAC4 File Offset: 0x00039CC4
		public virtual void Write(char value)
		{
		}

		// Token: 0x06000E68 RID: 3688 RVA: 0x0003BAC8 File Offset: 0x00039CC8
		public virtual void Write(char[] buffer)
		{
			if (buffer == null)
			{
				return;
			}
			this.Write(buffer, 0, buffer.Length);
		}

		// Token: 0x06000E69 RID: 3689 RVA: 0x0003BADC File Offset: 0x00039CDC
		public virtual void Write(int value)
		{
			this.Write(value.ToString(this.internalFormatProvider));
		}

		// Token: 0x06000E6A RID: 3690 RVA: 0x0003BAF4 File Offset: 0x00039CF4
		public virtual void Write(long value)
		{
			this.Write(value.ToString(this.internalFormatProvider));
		}

		// Token: 0x06000E6B RID: 3691 RVA: 0x0003BB0C File Offset: 0x00039D0C
		public virtual void Write(string value)
		{
			if (value != null)
			{
				this.Write(value.ToCharArray());
			}
		}

		// Token: 0x06000E6C RID: 3692 RVA: 0x0003BB20 File Offset: 0x00039D20
		public virtual void Write(string format, object arg0)
		{
			this.Write(string.Format(format, arg0));
		}

		// Token: 0x06000E6D RID: 3693 RVA: 0x0003BB30 File Offset: 0x00039D30
		public virtual void Write(string format, params object[] arg)
		{
			this.Write(string.Format(format, arg));
		}

		// Token: 0x06000E6E RID: 3694 RVA: 0x0003BB40 File Offset: 0x00039D40
		public virtual void Write(char[] buffer, int index, int count)
		{
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (index < 0 || index > buffer.Length)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (count < 0 || index > buffer.Length - count)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			while (count > 0)
			{
				this.Write(buffer[index]);
				count--;
				index++;
			}
		}

		// Token: 0x06000E6F RID: 3695 RVA: 0x0003BBB8 File Offset: 0x00039DB8
		public virtual void Write(string format, object arg0, object arg1)
		{
			this.Write(string.Format(format, arg0, arg1));
		}

		// Token: 0x06000E70 RID: 3696 RVA: 0x0003BBC8 File Offset: 0x00039DC8
		public virtual void Write(string format, object arg0, object arg1, object arg2)
		{
			this.Write(string.Format(format, arg0, arg1, arg2));
		}

		// Token: 0x06000E71 RID: 3697 RVA: 0x0003BBDC File Offset: 0x00039DDC
		public virtual void WriteLine()
		{
			this.Write(this.CoreNewLine);
		}

		// Token: 0x06000E72 RID: 3698 RVA: 0x0003BBEC File Offset: 0x00039DEC
		public virtual void WriteLine(string value)
		{
			this.Write(value);
			this.WriteLine();
		}

		// Token: 0x06000E73 RID: 3699 RVA: 0x0003BBFC File Offset: 0x00039DFC
		public virtual void WriteLine(string format, object arg0)
		{
			this.Write(format, arg0);
			this.WriteLine();
		}

		// Token: 0x06000E74 RID: 3700 RVA: 0x0003BC0C File Offset: 0x00039E0C
		public virtual void WriteLine(string format, object arg0, object arg1)
		{
			this.Write(format, arg0, arg1);
			this.WriteLine();
		}

		// Token: 0x04000600 RID: 1536
		protected char[] CoreNewLine;

		// Token: 0x04000601 RID: 1537
		internal IFormatProvider internalFormatProvider;

		// Token: 0x04000602 RID: 1538
		public static readonly TextWriter Null = new TextWriter.NullTextWriter();

		// Token: 0x02000170 RID: 368
		private sealed class NullTextWriter : TextWriter
		{
			// Token: 0x1700022E RID: 558
			// (get) Token: 0x06000E76 RID: 3702 RVA: 0x0003BC28 File Offset: 0x00039E28
			public override Encoding Encoding
			{
				get
				{
					return Encoding.Default;
				}
			}

			// Token: 0x06000E77 RID: 3703 RVA: 0x0003BC30 File Offset: 0x00039E30
			public override void Write(string s)
			{
			}

			// Token: 0x06000E78 RID: 3704 RVA: 0x0003BC34 File Offset: 0x00039E34
			public override void Write(char value)
			{
			}

			// Token: 0x06000E79 RID: 3705 RVA: 0x0003BC38 File Offset: 0x00039E38
			public override void Write(char[] value, int index, int count)
			{
			}
		}
	}
}
