﻿using System;
using System.Text;

namespace System.IO
{
	// Token: 0x02000172 RID: 370
	internal class UnexceptionalStreamWriter : StreamWriter
	{
		// Token: 0x06000E82 RID: 3714 RVA: 0x0003BED0 File Offset: 0x0003A0D0
		public UnexceptionalStreamWriter(Stream stream, Encoding encoding)
			: base(stream, encoding)
		{
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x0003BEDC File Offset: 0x0003A0DC
		public override void Flush()
		{
			try
			{
				base.Flush();
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x0003BF0C File Offset: 0x0003A10C
		public override void Write(char[] buffer, int index, int count)
		{
			try
			{
				base.Write(buffer, index, count);
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000E85 RID: 3717 RVA: 0x0003BF40 File Offset: 0x0003A140
		public override void Write(char value)
		{
			try
			{
				base.Write(value);
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x0003BF70 File Offset: 0x0003A170
		public override void Write(char[] value)
		{
			try
			{
				base.Write(value);
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x0003BFA0 File Offset: 0x0003A1A0
		public override void Write(string value)
		{
			try
			{
				base.Write(value);
			}
			catch (Exception)
			{
			}
		}
	}
}
