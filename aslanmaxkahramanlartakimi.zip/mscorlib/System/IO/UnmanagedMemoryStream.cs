﻿using System;
using System.Runtime.InteropServices;

namespace System.IO
{
	// Token: 0x02000173 RID: 371
	[CLSCompliant(false)]
	public class UnmanagedMemoryStream : Stream
	{
		// Token: 0x06000E88 RID: 3720 RVA: 0x0003BFD0 File Offset: 0x0003A1D0
		public unsafe UnmanagedMemoryStream(byte* pointer, long length)
		{
			this.Initialize(pointer, length, length, FileAccess.Read);
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06000E89 RID: 3721 RVA: 0x0003BFE4 File Offset: 0x0003A1E4
		// (remove) Token: 0x06000E8A RID: 3722 RVA: 0x0003C000 File Offset: 0x0003A200
		internal event EventHandler Closed;

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000E8B RID: 3723 RVA: 0x0003C01C File Offset: 0x0003A21C
		public override bool CanRead
		{
			get
			{
				return !this.closed && this.fileaccess != FileAccess.Write;
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000E8C RID: 3724 RVA: 0x0003C038 File Offset: 0x0003A238
		public override bool CanSeek
		{
			get
			{
				return !this.closed;
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000E8D RID: 3725 RVA: 0x0003C044 File Offset: 0x0003A244
		public override bool CanWrite
		{
			get
			{
				return !this.closed && this.fileaccess != FileAccess.Read;
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000E8E RID: 3726 RVA: 0x0003C060 File Offset: 0x0003A260
		public override long Length
		{
			get
			{
				if (this.closed)
				{
					throw new ObjectDisposedException("The stream is closed");
				}
				return this.length;
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000E8F RID: 3727 RVA: 0x0003C080 File Offset: 0x0003A280
		// (set) Token: 0x06000E90 RID: 3728 RVA: 0x0003C0A0 File Offset: 0x0003A2A0
		public override long Position
		{
			get
			{
				if (this.closed)
				{
					throw new ObjectDisposedException("The stream is closed");
				}
				return this.current_position;
			}
			set
			{
				if (this.closed)
				{
					throw new ObjectDisposedException("The stream is closed");
				}
				if (value < 0L)
				{
					throw new ArgumentOutOfRangeException("value", "Non-negative number required.");
				}
				if (value > 2147483647L)
				{
					throw new ArgumentOutOfRangeException("value", "The position is larger than Int32.MaxValue.");
				}
				this.current_position = value;
			}
		}

		// Token: 0x06000E91 RID: 3729 RVA: 0x0003C100 File Offset: 0x0003A300
		public override int Read([In] [Out] byte[] buffer, int offset, int count)
		{
			if (this.closed)
			{
				throw new ObjectDisposedException("The stream is closed");
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset", "Non-negative number required.");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "Non-negative number required.");
			}
			if (buffer.Length - offset < count)
			{
				throw new ArgumentException("The length of the buffer array minus the offset parameter is less than the count parameter");
			}
			if (this.fileaccess == FileAccess.Write)
			{
				throw new NotSupportedException("Stream does not support reading");
			}
			if (this.current_position >= this.length)
			{
				return 0;
			}
			int num = ((this.current_position + (long)count >= this.length) ? ((int)(this.length - this.current_position)) : count);
			Marshal.Copy(new IntPtr(this.initial_pointer.ToInt64() + this.current_position), buffer, offset, num);
			this.current_position += (long)num;
			return num;
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x0003C1FC File Offset: 0x0003A3FC
		public override int ReadByte()
		{
			if (this.closed)
			{
				throw new ObjectDisposedException("The stream is closed");
			}
			if (this.fileaccess == FileAccess.Write)
			{
				throw new NotSupportedException("Stream does not support reading");
			}
			if (this.current_position >= this.length)
			{
				return -1;
			}
			IntPtr intPtr = this.initial_pointer;
			long num;
			this.current_position = (num = this.current_position) + 1L;
			return (int)Marshal.ReadByte(intPtr, (int)num);
		}

		// Token: 0x06000E93 RID: 3731 RVA: 0x0003C268 File Offset: 0x0003A468
		public override long Seek(long offset, SeekOrigin loc)
		{
			if (this.closed)
			{
				throw new ObjectDisposedException("The stream is closed");
			}
			long num;
			switch (loc)
			{
			case SeekOrigin.Begin:
				if (offset < 0L)
				{
					throw new IOException("An attempt was made to seek before the beginning of the stream");
				}
				num = this.initial_position;
				break;
			case SeekOrigin.Current:
				num = this.current_position;
				break;
			case SeekOrigin.End:
				num = this.length;
				break;
			default:
				throw new ArgumentException("Invalid SeekOrigin option");
			}
			num += offset;
			if (num < this.initial_position)
			{
				throw new IOException("An attempt was made to seek before the beginning of the stream");
			}
			this.current_position = num;
			return this.current_position;
		}

		// Token: 0x06000E94 RID: 3732 RVA: 0x0003C310 File Offset: 0x0003A510
		public override void SetLength(long value)
		{
			if (this.closed)
			{
				throw new ObjectDisposedException("The stream is closed");
			}
			if (value < 0L)
			{
				throw new ArgumentOutOfRangeException("length", "Non-negative number required.");
			}
			if (value > this.capacity)
			{
				throw new IOException("Unable to expand length of this stream beyond its capacity.");
			}
			if (this.fileaccess == FileAccess.Read)
			{
				throw new NotSupportedException("Stream does not support writing.");
			}
			this.length = value;
			if (this.length < this.current_position)
			{
				this.current_position = this.length;
			}
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x0003C3A0 File Offset: 0x0003A5A0
		public override void Flush()
		{
			if (this.closed)
			{
				throw new ObjectDisposedException("The stream is closed");
			}
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x0003C3B8 File Offset: 0x0003A5B8
		protected override void Dispose(bool disposing)
		{
			if (this.closed)
			{
				return;
			}
			this.closed = true;
			if (this.Closed != null)
			{
				this.Closed(this, null);
			}
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x0003C3E8 File Offset: 0x0003A5E8
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this.closed)
			{
				throw new ObjectDisposedException("The stream is closed");
			}
			if (buffer == null)
			{
				throw new ArgumentNullException("The buffer parameter is a null reference");
			}
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset", "Non-negative number required.");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "Non-negative number required.");
			}
			if (buffer.Length - offset < count)
			{
				throw new ArgumentException("The length of the buffer array minus the offset parameter is less than the count parameter");
			}
			if (this.current_position > this.capacity - (long)count)
			{
				throw new NotSupportedException("Unable to expand length of this stream beyond its capacity.");
			}
			if (this.fileaccess == FileAccess.Read)
			{
				throw new NotSupportedException("Stream does not support writing.");
			}
			for (int i = 0; i < count; i++)
			{
				IntPtr intPtr = this.initial_pointer;
				long num;
				this.current_position = (num = this.current_position) + 1L;
				Marshal.WriteByte(intPtr, (int)num, buffer[offset + i]);
			}
			if (this.current_position > this.length)
			{
				this.length = this.current_position;
			}
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x0003C4E8 File Offset: 0x0003A6E8
		public override void WriteByte(byte value)
		{
			if (this.closed)
			{
				throw new ObjectDisposedException("The stream is closed");
			}
			if (this.current_position == this.capacity)
			{
				throw new NotSupportedException("The current position is at the end of the capacity of the stream");
			}
			if (this.fileaccess == FileAccess.Read)
			{
				throw new NotSupportedException("Stream does not support writing.");
			}
			Marshal.WriteByte(this.initial_pointer, (int)this.current_position, value);
			this.current_position += 1L;
			if (this.current_position > this.length)
			{
				this.length = this.current_position;
			}
		}

		// Token: 0x06000E99 RID: 3737 RVA: 0x0003C580 File Offset: 0x0003A780
		protected unsafe void Initialize(byte* pointer, long length, long capacity, FileAccess access)
		{
			if (pointer == null)
			{
				throw new ArgumentNullException("pointer");
			}
			if (length < 0L)
			{
				throw new ArgumentOutOfRangeException("length", "Non-negative number required.");
			}
			if (capacity < 0L)
			{
				throw new ArgumentOutOfRangeException("capacity", "Non-negative number required.");
			}
			if (length > capacity)
			{
				throw new ArgumentOutOfRangeException("length", "The length cannot be greater than the capacity.");
			}
			if (access < FileAccess.Read || access > FileAccess.ReadWrite)
			{
				throw new ArgumentOutOfRangeException("access", "Enum value was out of legal range.");
			}
			this.fileaccess = access;
			this.length = length;
			this.capacity = capacity;
			this.initial_position = 0L;
			this.current_position = this.initial_position;
			this.initial_pointer = new IntPtr((void*)pointer);
			this.closed = false;
		}

		// Token: 0x04000605 RID: 1541
		private long length;

		// Token: 0x04000606 RID: 1542
		private bool closed;

		// Token: 0x04000607 RID: 1543
		private long capacity;

		// Token: 0x04000608 RID: 1544
		private FileAccess fileaccess;

		// Token: 0x04000609 RID: 1545
		private IntPtr initial_pointer;

		// Token: 0x0400060A RID: 1546
		private long initial_position;

		// Token: 0x0400060B RID: 1547
		private long current_position;
	}
}
