﻿using System;

namespace System
{
	// Token: 0x02000174 RID: 372
	public interface IServiceProvider
	{
		// Token: 0x06000E9A RID: 3738
		object GetService(Type serviceType);
	}
}
