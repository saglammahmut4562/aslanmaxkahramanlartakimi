﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200013C RID: 316
	[ComVisible(true)]
	[Serializable]
	public sealed class IndexOutOfRangeException : SystemException
	{
		// Token: 0x06000C4E RID: 3150 RVA: 0x00032F4C File Offset: 0x0003114C
		public IndexOutOfRangeException()
			: base(Locale.GetText("Array index is out of range."))
		{
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x00032F60 File Offset: 0x00031160
		public IndexOutOfRangeException(string message)
			: base(message)
		{
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x00032F6C File Offset: 0x0003116C
		internal IndexOutOfRangeException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
