﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200013D RID: 317
	[ComVisible(true)]
	[Serializable]
	public struct Int16 : IComparable<short>, IEquatable<short>, IComparable, IConvertible, IFormattable
	{
		// Token: 0x06000C51 RID: 3153 RVA: 0x00032F78 File Offset: 0x00031178
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return Convert.ToBoolean(this);
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x00032F84 File Offset: 0x00031184
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this);
		}

		// Token: 0x06000C53 RID: 3155 RVA: 0x00032F90 File Offset: 0x00031190
		char IConvertible.ToChar(IFormatProvider provider)
		{
			return Convert.ToChar(this);
		}

		// Token: 0x06000C54 RID: 3156 RVA: 0x00032F9C File Offset: 0x0003119C
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			return Convert.ToDateTime(this);
		}

		// Token: 0x06000C55 RID: 3157 RVA: 0x00032FA8 File Offset: 0x000311A8
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return Convert.ToDecimal(this);
		}

		// Token: 0x06000C56 RID: 3158 RVA: 0x00032FB4 File Offset: 0x000311B4
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this);
		}

		// Token: 0x06000C57 RID: 3159 RVA: 0x00032FC0 File Offset: 0x000311C0
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x06000C58 RID: 3160 RVA: 0x00032FCC File Offset: 0x000311CC
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x06000C59 RID: 3161 RVA: 0x00032FD8 File Offset: 0x000311D8
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x06000C5A RID: 3162 RVA: 0x00032FE4 File Offset: 0x000311E4
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x06000C5B RID: 3163 RVA: 0x00032FF0 File Offset: 0x000311F0
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return Convert.ToSingle(this);
		}

		// Token: 0x06000C5C RID: 3164 RVA: 0x00032FFC File Offset: 0x000311FC
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			return Convert.ToType(this, targetType, provider, false);
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x00033020 File Offset: 0x00031220
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x06000C5E RID: 3166 RVA: 0x0003302C File Offset: 0x0003122C
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x06000C5F RID: 3167 RVA: 0x00033038 File Offset: 0x00031238
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x06000C60 RID: 3168 RVA: 0x00033044 File Offset: 0x00031244
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is short))
			{
				throw new ArgumentException(Locale.GetText("Value is not a System.Int16"));
			}
			short num = (short)value;
			if (this == num)
			{
				return 0;
			}
			if (this > num)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x06000C61 RID: 3169 RVA: 0x00033090 File Offset: 0x00031290
		public override bool Equals(object obj)
		{
			return obj is short && (short)obj == this;
		}

		// Token: 0x06000C62 RID: 3170 RVA: 0x000330AC File Offset: 0x000312AC
		public override int GetHashCode()
		{
			return (int)this;
		}

		// Token: 0x06000C63 RID: 3171 RVA: 0x000330B0 File Offset: 0x000312B0
		public int CompareTo(short value)
		{
			if (this == value)
			{
				return 0;
			}
			if (this > value)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x06000C64 RID: 3172 RVA: 0x000330C8 File Offset: 0x000312C8
		public bool Equals(short obj)
		{
			return obj == this;
		}

		// Token: 0x06000C65 RID: 3173 RVA: 0x000330D0 File Offset: 0x000312D0
		internal static bool Parse(string s, bool tryParse, out short result, out Exception exc)
		{
			short num = 0;
			int num2 = 1;
			bool flag = false;
			result = 0;
			exc = null;
			if (s == null)
			{
				if (!tryParse)
				{
					exc = new ArgumentNullException("s");
				}
				return false;
			}
			int length = s.Length;
			int i;
			char c;
			for (i = 0; i < length; i++)
			{
				c = s[i];
				if (!char.IsWhiteSpace(c))
				{
					break;
				}
			}
			if (i == length)
			{
				if (!tryParse)
				{
					exc = int.GetFormatException();
				}
				return false;
			}
			c = s[i];
			if (c == '+')
			{
				i++;
			}
			else if (c == '-')
			{
				num2 = -1;
				i++;
			}
			while (i < length)
			{
				c = s[i];
				if (c >= '0' && c <= '9')
				{
					byte b = (byte)(c - '0');
					if (num <= 3276)
					{
						if (num != 3276)
						{
							num = num * 10 + (short)b;
							flag = true;
							goto IL_0154;
						}
						if (b <= 7 || (num2 != 1 && b <= 8))
						{
							if (num2 == -1)
							{
								num = (short)((int)num * num2 * 10 - (int)b);
							}
							else
							{
								num = num * 10 + (short)b;
							}
							if (int.ProcessTrailingWhitespace(tryParse, s, i + 1, ref exc))
							{
								result = num;
								return true;
							}
						}
					}
					if (!tryParse)
					{
						exc = new OverflowException("Value is too large");
					}
					return false;
				}
				if (!int.ProcessTrailingWhitespace(tryParse, s, i, ref exc))
				{
					return false;
				}
				IL_0154:
				i++;
			}
			if (!flag)
			{
				if (!tryParse)
				{
					exc = int.GetFormatException();
				}
				return false;
			}
			if (num2 == -1)
			{
				result = (short)((int)num * num2);
			}
			else
			{
				result = num;
			}
			return true;
		}

		// Token: 0x06000C66 RID: 3174 RVA: 0x0003327C File Offset: 0x0003147C
		public static short Parse(string s, IFormatProvider provider)
		{
			return short.Parse(s, NumberStyles.Integer, provider);
		}

		// Token: 0x06000C67 RID: 3175 RVA: 0x00033288 File Offset: 0x00031488
		public static short Parse(string s, NumberStyles style, IFormatProvider provider)
		{
			int num = int.Parse(s, style, provider);
			if (num > 32767 || num < -32768)
			{
				throw new OverflowException("Value too large or too small.");
			}
			return (short)num;
		}

		// Token: 0x06000C68 RID: 3176 RVA: 0x000332C4 File Offset: 0x000314C4
		public static bool TryParse(string s, out short result)
		{
			Exception ex;
			if (!short.Parse(s, true, out result, out ex))
			{
				result = 0;
				return false;
			}
			return true;
		}

		// Token: 0x06000C69 RID: 3177 RVA: 0x000332E8 File Offset: 0x000314E8
		public override string ToString()
		{
			return NumberFormatter.NumberToString((int)this, null);
		}

		// Token: 0x06000C6A RID: 3178 RVA: 0x000332F4 File Offset: 0x000314F4
		public string ToString(IFormatProvider provider)
		{
			return NumberFormatter.NumberToString((int)this, provider);
		}

		// Token: 0x06000C6B RID: 3179 RVA: 0x00033300 File Offset: 0x00031500
		public string ToString(string format)
		{
			return this.ToString(format, null);
		}

		// Token: 0x06000C6C RID: 3180 RVA: 0x0003330C File Offset: 0x0003150C
		public string ToString(string format, IFormatProvider provider)
		{
			return NumberFormatter.NumberToString(format, this, provider);
		}

		// Token: 0x06000C6D RID: 3181 RVA: 0x00033318 File Offset: 0x00031518
		public TypeCode GetTypeCode()
		{
			return TypeCode.Int16;
		}

		// Token: 0x0400051A RID: 1306
		public const short MaxValue = 32767;

		// Token: 0x0400051B RID: 1307
		public const short MinValue = -32768;

		// Token: 0x0400051C RID: 1308
		internal short m_value;
	}
}
