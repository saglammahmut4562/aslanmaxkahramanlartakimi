﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;

namespace System
{
	// Token: 0x0200013F RID: 319
	[ComVisible(true)]
	[Serializable]
	public struct Int64 : IComparable<long>, IEquatable<long>, IComparable, IConvertible, IFormattable
	{
		// Token: 0x06000C98 RID: 3224 RVA: 0x00034194 File Offset: 0x00032394
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return Convert.ToBoolean(this);
		}

		// Token: 0x06000C99 RID: 3225 RVA: 0x000341A0 File Offset: 0x000323A0
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this);
		}

		// Token: 0x06000C9A RID: 3226 RVA: 0x000341AC File Offset: 0x000323AC
		char IConvertible.ToChar(IFormatProvider provider)
		{
			return Convert.ToChar(this);
		}

		// Token: 0x06000C9B RID: 3227 RVA: 0x000341B8 File Offset: 0x000323B8
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			return Convert.ToDateTime(this);
		}

		// Token: 0x06000C9C RID: 3228 RVA: 0x000341C4 File Offset: 0x000323C4
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return Convert.ToDecimal(this);
		}

		// Token: 0x06000C9D RID: 3229 RVA: 0x000341D0 File Offset: 0x000323D0
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this);
		}

		// Token: 0x06000C9E RID: 3230 RVA: 0x000341DC File Offset: 0x000323DC
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x06000C9F RID: 3231 RVA: 0x000341E8 File Offset: 0x000323E8
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x06000CA0 RID: 3232 RVA: 0x000341F4 File Offset: 0x000323F4
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x06000CA1 RID: 3233 RVA: 0x00034200 File Offset: 0x00032400
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x06000CA2 RID: 3234 RVA: 0x0003420C File Offset: 0x0003240C
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return Convert.ToSingle(this);
		}

		// Token: 0x06000CA3 RID: 3235 RVA: 0x00034218 File Offset: 0x00032418
		object IConvertible.ToType(Type targetType, IFormatProvider provider)
		{
			if (targetType == null)
			{
				throw new ArgumentNullException("targetType");
			}
			return Convert.ToType(this, targetType, provider, false);
		}

		// Token: 0x06000CA4 RID: 3236 RVA: 0x0003423C File Offset: 0x0003243C
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x06000CA5 RID: 3237 RVA: 0x00034248 File Offset: 0x00032448
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x06000CA6 RID: 3238 RVA: 0x00034254 File Offset: 0x00032454
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x06000CA7 RID: 3239 RVA: 0x00034260 File Offset: 0x00032460
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is long))
			{
				throw new ArgumentException(Locale.GetText("Value is not a System.Int64"));
			}
			long num = (long)value;
			if (this == num)
			{
				return 0;
			}
			return (this >= num) ? 1 : (-1);
		}

		// Token: 0x06000CA8 RID: 3240 RVA: 0x000342B0 File Offset: 0x000324B0
		public override bool Equals(object obj)
		{
			return obj is long && (long)obj == this;
		}

		// Token: 0x06000CA9 RID: 3241 RVA: 0x000342CC File Offset: 0x000324CC
		public override int GetHashCode()
		{
			return (int)(this & (long)((ulong)(-1))) ^ (int)(this >> 32);
		}

		// Token: 0x06000CAA RID: 3242 RVA: 0x000342DC File Offset: 0x000324DC
		public int CompareTo(long value)
		{
			if (this == value)
			{
				return 0;
			}
			if (this > value)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x06000CAB RID: 3243 RVA: 0x000342F4 File Offset: 0x000324F4
		public bool Equals(long obj)
		{
			return obj == this;
		}

		// Token: 0x06000CAC RID: 3244 RVA: 0x000342FC File Offset: 0x000324FC
		internal static bool Parse(string s, bool tryParse, out long result, out Exception exc)
		{
			long num = 0L;
			int num2 = 1;
			bool flag = false;
			result = 0L;
			exc = null;
			if (s == null)
			{
				if (!tryParse)
				{
					exc = new ArgumentNullException("s");
				}
				return false;
			}
			int length = s.Length;
			int i;
			char c;
			for (i = 0; i < length; i++)
			{
				c = s[i];
				if (!char.IsWhiteSpace(c))
				{
					break;
				}
			}
			if (i == length)
			{
				if (!tryParse)
				{
					exc = int.GetFormatException();
				}
				return false;
			}
			c = s[i];
			if (c == '+')
			{
				i++;
			}
			else if (c == '-')
			{
				num2 = -1;
				i++;
			}
			while (i < length)
			{
				c = s[i];
				if (c >= '0' && c <= '9')
				{
					byte b = (byte)(c - '0');
					if (num <= 922337203685477580L)
					{
						if (num != 922337203685477580L)
						{
							num = num * 10L + (long)b;
							flag = true;
							goto IL_0166;
						}
						if ((long)b <= 7L || (num2 != 1 && (long)b <= 8L))
						{
							if (num2 == -1)
							{
								num = num * (long)num2 * 10L - (long)b;
							}
							else
							{
								num = num * 10L + (long)b;
							}
							if (int.ProcessTrailingWhitespace(tryParse, s, i + 1, ref exc))
							{
								result = num;
								return true;
							}
						}
					}
					if (!tryParse)
					{
						exc = new OverflowException("Value is too large");
					}
					return false;
				}
				if (!int.ProcessTrailingWhitespace(tryParse, s, i, ref exc))
				{
					return false;
				}
				IL_0166:
				i++;
			}
			if (!flag)
			{
				if (!tryParse)
				{
					exc = int.GetFormatException();
				}
				return false;
			}
			if (num2 == -1)
			{
				result = num * (long)num2;
			}
			else
			{
				result = num;
			}
			return true;
		}

		// Token: 0x06000CAD RID: 3245 RVA: 0x000344BC File Offset: 0x000326BC
		public static long Parse(string s, IFormatProvider provider)
		{
			return long.Parse(s, NumberStyles.Integer, provider);
		}

		// Token: 0x06000CAE RID: 3246 RVA: 0x000344C8 File Offset: 0x000326C8
		internal static bool Parse(string s, NumberStyles style, IFormatProvider fp, bool tryParse, out long result, out Exception exc)
		{
			result = 0L;
			exc = null;
			if (s == null)
			{
				if (!tryParse)
				{
					exc = new ArgumentNullException("s");
				}
				return false;
			}
			if (s.Length == 0)
			{
				if (!tryParse)
				{
					exc = new FormatException("Input string was not in the correct format: s.Length==0.");
				}
				return false;
			}
			NumberFormatInfo numberFormatInfo = null;
			if (fp != null)
			{
				Type typeFromHandle = typeof(NumberFormatInfo);
				numberFormatInfo = (NumberFormatInfo)fp.GetFormat(typeFromHandle);
			}
			if (numberFormatInfo == null)
			{
				numberFormatInfo = Thread.CurrentThread.CurrentCulture.NumberFormat;
			}
			if (!int.CheckStyle(style, tryParse, ref exc))
			{
				return false;
			}
			bool flag = (style & NumberStyles.AllowCurrencySymbol) != NumberStyles.None;
			bool flag2 = (style & NumberStyles.AllowHexSpecifier) != NumberStyles.None;
			bool flag3 = (style & NumberStyles.AllowThousands) != NumberStyles.None;
			bool flag4 = (style & NumberStyles.AllowDecimalPoint) != NumberStyles.None;
			bool flag5 = (style & NumberStyles.AllowParentheses) != NumberStyles.None;
			bool flag6 = (style & NumberStyles.AllowTrailingSign) != NumberStyles.None;
			bool flag7 = (style & NumberStyles.AllowLeadingSign) != NumberStyles.None;
			bool flag8 = (style & NumberStyles.AllowTrailingWhite) != NumberStyles.None;
			bool flag9 = (style & NumberStyles.AllowLeadingWhite) != NumberStyles.None;
			int num = 0;
			if (flag9 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
			{
				return false;
			}
			bool flag10 = false;
			bool flag11 = false;
			bool flag12 = false;
			bool flag13 = false;
			if (flag5 && s[num] == '(')
			{
				flag10 = true;
				flag12 = true;
				flag11 = true;
				num++;
				if (flag9 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
				{
					return false;
				}
				if (s.Substring(num, numberFormatInfo.NegativeSign.Length) == numberFormatInfo.NegativeSign)
				{
					if (!tryParse)
					{
						exc = new FormatException("Input string was not in the correct format: Has Negative Sign.");
					}
					return false;
				}
				if (s.Substring(num, numberFormatInfo.PositiveSign.Length) == numberFormatInfo.PositiveSign)
				{
					if (!tryParse)
					{
						exc = new FormatException("Input string was not in the correct format: Has Positive Sign.");
					}
					return false;
				}
			}
			if (flag7 && !flag12)
			{
				int.FindSign(ref num, s, numberFormatInfo, ref flag12, ref flag11);
				if (flag12)
				{
					if (flag9 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
					{
						return false;
					}
					if (flag)
					{
						int.FindCurrency(ref num, s, numberFormatInfo, ref flag13);
						if (flag13 && flag9 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
						{
							return false;
						}
					}
				}
			}
			if (flag && !flag13)
			{
				int.FindCurrency(ref num, s, numberFormatInfo, ref flag13);
				if (flag13)
				{
					if (flag9 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
					{
						return false;
					}
					if (flag13 && !flag12 && flag7)
					{
						int.FindSign(ref num, s, numberFormatInfo, ref flag12, ref flag11);
						if (flag12 && flag9 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
						{
							return false;
						}
					}
				}
			}
			long num2 = 0L;
			int num3 = 0;
			bool flag14 = false;
			do
			{
				if (!int.ValidDigit(s[num], flag2))
				{
					if (!flag3 || (!int.FindOther(ref num, s, numberFormatInfo.NumberGroupSeparator) && !int.FindOther(ref num, s, numberFormatInfo.CurrencyGroupSeparator)))
					{
						if (flag14 || !flag4 || (!int.FindOther(ref num, s, numberFormatInfo.NumberDecimalSeparator) && !int.FindOther(ref num, s, numberFormatInfo.CurrencyDecimalSeparator)))
						{
							break;
						}
						flag14 = true;
					}
				}
				else if (flag2)
				{
					num3++;
					char c = s[num++];
					int num4;
					if (char.IsDigit(c))
					{
						num4 = (int)(c - '0');
					}
					else if (char.IsLower(c))
					{
						num4 = (int)(c - 'a' + '\n');
					}
					else
					{
						num4 = (int)(c - 'A' + '\n');
					}
					ulong num5 = (ulong)num2;
					try
					{
						num2 = (long)(checked(num5 * 16UL + (ulong)num4));
					}
					catch (OverflowException ex)
					{
						if (!tryParse)
						{
							exc = ex;
						}
						return false;
					}
				}
				else if (flag14)
				{
					num3++;
					if (s[num++] != '0')
					{
						goto Block_49;
					}
				}
				else
				{
					num3++;
					checked
					{
						try
						{
							num2 = num2 * 10L - unchecked((long)(checked(s[num++] - '0')));
						}
						catch (OverflowException)
						{
							if (!tryParse)
							{
								exc = new OverflowException("Value too large or too small.");
							}
							return false;
						}
					}
				}
			}
			while (num < s.Length);
			goto IL_0462;
			Block_49:
			if (!tryParse)
			{
				exc = new OverflowException("Value too large or too small.");
			}
			return false;
			IL_0462:
			if (num3 == 0)
			{
				if (!tryParse)
				{
					exc = new FormatException("Input string was not in the correct format: nDigits == 0.");
				}
				return false;
			}
			if (flag6 && !flag12)
			{
				int.FindSign(ref num, s, numberFormatInfo, ref flag12, ref flag11);
				if (flag12)
				{
					if (flag8 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
					{
						return false;
					}
					if (flag)
					{
						int.FindCurrency(ref num, s, numberFormatInfo, ref flag13);
					}
				}
			}
			if (flag && !flag13)
			{
				if (numberFormatInfo.CurrencyPositivePattern == 3 && s[num++] != ' ')
				{
					if (tryParse)
					{
						return false;
					}
					throw new FormatException("Input string was not in the correct format: no space between number and currency symbol.");
				}
				else
				{
					int.FindCurrency(ref num, s, numberFormatInfo, ref flag13);
					if (flag13 && num < s.Length)
					{
						if (flag8 && !int.JumpOverWhite(ref num, s, true, tryParse, ref exc))
						{
							return false;
						}
						if (!flag12 && flag6)
						{
							int.FindSign(ref num, s, numberFormatInfo, ref flag12, ref flag11);
						}
					}
				}
			}
			if (flag8 && num < s.Length && !int.JumpOverWhite(ref num, s, false, tryParse, ref exc))
			{
				return false;
			}
			if (flag10)
			{
				if (num >= s.Length || s[num++] != ')')
				{
					if (!tryParse)
					{
						exc = new FormatException("Input string was not in the correct format: No room for close parens.");
					}
					return false;
				}
				if (flag8 && num < s.Length && !int.JumpOverWhite(ref num, s, false, tryParse, ref exc))
				{
					return false;
				}
			}
			if (num < s.Length && s[num] != '\0')
			{
				if (!tryParse)
				{
					exc = new FormatException(string.Concat(new object[] { "Input string was not in the correct format: Did not parse entire string. pos = ", num, " s.Length = ", s.Length }));
				}
				return false;
			}
			checked
			{
				if (!flag11 && !flag2)
				{
					try
					{
						num2 = (long)(unchecked((ulong)0) - (ulong)num2);
					}
					catch (OverflowException ex2)
					{
						if (!tryParse)
						{
							exc = ex2;
						}
						return false;
					}
				}
				result = num2;
				return true;
			}
		}

		// Token: 0x06000CAF RID: 3247 RVA: 0x00034B80 File Offset: 0x00032D80
		public static long Parse(string s)
		{
			long num;
			Exception ex;
			if (!long.Parse(s, false, out num, out ex))
			{
				throw ex;
			}
			return num;
		}

		// Token: 0x06000CB0 RID: 3248 RVA: 0x00034BA0 File Offset: 0x00032DA0
		public static long Parse(string s, NumberStyles style, IFormatProvider provider)
		{
			long num;
			Exception ex;
			if (!long.Parse(s, style, provider, false, out num, out ex))
			{
				throw ex;
			}
			return num;
		}

		// Token: 0x06000CB1 RID: 3249 RVA: 0x00034BC4 File Offset: 0x00032DC4
		public static bool TryParse(string s, out long result)
		{
			Exception ex;
			if (!long.Parse(s, true, out result, out ex))
			{
				result = 0L;
				return false;
			}
			return true;
		}

		// Token: 0x06000CB2 RID: 3250 RVA: 0x00034BE8 File Offset: 0x00032DE8
		public static bool TryParse(string s, NumberStyles style, IFormatProvider provider, out long result)
		{
			Exception ex;
			if (!long.Parse(s, style, provider, true, out result, out ex))
			{
				result = 0L;
				return false;
			}
			return true;
		}

		// Token: 0x06000CB3 RID: 3251 RVA: 0x00034C10 File Offset: 0x00032E10
		public override string ToString()
		{
			return NumberFormatter.NumberToString(this, null);
		}

		// Token: 0x06000CB4 RID: 3252 RVA: 0x00034C1C File Offset: 0x00032E1C
		public string ToString(IFormatProvider provider)
		{
			return NumberFormatter.NumberToString(this, provider);
		}

		// Token: 0x06000CB5 RID: 3253 RVA: 0x00034C28 File Offset: 0x00032E28
		public string ToString(string format)
		{
			return this.ToString(format, null);
		}

		// Token: 0x06000CB6 RID: 3254 RVA: 0x00034C34 File Offset: 0x00032E34
		public string ToString(string format, IFormatProvider provider)
		{
			return NumberFormatter.NumberToString(format, this, provider);
		}

		// Token: 0x06000CB7 RID: 3255 RVA: 0x00034C40 File Offset: 0x00032E40
		public TypeCode GetTypeCode()
		{
			return TypeCode.Int64;
		}

		// Token: 0x04000520 RID: 1312
		public const long MaxValue = 9223372036854775807L;

		// Token: 0x04000521 RID: 1313
		public const long MinValue = -9223372036854775808L;

		// Token: 0x04000522 RID: 1314
		internal long m_value;
	}
}
