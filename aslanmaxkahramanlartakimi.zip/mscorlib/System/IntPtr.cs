﻿using System;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000140 RID: 320
	[ComVisible(true)]
	[Serializable]
	public struct IntPtr : ISerializable
	{
		// Token: 0x06000CB8 RID: 3256 RVA: 0x00034C44 File Offset: 0x00032E44
		[ReliabilityContract(Consistency.MayCorruptInstance, Cer.MayFail)]
		public IntPtr(int value)
		{
			this.m_value = value;
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x00034C50 File Offset: 0x00032E50
		[ReliabilityContract(Consistency.MayCorruptInstance, Cer.MayFail)]
		public IntPtr(long value)
		{
			this.m_value = value;
		}

		// Token: 0x06000CBA RID: 3258 RVA: 0x00034C5C File Offset: 0x00032E5C
		[CLSCompliant(false)]
		[ReliabilityContract(Consistency.MayCorruptInstance, Cer.MayFail)]
		public unsafe IntPtr(void* value)
		{
			this.m_value = value;
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x00034C68 File Offset: 0x00032E68
		private IntPtr(SerializationInfo info, StreamingContext context)
		{
			long @int = info.GetInt64("value");
			this.m_value = @int;
		}

		// Token: 0x06000CBC RID: 3260 RVA: 0x00034C8C File Offset: 0x00032E8C
		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			info.AddValue("value", this.ToInt64());
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000CBD RID: 3261 RVA: 0x00034CB0 File Offset: 0x00032EB0
		public unsafe static int Size
		{
			[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
			get
			{
				return sizeof(void*);
			}
		}

		// Token: 0x06000CBE RID: 3262 RVA: 0x00034CB8 File Offset: 0x00032EB8
		public override bool Equals(object obj)
		{
			return obj is IntPtr && ((IntPtr)obj).m_value == this.m_value;
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x00034CE8 File Offset: 0x00032EE8
		public override int GetHashCode()
		{
			return this.m_value;
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x00034CF4 File Offset: 0x00032EF4
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public int ToInt32()
		{
			return this.m_value;
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x00034D00 File Offset: 0x00032F00
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public long ToInt64()
		{
			if (IntPtr.Size == 4)
			{
				return (long)this.m_value;
			}
			return this.m_value;
		}

		// Token: 0x06000CC2 RID: 3266 RVA: 0x00034D20 File Offset: 0x00032F20
		[CLSCompliant(false)]
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public unsafe void* ToPointer()
		{
			return this.m_value;
		}

		// Token: 0x06000CC3 RID: 3267 RVA: 0x00034D28 File Offset: 0x00032F28
		public override string ToString()
		{
			return this.ToString(null);
		}

		// Token: 0x06000CC4 RID: 3268 RVA: 0x00034D34 File Offset: 0x00032F34
		public string ToString(string format)
		{
			if (IntPtr.Size == 4)
			{
				return this.m_value.ToString(format);
			}
			return this.m_value.ToString(format);
		}

		// Token: 0x06000CC5 RID: 3269 RVA: 0x00034D70 File Offset: 0x00032F70
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static bool operator ==(IntPtr value1, IntPtr value2)
		{
			return value1.m_value == value2.m_value;
		}

		// Token: 0x06000CC6 RID: 3270 RVA: 0x00034D84 File Offset: 0x00032F84
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static bool operator !=(IntPtr value1, IntPtr value2)
		{
			return value1.m_value != value2.m_value;
		}

		// Token: 0x06000CC7 RID: 3271 RVA: 0x00034D9C File Offset: 0x00032F9C
		[ReliabilityContract(Consistency.MayCorruptInstance, Cer.MayFail)]
		public static explicit operator IntPtr(int value)
		{
			return new IntPtr(value);
		}

		// Token: 0x06000CC8 RID: 3272 RVA: 0x00034DA4 File Offset: 0x00032FA4
		[ReliabilityContract(Consistency.MayCorruptInstance, Cer.MayFail)]
		public static explicit operator IntPtr(long value)
		{
			return new IntPtr(value);
		}

		// Token: 0x06000CC9 RID: 3273 RVA: 0x00034DAC File Offset: 0x00032FAC
		[ReliabilityContract(Consistency.MayCorruptInstance, Cer.MayFail)]
		[CLSCompliant(false)]
		public unsafe static explicit operator IntPtr(void* value)
		{
			return new IntPtr(value);
		}

		// Token: 0x06000CCA RID: 3274 RVA: 0x00034DB4 File Offset: 0x00032FB4
		public static explicit operator int(IntPtr value)
		{
			return value.m_value;
		}

		// Token: 0x06000CCB RID: 3275 RVA: 0x00034DC0 File Offset: 0x00032FC0
		public static explicit operator long(IntPtr value)
		{
			return value.ToInt64();
		}

		// Token: 0x06000CCC RID: 3276 RVA: 0x00034DCC File Offset: 0x00032FCC
		[CLSCompliant(false)]
		public unsafe static explicit operator void*(IntPtr value)
		{
			return value.m_value;
		}

		// Token: 0x04000523 RID: 1315
		private unsafe void* m_value;

		// Token: 0x04000524 RID: 1316
		public static readonly IntPtr Zero;
	}
}
