﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000141 RID: 321
	[ComVisible(true)]
	[Serializable]
	public class InvalidCastException : SystemException
	{
		// Token: 0x06000CCD RID: 3277 RVA: 0x00034DD8 File Offset: 0x00032FD8
		public InvalidCastException()
			: base(Locale.GetText("Cannot cast from source type to destination type."))
		{
			base.HResult = -2147467262;
		}

		// Token: 0x06000CCE RID: 3278 RVA: 0x00034DF8 File Offset: 0x00032FF8
		public InvalidCastException(string message)
			: base(message)
		{
			base.HResult = -2147467262;
		}

		// Token: 0x06000CCF RID: 3279 RVA: 0x00034E0C File Offset: 0x0003300C
		protected InvalidCastException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000525 RID: 1317
		private const int Result = -2147467262;
	}
}
