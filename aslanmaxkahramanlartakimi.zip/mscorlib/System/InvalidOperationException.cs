﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000142 RID: 322
	[ComVisible(true)]
	[Serializable]
	public class InvalidOperationException : SystemException
	{
		// Token: 0x06000CD0 RID: 3280 RVA: 0x00034E18 File Offset: 0x00033018
		public InvalidOperationException()
			: base(Locale.GetText("Operation is not valid due to the current state of the object"))
		{
			base.HResult = -2146233079;
		}

		// Token: 0x06000CD1 RID: 3281 RVA: 0x00034E38 File Offset: 0x00033038
		public InvalidOperationException(string message)
			: base(message)
		{
			base.HResult = -2146233079;
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x00034E4C File Offset: 0x0003304C
		public InvalidOperationException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2146233079;
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x00034E64 File Offset: 0x00033064
		protected InvalidOperationException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000526 RID: 1318
		private const int Result = -2146233079;
	}
}
