﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000175 RID: 373
	[ComVisible(true)]
	[Serializable]
	public enum LoaderOptimization
	{
		// Token: 0x0400060E RID: 1550
		NotSpecified,
		// Token: 0x0400060F RID: 1551
		SingleDomain,
		// Token: 0x04000610 RID: 1552
		MultiDomain,
		// Token: 0x04000611 RID: 1553
		MultiDomainHost,
		// Token: 0x04000612 RID: 1554
		[Obsolete]
		DomainMask = 3,
		// Token: 0x04000613 RID: 1555
		[Obsolete]
		DisallowBindings
	}
}
