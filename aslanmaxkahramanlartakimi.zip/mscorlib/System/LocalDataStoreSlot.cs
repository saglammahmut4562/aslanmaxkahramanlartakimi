﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace System
{
	// Token: 0x02000176 RID: 374
	[ComVisible(true)]
	public sealed class LocalDataStoreSlot
	{
		// Token: 0x06000E9B RID: 3739 RVA: 0x0003C644 File Offset: 0x0003A844
		internal LocalDataStoreSlot(bool in_thread)
		{
			this.thread_local = in_thread;
			object obj = LocalDataStoreSlot.lock_obj;
			lock (obj)
			{
				bool[] array;
				if (in_thread)
				{
					array = LocalDataStoreSlot.slot_bitmap_thread;
				}
				else
				{
					array = LocalDataStoreSlot.slot_bitmap_context;
				}
				int i;
				if (array != null)
				{
					for (i = 0; i < array.Length; i++)
					{
						if (!array[i])
						{
							this.slot = i;
							array[i] = true;
							return;
						}
					}
					bool[] array2 = new bool[i + 2];
					array.CopyTo(array2, 0);
					array = array2;
				}
				else
				{
					array = new bool[2];
					i = 0;
				}
				array[i] = true;
				this.slot = i;
				if (in_thread)
				{
					LocalDataStoreSlot.slot_bitmap_thread = array;
				}
				else
				{
					LocalDataStoreSlot.slot_bitmap_context = array;
				}
			}
		}

		// Token: 0x06000E9D RID: 3741 RVA: 0x0003C720 File Offset: 0x0003A920
		protected override void Finalize()
		{
			try
			{
				Thread.FreeLocalSlotValues(this.slot, this.thread_local);
				object obj = LocalDataStoreSlot.lock_obj;
				lock (obj)
				{
					if (this.thread_local)
					{
						LocalDataStoreSlot.slot_bitmap_thread[this.slot] = false;
					}
					else
					{
						LocalDataStoreSlot.slot_bitmap_context[this.slot] = false;
					}
				}
			}
			finally
			{
				base.Finalize();
			}
		}

		// Token: 0x04000614 RID: 1556
		internal int slot;

		// Token: 0x04000615 RID: 1557
		internal bool thread_local;

		// Token: 0x04000616 RID: 1558
		private static object lock_obj = new object();

		// Token: 0x04000617 RID: 1559
		private static bool[] slot_bitmap_thread;

		// Token: 0x04000618 RID: 1560
		private static bool[] slot_bitmap_context;
	}
}
