﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;

namespace System
{
	// Token: 0x02000177 RID: 375
	[ComVisible(true)]
	[Serializable]
	public abstract class MarshalByRefObject
	{
		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000E9F RID: 3743 RVA: 0x0003C7B0 File Offset: 0x0003A9B0
		// (set) Token: 0x06000EA0 RID: 3744 RVA: 0x0003C7B8 File Offset: 0x0003A9B8
		internal ServerIdentity ObjectIdentity
		{
			get
			{
				return this._identity;
			}
			set
			{
				this._identity = value;
			}
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x0003C7C4 File Offset: 0x0003A9C4
		public virtual ObjRef CreateObjRef(Type requestedType)
		{
			if (this._identity == null)
			{
				throw new RemotingException(Locale.GetText("No remoting information was found for the object."));
			}
			return this._identity.CreateObjRef(requestedType);
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x0003C7F0 File Offset: 0x0003A9F0
		public object GetLifetimeService()
		{
			if (this._identity == null)
			{
				return null;
			}
			return this._identity.Lease;
		}

		// Token: 0x06000EA3 RID: 3747 RVA: 0x0003C80C File Offset: 0x0003AA0C
		public virtual object InitializeLifetimeService()
		{
			if (this._identity != null && this._identity.Lease != null)
			{
				return this._identity.Lease;
			}
			return new Lease();
		}

		// Token: 0x04000619 RID: 1561
		[NonSerialized]
		private ServerIdentity _identity;
	}
}
