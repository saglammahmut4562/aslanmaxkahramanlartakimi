﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;

namespace System
{
	// Token: 0x02000178 RID: 376
	public static class Math
	{
		// Token: 0x06000EA4 RID: 3748 RVA: 0x0003C83C File Offset: 0x0003AA3C
		public static double Abs(double value)
		{
			return (value >= 0.0) ? value : (-value);
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0003C858 File Offset: 0x0003AA58
		public static float Abs(float value)
		{
			return (value >= 0f) ? value : (-value);
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x0003C870 File Offset: 0x0003AA70
		public static int Abs(int value)
		{
			if (value == -2147483648)
			{
				throw new OverflowException(Locale.GetText("Value is too small."));
			}
			return (value >= 0) ? value : (-value);
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x0003C89C File Offset: 0x0003AA9C
		public static long Abs(long value)
		{
			if (value == -9223372036854775808L)
			{
				throw new OverflowException(Locale.GetText("Value is too small."));
			}
			return (value >= 0L) ? value : (-value);
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x0003C8D0 File Offset: 0x0003AAD0
		public static double Ceiling(double a)
		{
			double num = Math.Floor(a);
			if (num != a)
			{
				num += 1.0;
			}
			return num;
		}

		// Token: 0x06000EA9 RID: 3753
		[MethodImpl(4096)]
		public static extern double Floor(double d);

		// Token: 0x06000EAA RID: 3754 RVA: 0x0003C8F8 File Offset: 0x0003AAF8
		public static double Log(double a, double newBase)
		{
			double num = Math.Log(a) / Math.Log(newBase);
			return (num != 0.0) ? num : 0.0;
		}

		// Token: 0x06000EAB RID: 3755 RVA: 0x0003C934 File Offset: 0x0003AB34
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static double Max(double val1, double val2)
		{
			if (double.IsNaN(val1) || double.IsNaN(val2))
			{
				return double.NaN;
			}
			return (val1 <= val2) ? val2 : val1;
		}

		// Token: 0x06000EAC RID: 3756 RVA: 0x0003C964 File Offset: 0x0003AB64
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static int Max(int val1, int val2)
		{
			return (val1 <= val2) ? val2 : val1;
		}

		// Token: 0x06000EAD RID: 3757 RVA: 0x0003C974 File Offset: 0x0003AB74
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static double Min(double val1, double val2)
		{
			if (double.IsNaN(val1) || double.IsNaN(val2))
			{
				return double.NaN;
			}
			return (val1 >= val2) ? val2 : val1;
		}

		// Token: 0x06000EAE RID: 3758 RVA: 0x0003C9A4 File Offset: 0x0003ABA4
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static int Min(int val1, int val2)
		{
			return (val1 >= val2) ? val2 : val1;
		}

		// Token: 0x06000EAF RID: 3759 RVA: 0x0003C9B4 File Offset: 0x0003ABB4
		public static decimal Round(decimal d)
		{
			decimal num = decimal.Floor(d);
			decimal num2 = d - num;
			if ((num2 == 0.5m && 2.0m * (num / 2.0m - decimal.Floor(num / 2.0m)) != 0m) || num2 > 0.5m)
			{
				num += 1m;
			}
			return num;
		}

		// Token: 0x06000EB0 RID: 3760
		[MethodImpl(4096)]
		public static extern double Round(double a);

		// Token: 0x06000EB1 RID: 3761
		[MethodImpl(4096)]
		public static extern double Sin(double a);

		// Token: 0x06000EB2 RID: 3762
		[MethodImpl(4096)]
		public static extern double Cos(double d);

		// Token: 0x06000EB3 RID: 3763
		[MethodImpl(4096)]
		public static extern double Tan(double a);

		// Token: 0x06000EB4 RID: 3764
		[MethodImpl(4096)]
		public static extern double Acos(double d);

		// Token: 0x06000EB5 RID: 3765
		[MethodImpl(4096)]
		public static extern double Atan2(double y, double x);

		// Token: 0x06000EB6 RID: 3766
		[MethodImpl(4096)]
		public static extern double Log(double d);

		// Token: 0x06000EB7 RID: 3767
		[MethodImpl(4096)]
		public static extern double Log10(double d);

		// Token: 0x06000EB8 RID: 3768
		[MethodImpl(4096)]
		public static extern double Pow(double x, double y);

		// Token: 0x06000EB9 RID: 3769
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		[MethodImpl(4096)]
		public static extern double Sqrt(double d);

		// Token: 0x0400061A RID: 1562
		public const double E = 2.718281828459045;

		// Token: 0x0400061B RID: 1563
		public const double PI = 3.141592653589793;
	}
}
