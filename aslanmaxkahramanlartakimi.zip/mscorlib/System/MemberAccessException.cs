﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000179 RID: 377
	[ComVisible(true)]
	[Serializable]
	public class MemberAccessException : SystemException
	{
		// Token: 0x06000EBA RID: 3770 RVA: 0x0003CA50 File Offset: 0x0003AC50
		public MemberAccessException()
			: base(Locale.GetText("Cannot access a class member."))
		{
			base.HResult = -2146233062;
		}

		// Token: 0x06000EBB RID: 3771 RVA: 0x0003CA70 File Offset: 0x0003AC70
		public MemberAccessException(string message)
			: base(message)
		{
			base.HResult = -2146233062;
		}

		// Token: 0x06000EBC RID: 3772 RVA: 0x0003CA84 File Offset: 0x0003AC84
		protected MemberAccessException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x0400061C RID: 1564
		private const int Result = -2146233062;
	}
}
