﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200017A RID: 378
	[ComVisible(true)]
	[Serializable]
	public class MethodAccessException : MemberAccessException
	{
		// Token: 0x06000EBD RID: 3773 RVA: 0x0003CA90 File Offset: 0x0003AC90
		public MethodAccessException()
			: base(Locale.GetText("Attempt to access a private/protected method failed."))
		{
			base.HResult = -2146233072;
		}

		// Token: 0x06000EBE RID: 3774 RVA: 0x0003CAB0 File Offset: 0x0003ACB0
		protected MethodAccessException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x0400061D RID: 1565
		private const int Result = -2146233072;
	}
}
