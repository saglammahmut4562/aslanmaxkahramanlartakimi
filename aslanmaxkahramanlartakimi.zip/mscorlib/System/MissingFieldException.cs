﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200017B RID: 379
	[ComVisible(true)]
	[Serializable]
	public class MissingFieldException : MissingMemberException
	{
		// Token: 0x06000EBF RID: 3775 RVA: 0x0003CABC File Offset: 0x0003ACBC
		public MissingFieldException()
			: base(Locale.GetText("Cannot find requested field."))
		{
			base.HResult = -2146233071;
		}

		// Token: 0x06000EC0 RID: 3776 RVA: 0x0003CADC File Offset: 0x0003ACDC
		public MissingFieldException(string message)
			: base(message)
		{
			base.HResult = -2146233071;
		}

		// Token: 0x06000EC1 RID: 3777 RVA: 0x0003CAF0 File Offset: 0x0003ACF0
		protected MissingFieldException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000EC2 RID: 3778 RVA: 0x0003CAFC File Offset: 0x0003ACFC
		public override string Message
		{
			get
			{
				if (this.ClassName == null)
				{
					return base.Message;
				}
				string text = Locale.GetText("Field '{0}.{1}' not found.");
				return string.Format(text, this.ClassName, this.MemberName);
			}
		}

		// Token: 0x0400061E RID: 1566
		private const int Result = -2146233071;
	}
}
