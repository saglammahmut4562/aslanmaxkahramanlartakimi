﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200017C RID: 380
	[ComVisible(true)]
	[Serializable]
	public class MissingMemberException : MemberAccessException
	{
		// Token: 0x06000EC3 RID: 3779 RVA: 0x0003CB38 File Offset: 0x0003AD38
		public MissingMemberException()
			: base(Locale.GetText("Cannot find the requested class member."))
		{
			base.HResult = -2146233070;
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x0003CB58 File Offset: 0x0003AD58
		public MissingMemberException(string message)
			: base(message)
		{
			base.HResult = -2146233070;
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0003CB6C File Offset: 0x0003AD6C
		protected MissingMemberException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
			this.ClassName = info.GetString("MMClassName");
			this.MemberName = info.GetString("MMMemberName");
			this.Signature = (byte[])info.GetValue("MMSignature", typeof(byte[]));
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0003CBC4 File Offset: 0x0003ADC4
		public MissingMemberException(string className, string memberName)
		{
			this.ClassName = className;
			this.MemberName = memberName;
			base.HResult = -2146233070;
		}

		// Token: 0x06000EC7 RID: 3783 RVA: 0x0003CBE8 File Offset: 0x0003ADE8
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("MMClassName", this.ClassName);
			info.AddValue("MMMemberName", this.MemberName);
			info.AddValue("MMSignature", this.Signature);
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000EC8 RID: 3784 RVA: 0x0003CC28 File Offset: 0x0003AE28
		public override string Message
		{
			get
			{
				if (this.ClassName == null)
				{
					return base.Message;
				}
				string text = Locale.GetText("Member {0}.{1} not found.");
				return string.Format(text, this.ClassName, this.MemberName);
			}
		}

		// Token: 0x0400061F RID: 1567
		private const int Result = -2146233070;

		// Token: 0x04000620 RID: 1568
		protected string ClassName;

		// Token: 0x04000621 RID: 1569
		protected string MemberName;

		// Token: 0x04000622 RID: 1570
		protected byte[] Signature;
	}
}
