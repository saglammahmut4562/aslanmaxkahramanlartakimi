﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200017D RID: 381
	[ComVisible(true)]
	[Serializable]
	public class MissingMethodException : MissingMemberException
	{
		// Token: 0x06000EC9 RID: 3785 RVA: 0x0003CC64 File Offset: 0x0003AE64
		public MissingMethodException()
			: base(Locale.GetText("Cannot find the requested method."))
		{
			base.HResult = -2146233069;
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x0003CC84 File Offset: 0x0003AE84
		public MissingMethodException(string message)
			: base(message)
		{
			base.HResult = -2146233069;
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x0003CC98 File Offset: 0x0003AE98
		protected MissingMethodException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x06000ECC RID: 3788 RVA: 0x0003CCA4 File Offset: 0x0003AEA4
		public MissingMethodException(string className, string methodName)
			: base(className, methodName)
		{
			base.HResult = -2146233069;
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000ECD RID: 3789 RVA: 0x0003CCBC File Offset: 0x0003AEBC
		public override string Message
		{
			get
			{
				if (this.ClassName == null)
				{
					return base.Message;
				}
				string text = Locale.GetText("Method not found: '{0}.{1}'.");
				return string.Format(text, this.ClassName, this.MemberName);
			}
		}

		// Token: 0x04000623 RID: 1571
		private const int Result = -2146233069;
	}
}
