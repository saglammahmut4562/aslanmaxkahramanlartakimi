﻿using System;

namespace System
{
	// Token: 0x0200017E RID: 382
	internal class MonoAsyncCall
	{
		// Token: 0x04000624 RID: 1572
		private object msg;

		// Token: 0x04000625 RID: 1573
		private IntPtr cb_method;

		// Token: 0x04000626 RID: 1574
		private object cb_target;

		// Token: 0x04000627 RID: 1575
		private object state;

		// Token: 0x04000628 RID: 1576
		private object res;

		// Token: 0x04000629 RID: 1577
		private object out_args;

		// Token: 0x0400062A RID: 1578
		private long wait_event;
	}
}
