﻿using System;

namespace System
{
	// Token: 0x02000181 RID: 385
	[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
	internal class MonoDocumentationNoteAttribute : MonoTODOAttribute
	{
		// Token: 0x06000EDE RID: 3806 RVA: 0x0003D420 File Offset: 0x0003B620
		public MonoDocumentationNoteAttribute(string comment)
			: base(comment)
		{
		}
	}
}
