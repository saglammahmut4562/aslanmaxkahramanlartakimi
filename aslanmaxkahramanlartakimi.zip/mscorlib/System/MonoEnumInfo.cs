﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace System
{
	// Token: 0x02000182 RID: 386
	internal struct MonoEnumInfo
	{
		// Token: 0x06000EDF RID: 3807 RVA: 0x0003D42C File Offset: 0x0003B62C
		private MonoEnumInfo(MonoEnumInfo other)
		{
			this.utype = other.utype;
			this.values = other.values;
			this.names = other.names;
			this.name_hash = other.name_hash;
		}

		// Token: 0x06000EE1 RID: 3809
		[MethodImpl(4096)]
		private static extern void get_enum_info(Type enumType, out MonoEnumInfo info);

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000EE2 RID: 3810 RVA: 0x0003D4A4 File Offset: 0x0003B6A4
		private static Hashtable Cache
		{
			get
			{
				if (MonoEnumInfo.cache == null)
				{
					MonoEnumInfo.cache = new Hashtable();
				}
				return MonoEnumInfo.cache;
			}
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x0003D4C0 File Offset: 0x0003B6C0
		internal static void GetInfo(Type enumType, out MonoEnumInfo info)
		{
			if (MonoEnumInfo.Cache.ContainsKey(enumType))
			{
				info = (MonoEnumInfo)MonoEnumInfo.cache[enumType];
				return;
			}
			object obj = MonoEnumInfo.global_cache_monitor;
			lock (obj)
			{
				if (MonoEnumInfo.global_cache.ContainsKey(enumType))
				{
					object obj2 = MonoEnumInfo.global_cache[enumType];
					MonoEnumInfo.cache[enumType] = obj2;
					info = (MonoEnumInfo)obj2;
					return;
				}
			}
			MonoEnumInfo.get_enum_info(enumType, out info);
			IComparer comparer = null;
			if (info.values is int[])
			{
				comparer = MonoEnumInfo.int_comparer;
			}
			else if (info.values is short[])
			{
				comparer = MonoEnumInfo.short_comparer;
			}
			else if (info.values is sbyte[])
			{
				comparer = MonoEnumInfo.sbyte_comparer;
			}
			else if (info.values is long[])
			{
				comparer = MonoEnumInfo.long_comparer;
			}
			Array.Sort(info.values, info.names, comparer);
			if (info.names.Length > 50)
			{
				info.name_hash = new Hashtable(info.names.Length);
				for (int i = 0; i < info.names.Length; i++)
				{
					info.name_hash[info.names[i]] = i;
				}
			}
			MonoEnumInfo monoEnumInfo = new MonoEnumInfo(info);
			object obj3 = MonoEnumInfo.global_cache_monitor;
			lock (obj3)
			{
				MonoEnumInfo.global_cache[enumType] = monoEnumInfo;
			}
		}

		// Token: 0x04000630 RID: 1584
		internal Type utype;

		// Token: 0x04000631 RID: 1585
		internal Array values;

		// Token: 0x04000632 RID: 1586
		internal string[] names;

		// Token: 0x04000633 RID: 1587
		internal Hashtable name_hash;

		// Token: 0x04000634 RID: 1588
		[ThreadStatic]
		private static Hashtable cache;

		// Token: 0x04000635 RID: 1589
		private static Hashtable global_cache = new Hashtable();

		// Token: 0x04000636 RID: 1590
		private static object global_cache_monitor = new object();

		// Token: 0x04000637 RID: 1591
		internal static MonoEnumInfo.SByteComparer sbyte_comparer = new MonoEnumInfo.SByteComparer();

		// Token: 0x04000638 RID: 1592
		internal static MonoEnumInfo.ShortComparer short_comparer = new MonoEnumInfo.ShortComparer();

		// Token: 0x04000639 RID: 1593
		internal static MonoEnumInfo.IntComparer int_comparer = new MonoEnumInfo.IntComparer();

		// Token: 0x0400063A RID: 1594
		internal static MonoEnumInfo.LongComparer long_comparer = new MonoEnumInfo.LongComparer();

		// Token: 0x02000183 RID: 387
		internal class IntComparer : IComparer<int>, IComparer
		{
			// Token: 0x06000EE5 RID: 3813 RVA: 0x0003D67C File Offset: 0x0003B87C
			public int Compare(object x, object y)
			{
				int num = (int)x;
				int num2 = (int)y;
				if (num == num2)
				{
					return 0;
				}
				if (num < num2)
				{
					return -1;
				}
				return 1;
			}

			// Token: 0x06000EE6 RID: 3814 RVA: 0x0003D6AC File Offset: 0x0003B8AC
			public int Compare(int ix, int iy)
			{
				if (ix == iy)
				{
					return 0;
				}
				if (ix < iy)
				{
					return -1;
				}
				return 1;
			}
		}

		// Token: 0x02000184 RID: 388
		internal class LongComparer : IComparer<long>, IComparer
		{
			// Token: 0x06000EE8 RID: 3816 RVA: 0x0003D6CC File Offset: 0x0003B8CC
			public int Compare(object x, object y)
			{
				long num = (long)x;
				long num2 = (long)y;
				if (num == num2)
				{
					return 0;
				}
				if (num < num2)
				{
					return -1;
				}
				return 1;
			}

			// Token: 0x06000EE9 RID: 3817 RVA: 0x0003D6FC File Offset: 0x0003B8FC
			public int Compare(long ix, long iy)
			{
				if (ix == iy)
				{
					return 0;
				}
				if (ix < iy)
				{
					return -1;
				}
				return 1;
			}
		}

		// Token: 0x02000185 RID: 389
		internal class SByteComparer : IComparer<sbyte>, IComparer
		{
			// Token: 0x06000EEB RID: 3819 RVA: 0x0003D71C File Offset: 0x0003B91C
			public int Compare(object x, object y)
			{
				sbyte b = (sbyte)x;
				sbyte b2 = (sbyte)y;
				return (int)((byte)b - (byte)b2);
			}

			// Token: 0x06000EEC RID: 3820 RVA: 0x0003D73C File Offset: 0x0003B93C
			public int Compare(sbyte ix, sbyte iy)
			{
				return (int)((byte)ix - (byte)iy);
			}
		}

		// Token: 0x02000186 RID: 390
		internal class ShortComparer : IComparer<short>, IComparer
		{
			// Token: 0x06000EEE RID: 3822 RVA: 0x0003D74C File Offset: 0x0003B94C
			public int Compare(object x, object y)
			{
				short num = (short)x;
				short num2 = (short)y;
				return (int)((ushort)num - (ushort)num2);
			}

			// Token: 0x06000EEF RID: 3823 RVA: 0x0003D76C File Offset: 0x0003B96C
			public int Compare(short ix, short iy)
			{
				return (int)((ushort)ix - (ushort)iy);
			}
		}
	}
}
