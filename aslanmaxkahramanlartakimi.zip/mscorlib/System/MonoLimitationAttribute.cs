﻿using System;

namespace System
{
	// Token: 0x02000187 RID: 391
	[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
	internal class MonoLimitationAttribute : MonoTODOAttribute
	{
		// Token: 0x06000EF0 RID: 3824 RVA: 0x0003D774 File Offset: 0x0003B974
		public MonoLimitationAttribute(string comment)
			: base(comment)
		{
		}
	}
}
