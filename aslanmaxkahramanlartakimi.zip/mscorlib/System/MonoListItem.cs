﻿using System;

namespace System
{
	// Token: 0x02000188 RID: 392
	internal sealed class MonoListItem
	{
		// Token: 0x0400063B RID: 1595
		private MonoListItem next;

		// Token: 0x0400063C RID: 1596
		private object data;
	}
}
