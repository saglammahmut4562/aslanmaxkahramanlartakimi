﻿using System;

namespace System
{
	// Token: 0x02000189 RID: 393
	[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
	internal class MonoNotSupportedAttribute : MonoTODOAttribute
	{
		// Token: 0x06000EF1 RID: 3825 RVA: 0x0003D780 File Offset: 0x0003B980
		public MonoNotSupportedAttribute(string comment)
			: base(comment)
		{
		}
	}
}
