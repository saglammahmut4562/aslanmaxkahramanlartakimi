﻿using System;

namespace System
{
	// Token: 0x0200018A RID: 394
	[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
	internal class MonoTODOAttribute : Attribute
	{
		// Token: 0x06000EF2 RID: 3826 RVA: 0x0003D78C File Offset: 0x0003B98C
		public MonoTODOAttribute()
		{
		}

		// Token: 0x06000EF3 RID: 3827 RVA: 0x0003D794 File Offset: 0x0003B994
		public MonoTODOAttribute(string comment)
		{
			this.comment = comment;
		}

		// Token: 0x0400063D RID: 1597
		private string comment;
	}
}
