﻿using System;

namespace System
{
	// Token: 0x0200018B RID: 395
	internal class MonoTouchAOTHelper
	{
		// Token: 0x0400063E RID: 1598
		internal static bool FalseFlag;
	}
}
