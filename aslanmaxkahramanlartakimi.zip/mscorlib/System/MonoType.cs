﻿using System;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200018C RID: 396
	[Serializable]
	internal class MonoType : Type, ISerializable
	{
		// Token: 0x06000EF5 RID: 3829
		[MethodImpl(4096)]
		private static extern TypeAttributes get_attributes(Type type);

		// Token: 0x06000EF6 RID: 3830 RVA: 0x0003D7A8 File Offset: 0x0003B9A8
		internal ConstructorInfo GetDefaultConstructor()
		{
			if (this.type_info == null)
			{
				this.type_info = new MonoTypeInfo();
			}
			ConstructorInfo constructorInfo;
			if ((constructorInfo = this.type_info.default_ctor) == null)
			{
				constructorInfo = (this.type_info.default_ctor = this.GetConstructor(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, CallingConventions.Any, Type.EmptyTypes, null));
			}
			return constructorInfo;
		}

		// Token: 0x06000EF7 RID: 3831 RVA: 0x0003D800 File Offset: 0x0003BA00
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			return MonoType.get_attributes(this);
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x0003D808 File Offset: 0x0003BA08
		protected override ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			if (bindingAttr == BindingFlags.Default)
			{
				bindingAttr = BindingFlags.Instance | BindingFlags.Public;
			}
			ConstructorInfo[] constructors = this.GetConstructors(bindingAttr);
			ConstructorInfo constructorInfo = null;
			int num = 0;
			foreach (ConstructorInfo constructorInfo2 in constructors)
			{
				if (callConvention == CallingConventions.Any || (constructorInfo2.CallingConvention & callConvention) == callConvention)
				{
					constructorInfo = constructorInfo2;
					num++;
				}
			}
			if (num == 0)
			{
				return null;
			}
			if (types != null)
			{
				MethodBase[] array2 = new MethodBase[num];
				if (num == 1)
				{
					array2[0] = constructorInfo;
				}
				else
				{
					num = 0;
					foreach (ConstructorInfo constructorInfo3 in constructors)
					{
						if (callConvention == CallingConventions.Any || (constructorInfo3.CallingConvention & callConvention) == callConvention)
						{
							array2[num++] = constructorInfo3;
						}
					}
				}
				if (binder == null)
				{
					binder = Binder.DefaultBinder;
				}
				return (ConstructorInfo)this.CheckMethodSecurity(binder.SelectMethod(bindingAttr, array2, types, modifiers));
			}
			if (num > 1)
			{
				throw new AmbiguousMatchException();
			}
			return (ConstructorInfo)this.CheckMethodSecurity(constructorInfo);
		}

		// Token: 0x06000EF9 RID: 3833
		[MethodImpl(4096)]
		internal extern ConstructorInfo[] GetConstructors_internal(BindingFlags bindingAttr, Type reflected_type);

		// Token: 0x06000EFA RID: 3834 RVA: 0x0003D920 File Offset: 0x0003BB20
		public override ConstructorInfo[] GetConstructors(BindingFlags bindingAttr)
		{
			return this.GetConstructors_internal(bindingAttr, this);
		}

		// Token: 0x06000EFB RID: 3835
		[MethodImpl(4096)]
		private extern EventInfo InternalGetEvent(string name, BindingFlags bindingAttr);

		// Token: 0x06000EFC RID: 3836 RVA: 0x0003D92C File Offset: 0x0003BB2C
		public override EventInfo GetEvent(string name, BindingFlags bindingAttr)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			return this.InternalGetEvent(name, bindingAttr);
		}

		// Token: 0x06000EFD RID: 3837
		[MethodImpl(4096)]
		internal extern EventInfo[] GetEvents_internal(BindingFlags bindingAttr, Type reflected_type);

		// Token: 0x06000EFE RID: 3838 RVA: 0x0003D948 File Offset: 0x0003BB48
		public override EventInfo[] GetEvents(BindingFlags bindingAttr)
		{
			return this.GetEvents_internal(bindingAttr, this);
		}

		// Token: 0x06000EFF RID: 3839
		[MethodImpl(4096)]
		public override extern FieldInfo GetField(string name, BindingFlags bindingAttr);

		// Token: 0x06000F00 RID: 3840
		[MethodImpl(4096)]
		internal extern FieldInfo[] GetFields_internal(BindingFlags bindingAttr, Type reflected_type);

		// Token: 0x06000F01 RID: 3841 RVA: 0x0003D954 File Offset: 0x0003BB54
		public override FieldInfo[] GetFields(BindingFlags bindingAttr)
		{
			return this.GetFields_internal(bindingAttr, this);
		}

		// Token: 0x06000F02 RID: 3842
		[MethodImpl(4096)]
		public override extern Type[] GetInterfaces();

		// Token: 0x06000F03 RID: 3843
		[MethodImpl(4096)]
		internal extern MethodInfo[] GetMethodsByName(string name, BindingFlags bindingAttr, bool ignoreCase, Type reflected_type);

		// Token: 0x06000F04 RID: 3844 RVA: 0x0003D960 File Offset: 0x0003BB60
		public override MethodInfo[] GetMethods(BindingFlags bindingAttr)
		{
			return this.GetMethodsByName(null, bindingAttr, false, this);
		}

		// Token: 0x06000F05 RID: 3845 RVA: 0x0003D96C File Offset: 0x0003BB6C
		protected override MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			bool flag = (bindingAttr & BindingFlags.IgnoreCase) != BindingFlags.Default;
			MethodInfo[] methodsByName = this.GetMethodsByName(name, bindingAttr, flag, this);
			MethodInfo methodInfo = null;
			int num = 0;
			foreach (MethodInfo methodInfo2 in methodsByName)
			{
				if (callConvention == CallingConventions.Any || (methodInfo2.CallingConvention & callConvention) == callConvention)
				{
					methodInfo = methodInfo2;
					num++;
				}
			}
			if (num == 0)
			{
				return null;
			}
			if (num == 1 && types == null)
			{
				return (MethodInfo)this.CheckMethodSecurity(methodInfo);
			}
			MethodBase[] array2 = new MethodBase[num];
			if (num == 1)
			{
				array2[0] = methodInfo;
			}
			else
			{
				num = 0;
				foreach (MethodInfo methodInfo3 in methodsByName)
				{
					if (callConvention == CallingConventions.Any || (methodInfo3.CallingConvention & callConvention) == callConvention)
					{
						array2[num++] = methodInfo3;
					}
				}
			}
			if (types == null)
			{
				return (MethodInfo)this.CheckMethodSecurity(Binder.FindMostDerivedMatch(array2));
			}
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			return (MethodInfo)this.CheckMethodSecurity(binder.SelectMethod(bindingAttr, array2, types, modifiers));
		}

		// Token: 0x06000F06 RID: 3846
		[MethodImpl(4096)]
		private extern MethodInfo GetCorrespondingInflatedMethod(MethodInfo generic);

		// Token: 0x06000F07 RID: 3847
		[MethodImpl(4096)]
		private extern ConstructorInfo GetCorrespondingInflatedConstructor(ConstructorInfo generic);

		// Token: 0x06000F08 RID: 3848 RVA: 0x0003DAA8 File Offset: 0x0003BCA8
		internal override MethodInfo GetMethod(MethodInfo fromNoninstanciated)
		{
			if (fromNoninstanciated == null)
			{
				throw new ArgumentNullException("fromNoninstanciated");
			}
			return this.GetCorrespondingInflatedMethod(fromNoninstanciated);
		}

		// Token: 0x06000F09 RID: 3849 RVA: 0x0003DAC4 File Offset: 0x0003BCC4
		internal override ConstructorInfo GetConstructor(ConstructorInfo fromNoninstanciated)
		{
			if (fromNoninstanciated == null)
			{
				throw new ArgumentNullException("fromNoninstanciated");
			}
			return this.GetCorrespondingInflatedConstructor(fromNoninstanciated);
		}

		// Token: 0x06000F0A RID: 3850 RVA: 0x0003DAE0 File Offset: 0x0003BCE0
		internal override FieldInfo GetField(FieldInfo fromNoninstanciated)
		{
			BindingFlags bindingFlags = ((!fromNoninstanciated.IsStatic) ? BindingFlags.Instance : BindingFlags.Static);
			bindingFlags |= ((!fromNoninstanciated.IsPublic) ? BindingFlags.NonPublic : BindingFlags.Public);
			return this.GetField(fromNoninstanciated.Name, bindingFlags);
		}

		// Token: 0x06000F0B RID: 3851
		[MethodImpl(4096)]
		public override extern Type[] GetNestedTypes(BindingFlags bindingAttr);

		// Token: 0x06000F0C RID: 3852
		[MethodImpl(4096)]
		internal extern PropertyInfo[] GetPropertiesByName(string name, BindingFlags bindingAttr, bool icase, Type reflected_type);

		// Token: 0x06000F0D RID: 3853 RVA: 0x0003DB24 File Offset: 0x0003BD24
		public override PropertyInfo[] GetProperties(BindingFlags bindingAttr)
		{
			return this.GetPropertiesByName(null, bindingAttr, false, this);
		}

		// Token: 0x06000F0E RID: 3854 RVA: 0x0003DB30 File Offset: 0x0003BD30
		protected override PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
		{
			bool flag = (bindingAttr & BindingFlags.IgnoreCase) != BindingFlags.Default;
			PropertyInfo[] propertiesByName = this.GetPropertiesByName(name, bindingAttr, flag, this);
			int num = propertiesByName.Length;
			if (num == 0)
			{
				return null;
			}
			if (num == 1 && (types == null || types.Length == 0) && (returnType == null || returnType == propertiesByName[0].PropertyType))
			{
				return propertiesByName[0];
			}
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			return binder.SelectProperty(bindingAttr, propertiesByName, returnType, types, modifiers);
		}

		// Token: 0x06000F0F RID: 3855 RVA: 0x0003DBAC File Offset: 0x0003BDAC
		protected override bool HasElementTypeImpl()
		{
			return this.IsArrayImpl() || this.IsByRefImpl() || this.IsPointerImpl();
		}

		// Token: 0x06000F10 RID: 3856 RVA: 0x0003DBD0 File Offset: 0x0003BDD0
		protected override bool IsArrayImpl()
		{
			return Type.IsArrayImpl(this);
		}

		// Token: 0x06000F11 RID: 3857
		[MethodImpl(4096)]
		protected override extern bool IsByRefImpl();

		// Token: 0x06000F12 RID: 3858
		[MethodImpl(4096)]
		protected override extern bool IsPointerImpl();

		// Token: 0x06000F13 RID: 3859
		[MethodImpl(4096)]
		protected override extern bool IsPrimitiveImpl();

		// Token: 0x06000F14 RID: 3860 RVA: 0x0003DBD8 File Offset: 0x0003BDD8
		public override bool IsSubclassOf(Type type)
		{
			if (type == null)
			{
				throw new ArgumentNullException("type");
			}
			return base.IsSubclassOf(type);
		}

		// Token: 0x06000F15 RID: 3861 RVA: 0x0003DBF4 File Offset: 0x0003BDF4
		public override object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters)
		{
			if ((invokeAttr & BindingFlags.CreateInstance) != BindingFlags.Default)
			{
				if ((invokeAttr & (BindingFlags.GetField | BindingFlags.GetProperty | BindingFlags.SetProperty)) != BindingFlags.Default)
				{
					throw new ArgumentException("bindingFlags");
				}
			}
			else if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			if ((invokeAttr & BindingFlags.GetField) != BindingFlags.Default && (invokeAttr & BindingFlags.SetField) != BindingFlags.Default)
			{
				throw new ArgumentException("Cannot specify both Get and Set on a field.", "bindingFlags");
			}
			if ((invokeAttr & BindingFlags.GetProperty) != BindingFlags.Default && (invokeAttr & BindingFlags.SetProperty) != BindingFlags.Default)
			{
				throw new ArgumentException("Cannot specify both Get and Set on a property.", "bindingFlags");
			}
			if ((invokeAttr & BindingFlags.InvokeMethod) != BindingFlags.Default)
			{
				if ((invokeAttr & BindingFlags.SetField) != BindingFlags.Default)
				{
					throw new ArgumentException("Cannot specify Set on a field and Invoke on a method.", "bindingFlags");
				}
				if ((invokeAttr & BindingFlags.SetProperty) != BindingFlags.Default)
				{
					throw new ArgumentException("Cannot specify Set on a property and Invoke on a method.", "bindingFlags");
				}
			}
			if (namedParameters != null && (args == null || args.Length < namedParameters.Length))
			{
				throw new ArgumentException("namedParameters cannot be more than named arguments in number");
			}
			if ((invokeAttr & (BindingFlags.InvokeMethod | BindingFlags.CreateInstance | BindingFlags.GetField | BindingFlags.SetField | BindingFlags.GetProperty | BindingFlags.SetProperty)) == BindingFlags.Default)
			{
				throw new ArgumentException("Must specify binding flags describing the invoke operation required.", "bindingFlags");
			}
			if ((invokeAttr & (BindingFlags.Public | BindingFlags.NonPublic)) == BindingFlags.Default)
			{
				invokeAttr |= BindingFlags.Public;
			}
			if ((invokeAttr & (BindingFlags.Instance | BindingFlags.Static)) == BindingFlags.Default)
			{
				invokeAttr |= BindingFlags.Instance | BindingFlags.Static;
			}
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			if ((invokeAttr & BindingFlags.CreateInstance) != BindingFlags.Default)
			{
				invokeAttr |= BindingFlags.DeclaredOnly;
				ConstructorInfo[] constructors = this.GetConstructors(invokeAttr);
				object obj = null;
				MethodBase methodBase = binder.BindToMethod(invokeAttr, constructors, ref args, modifiers, culture, namedParameters, out obj);
				if (methodBase != null)
				{
					object obj2 = methodBase.Invoke(target, invokeAttr, binder, args, culture);
					binder.ReorderArgumentArray(ref args, obj);
					return obj2;
				}
				if (this.IsValueType && args == null)
				{
					return Activator.CreateInstanceInternal(this);
				}
				throw new MissingMethodException("Constructor on type '" + this.FullName + "' not found.");
			}
			else
			{
				if (name == string.Empty && Attribute.IsDefined(this, typeof(DefaultMemberAttribute)))
				{
					DefaultMemberAttribute defaultMemberAttribute = (DefaultMemberAttribute)Attribute.GetCustomAttribute(this, typeof(DefaultMemberAttribute));
					name = defaultMemberAttribute.MemberName;
				}
				bool flag = (invokeAttr & BindingFlags.IgnoreCase) != BindingFlags.Default;
				string text = null;
				bool flag2 = false;
				if ((invokeAttr & BindingFlags.InvokeMethod) != BindingFlags.Default)
				{
					MethodInfo[] methodsByName = this.GetMethodsByName(name, invokeAttr, flag, this);
					object obj3 = null;
					if (args == null)
					{
						args = new object[0];
					}
					MethodBase methodBase2 = binder.BindToMethod(invokeAttr, methodsByName, ref args, modifiers, culture, namedParameters, out obj3);
					if (methodBase2 != null)
					{
						ParameterInfo[] parameters = methodBase2.GetParameters();
						for (int i = 0; i < parameters.Length; i++)
						{
							if (global::System.Reflection.Missing.Value == args[i] && (parameters[i].Attributes & ParameterAttributes.HasDefault) != ParameterAttributes.HasDefault)
							{
								throw new ArgumentException("Used Missing.Value for argument without default value", "parameters");
							}
						}
						bool flag3 = parameters.Length > 0 && Attribute.IsDefined(parameters[parameters.Length - 1], typeof(ParamArrayAttribute));
						if (flag3)
						{
							this.ReorderParamArrayArguments(ref args, methodBase2);
						}
						object obj4 = methodBase2.Invoke(target, invokeAttr, binder, args, culture);
						binder.ReorderArgumentArray(ref args, obj3);
						return obj4;
					}
					if (methodsByName.Length > 0)
					{
						text = "The best match for method " + name + " has some invalid parameter.";
					}
					else
					{
						text = "Cannot find method " + name + ".";
					}
				}
				if ((invokeAttr & BindingFlags.GetField) != BindingFlags.Default)
				{
					FieldInfo field = this.GetField(name, invokeAttr);
					if (field != null)
					{
						return field.GetValue(target);
					}
					if ((invokeAttr & BindingFlags.GetProperty) == BindingFlags.Default)
					{
						flag2 = true;
					}
				}
				else if ((invokeAttr & BindingFlags.SetField) != BindingFlags.Default)
				{
					FieldInfo field2 = this.GetField(name, invokeAttr);
					if (field2 != null)
					{
						if (args == null)
						{
							throw new ArgumentNullException("providedArgs");
						}
						if (args == null || args.Length != 1)
						{
							throw new ArgumentException("Only the field value can be specified to set a field value.", "bindingFlags");
						}
						field2.SetValue(target, args[0]);
						return null;
					}
					else if ((invokeAttr & BindingFlags.SetProperty) == BindingFlags.Default)
					{
						flag2 = true;
					}
				}
				if ((invokeAttr & BindingFlags.GetProperty) != BindingFlags.Default)
				{
					PropertyInfo[] propertiesByName = this.GetPropertiesByName(name, invokeAttr, flag, this);
					object obj5 = null;
					int num = 0;
					for (int j = 0; j < propertiesByName.Length; j++)
					{
						if (propertiesByName[j].GetGetMethod(true) != null)
						{
							num++;
						}
					}
					MethodBase[] array = new MethodBase[num];
					num = 0;
					for (int j = 0; j < propertiesByName.Length; j++)
					{
						MethodBase getMethod = propertiesByName[j].GetGetMethod(true);
						if (getMethod != null)
						{
							array[num++] = getMethod;
						}
					}
					MethodBase methodBase3 = binder.BindToMethod(invokeAttr, array, ref args, modifiers, culture, namedParameters, out obj5);
					if (methodBase3 != null)
					{
						ParameterInfo[] parameters2 = methodBase3.GetParameters();
						bool flag4 = parameters2.Length > 0 && Attribute.IsDefined(parameters2[parameters2.Length - 1], typeof(ParamArrayAttribute));
						if (flag4)
						{
							this.ReorderParamArrayArguments(ref args, methodBase3);
						}
						object obj6 = methodBase3.Invoke(target, invokeAttr, binder, args, culture);
						binder.ReorderArgumentArray(ref args, obj5);
						return obj6;
					}
					flag2 = true;
				}
				else if ((invokeAttr & BindingFlags.SetProperty) != BindingFlags.Default)
				{
					PropertyInfo[] propertiesByName2 = this.GetPropertiesByName(name, invokeAttr, flag, this);
					object obj7 = null;
					int num2 = 0;
					for (int k = 0; k < propertiesByName2.Length; k++)
					{
						if (propertiesByName2[k].GetSetMethod(true) != null)
						{
							num2++;
						}
					}
					MethodBase[] array2 = new MethodBase[num2];
					num2 = 0;
					for (int k = 0; k < propertiesByName2.Length; k++)
					{
						MethodBase setMethod = propertiesByName2[k].GetSetMethod(true);
						if (setMethod != null)
						{
							array2[num2++] = setMethod;
						}
					}
					MethodBase methodBase4 = binder.BindToMethod(invokeAttr, array2, ref args, modifiers, culture, namedParameters, out obj7);
					if (methodBase4 != null)
					{
						ParameterInfo[] parameters3 = methodBase4.GetParameters();
						bool flag5 = parameters3.Length > 0 && Attribute.IsDefined(parameters3[parameters3.Length - 1], typeof(ParamArrayAttribute));
						if (flag5)
						{
							this.ReorderParamArrayArguments(ref args, methodBase4);
						}
						object obj8 = methodBase4.Invoke(target, invokeAttr, binder, args, culture);
						binder.ReorderArgumentArray(ref args, obj7);
						return obj8;
					}
					flag2 = true;
				}
				if (text != null)
				{
					throw new MissingMethodException(text);
				}
				if (flag2)
				{
					throw new MissingFieldException("Cannot find variable " + name + ".");
				}
				return null;
			}
		}

		// Token: 0x06000F16 RID: 3862
		[MethodImpl(4096)]
		public override extern Type GetElementType();

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000F17 RID: 3863 RVA: 0x0003E258 File Offset: 0x0003C458
		public override Type UnderlyingSystemType
		{
			get
			{
				return this;
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000F18 RID: 3864
		public override extern Assembly Assembly
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000F19 RID: 3865 RVA: 0x0003E25C File Offset: 0x0003C45C
		public override string AssemblyQualifiedName
		{
			get
			{
				return this.getFullName(true, true);
			}
		}

		// Token: 0x06000F1A RID: 3866
		[MethodImpl(4096)]
		private extern string getFullName(bool full_name, bool assembly_qualified);

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000F1B RID: 3867
		public override extern Type BaseType
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000F1C RID: 3868 RVA: 0x0003E268 File Offset: 0x0003C468
		public override string FullName
		{
			get
			{
				if (this.type_info == null)
				{
					this.type_info = new MonoTypeInfo();
				}
				string text;
				if ((text = this.type_info.full_name) == null)
				{
					text = (this.type_info.full_name = this.getFullName(true, false));
				}
				return text;
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000F1D RID: 3869 RVA: 0x0003E2B8 File Offset: 0x0003C4B8
		public override Guid GUID
		{
			get
			{
				object[] customAttributes = this.GetCustomAttributes(typeof(GuidAttribute), true);
				if (customAttributes.Length == 0)
				{
					return Guid.Empty;
				}
				return new Guid(((GuidAttribute)customAttributes[0]).Value);
			}
		}

		// Token: 0x06000F1E RID: 3870 RVA: 0x0003E2F8 File Offset: 0x0003C4F8
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x06000F1F RID: 3871 RVA: 0x0003E304 File Offset: 0x0003C504
		public override object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x06000F20 RID: 3872 RVA: 0x0003E310 File Offset: 0x0003C510
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			if (attributeType == null)
			{
				throw new ArgumentNullException("attributeType");
			}
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000F21 RID: 3873 RVA: 0x0003E32C File Offset: 0x0003C52C
		public override MemberTypes MemberType
		{
			get
			{
				if (this.DeclaringType != null && !this.IsGenericParameter)
				{
					return MemberTypes.NestedType;
				}
				return MemberTypes.TypeInfo;
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000F22 RID: 3874
		public override extern string Name
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x06000F23 RID: 3875
		public override extern string Namespace
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000F24 RID: 3876
		public override extern Module Module
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000F25 RID: 3877
		public override extern Type DeclaringType
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000F26 RID: 3878 RVA: 0x0003E34C File Offset: 0x0003C54C
		public override Type ReflectedType
		{
			get
			{
				return this.DeclaringType;
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000F27 RID: 3879 RVA: 0x0003E354 File Offset: 0x0003C554
		public override RuntimeTypeHandle TypeHandle
		{
			get
			{
				return this._impl;
			}
		}

		// Token: 0x06000F28 RID: 3880
		[MethodImpl(4096)]
		public override extern int GetArrayRank();

		// Token: 0x06000F29 RID: 3881 RVA: 0x0003E35C File Offset: 0x0003C55C
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			UnitySerializationHolder.GetTypeData(this, info, context);
		}

		// Token: 0x06000F2A RID: 3882 RVA: 0x0003E368 File Offset: 0x0003C568
		public override string ToString()
		{
			return this.getFullName(false, false);
		}

		// Token: 0x06000F2B RID: 3883
		[MethodImpl(4096)]
		public override extern Type[] GetGenericArguments();

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000F2C RID: 3884 RVA: 0x0003E374 File Offset: 0x0003C574
		public override bool ContainsGenericParameters
		{
			get
			{
				if (this.IsGenericParameter)
				{
					return true;
				}
				if (this.IsGenericType)
				{
					foreach (Type type in this.GetGenericArguments())
					{
						if (type.ContainsGenericParameters)
						{
							return true;
						}
					}
				}
				return this.HasElementType && this.GetElementType().ContainsGenericParameters;
			}
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000F2D RID: 3885
		public override extern bool IsGenericParameter
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000F2E RID: 3886
		public override extern MethodBase DeclaringMethod
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x06000F2F RID: 3887 RVA: 0x0003E3E0 File Offset: 0x0003C5E0
		public override Type GetGenericTypeDefinition()
		{
			Type genericTypeDefinition_impl = base.GetGenericTypeDefinition_impl();
			if (genericTypeDefinition_impl == null)
			{
				throw new InvalidOperationException();
			}
			return genericTypeDefinition_impl;
		}

		// Token: 0x06000F30 RID: 3888 RVA: 0x0003E404 File Offset: 0x0003C604
		private MethodBase CheckMethodSecurity(MethodBase mb)
		{
			return mb;
		}

		// Token: 0x06000F31 RID: 3889 RVA: 0x0003E408 File Offset: 0x0003C608
		private void ReorderParamArrayArguments(ref object[] args, MethodBase method)
		{
			ParameterInfo[] parameters = method.GetParameters();
			object[] array = new object[parameters.Length];
			Array array2 = Array.CreateInstance(parameters[parameters.Length - 1].ParameterType.GetElementType(), args.Length - (parameters.Length - 1));
			int num = 0;
			for (int i = 0; i < args.Length; i++)
			{
				if (i < parameters.Length - 1)
				{
					array[i] = args[i];
				}
				else
				{
					array2.SetValue(args[i], num);
					num++;
				}
			}
			array[parameters.Length - 1] = array2;
			args = array;
		}

		// Token: 0x0400063F RID: 1599
		[NonSerialized]
		private MonoTypeInfo type_info;
	}
}
