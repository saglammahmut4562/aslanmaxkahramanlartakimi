﻿using System;
using System.Reflection;

namespace System
{
	// Token: 0x0200018D RID: 397
	internal class MonoTypeInfo
	{
		// Token: 0x04000640 RID: 1600
		public string full_name;

		// Token: 0x04000641 RID: 1601
		public ConstructorInfo default_ctor;
	}
}
