﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200018F RID: 399
	[ComVisible(true)]
	[Serializable]
	public sealed class MulticastNotSupportedException : SystemException
	{
		// Token: 0x06000F3C RID: 3900 RVA: 0x0003E86C File Offset: 0x0003CA6C
		public MulticastNotSupportedException()
			: base(Locale.GetText("This operation cannot be performed with the specified delagates."))
		{
		}

		// Token: 0x06000F3D RID: 3901 RVA: 0x0003E880 File Offset: 0x0003CA80
		public MulticastNotSupportedException(string message)
			: base(message)
		{
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x0003E88C File Offset: 0x0003CA8C
		internal MulticastNotSupportedException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
