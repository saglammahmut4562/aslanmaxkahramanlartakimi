﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000190 RID: 400
	[AttributeUsage(AttributeTargets.Field, Inherited = false)]
	[ComVisible(true)]
	public sealed class NonSerializedAttribute : Attribute
	{
	}
}
