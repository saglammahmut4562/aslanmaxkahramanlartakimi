﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000191 RID: 401
	[ComVisible(true)]
	[Serializable]
	public class NotImplementedException : SystemException
	{
		// Token: 0x06000F40 RID: 3904 RVA: 0x0003E8A0 File Offset: 0x0003CAA0
		public NotImplementedException()
			: base(Locale.GetText("The requested feature is not implemented."))
		{
			base.HResult = -2147467263;
		}

		// Token: 0x06000F41 RID: 3905 RVA: 0x0003E8C0 File Offset: 0x0003CAC0
		public NotImplementedException(string message)
			: base(message)
		{
			base.HResult = -2147467263;
		}

		// Token: 0x06000F42 RID: 3906 RVA: 0x0003E8D4 File Offset: 0x0003CAD4
		public NotImplementedException(string message, Exception inner)
			: base(message, inner)
		{
			base.HResult = -2147467263;
		}

		// Token: 0x06000F43 RID: 3907 RVA: 0x0003E8EC File Offset: 0x0003CAEC
		protected NotImplementedException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000644 RID: 1604
		private const int Result = -2147467263;
	}
}
