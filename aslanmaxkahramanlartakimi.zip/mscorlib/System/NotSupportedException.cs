﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000192 RID: 402
	[ComVisible(true)]
	[Serializable]
	public class NotSupportedException : SystemException
	{
		// Token: 0x06000F44 RID: 3908 RVA: 0x0003E8F8 File Offset: 0x0003CAF8
		public NotSupportedException()
			: base(Locale.GetText("Operation is not supported."))
		{
			base.HResult = -2146233067;
		}

		// Token: 0x06000F45 RID: 3909 RVA: 0x0003E918 File Offset: 0x0003CB18
		public NotSupportedException(string message)
			: base(message)
		{
			base.HResult = -2146233067;
		}

		// Token: 0x06000F46 RID: 3910 RVA: 0x0003E92C File Offset: 0x0003CB2C
		protected NotSupportedException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000645 RID: 1605
		private const int Result = -2146233067;
	}
}
