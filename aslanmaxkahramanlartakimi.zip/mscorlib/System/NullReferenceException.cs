﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000195 RID: 405
	[ComVisible(true)]
	[Serializable]
	public class NullReferenceException : SystemException
	{
		// Token: 0x06000F55 RID: 3925 RVA: 0x0003EB00 File Offset: 0x0003CD00
		public NullReferenceException()
			: base(Locale.GetText("A null value was found where an object instance was required."))
		{
			base.HResult = -2147467261;
		}

		// Token: 0x06000F56 RID: 3926 RVA: 0x0003EB20 File Offset: 0x0003CD20
		public NullReferenceException(string message)
			: base(message)
		{
			base.HResult = -2147467261;
		}

		// Token: 0x06000F57 RID: 3927 RVA: 0x0003EB34 File Offset: 0x0003CD34
		public NullReferenceException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2147467261;
		}

		// Token: 0x06000F58 RID: 3928 RVA: 0x0003EB4C File Offset: 0x0003CD4C
		protected NullReferenceException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000648 RID: 1608
		private const int Result = -2147467261;
	}
}
