﻿using System;

namespace System
{
	// Token: 0x02000194 RID: 404
	[Serializable]
	public struct Nullable<T> where T : struct
	{
		// Token: 0x06000F48 RID: 3912 RVA: 0x0003E978 File Offset: 0x0003CB78
		public Nullable(T value)
		{
			this.has_value = true;
			this.value = value;
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000F49 RID: 3913 RVA: 0x0003E988 File Offset: 0x0003CB88
		public bool HasValue
		{
			get
			{
				return this.has_value;
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000F4A RID: 3914 RVA: 0x0003E990 File Offset: 0x0003CB90
		public T Value
		{
			get
			{
				if (!this.has_value)
				{
					throw new InvalidOperationException("Nullable object must have a value.");
				}
				return this.value;
			}
		}

		// Token: 0x06000F4B RID: 3915 RVA: 0x0003E9B0 File Offset: 0x0003CBB0
		public override bool Equals(object other)
		{
			if (other == null)
			{
				return !this.has_value;
			}
			return other is T? && this.Equals((T?)other);
		}

		// Token: 0x06000F4C RID: 3916 RVA: 0x0003E9DC File Offset: 0x0003CBDC
		private bool Equals(T? other)
		{
			return other.has_value == this.has_value && (!this.has_value || other.value.Equals(this.value));
		}

		// Token: 0x06000F4D RID: 3917 RVA: 0x0003EA1C File Offset: 0x0003CC1C
		public override int GetHashCode()
		{
			if (!this.has_value)
			{
				return 0;
			}
			return this.value.GetHashCode();
		}

		// Token: 0x06000F4E RID: 3918 RVA: 0x0003EA3C File Offset: 0x0003CC3C
		public T GetValueOrDefault()
		{
			return (!this.has_value) ? default(T) : this.value;
		}

		// Token: 0x06000F4F RID: 3919 RVA: 0x0003EA68 File Offset: 0x0003CC68
		public T GetValueOrDefault(T defaultValue)
		{
			return (!this.has_value) ? defaultValue : this.value;
		}

		// Token: 0x06000F50 RID: 3920 RVA: 0x0003EA84 File Offset: 0x0003CC84
		public override string ToString()
		{
			if (this.has_value)
			{
				return this.value.ToString();
			}
			return string.Empty;
		}

		// Token: 0x06000F51 RID: 3921 RVA: 0x0003EAA8 File Offset: 0x0003CCA8
		private static object Box(T? o)
		{
			if (!o.has_value)
			{
				return null;
			}
			return o.value;
		}

		// Token: 0x06000F52 RID: 3922 RVA: 0x0003EAC4 File Offset: 0x0003CCC4
		private static T? Unbox(object o)
		{
			if (o == null)
			{
				return null;
			}
			return new T?((T)((object)o));
		}

		// Token: 0x06000F53 RID: 3923 RVA: 0x0003EAEC File Offset: 0x0003CCEC
		public static implicit operator T?(T value)
		{
			return new T?(value);
		}

		// Token: 0x06000F54 RID: 3924 RVA: 0x0003EAF4 File Offset: 0x0003CCF4
		public static explicit operator T(T? value)
		{
			return value.Value;
		}

		// Token: 0x04000646 RID: 1606
		internal T value;

		// Token: 0x04000647 RID: 1607
		internal bool has_value;
	}
}
