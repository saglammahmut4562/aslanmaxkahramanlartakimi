﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000193 RID: 403
	[ComVisible(true)]
	public static class Nullable
	{
		// Token: 0x06000F47 RID: 3911 RVA: 0x0003E938 File Offset: 0x0003CB38
		public static Type GetUnderlyingType(Type nullableType)
		{
			if (nullableType == null)
			{
				throw new ArgumentNullException("nullableType");
			}
			if (nullableType.IsGenericType && nullableType.GetGenericTypeDefinition() == typeof(Nullable<>))
			{
				return nullableType.GetGenericArguments()[0];
			}
			return null;
		}
	}
}
