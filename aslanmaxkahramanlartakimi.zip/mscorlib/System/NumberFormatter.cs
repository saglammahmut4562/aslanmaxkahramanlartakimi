﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace System
{
	// Token: 0x02000196 RID: 406
	internal sealed class NumberFormatter
	{
		// Token: 0x06000F59 RID: 3929 RVA: 0x0003EB58 File Offset: 0x0003CD58
		public NumberFormatter(Thread current)
		{
			this._cbuf = new char[0];
			if (current == null)
			{
				return;
			}
			this._thread = current;
			this.CurrentCulture = this._thread.CurrentCulture;
		}

		// Token: 0x06000F5A RID: 3930 RVA: 0x0003EB8C File Offset: 0x0003CD8C
		static NumberFormatter()
		{
			NumberFormatter.GetFormatterTables(out NumberFormatter.MantissaBitsTable, out NumberFormatter.TensExponentTable, out NumberFormatter.DigitLowerTable, out NumberFormatter.DigitUpperTable, out NumberFormatter.TenPowersList, out NumberFormatter.DecHexDigits);
		}

		// Token: 0x06000F5B RID: 3931
		[MethodImpl(4096)]
		private unsafe static extern void GetFormatterTables(out ulong* MantissaBitsTable, out int* TensExponentTable, out char* DigitLowerTable, out char* DigitUpperTable, out long* TenPowersList, out int* DecHexDigits);

		// Token: 0x06000F5C RID: 3932 RVA: 0x0003EBB4 File Offset: 0x0003CDB4
		private unsafe static long GetTenPowerOf(int i)
		{
			return NumberFormatter.TenPowersList[i];
		}

		// Token: 0x06000F5D RID: 3933 RVA: 0x0003EBC0 File Offset: 0x0003CDC0
		private void InitDecHexDigits(uint value)
		{
			if (value >= 100000000U)
			{
				int num = (int)(value / 100000000U);
				value -= (uint)(100000000 * num);
				this._val2 = NumberFormatter.FastToDecHex(num);
			}
			this._val1 = NumberFormatter.ToDecHex((int)value);
		}

		// Token: 0x06000F5E RID: 3934 RVA: 0x0003EC04 File Offset: 0x0003CE04
		private void InitDecHexDigits(ulong value)
		{
			if (value >= 100000000UL)
			{
				long num = (long)(value / 100000000UL);
				value -= (ulong)(100000000L * num);
				if (num >= 100000000L)
				{
					int num2 = (int)(num / 100000000L);
					num -= (long)num2 * 100000000L;
					this._val3 = NumberFormatter.ToDecHex(num2);
				}
				if (num != 0L)
				{
					this._val2 = NumberFormatter.ToDecHex((int)num);
				}
			}
			if (value != 0UL)
			{
				this._val1 = NumberFormatter.ToDecHex((int)value);
			}
		}

		// Token: 0x06000F5F RID: 3935 RVA: 0x0003EC88 File Offset: 0x0003CE88
		private void InitDecHexDigits(uint hi, ulong lo)
		{
			if (hi == 0U)
			{
				this.InitDecHexDigits(lo);
				return;
			}
			uint num = hi / 100000000U;
			ulong num2 = (ulong)(hi - num * 100000000U);
			ulong num3 = lo / 100000000UL;
			ulong num4 = lo - num3 * 100000000UL + num2 * 9551616UL;
			hi = num;
			lo = num3 + num2 * 184467440737UL;
			num3 = num4 / 100000000UL;
			num4 -= num3 * 100000000UL;
			lo += num3;
			this._val1 = NumberFormatter.ToDecHex((int)num4);
			num3 = lo / 100000000UL;
			num4 = lo - num3 * 100000000UL;
			lo = num3;
			if (hi != 0U)
			{
				lo += (ulong)hi * 184467440737UL;
				num4 += (ulong)hi * 9551616UL;
				num3 = num4 / 100000000UL;
				lo += num3;
				num4 -= num3 * 100000000UL;
			}
			this._val2 = NumberFormatter.ToDecHex((int)num4);
			if (lo >= 100000000UL)
			{
				num3 = lo / 100000000UL;
				lo -= num3 * 100000000UL;
				this._val4 = NumberFormatter.ToDecHex((int)num3);
			}
			this._val3 = NumberFormatter.ToDecHex((int)lo);
		}

		// Token: 0x06000F60 RID: 3936 RVA: 0x0003EDA8 File Offset: 0x0003CFA8
		private unsafe static uint FastToDecHex(int val)
		{
			if (val < 100)
			{
				return (uint)NumberFormatter.DecHexDigits[val];
			}
			int num = val * 5243 >> 19;
			return (uint)((NumberFormatter.DecHexDigits[num] << 8) | NumberFormatter.DecHexDigits[val - num * 100]);
		}

		// Token: 0x06000F61 RID: 3937 RVA: 0x0003EDF0 File Offset: 0x0003CFF0
		private static uint ToDecHex(int val)
		{
			uint num = 0U;
			if (val >= 10000)
			{
				int num2 = val / 10000;
				val -= num2 * 10000;
				num = NumberFormatter.FastToDecHex(num2) << 16;
			}
			return num | NumberFormatter.FastToDecHex(val);
		}

		// Token: 0x06000F62 RID: 3938 RVA: 0x0003EE30 File Offset: 0x0003D030
		private static int FastDecHexLen(int val)
		{
			if (val < 256)
			{
				if (val < 16)
				{
					return 1;
				}
				return 2;
			}
			else
			{
				if (val < 4096)
				{
					return 3;
				}
				return 4;
			}
		}

		// Token: 0x06000F63 RID: 3939 RVA: 0x0003EE58 File Offset: 0x0003D058
		private static int DecHexLen(uint val)
		{
			if (val < 65536U)
			{
				return NumberFormatter.FastDecHexLen((int)val);
			}
			return 4 + NumberFormatter.FastDecHexLen((int)(val >> 16));
		}

		// Token: 0x06000F64 RID: 3940 RVA: 0x0003EE78 File Offset: 0x0003D078
		private int DecHexLen()
		{
			if (this._val4 != 0U)
			{
				return NumberFormatter.DecHexLen(this._val4) + 24;
			}
			if (this._val3 != 0U)
			{
				return NumberFormatter.DecHexLen(this._val3) + 16;
			}
			if (this._val2 != 0U)
			{
				return NumberFormatter.DecHexLen(this._val2) + 8;
			}
			if (this._val1 != 0U)
			{
				return NumberFormatter.DecHexLen(this._val1);
			}
			return 0;
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x0003EEEC File Offset: 0x0003D0EC
		private static int ScaleOrder(long hi)
		{
			for (int i = 18; i >= 0; i--)
			{
				if (hi >= NumberFormatter.GetTenPowerOf(i))
				{
					return i + 1;
				}
			}
			return 1;
		}

		// Token: 0x06000F66 RID: 3942 RVA: 0x0003EF20 File Offset: 0x0003D120
		private int InitialFloatingPrecision()
		{
			if (this._specifier == 'R')
			{
				return this._defPrecision + 2;
			}
			if (this._precision < this._defPrecision)
			{
				return this._defPrecision;
			}
			if (this._specifier == 'G')
			{
				return Math.Min(this._defPrecision + 2, this._precision);
			}
			if (this._specifier == 'E')
			{
				return Math.Min(this._defPrecision + 2, this._precision + 1);
			}
			return this._defPrecision;
		}

		// Token: 0x06000F67 RID: 3943 RVA: 0x0003EFA8 File Offset: 0x0003D1A8
		private static int ParsePrecision(string format)
		{
			int num = 0;
			for (int i = 1; i < format.Length; i++)
			{
				int num2 = (int)(format[i] - '0');
				num = num * 10 + num2;
				if (num2 < 0 || num2 > 9 || num > 99)
				{
					return -2;
				}
			}
			return num;
		}

		// Token: 0x06000F68 RID: 3944 RVA: 0x0003EFFC File Offset: 0x0003D1FC
		private void Init(string format)
		{
			this._val1 = (this._val2 = (this._val3 = (this._val4 = 0U)));
			this._offset = 0;
			this._NaN = (this._infinity = false);
			this._isCustomFormat = false;
			this._specifierIsUpper = true;
			this._precision = -1;
			if (format == null || format.Length == 0)
			{
				this._specifier = 'G';
				return;
			}
			char c = format[0];
			if (c >= 'a' && c <= 'z')
			{
				c = c - 'a' + 'A';
				this._specifierIsUpper = false;
			}
			else if (c < 'A' || c > 'Z')
			{
				this._isCustomFormat = true;
				this._specifier = '0';
				return;
			}
			this._specifier = c;
			if (format.Length > 1)
			{
				this._precision = NumberFormatter.ParsePrecision(format);
				if (this._precision == -2)
				{
					this._isCustomFormat = true;
					this._specifier = '0';
					this._precision = -1;
				}
			}
		}

		// Token: 0x06000F69 RID: 3945 RVA: 0x0003F100 File Offset: 0x0003D300
		private void InitHex(ulong value)
		{
			int defPrecision = this._defPrecision;
			switch (defPrecision)
			{
			case 3:
				value = (ulong)((byte)value);
				break;
			default:
				if (defPrecision == 10)
				{
					value = (ulong)((uint)value);
				}
				break;
			case 5:
				value = (ulong)((ushort)value);
				break;
			}
			this._val1 = (uint)value;
			this._val2 = (uint)(value >> 32);
			this._decPointPos = (this._digitsLen = this.DecHexLen());
			if (value == 0UL)
			{
				this._decPointPos = 1;
			}
		}

		// Token: 0x06000F6A RID: 3946 RVA: 0x0003F188 File Offset: 0x0003D388
		private void Init(string format, int value, int defPrecision)
		{
			this.Init(format);
			this._defPrecision = defPrecision;
			this._positive = value >= 0;
			if (value == 0 || this._specifier == 'X')
			{
				this.InitHex((ulong)((long)value));
				return;
			}
			if (value < 0)
			{
				value = -value;
			}
			this.InitDecHexDigits((uint)value);
			this._decPointPos = (this._digitsLen = this.DecHexLen());
		}

		// Token: 0x06000F6B RID: 3947 RVA: 0x0003F1F4 File Offset: 0x0003D3F4
		private void Init(string format, uint value, int defPrecision)
		{
			this.Init(format);
			this._defPrecision = defPrecision;
			this._positive = true;
			if (value == 0U || this._specifier == 'X')
			{
				this.InitHex((ulong)value);
				return;
			}
			this.InitDecHexDigits(value);
			this._decPointPos = (this._digitsLen = this.DecHexLen());
		}

		// Token: 0x06000F6C RID: 3948 RVA: 0x0003F250 File Offset: 0x0003D450
		private void Init(string format, long value)
		{
			this.Init(format);
			this._defPrecision = 19;
			this._positive = value >= 0L;
			if (value == 0L || this._specifier == 'X')
			{
				this.InitHex((ulong)value);
				return;
			}
			if (value < 0L)
			{
				value = -value;
			}
			this.InitDecHexDigits((ulong)value);
			this._decPointPos = (this._digitsLen = this.DecHexLen());
		}

		// Token: 0x06000F6D RID: 3949 RVA: 0x0003F2C0 File Offset: 0x0003D4C0
		private void Init(string format, ulong value)
		{
			this.Init(format);
			this._defPrecision = 20;
			this._positive = true;
			if (value == 0UL || this._specifier == 'X')
			{
				this.InitHex(value);
				return;
			}
			this.InitDecHexDigits(value);
			this._decPointPos = (this._digitsLen = this.DecHexLen());
		}

		// Token: 0x06000F6E RID: 3950 RVA: 0x0003F31C File Offset: 0x0003D51C
		private unsafe void Init(string format, double value, int defPrecision)
		{
			this.Init(format);
			this._defPrecision = defPrecision;
			long num = BitConverter.DoubleToInt64Bits(value);
			this._positive = num >= 0L;
			num &= long.MaxValue;
			if (num == 0L)
			{
				this._decPointPos = 1;
				this._digitsLen = 0;
				this._positive = true;
				return;
			}
			int num2 = (int)(num >> 52);
			long num3 = num & 4503599627370495L;
			if (num2 == 2047)
			{
				this._NaN = num3 != 0L;
				this._infinity = num3 == 0L;
				return;
			}
			int num4 = 0;
			if (num2 == 0)
			{
				num2 = 1;
				int num5 = NumberFormatter.ScaleOrder(num3);
				if (num5 < 15)
				{
					num4 = num5 - 15;
					num3 *= NumberFormatter.GetTenPowerOf(-num4);
				}
			}
			else
			{
				num3 = (num3 + 4503599627370495L + 1L) * 10L;
				num4 = -1;
			}
			ulong num6 = (ulong)((uint)num3);
			ulong num7 = (ulong)num3 >> 32;
			ulong num8 = NumberFormatter.MantissaBitsTable[num2];
			ulong num9 = num8 >> 32;
			num8 = (ulong)((uint)num8);
			ulong num10 = num7 * num8 + num6 * num9 + (num6 * num8 >> 32);
			long num11 = (long)(num7 * num9 + (num10 >> 32));
			while (num11 < 10000000000000000L)
			{
				num10 = (num10 & (ulong)(-1)) * 10UL;
				num11 = num11 * 10L + (long)(num10 >> 32);
				num4--;
			}
			if ((num10 & (ulong)(-2147483648)) != 0UL)
			{
				num11 += 1L;
			}
			int num12 = 17;
			this._decPointPos = NumberFormatter.TensExponentTable[num2] + num4 + num12;
			int num13 = this.InitialFloatingPrecision();
			if (num12 > num13)
			{
				long tenPowerOf = NumberFormatter.GetTenPowerOf(num12 - num13);
				num11 = (num11 + (tenPowerOf >> 1)) / tenPowerOf;
				num12 = num13;
			}
			if (num11 >= NumberFormatter.GetTenPowerOf(num12))
			{
				num12++;
				this._decPointPos++;
			}
			this.InitDecHexDigits((ulong)num11);
			this._offset = this.CountTrailingZeros();
			this._digitsLen = num12 - this._offset;
		}

		// Token: 0x06000F6F RID: 3951 RVA: 0x0003F50C File Offset: 0x0003D70C
		private void Init(string format, decimal value)
		{
			this.Init(format);
			this._defPrecision = 100;
			int[] bits = decimal.GetBits(value);
			int num = (bits[3] & 2031616) >> 16;
			this._positive = bits[3] >= 0;
			if (bits[0] == 0 && bits[1] == 0 && bits[2] == 0)
			{
				this._decPointPos = -num;
				this._positive = true;
				this._digitsLen = 0;
				return;
			}
			this.InitDecHexDigits((uint)bits[2], (ulong)(((long)bits[1] << 32) | (long)((ulong)bits[0])));
			this._digitsLen = this.DecHexLen();
			this._decPointPos = this._digitsLen - num;
			if (this._precision != -1 || this._specifier != 'G')
			{
				this._offset = this.CountTrailingZeros();
				this._digitsLen -= this._offset;
			}
		}

		// Token: 0x06000F70 RID: 3952 RVA: 0x0003F5E4 File Offset: 0x0003D7E4
		private void ResetCharBuf(int size)
		{
			this._ind = 0;
			if (this._cbuf.Length < size)
			{
				this._cbuf = new char[size];
			}
		}

		// Token: 0x06000F71 RID: 3953 RVA: 0x0003F608 File Offset: 0x0003D808
		private void Resize(int len)
		{
			char[] array = new char[len];
			Array.Copy(this._cbuf, array, this._ind);
			this._cbuf = array;
		}

		// Token: 0x06000F72 RID: 3954 RVA: 0x0003F638 File Offset: 0x0003D838
		private void Append(char c)
		{
			if (this._ind == this._cbuf.Length)
			{
				this.Resize(this._ind + 10);
			}
			this._cbuf[this._ind++] = c;
		}

		// Token: 0x06000F73 RID: 3955 RVA: 0x0003F680 File Offset: 0x0003D880
		private void Append(char c, int cnt)
		{
			if (this._ind + cnt > this._cbuf.Length)
			{
				this.Resize(this._ind + cnt + 10);
			}
			while (cnt-- > 0)
			{
				this._cbuf[this._ind++] = c;
			}
		}

		// Token: 0x06000F74 RID: 3956 RVA: 0x0003F6E0 File Offset: 0x0003D8E0
		private void Append(string s)
		{
			int length = s.Length;
			if (this._ind + length > this._cbuf.Length)
			{
				this.Resize(this._ind + length + 10);
			}
			for (int i = 0; i < length; i++)
			{
				this._cbuf[this._ind++] = s[i];
			}
		}

		// Token: 0x06000F75 RID: 3957 RVA: 0x0003F74C File Offset: 0x0003D94C
		private NumberFormatInfo GetNumberFormatInstance(IFormatProvider fp)
		{
			if (this._nfi != null && fp == null)
			{
				return this._nfi;
			}
			return NumberFormatInfo.GetInstance(fp);
		}

		// Token: 0x1700024D RID: 589
		// (set) Token: 0x06000F76 RID: 3958 RVA: 0x0003F76C File Offset: 0x0003D96C
		public CultureInfo CurrentCulture
		{
			set
			{
				if (value != null && value.IsReadOnly)
				{
					this._nfi = value.NumberFormat;
				}
				else
				{
					this._nfi = null;
				}
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x06000F77 RID: 3959 RVA: 0x0003F798 File Offset: 0x0003D998
		private int IntegerDigits
		{
			get
			{
				return (this._decPointPos <= 0) ? 1 : this._decPointPos;
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000F78 RID: 3960 RVA: 0x0003F7B4 File Offset: 0x0003D9B4
		private int DecimalDigits
		{
			get
			{
				return (this._digitsLen <= this._decPointPos) ? 0 : (this._digitsLen - this._decPointPos);
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x06000F79 RID: 3961 RVA: 0x0003F7DC File Offset: 0x0003D9DC
		private bool IsFloatingSource
		{
			get
			{
				return this._defPrecision == 15 || this._defPrecision == 7;
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000F7A RID: 3962 RVA: 0x0003F7F8 File Offset: 0x0003D9F8
		private bool IsZero
		{
			get
			{
				return this._digitsLen == 0;
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000F7B RID: 3963 RVA: 0x0003F804 File Offset: 0x0003DA04
		private bool IsZeroInteger
		{
			get
			{
				return this._digitsLen == 0 || this._decPointPos <= 0;
			}
		}

		// Token: 0x06000F7C RID: 3964 RVA: 0x0003F820 File Offset: 0x0003DA20
		private void RoundPos(int pos)
		{
			this.RoundBits(this._digitsLen - pos);
		}

		// Token: 0x06000F7D RID: 3965 RVA: 0x0003F834 File Offset: 0x0003DA34
		private bool RoundDecimal(int decimals)
		{
			return this.RoundBits(this._digitsLen - this._decPointPos - decimals);
		}

		// Token: 0x06000F7E RID: 3966 RVA: 0x0003F84C File Offset: 0x0003DA4C
		private bool RoundBits(int shift)
		{
			if (shift <= 0)
			{
				return false;
			}
			if (shift > this._digitsLen)
			{
				this._digitsLen = 0;
				this._decPointPos = 1;
				this._val1 = (this._val2 = (this._val3 = (this._val4 = 0U)));
				this._positive = true;
				return false;
			}
			shift += this._offset;
			this._digitsLen += this._offset;
			while (shift > 8)
			{
				this._val1 = this._val2;
				this._val2 = this._val3;
				this._val3 = this._val4;
				this._val4 = 0U;
				this._digitsLen -= 8;
				shift -= 8;
			}
			shift = shift - 1 << 2;
			uint num = this._val1 >> shift;
			uint num2 = num & 15U;
			this._val1 = (num ^ num2) << shift;
			bool flag = false;
			if (num2 >= 5U)
			{
				this._val1 |= 2576980377U >> 28 - shift;
				this.AddOneToDecHex();
				int num3 = this.DecHexLen();
				flag = num3 != this._digitsLen;
				this._decPointPos = this._decPointPos + num3 - this._digitsLen;
				this._digitsLen = num3;
			}
			this.RemoveTrailingZeros();
			return flag;
		}

		// Token: 0x06000F7F RID: 3967 RVA: 0x0003F9A0 File Offset: 0x0003DBA0
		private void RemoveTrailingZeros()
		{
			this._offset = this.CountTrailingZeros();
			this._digitsLen -= this._offset;
			if (this._digitsLen == 0)
			{
				this._offset = 0;
				this._decPointPos = 1;
				this._positive = true;
			}
		}

		// Token: 0x06000F80 RID: 3968 RVA: 0x0003F9EC File Offset: 0x0003DBEC
		private void AddOneToDecHex()
		{
			if (this._val1 == 2576980377U)
			{
				this._val1 = 0U;
				if (this._val2 == 2576980377U)
				{
					this._val2 = 0U;
					if (this._val3 == 2576980377U)
					{
						this._val3 = 0U;
						this._val4 = NumberFormatter.AddOneToDecHex(this._val4);
					}
					else
					{
						this._val3 = NumberFormatter.AddOneToDecHex(this._val3);
					}
				}
				else
				{
					this._val2 = NumberFormatter.AddOneToDecHex(this._val2);
				}
			}
			else
			{
				this._val1 = NumberFormatter.AddOneToDecHex(this._val1);
			}
		}

		// Token: 0x06000F81 RID: 3969 RVA: 0x0003FA94 File Offset: 0x0003DC94
		private static uint AddOneToDecHex(uint val)
		{
			if ((val & 65535U) == 39321U)
			{
				if ((val & 16777215U) == 10066329U)
				{
					if ((val & 268435455U) == 161061273U)
					{
						return val + 107374183U;
					}
					return val + 6710887U;
				}
				else
				{
					if ((val & 1048575U) == 629145U)
					{
						return val + 419431U;
					}
					return val + 26215U;
				}
			}
			else if ((val & 255U) == 153U)
			{
				if ((val & 4095U) == 2457U)
				{
					return val + 1639U;
				}
				return val + 103U;
			}
			else
			{
				if ((val & 15U) == 9U)
				{
					return val + 7U;
				}
				return val + 1U;
			}
		}

		// Token: 0x06000F82 RID: 3970 RVA: 0x0003FB48 File Offset: 0x0003DD48
		private int CountTrailingZeros()
		{
			if (this._val1 != 0U)
			{
				return NumberFormatter.CountTrailingZeros(this._val1);
			}
			if (this._val2 != 0U)
			{
				return NumberFormatter.CountTrailingZeros(this._val2) + 8;
			}
			if (this._val3 != 0U)
			{
				return NumberFormatter.CountTrailingZeros(this._val3) + 16;
			}
			if (this._val4 != 0U)
			{
				return NumberFormatter.CountTrailingZeros(this._val4) + 24;
			}
			return this._digitsLen;
		}

		// Token: 0x06000F83 RID: 3971 RVA: 0x0003FBC0 File Offset: 0x0003DDC0
		private static int CountTrailingZeros(uint val)
		{
			if ((val & 65535U) == 0U)
			{
				if ((val & 16777215U) == 0U)
				{
					if ((val & 268435455U) == 0U)
					{
						return 7;
					}
					return 6;
				}
				else
				{
					if ((val & 1048575U) == 0U)
					{
						return 5;
					}
					return 4;
				}
			}
			else if ((val & 255U) == 0U)
			{
				if ((val & 4095U) == 0U)
				{
					return 3;
				}
				return 2;
			}
			else
			{
				if ((val & 15U) == 0U)
				{
					return 1;
				}
				return 0;
			}
		}

		// Token: 0x06000F84 RID: 3972 RVA: 0x0003FC30 File Offset: 0x0003DE30
		private static NumberFormatter GetInstance()
		{
			NumberFormatter numberFormatter = NumberFormatter.threadNumberFormatter;
			NumberFormatter.threadNumberFormatter = null;
			if (numberFormatter == null)
			{
				return new NumberFormatter(Thread.CurrentThread);
			}
			return numberFormatter;
		}

		// Token: 0x06000F85 RID: 3973 RVA: 0x0003FC5C File Offset: 0x0003DE5C
		private void Release()
		{
			NumberFormatter.threadNumberFormatter = this;
		}

		// Token: 0x06000F86 RID: 3974 RVA: 0x0003FC64 File Offset: 0x0003DE64
		internal static void SetThreadCurrentCulture(CultureInfo culture)
		{
			if (NumberFormatter.threadNumberFormatter != null)
			{
				NumberFormatter.threadNumberFormatter.CurrentCulture = culture;
			}
		}

		// Token: 0x06000F87 RID: 3975 RVA: 0x0003FC7C File Offset: 0x0003DE7C
		public static string NumberToString(string format, sbyte value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, (int)value, 3);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F88 RID: 3976 RVA: 0x0003FCAC File Offset: 0x0003DEAC
		public static string NumberToString(string format, byte value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, (int)value, 3);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F89 RID: 3977 RVA: 0x0003FCD8 File Offset: 0x0003DED8
		public static string NumberToString(string format, ushort value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, (int)value, 5);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F8A RID: 3978 RVA: 0x0003FD04 File Offset: 0x0003DF04
		public static string NumberToString(string format, short value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, (int)value, 5);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F8B RID: 3979 RVA: 0x0003FD30 File Offset: 0x0003DF30
		public static string NumberToString(string format, uint value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, value, 10);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F8C RID: 3980 RVA: 0x0003FD60 File Offset: 0x0003DF60
		public static string NumberToString(string format, int value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, value, 10);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F8D RID: 3981 RVA: 0x0003FD90 File Offset: 0x0003DF90
		public static string NumberToString(string format, ulong value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, value);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x0003FDBC File Offset: 0x0003DFBC
		public static string NumberToString(string format, long value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, value);
			string text = instance.IntegerToString(format, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F8F RID: 3983 RVA: 0x0003FDE8 File Offset: 0x0003DFE8
		public static string NumberToString(string format, float value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, (double)value, 7);
			NumberFormatInfo numberFormatInstance = instance.GetNumberFormatInstance(fp);
			string text;
			if (instance._NaN)
			{
				text = numberFormatInstance.NaNSymbol;
			}
			else if (instance._infinity)
			{
				if (instance._positive)
				{
					text = numberFormatInstance.PositiveInfinitySymbol;
				}
				else
				{
					text = numberFormatInstance.NegativeInfinitySymbol;
				}
			}
			else if (instance._specifier == 'R')
			{
				text = instance.FormatRoundtrip(value, numberFormatInstance);
			}
			else
			{
				text = instance.NumberToString(format, numberFormatInstance);
			}
			instance.Release();
			return text;
		}

		// Token: 0x06000F90 RID: 3984 RVA: 0x0003FE80 File Offset: 0x0003E080
		public static string NumberToString(string format, double value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, value, 15);
			NumberFormatInfo numberFormatInstance = instance.GetNumberFormatInstance(fp);
			string text;
			if (instance._NaN)
			{
				text = numberFormatInstance.NaNSymbol;
			}
			else if (instance._infinity)
			{
				if (instance._positive)
				{
					text = numberFormatInstance.PositiveInfinitySymbol;
				}
				else
				{
					text = numberFormatInstance.NegativeInfinitySymbol;
				}
			}
			else if (instance._specifier == 'R')
			{
				text = instance.FormatRoundtrip(value, numberFormatInstance);
			}
			else
			{
				text = instance.NumberToString(format, numberFormatInstance);
			}
			instance.Release();
			return text;
		}

		// Token: 0x06000F91 RID: 3985 RVA: 0x0003FF18 File Offset: 0x0003E118
		public static string NumberToString(string format, decimal value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(format, value);
			string text = instance.NumberToString(format, instance.GetNumberFormatInstance(fp));
			instance.Release();
			return text;
		}

		// Token: 0x06000F92 RID: 3986 RVA: 0x0003FF4C File Offset: 0x0003E14C
		public static string NumberToString(uint value, IFormatProvider fp)
		{
			if (value >= 100000000U)
			{
				return NumberFormatter.NumberToString(null, value, fp);
			}
			NumberFormatter instance = NumberFormatter.GetInstance();
			string text = instance.FastIntegerToString((int)value, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F93 RID: 3987 RVA: 0x0003FF84 File Offset: 0x0003E184
		public static string NumberToString(int value, IFormatProvider fp)
		{
			if (value >= 100000000 || value <= -100000000)
			{
				return NumberFormatter.NumberToString(null, value, fp);
			}
			NumberFormatter instance = NumberFormatter.GetInstance();
			string text = instance.FastIntegerToString(value, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x0003FFC8 File Offset: 0x0003E1C8
		public static string NumberToString(ulong value, IFormatProvider fp)
		{
			if (value >= 100000000UL)
			{
				return NumberFormatter.NumberToString(null, value, fp);
			}
			NumberFormatter instance = NumberFormatter.GetInstance();
			string text = instance.FastIntegerToString((int)value, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F95 RID: 3989 RVA: 0x00040004 File Offset: 0x0003E204
		public static string NumberToString(long value, IFormatProvider fp)
		{
			if (value >= 100000000L || value <= -100000000L)
			{
				return NumberFormatter.NumberToString(null, value, fp);
			}
			NumberFormatter instance = NumberFormatter.GetInstance();
			string text = instance.FastIntegerToString((int)value, fp);
			instance.Release();
			return text;
		}

		// Token: 0x06000F96 RID: 3990 RVA: 0x0004004C File Offset: 0x0003E24C
		public static string NumberToString(float value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			instance.Init(null, (double)value, 7);
			NumberFormatInfo numberFormatInstance = instance.GetNumberFormatInstance(fp);
			string text;
			if (instance._NaN)
			{
				text = numberFormatInstance.NaNSymbol;
			}
			else if (instance._infinity)
			{
				if (instance._positive)
				{
					text = numberFormatInstance.PositiveInfinitySymbol;
				}
				else
				{
					text = numberFormatInstance.NegativeInfinitySymbol;
				}
			}
			else
			{
				text = instance.FormatGeneral(-1, numberFormatInstance);
			}
			instance.Release();
			return text;
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x000400C8 File Offset: 0x0003E2C8
		public static string NumberToString(double value, IFormatProvider fp)
		{
			NumberFormatter instance = NumberFormatter.GetInstance();
			NumberFormatInfo numberFormatInstance = instance.GetNumberFormatInstance(fp);
			instance.Init(null, value, 15);
			string text;
			if (instance._NaN)
			{
				text = numberFormatInstance.NaNSymbol;
			}
			else if (instance._infinity)
			{
				if (instance._positive)
				{
					text = numberFormatInstance.PositiveInfinitySymbol;
				}
				else
				{
					text = numberFormatInstance.NegativeInfinitySymbol;
				}
			}
			else
			{
				text = instance.FormatGeneral(-1, numberFormatInstance);
			}
			instance.Release();
			return text;
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x00040144 File Offset: 0x0003E344
		private string FastIntegerToString(int value, IFormatProvider fp)
		{
			if (value < 0)
			{
				string negativeSign = this.GetNumberFormatInstance(fp).NegativeSign;
				this.ResetCharBuf(8 + negativeSign.Length);
				value = -value;
				this.Append(negativeSign);
			}
			else
			{
				this.ResetCharBuf(8);
			}
			if (value >= 10000)
			{
				int num = value / 10000;
				this.FastAppendDigits(num, false);
				this.FastAppendDigits(value - num * 10000, true);
			}
			else
			{
				this.FastAppendDigits(value, false);
			}
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x000401D4 File Offset: 0x0003E3D4
		private string IntegerToString(string format, IFormatProvider fp)
		{
			NumberFormatInfo numberFormatInstance = this.GetNumberFormatInstance(fp);
			char specifier = this._specifier;
			switch (specifier)
			{
			case 'C':
				return this.FormatCurrency(this._precision, numberFormatInstance);
			case 'D':
				return this.FormatDecimal(this._precision, numberFormatInstance);
			case 'E':
				return this.FormatExponential(this._precision, numberFormatInstance);
			case 'F':
				return this.FormatFixedPoint(this._precision, numberFormatInstance);
			case 'G':
				if (this._precision <= 0)
				{
					return this.FormatDecimal(-1, numberFormatInstance);
				}
				return this.FormatGeneral(this._precision, numberFormatInstance);
			default:
				if (specifier == 'X')
				{
					return this.FormatHexadecimal(this._precision);
				}
				if (this._isCustomFormat)
				{
					return this.FormatCustom(format, numberFormatInstance);
				}
				throw new FormatException("The specified format '" + format + "' is invalid");
			case 'N':
				return this.FormatNumber(this._precision, numberFormatInstance);
			case 'P':
				return this.FormatPercent(this._precision, numberFormatInstance);
			}
		}

		// Token: 0x06000F9A RID: 3994 RVA: 0x000402EC File Offset: 0x0003E4EC
		private string NumberToString(string format, NumberFormatInfo nfi)
		{
			char specifier = this._specifier;
			switch (specifier)
			{
			case 'C':
				return this.FormatCurrency(this._precision, nfi);
			default:
				switch (specifier)
				{
				case 'N':
					return this.FormatNumber(this._precision, nfi);
				default:
					if (specifier != 'X')
					{
					}
					if (this._isCustomFormat)
					{
						return this.FormatCustom(format, nfi);
					}
					throw new FormatException("The specified format '" + format + "' is invalid");
				case 'P':
					return this.FormatPercent(this._precision, nfi);
				}
				break;
			case 'E':
				return this.FormatExponential(this._precision, nfi);
			case 'F':
				return this.FormatFixedPoint(this._precision, nfi);
			case 'G':
				return this.FormatGeneral(this._precision, nfi);
			}
		}

		// Token: 0x06000F9B RID: 3995 RVA: 0x000403BC File Offset: 0x0003E5BC
		public string FormatCurrency(int precision, NumberFormatInfo nfi)
		{
			precision = ((precision < 0) ? nfi.CurrencyDecimalDigits : precision);
			this.RoundDecimal(precision);
			this.ResetCharBuf(this.IntegerDigits * 2 + precision * 2 + 16);
			if (this._positive)
			{
				switch (nfi.CurrencyPositivePattern)
				{
				case 0:
					this.Append(nfi.CurrencySymbol);
					break;
				case 2:
					this.Append(nfi.CurrencySymbol);
					this.Append(' ');
					break;
				}
			}
			else
			{
				switch (nfi.CurrencyNegativePattern)
				{
				case 0:
					this.Append('(');
					this.Append(nfi.CurrencySymbol);
					break;
				case 1:
					this.Append(nfi.NegativeSign);
					this.Append(nfi.CurrencySymbol);
					break;
				case 2:
					this.Append(nfi.CurrencySymbol);
					this.Append(nfi.NegativeSign);
					break;
				case 3:
					this.Append(nfi.CurrencySymbol);
					break;
				case 4:
					this.Append('(');
					break;
				case 5:
					this.Append(nfi.NegativeSign);
					break;
				case 8:
					this.Append(nfi.NegativeSign);
					break;
				case 9:
					this.Append(nfi.NegativeSign);
					this.Append(nfi.CurrencySymbol);
					this.Append(' ');
					break;
				case 11:
					this.Append(nfi.CurrencySymbol);
					this.Append(' ');
					break;
				case 12:
					this.Append(nfi.CurrencySymbol);
					this.Append(' ');
					this.Append(nfi.NegativeSign);
					break;
				case 14:
					this.Append('(');
					this.Append(nfi.CurrencySymbol);
					this.Append(' ');
					break;
				case 15:
					this.Append('(');
					break;
				}
			}
			this.AppendIntegerStringWithGroupSeparator(nfi.RawCurrencyGroupSizes, nfi.CurrencyGroupSeparator);
			if (precision > 0)
			{
				this.Append(nfi.CurrencyDecimalSeparator);
				this.AppendDecimalString(precision);
			}
			if (this._positive)
			{
				switch (nfi.CurrencyPositivePattern)
				{
				case 1:
					this.Append(nfi.CurrencySymbol);
					break;
				case 3:
					this.Append(' ');
					this.Append(nfi.CurrencySymbol);
					break;
				}
			}
			else
			{
				switch (nfi.CurrencyNegativePattern)
				{
				case 0:
					this.Append(')');
					break;
				case 3:
					this.Append(nfi.NegativeSign);
					break;
				case 4:
					this.Append(nfi.CurrencySymbol);
					this.Append(')');
					break;
				case 5:
					this.Append(nfi.CurrencySymbol);
					break;
				case 6:
					this.Append(nfi.NegativeSign);
					this.Append(nfi.CurrencySymbol);
					break;
				case 7:
					this.Append(nfi.CurrencySymbol);
					this.Append(nfi.NegativeSign);
					break;
				case 8:
					this.Append(' ');
					this.Append(nfi.CurrencySymbol);
					break;
				case 10:
					this.Append(' ');
					this.Append(nfi.CurrencySymbol);
					this.Append(nfi.NegativeSign);
					break;
				case 11:
					this.Append(nfi.NegativeSign);
					break;
				case 13:
					this.Append(nfi.NegativeSign);
					this.Append(' ');
					this.Append(nfi.CurrencySymbol);
					break;
				case 14:
					this.Append(')');
					break;
				case 15:
					this.Append(' ');
					this.Append(nfi.CurrencySymbol);
					this.Append(')');
					break;
				}
			}
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x000407D8 File Offset: 0x0003E9D8
		private string FormatDecimal(int precision, NumberFormatInfo nfi)
		{
			if (precision < this._digitsLen)
			{
				precision = this._digitsLen;
			}
			if (precision == 0)
			{
				return "0";
			}
			this.ResetCharBuf(precision + 1);
			if (!this._positive)
			{
				this.Append(nfi.NegativeSign);
			}
			this.AppendDigits(0, precision);
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000F9D RID: 3997 RVA: 0x00040840 File Offset: 0x0003EA40
		private unsafe string FormatHexadecimal(int precision)
		{
			int i = Math.Max(precision, this._decPointPos);
			char* ptr = ((!this._specifierIsUpper) ? NumberFormatter.DigitLowerTable : NumberFormatter.DigitUpperTable);
			this.ResetCharBuf(i);
			this._ind = i;
			ulong num = (ulong)this._val1 | ((ulong)this._val2 << 32);
			while (i > 0)
			{
				this._cbuf[--i] = ptr[(num & 15UL) * 2UL / 2UL];
				num >>= 4;
			}
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000F9E RID: 3998 RVA: 0x000408D0 File Offset: 0x0003EAD0
		public string FormatFixedPoint(int precision, NumberFormatInfo nfi)
		{
			if (precision == -1)
			{
				precision = nfi.NumberDecimalDigits;
			}
			this.RoundDecimal(precision);
			this.ResetCharBuf(this.IntegerDigits + precision + 2);
			if (!this._positive)
			{
				this.Append(nfi.NegativeSign);
			}
			this.AppendIntegerString(this.IntegerDigits);
			if (precision > 0)
			{
				this.Append(nfi.NumberDecimalSeparator);
				this.AppendDecimalString(precision);
			}
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000F9F RID: 3999 RVA: 0x00040954 File Offset: 0x0003EB54
		private string FormatRoundtrip(double origval, NumberFormatInfo nfi)
		{
			NumberFormatter clone = this.GetClone();
			if (origval >= -1.79769313486231E+308 && origval <= 1.79769313486231E+308)
			{
				string text = this.FormatGeneral(this._defPrecision, nfi);
				if (origval == double.Parse(text, nfi))
				{
					return text;
				}
			}
			return clone.FormatGeneral(this._defPrecision + 2, nfi);
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x000409B4 File Offset: 0x0003EBB4
		private string FormatRoundtrip(float origval, NumberFormatInfo nfi)
		{
			NumberFormatter clone = this.GetClone();
			string text = this.FormatGeneral(this._defPrecision, nfi);
			if (origval == float.Parse(text, nfi))
			{
				return text;
			}
			return clone.FormatGeneral(this._defPrecision + 2, nfi);
		}

		// Token: 0x06000FA1 RID: 4001 RVA: 0x000409F4 File Offset: 0x0003EBF4
		private string FormatGeneral(int precision, NumberFormatInfo nfi)
		{
			bool flag;
			if (precision == -1)
			{
				flag = this.IsFloatingSource;
				precision = this._defPrecision;
			}
			else
			{
				flag = true;
				if (precision == 0)
				{
					precision = this._defPrecision;
				}
				this.RoundPos(precision);
			}
			int num = this._decPointPos;
			int digitsLen = this._digitsLen;
			int num2 = digitsLen - num;
			if ((num > precision || num <= -4) && flag)
			{
				return this.FormatExponential(digitsLen - 1, nfi, 2);
			}
			if (num2 < 0)
			{
				num2 = 0;
			}
			if (num < 0)
			{
				num = 0;
			}
			this.ResetCharBuf(num2 + num + 3);
			if (!this._positive)
			{
				this.Append(nfi.NegativeSign);
			}
			if (num == 0)
			{
				this.Append('0');
			}
			else
			{
				this.AppendDigits(digitsLen - num, digitsLen);
			}
			if (num2 > 0)
			{
				this.Append(nfi.NumberDecimalSeparator);
				this.AppendDigits(0, num2);
			}
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000FA2 RID: 4002 RVA: 0x00040AE4 File Offset: 0x0003ECE4
		public string FormatNumber(int precision, NumberFormatInfo nfi)
		{
			precision = ((precision < 0) ? nfi.NumberDecimalDigits : precision);
			this.ResetCharBuf(this.IntegerDigits * 3 + precision);
			this.RoundDecimal(precision);
			if (!this._positive)
			{
				switch (nfi.NumberNegativePattern)
				{
				case 0:
					this.Append('(');
					break;
				case 1:
					this.Append(nfi.NegativeSign);
					break;
				case 2:
					this.Append(nfi.NegativeSign);
					this.Append(' ');
					break;
				}
			}
			this.AppendIntegerStringWithGroupSeparator(nfi.RawNumberGroupSizes, nfi.NumberGroupSeparator);
			if (precision > 0)
			{
				this.Append(nfi.NumberDecimalSeparator);
				this.AppendDecimalString(precision);
			}
			if (!this._positive)
			{
				switch (nfi.NumberNegativePattern)
				{
				case 0:
					this.Append(')');
					break;
				case 3:
					this.Append(nfi.NegativeSign);
					break;
				case 4:
					this.Append(' ');
					this.Append(nfi.NegativeSign);
					break;
				}
			}
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000FA3 RID: 4003 RVA: 0x00040C24 File Offset: 0x0003EE24
		public string FormatPercent(int precision, NumberFormatInfo nfi)
		{
			precision = ((precision < 0) ? nfi.PercentDecimalDigits : precision);
			this.Multiply10(2);
			this.RoundDecimal(precision);
			this.ResetCharBuf(this.IntegerDigits * 2 + precision + 16);
			if (this._positive)
			{
				if (nfi.PercentPositivePattern == 2)
				{
					this.Append(nfi.PercentSymbol);
				}
			}
			else
			{
				switch (nfi.PercentNegativePattern)
				{
				case 0:
					this.Append(nfi.NegativeSign);
					break;
				case 1:
					this.Append(nfi.NegativeSign);
					break;
				case 2:
					this.Append(nfi.NegativeSign);
					this.Append(nfi.PercentSymbol);
					break;
				}
			}
			this.AppendIntegerStringWithGroupSeparator(nfi.RawPercentGroupSizes, nfi.PercentGroupSeparator);
			if (precision > 0)
			{
				this.Append(nfi.PercentDecimalSeparator);
				this.AppendDecimalString(precision);
			}
			if (this._positive)
			{
				int num = nfi.PercentPositivePattern;
				if (num != 0)
				{
					if (num == 1)
					{
						this.Append(nfi.PercentSymbol);
					}
				}
				else
				{
					this.Append(' ');
					this.Append(nfi.PercentSymbol);
				}
			}
			else
			{
				int num = nfi.PercentNegativePattern;
				if (num != 0)
				{
					if (num == 1)
					{
						this.Append(nfi.PercentSymbol);
					}
				}
				else
				{
					this.Append(' ');
					this.Append(nfi.PercentSymbol);
				}
			}
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000FA4 RID: 4004 RVA: 0x00040DC4 File Offset: 0x0003EFC4
		public string FormatExponential(int precision, NumberFormatInfo nfi)
		{
			if (precision == -1)
			{
				precision = 6;
			}
			this.RoundPos(precision + 1);
			return this.FormatExponential(precision, nfi, 3);
		}

		// Token: 0x06000FA5 RID: 4005 RVA: 0x00040DE4 File Offset: 0x0003EFE4
		private string FormatExponential(int precision, NumberFormatInfo nfi, int expDigits)
		{
			int decPointPos = this._decPointPos;
			int digitsLen = this._digitsLen;
			int num = decPointPos - 1;
			int num2 = (this._decPointPos = 1);
			this.ResetCharBuf(precision + 8);
			if (!this._positive)
			{
				this.Append(nfi.NegativeSign);
			}
			this.AppendOneDigit(digitsLen - 1);
			if (precision > 0)
			{
				this.Append(nfi.NumberDecimalSeparator);
				this.AppendDigits(digitsLen - precision - 1, digitsLen - this._decPointPos);
			}
			this.AppendExponent(nfi, num, expDigits);
			return new string(this._cbuf, 0, this._ind);
		}

		// Token: 0x06000FA6 RID: 4006 RVA: 0x00040E78 File Offset: 0x0003F078
		public string FormatCustom(string format, NumberFormatInfo nfi)
		{
			bool positive = this._positive;
			int num = 0;
			int num2 = 0;
			NumberFormatter.CustomInfo.GetActiveSection(format, ref positive, this.IsZero, ref num, ref num2);
			if (num2 == 0)
			{
				return (!this._positive) ? nfi.NegativeSign : string.Empty;
			}
			this._positive = positive;
			NumberFormatter.CustomInfo customInfo = NumberFormatter.CustomInfo.Parse(format, num, num2, nfi);
			StringBuilder stringBuilder = new StringBuilder(customInfo.IntegerDigits * 2);
			StringBuilder stringBuilder2 = new StringBuilder(customInfo.DecimalDigits * 2);
			StringBuilder stringBuilder3 = ((!customInfo.UseExponent) ? null : new StringBuilder(customInfo.ExponentDigits * 2));
			int num3 = 0;
			if (customInfo.Percents > 0)
			{
				this.Multiply10(2 * customInfo.Percents);
			}
			if (customInfo.Permilles > 0)
			{
				this.Multiply10(3 * customInfo.Permilles);
			}
			if (customInfo.DividePlaces > 0)
			{
				this.Divide10(customInfo.DividePlaces);
			}
			bool flag = true;
			if (customInfo.UseExponent && (customInfo.DecimalDigits > 0 || customInfo.IntegerDigits > 0))
			{
				if (!this.IsZero)
				{
					this.RoundPos(customInfo.DecimalDigits + customInfo.IntegerDigits);
					num3 -= this._decPointPos - customInfo.IntegerDigits;
					this._decPointPos = customInfo.IntegerDigits;
				}
				flag = num3 <= 0;
				NumberFormatter.AppendNonNegativeNumber(stringBuilder3, (num3 >= 0) ? num3 : (-num3));
			}
			else
			{
				this.RoundDecimal(customInfo.DecimalDigits);
			}
			if (customInfo.IntegerDigits != 0 || !this.IsZeroInteger)
			{
				this.AppendIntegerString(this.IntegerDigits, stringBuilder);
			}
			this.AppendDecimalString(this.DecimalDigits, stringBuilder2);
			if (customInfo.UseExponent)
			{
				if (customInfo.DecimalDigits <= 0 && customInfo.IntegerDigits <= 0)
				{
					this._positive = true;
				}
				if (stringBuilder.Length < customInfo.IntegerDigits)
				{
					stringBuilder.Insert(0, "0", customInfo.IntegerDigits - stringBuilder.Length);
				}
				while (stringBuilder3.Length < customInfo.ExponentDigits - customInfo.ExponentTailSharpDigits)
				{
					stringBuilder3.Insert(0, '0');
				}
				if (flag && !customInfo.ExponentNegativeSignOnly)
				{
					stringBuilder3.Insert(0, nfi.PositiveSign);
				}
				else if (!flag)
				{
					stringBuilder3.Insert(0, nfi.NegativeSign);
				}
			}
			else
			{
				if (stringBuilder.Length < customInfo.IntegerDigits - customInfo.IntegerHeadSharpDigits)
				{
					stringBuilder.Insert(0, "0", customInfo.IntegerDigits - customInfo.IntegerHeadSharpDigits - stringBuilder.Length);
				}
				if (customInfo.IntegerDigits == customInfo.IntegerHeadSharpDigits && NumberFormatter.IsZeroOnly(stringBuilder))
				{
					stringBuilder.Remove(0, stringBuilder.Length);
				}
			}
			NumberFormatter.ZeroTrimEnd(stringBuilder2, true);
			while (stringBuilder2.Length < customInfo.DecimalDigits - customInfo.DecimalTailSharpDigits)
			{
				stringBuilder2.Append('0');
			}
			if (stringBuilder2.Length > customInfo.DecimalDigits)
			{
				stringBuilder2.Remove(customInfo.DecimalDigits, stringBuilder2.Length - customInfo.DecimalDigits);
			}
			return customInfo.Format(format, num, num2, nfi, this._positive, stringBuilder, stringBuilder2, stringBuilder3);
		}

		// Token: 0x06000FA7 RID: 4007 RVA: 0x000411CC File Offset: 0x0003F3CC
		private static void ZeroTrimEnd(StringBuilder sb, bool canEmpty)
		{
			int num = 0;
			int num2 = sb.Length - 1;
			while ((!canEmpty) ? (num2 > 0) : (num2 >= 0))
			{
				if (sb[num2] != '0')
				{
					break;
				}
				num++;
				num2--;
			}
			if (num > 0)
			{
				sb.Remove(sb.Length - num, num);
			}
		}

		// Token: 0x06000FA8 RID: 4008 RVA: 0x00041238 File Offset: 0x0003F438
		private static bool IsZeroOnly(StringBuilder sb)
		{
			for (int i = 0; i < sb.Length; i++)
			{
				if (char.IsDigit(sb[i]) && sb[i] != '0')
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000FA9 RID: 4009 RVA: 0x00041280 File Offset: 0x0003F480
		private static void AppendNonNegativeNumber(StringBuilder sb, int v)
		{
			if (v < 0)
			{
				throw new ArgumentException();
			}
			int num = NumberFormatter.ScaleOrder((long)v) - 1;
			do
			{
				int num2 = v / (int)NumberFormatter.GetTenPowerOf(num);
				sb.Append((char)(48 | num2));
				v -= (int)NumberFormatter.GetTenPowerOf(num--) * num2;
			}
			while (num >= 0);
		}

		// Token: 0x06000FAA RID: 4010 RVA: 0x000412D4 File Offset: 0x0003F4D4
		private void AppendIntegerString(int minLength, StringBuilder sb)
		{
			if (this._decPointPos <= 0)
			{
				sb.Append('0', minLength);
				return;
			}
			if (this._decPointPos < minLength)
			{
				sb.Append('0', minLength - this._decPointPos);
			}
			this.AppendDigits(this._digitsLen - this._decPointPos, this._digitsLen, sb);
		}

		// Token: 0x06000FAB RID: 4011 RVA: 0x00041330 File Offset: 0x0003F530
		private void AppendIntegerString(int minLength)
		{
			if (this._decPointPos <= 0)
			{
				this.Append('0', minLength);
				return;
			}
			if (this._decPointPos < minLength)
			{
				this.Append('0', minLength - this._decPointPos);
			}
			this.AppendDigits(this._digitsLen - this._decPointPos, this._digitsLen);
		}

		// Token: 0x06000FAC RID: 4012 RVA: 0x00041388 File Offset: 0x0003F588
		private void AppendDecimalString(int precision, StringBuilder sb)
		{
			this.AppendDigits(this._digitsLen - precision - this._decPointPos, this._digitsLen - this._decPointPos, sb);
		}

		// Token: 0x06000FAD RID: 4013 RVA: 0x000413B0 File Offset: 0x0003F5B0
		private void AppendDecimalString(int precision)
		{
			this.AppendDigits(this._digitsLen - precision - this._decPointPos, this._digitsLen - this._decPointPos);
		}

		// Token: 0x06000FAE RID: 4014 RVA: 0x000413D4 File Offset: 0x0003F5D4
		private void AppendIntegerStringWithGroupSeparator(int[] groups, string groupSeparator)
		{
			if (this.IsZeroInteger)
			{
				this.Append('0');
				return;
			}
			int num = 0;
			int num2 = 0;
			for (int i = 0; i < groups.Length; i++)
			{
				num += groups[i];
				if (num > this._decPointPos)
				{
					break;
				}
				num2 = i;
			}
			if (groups.Length > 0 && num > 0)
			{
				int num3 = groups[num2];
				int num4 = ((this._decPointPos <= num) ? 0 : (this._decPointPos - num));
				if (num3 == 0)
				{
					while (num2 >= 0 && groups[num2] == 0)
					{
						num2--;
					}
					num3 = ((num4 <= 0) ? groups[num2] : num4);
				}
				int num5;
				if (num4 == 0)
				{
					num5 = num3;
				}
				else
				{
					num2 += num4 / num3;
					num5 = num4 % num3;
					if (num5 == 0)
					{
						num5 = num3;
					}
					else
					{
						num2++;
					}
				}
				int num6 = 0;
				while (this._decPointPos - num6 > num5 && num5 != 0)
				{
					this.AppendDigits(this._digitsLen - num6 - num5, this._digitsLen - num6);
					num6 += num5;
					this.Append(groupSeparator);
					if (--num2 < groups.Length && num2 >= 0)
					{
						num3 = groups[num2];
					}
					num5 = num3;
				}
				this.AppendDigits(this._digitsLen - this._decPointPos, this._digitsLen - num6);
			}
			else
			{
				this.AppendDigits(this._digitsLen - this._decPointPos, this._digitsLen);
			}
		}

		// Token: 0x06000FAF RID: 4015 RVA: 0x00041564 File Offset: 0x0003F764
		private void AppendExponent(NumberFormatInfo nfi, int exponent, int minDigits)
		{
			if (this._specifierIsUpper || this._specifier == 'R')
			{
				this.Append('E');
			}
			else
			{
				this.Append('e');
			}
			if (exponent >= 0)
			{
				this.Append(nfi.PositiveSign);
			}
			else
			{
				this.Append(nfi.NegativeSign);
				exponent = -exponent;
			}
			if (exponent == 0)
			{
				this.Append('0', minDigits);
			}
			else if (exponent < 10)
			{
				this.Append('0', minDigits - 1);
				this.Append((char)(48 | exponent));
			}
			else
			{
				uint num = NumberFormatter.FastToDecHex(exponent);
				if (exponent >= 100 || minDigits == 3)
				{
					this.Append((char)(48U | (num >> 8)));
				}
				this.Append((char)(48U | ((num >> 4) & 15U)));
				this.Append((char)(48U | (num & 15U)));
			}
		}

		// Token: 0x06000FB0 RID: 4016 RVA: 0x00041640 File Offset: 0x0003F840
		private void AppendOneDigit(int start)
		{
			if (this._ind == this._cbuf.Length)
			{
				this.Resize(this._ind + 10);
			}
			start += this._offset;
			uint num;
			if (start < 0)
			{
				num = 0U;
			}
			else if (start < 8)
			{
				num = this._val1;
			}
			else if (start < 16)
			{
				num = this._val2;
			}
			else if (start < 24)
			{
				num = this._val3;
			}
			else if (start < 32)
			{
				num = this._val4;
			}
			else
			{
				num = 0U;
			}
			num >>= (start & 7) << 2;
			this._cbuf[this._ind++] = (char)(48U | (num & 15U));
		}

		// Token: 0x06000FB1 RID: 4017 RVA: 0x00041704 File Offset: 0x0003F904
		private unsafe void FastAppendDigits(int val, bool force)
		{
			int ind = this._ind;
			int num2;
			if (force || val >= 100)
			{
				int num = val * 5243 >> 19;
				num2 = NumberFormatter.DecHexDigits[num];
				if (force || val >= 1000)
				{
					this._cbuf[ind++] = (char)(48 | (num2 >> 4));
				}
				this._cbuf[ind++] = (char)(48 | (num2 & 15));
				num2 = NumberFormatter.DecHexDigits[val - num * 100];
			}
			else
			{
				num2 = NumberFormatter.DecHexDigits[val];
			}
			if (force || val >= 10)
			{
				this._cbuf[ind++] = (char)(48 | (num2 >> 4));
			}
			this._cbuf[ind++] = (char)(48 | (num2 & 15));
			this._ind = ind;
		}

		// Token: 0x06000FB2 RID: 4018 RVA: 0x000417D0 File Offset: 0x0003F9D0
		private void AppendDigits(int start, int end)
		{
			if (start >= end)
			{
				return;
			}
			int num = this._ind + (end - start);
			if (num > this._cbuf.Length)
			{
				this.Resize(num + 10);
			}
			this._ind = num;
			end += this._offset;
			start += this._offset;
			int num2 = start + 8 - (start & 7);
			for (;;)
			{
				uint num3;
				if (num2 == 8)
				{
					num3 = this._val1;
				}
				else if (num2 == 16)
				{
					num3 = this._val2;
				}
				else if (num2 == 24)
				{
					num3 = this._val3;
				}
				else if (num2 == 32)
				{
					num3 = this._val4;
				}
				else
				{
					num3 = 0U;
				}
				num3 >>= (start & 7) << 2;
				if (num2 > end)
				{
					num2 = end;
				}
				this._cbuf[--num] = (char)(48U | (num3 & 15U));
				switch (num2 - start)
				{
				case 1:
					goto IL_01C8;
				case 2:
					goto IL_01AB;
				case 3:
					goto IL_018E;
				case 4:
					goto IL_0171;
				case 5:
					goto IL_0154;
				case 6:
					goto IL_0137;
				case 7:
					goto IL_011A;
				case 8:
					this._cbuf[--num] = (char)(48U | ((num3 >>= 4) & 15U));
					goto IL_011A;
				}
				IL_01D5:
				start = num2;
				num2 += 8;
				continue;
				IL_01C8:
				if (num2 == end)
				{
					break;
				}
				goto IL_01D5;
				IL_01AB:
				this._cbuf[--num] = (char)(48U | ((num3 >> 4) & 15U));
				goto IL_01C8;
				IL_018E:
				this._cbuf[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_01AB;
				IL_0171:
				this._cbuf[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_018E;
				IL_0154:
				this._cbuf[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_0171;
				IL_0137:
				this._cbuf[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_0154;
				IL_011A:
				this._cbuf[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_0137;
			}
		}

		// Token: 0x06000FB3 RID: 4019 RVA: 0x000419C0 File Offset: 0x0003FBC0
		private void AppendDigits(int start, int end, StringBuilder sb)
		{
			if (start >= end)
			{
				return;
			}
			int num = sb.Length + (end - start);
			sb.Length = num;
			end += this._offset;
			start += this._offset;
			int num2 = start + 8 - (start & 7);
			for (;;)
			{
				uint num3;
				if (num2 == 8)
				{
					num3 = this._val1;
				}
				else if (num2 == 16)
				{
					num3 = this._val2;
				}
				else if (num2 == 24)
				{
					num3 = this._val3;
				}
				else if (num2 == 32)
				{
					num3 = this._val4;
				}
				else
				{
					num3 = 0U;
				}
				num3 >>= (start & 7) << 2;
				if (num2 > end)
				{
					num2 = end;
				}
				sb[--num] = (char)(48U | (num3 & 15U));
				switch (num2 - start)
				{
				case 1:
					goto IL_01A8;
				case 2:
					goto IL_018C;
				case 3:
					goto IL_0170;
				case 4:
					goto IL_0154;
				case 5:
					goto IL_0138;
				case 6:
					goto IL_011C;
				case 7:
					goto IL_0100;
				case 8:
					sb[--num] = (char)(48U | ((num3 >>= 4) & 15U));
					goto IL_0100;
				}
				IL_01B5:
				start = num2;
				num2 += 8;
				continue;
				IL_01A8:
				if (num2 == end)
				{
					break;
				}
				goto IL_01B5;
				IL_018C:
				sb[--num] = (char)(48U | ((num3 >> 4) & 15U));
				goto IL_01A8;
				IL_0170:
				sb[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_018C;
				IL_0154:
				sb[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_0170;
				IL_0138:
				sb[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_0154;
				IL_011C:
				sb[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_0138;
				IL_0100:
				sb[--num] = (char)(48U | ((num3 >>= 4) & 15U));
				goto IL_011C;
			}
		}

		// Token: 0x06000FB4 RID: 4020 RVA: 0x00041B90 File Offset: 0x0003FD90
		private void Multiply10(int count)
		{
			if (count <= 0 || this._digitsLen == 0)
			{
				return;
			}
			this._decPointPos += count;
		}

		// Token: 0x06000FB5 RID: 4021 RVA: 0x00041BB4 File Offset: 0x0003FDB4
		private void Divide10(int count)
		{
			if (count <= 0 || this._digitsLen == 0)
			{
				return;
			}
			this._decPointPos -= count;
		}

		// Token: 0x06000FB6 RID: 4022 RVA: 0x00041BD8 File Offset: 0x0003FDD8
		private NumberFormatter GetClone()
		{
			return (NumberFormatter)base.MemberwiseClone();
		}

		// Token: 0x04000649 RID: 1609
		private const int DefaultExpPrecision = 6;

		// Token: 0x0400064A RID: 1610
		private const int HundredMillion = 100000000;

		// Token: 0x0400064B RID: 1611
		private const long SeventeenDigitsThreshold = 10000000000000000L;

		// Token: 0x0400064C RID: 1612
		private const ulong ULongDivHundredMillion = 184467440737UL;

		// Token: 0x0400064D RID: 1613
		private const ulong ULongModHundredMillion = 9551616UL;

		// Token: 0x0400064E RID: 1614
		private const int DoubleBitsExponentShift = 52;

		// Token: 0x0400064F RID: 1615
		private const int DoubleBitsExponentMask = 2047;

		// Token: 0x04000650 RID: 1616
		private const long DoubleBitsMantissaMask = 4503599627370495L;

		// Token: 0x04000651 RID: 1617
		private const int DecimalBitsScaleMask = 2031616;

		// Token: 0x04000652 RID: 1618
		private const int SingleDefPrecision = 7;

		// Token: 0x04000653 RID: 1619
		private const int DoubleDefPrecision = 15;

		// Token: 0x04000654 RID: 1620
		private const int Int8DefPrecision = 3;

		// Token: 0x04000655 RID: 1621
		private const int UInt8DefPrecision = 3;

		// Token: 0x04000656 RID: 1622
		private const int Int16DefPrecision = 5;

		// Token: 0x04000657 RID: 1623
		private const int UInt16DefPrecision = 5;

		// Token: 0x04000658 RID: 1624
		private const int Int32DefPrecision = 10;

		// Token: 0x04000659 RID: 1625
		private const int UInt32DefPrecision = 10;

		// Token: 0x0400065A RID: 1626
		private const int Int64DefPrecision = 19;

		// Token: 0x0400065B RID: 1627
		private const int UInt64DefPrecision = 20;

		// Token: 0x0400065C RID: 1628
		private const int DecimalDefPrecision = 100;

		// Token: 0x0400065D RID: 1629
		private const int TenPowersListLength = 19;

		// Token: 0x0400065E RID: 1630
		private const double MinRoundtripVal = -1.79769313486231E+308;

		// Token: 0x0400065F RID: 1631
		private const double MaxRoundtripVal = 1.79769313486231E+308;

		// Token: 0x04000660 RID: 1632
		private unsafe static readonly ulong* MantissaBitsTable;

		// Token: 0x04000661 RID: 1633
		private unsafe static readonly int* TensExponentTable;

		// Token: 0x04000662 RID: 1634
		private unsafe static readonly char* DigitLowerTable;

		// Token: 0x04000663 RID: 1635
		private unsafe static readonly char* DigitUpperTable;

		// Token: 0x04000664 RID: 1636
		private unsafe static readonly long* TenPowersList;

		// Token: 0x04000665 RID: 1637
		private unsafe static readonly int* DecHexDigits;

		// Token: 0x04000666 RID: 1638
		private Thread _thread;

		// Token: 0x04000667 RID: 1639
		private NumberFormatInfo _nfi;

		// Token: 0x04000668 RID: 1640
		private bool _NaN;

		// Token: 0x04000669 RID: 1641
		private bool _infinity;

		// Token: 0x0400066A RID: 1642
		private bool _isCustomFormat;

		// Token: 0x0400066B RID: 1643
		private bool _specifierIsUpper;

		// Token: 0x0400066C RID: 1644
		private bool _positive;

		// Token: 0x0400066D RID: 1645
		private char _specifier;

		// Token: 0x0400066E RID: 1646
		private int _precision;

		// Token: 0x0400066F RID: 1647
		private int _defPrecision;

		// Token: 0x04000670 RID: 1648
		private int _digitsLen;

		// Token: 0x04000671 RID: 1649
		private int _offset;

		// Token: 0x04000672 RID: 1650
		private int _decPointPos;

		// Token: 0x04000673 RID: 1651
		private uint _val1;

		// Token: 0x04000674 RID: 1652
		private uint _val2;

		// Token: 0x04000675 RID: 1653
		private uint _val3;

		// Token: 0x04000676 RID: 1654
		private uint _val4;

		// Token: 0x04000677 RID: 1655
		private char[] _cbuf;

		// Token: 0x04000678 RID: 1656
		private int _ind;

		// Token: 0x04000679 RID: 1657
		[ThreadStatic]
		private static NumberFormatter threadNumberFormatter;

		// Token: 0x02000197 RID: 407
		private class CustomInfo
		{
			// Token: 0x06000FB8 RID: 4024 RVA: 0x00041C00 File Offset: 0x0003FE00
			public static void GetActiveSection(string format, ref bool positive, bool zero, ref int offset, ref int length)
			{
				int[] array = new int[3];
				int num = 0;
				int num2 = 0;
				char c = '\0';
				for (int i = 0; i < format.Length; i++)
				{
					char c2 = format[i];
					if (c2 == c || (c == '\0' && (c2 == '"' || c2 == '\'')))
					{
						if (c == '\0')
						{
							c = c2;
						}
						else
						{
							c = '\0';
						}
					}
					else if (c == '\0' && format[i] == ';' && (i == 0 || format[i - 1] != '\\'))
					{
						array[num++] = i - num2;
						num2 = i + 1;
						if (num == 3)
						{
							break;
						}
					}
				}
				if (num == 0)
				{
					offset = 0;
					length = format.Length;
					return;
				}
				if (num == 1)
				{
					if (positive || zero)
					{
						offset = 0;
						length = array[0];
						return;
					}
					if (array[0] + 1 < format.Length)
					{
						positive = true;
						offset = array[0] + 1;
						length = format.Length - offset;
						return;
					}
					offset = 0;
					length = array[0];
					return;
				}
				else if (num == 2)
				{
					if (zero)
					{
						offset = array[0] + array[1] + 2;
						length = format.Length - offset;
						return;
					}
					if (positive)
					{
						offset = 0;
						length = array[0];
						return;
					}
					if (array[1] > 0)
					{
						positive = true;
						offset = array[0] + 1;
						length = array[1];
						return;
					}
					offset = 0;
					length = array[0];
					return;
				}
				else
				{
					if (num != 3)
					{
						throw new ArgumentException();
					}
					if (zero)
					{
						offset = array[0] + array[1] + 2;
						length = array[2];
						return;
					}
					if (positive)
					{
						offset = 0;
						length = array[0];
						return;
					}
					if (array[1] > 0)
					{
						positive = true;
						offset = array[0] + 1;
						length = array[1];
						return;
					}
					offset = 0;
					length = array[0];
					return;
				}
			}

			// Token: 0x06000FB9 RID: 4025 RVA: 0x00041DD4 File Offset: 0x0003FFD4
			public static NumberFormatter.CustomInfo Parse(string format, int offset, int length, NumberFormatInfo nfi)
			{
				char c = '\0';
				bool flag = true;
				bool flag2 = false;
				bool flag3 = false;
				bool flag4 = true;
				NumberFormatter.CustomInfo customInfo = new NumberFormatter.CustomInfo();
				int num = 0;
				int num2 = offset;
				while (num2 - offset < length)
				{
					char c2 = format[num2];
					if (c2 == c && c2 != '\0')
					{
						c = '\0';
					}
					else if (c == '\0')
					{
						if (flag3 && c2 != '\0' && c2 != '0' && c2 != '#')
						{
							flag3 = false;
							flag = customInfo.DecimalPointPos < 0;
							flag2 = !flag;
							num2--;
						}
						else
						{
							char c3 = c2;
							switch (c3)
							{
							case '"':
							case '\'':
								if (c2 == '"' || c2 == '\'')
								{
									c = c2;
								}
								goto IL_0311;
							case '#':
								if (flag4 && flag)
								{
									customInfo.IntegerHeadSharpDigits++;
								}
								else if (flag2)
								{
									customInfo.DecimalTailSharpDigits++;
								}
								else if (flag3)
								{
									customInfo.ExponentTailSharpDigits++;
								}
								break;
							default:
								switch (c3)
								{
								case ',':
									if (flag && customInfo.IntegerDigits > 0)
									{
										num++;
									}
									goto IL_0311;
								default:
									if (c3 != 'E')
									{
										if (c3 == '\\')
										{
											num2++;
											goto IL_0311;
										}
										if (c3 != 'e')
										{
											if (c3 != '‰')
											{
												goto IL_0311;
											}
											customInfo.Permilles++;
											goto IL_0311;
										}
									}
									if (customInfo.UseExponent)
									{
										goto IL_0311;
									}
									customInfo.UseExponent = true;
									flag = false;
									flag2 = false;
									flag3 = true;
									if (num2 + 1 - offset < length)
									{
										char c4 = format[num2 + 1];
										if (c4 == '+')
										{
											customInfo.ExponentNegativeSignOnly = false;
										}
										if (c4 == '+' || c4 == '-')
										{
											num2++;
										}
										else if (c4 != '0' && c4 != '#')
										{
											customInfo.UseExponent = false;
											if (customInfo.DecimalPointPos < 0)
											{
												flag = true;
											}
										}
									}
									goto IL_0311;
								case '.':
									flag = false;
									flag2 = true;
									flag3 = false;
									if (customInfo.DecimalPointPos == -1)
									{
										customInfo.DecimalPointPos = num2;
									}
									goto IL_0311;
								case '0':
									break;
								}
								break;
							case '%':
								customInfo.Percents++;
								goto IL_0311;
							}
							if (c2 != '#')
							{
								flag4 = false;
								if (flag2)
								{
									customInfo.DecimalTailSharpDigits = 0;
								}
								else if (flag3)
								{
									customInfo.ExponentTailSharpDigits = 0;
								}
							}
							if (customInfo.IntegerHeadPos == -1)
							{
								customInfo.IntegerHeadPos = num2;
							}
							if (flag)
							{
								customInfo.IntegerDigits++;
								if (num > 0)
								{
									customInfo.UseGroup = true;
								}
								num = 0;
							}
							else if (flag2)
							{
								customInfo.DecimalDigits++;
							}
							else if (flag3)
							{
								customInfo.ExponentDigits++;
							}
						}
					}
					IL_0311:
					num2++;
				}
				if (customInfo.ExponentDigits == 0)
				{
					customInfo.UseExponent = false;
				}
				else
				{
					customInfo.IntegerHeadSharpDigits = 0;
				}
				if (customInfo.DecimalDigits == 0)
				{
					customInfo.DecimalPointPos = -1;
				}
				customInfo.DividePlaces += num * 3;
				return customInfo;
			}

			// Token: 0x06000FBA RID: 4026 RVA: 0x0004214C File Offset: 0x0004034C
			public string Format(string format, int offset, int length, NumberFormatInfo nfi, bool positive, StringBuilder sb_int, StringBuilder sb_dec, StringBuilder sb_exp)
			{
				StringBuilder stringBuilder = new StringBuilder();
				char c = '\0';
				bool flag = true;
				bool flag2 = false;
				int num = 0;
				int i = 0;
				int num2 = 0;
				int[] rawNumberGroupSizes = nfi.RawNumberGroupSizes;
				string numberGroupSeparator = nfi.NumberGroupSeparator;
				int num3 = 0;
				int num4 = 0;
				int num5 = 0;
				int num6 = 0;
				int num7 = 0;
				if (this.UseGroup && rawNumberGroupSizes.Length > 0)
				{
					num3 = sb_int.Length;
					for (int j = 0; j < rawNumberGroupSizes.Length; j++)
					{
						num4 += rawNumberGroupSizes[j];
						if (num4 <= num3)
						{
							num5 = j;
						}
					}
					num7 = rawNumberGroupSizes[num5];
					int num8 = ((num3 <= num4) ? 0 : (num3 - num4));
					if (num7 == 0)
					{
						while (num5 >= 0 && rawNumberGroupSizes[num5] == 0)
						{
							num5--;
						}
						num7 = ((num8 <= 0) ? rawNumberGroupSizes[num5] : num8);
					}
					if (num8 == 0)
					{
						num6 = num7;
					}
					else
					{
						num5 += num8 / num7;
						num6 = num8 % num7;
						if (num6 == 0)
						{
							num6 = num7;
						}
						else
						{
							num5++;
						}
					}
				}
				else
				{
					this.UseGroup = false;
				}
				int num9 = offset;
				while (num9 - offset < length)
				{
					char c2 = format[num9];
					if (c2 == c && c2 != '\0')
					{
						c = '\0';
					}
					else if (c != '\0')
					{
						stringBuilder.Append(c2);
					}
					else
					{
						char c3 = c2;
						switch (c3)
						{
						case '"':
						case '\'':
							if (c2 == '"' || c2 == '\'')
							{
								c = c2;
							}
							goto IL_0474;
						case '#':
							break;
						default:
							switch (c3)
							{
							case ',':
								goto IL_0474;
							default:
							{
								if (c3 != 'E')
								{
									if (c3 == '\\')
									{
										num9++;
										if (num9 - offset < length)
										{
											stringBuilder.Append(format[num9]);
										}
										goto IL_0474;
									}
									if (c3 != 'e')
									{
										if (c3 != '‰')
										{
											stringBuilder.Append(c2);
											goto IL_0474;
										}
										stringBuilder.Append(nfi.PerMilleSymbol);
										goto IL_0474;
									}
								}
								if (sb_exp == null || !this.UseExponent)
								{
									stringBuilder.Append(c2);
									goto IL_0474;
								}
								bool flag3 = true;
								bool flag4 = false;
								int num10 = num9 + 1;
								while (num10 - offset < length)
								{
									if (format[num10] == '0')
									{
										flag4 = true;
									}
									else if (num10 != num9 + 1 || (format[num10] != '+' && format[num10] != '-'))
									{
										if (!flag4)
										{
											flag3 = false;
										}
										break;
									}
									num10++;
								}
								if (flag3)
								{
									num9 = num10 - 1;
									flag = this.DecimalPointPos < 0;
									flag2 = !flag;
									stringBuilder.Append(c2);
									stringBuilder.Append(sb_exp);
									sb_exp = null;
								}
								else
								{
									stringBuilder.Append(c2);
								}
								goto IL_0474;
							}
							case '.':
								if (this.DecimalPointPos == num9)
								{
									if (this.DecimalDigits > 0)
									{
										while (i < sb_int.Length)
										{
											stringBuilder.Append(sb_int[i++]);
										}
									}
									if (sb_dec.Length > 0)
									{
										stringBuilder.Append(nfi.NumberDecimalSeparator);
									}
								}
								flag = false;
								flag2 = true;
								goto IL_0474;
							case '0':
								break;
							}
							break;
						case '%':
							stringBuilder.Append(nfi.PercentSymbol);
							goto IL_0474;
						}
						if (flag)
						{
							num++;
							if (this.IntegerDigits - num < sb_int.Length + i || c2 == '0')
							{
								while (this.IntegerDigits - num + i < sb_int.Length)
								{
									stringBuilder.Append(sb_int[i++]);
									if (this.UseGroup && --num3 > 0 && --num6 == 0)
									{
										stringBuilder.Append(numberGroupSeparator);
										if (--num5 < rawNumberGroupSizes.Length && num5 >= 0)
										{
											num7 = rawNumberGroupSizes[num5];
										}
										num6 = num7;
									}
								}
							}
						}
						else if (flag2)
						{
							if (num2 < sb_dec.Length)
							{
								stringBuilder.Append(sb_dec[num2++]);
							}
						}
						else
						{
							stringBuilder.Append(c2);
						}
					}
					IL_0474:
					num9++;
				}
				if (!positive)
				{
					stringBuilder.Insert(0, nfi.NegativeSign);
				}
				return stringBuilder.ToString();
			}

			// Token: 0x0400067A RID: 1658
			public bool UseGroup;

			// Token: 0x0400067B RID: 1659
			public int DecimalDigits;

			// Token: 0x0400067C RID: 1660
			public int DecimalPointPos = -1;

			// Token: 0x0400067D RID: 1661
			public int DecimalTailSharpDigits;

			// Token: 0x0400067E RID: 1662
			public int IntegerDigits;

			// Token: 0x0400067F RID: 1663
			public int IntegerHeadSharpDigits;

			// Token: 0x04000680 RID: 1664
			public int IntegerHeadPos;

			// Token: 0x04000681 RID: 1665
			public bool UseExponent;

			// Token: 0x04000682 RID: 1666
			public int ExponentDigits;

			// Token: 0x04000683 RID: 1667
			public int ExponentTailSharpDigits;

			// Token: 0x04000684 RID: 1668
			public bool ExponentNegativeSignOnly = true;

			// Token: 0x04000685 RID: 1669
			public int DividePlaces;

			// Token: 0x04000686 RID: 1670
			public int Percents;

			// Token: 0x04000687 RID: 1671
			public int Permilles;
		}
	}
}
