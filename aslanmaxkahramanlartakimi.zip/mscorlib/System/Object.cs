﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000198 RID: 408
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.AutoDual)]
	[Serializable]
	public class Object
	{
		// Token: 0x06000FBB RID: 4027 RVA: 0x000425FC File Offset: 0x000407FC
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]
		public Object()
		{
		}

		// Token: 0x06000FBC RID: 4028 RVA: 0x00042600 File Offset: 0x00040800
		public virtual bool Equals(object obj)
		{
			return this == obj;
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x00042608 File Offset: 0x00040808
		public static bool Equals(object objA, object objB)
		{
			return objA == objB || (objA != null && objB != null && objA.Equals(objB));
		}

		// Token: 0x06000FBE RID: 4030 RVA: 0x00042628 File Offset: 0x00040828
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		protected virtual void Finalize()
		{
		}

		// Token: 0x06000FBF RID: 4031 RVA: 0x0004262C File Offset: 0x0004082C
		public virtual int GetHashCode()
		{
			return object.InternalGetHashCode(this);
		}

		// Token: 0x06000FC0 RID: 4032
		[MethodImpl(4096)]
		public extern Type GetType();

		// Token: 0x06000FC1 RID: 4033
		[MethodImpl(4096)]
		protected extern object MemberwiseClone();

		// Token: 0x06000FC2 RID: 4034 RVA: 0x00042634 File Offset: 0x00040834
		public virtual string ToString()
		{
			return this.GetType().ToString();
		}

		// Token: 0x06000FC3 RID: 4035 RVA: 0x00042644 File Offset: 0x00040844
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		public static bool ReferenceEquals(object objA, object objB)
		{
			return objA == objB;
		}

		// Token: 0x06000FC4 RID: 4036
		[MethodImpl(4096)]
		internal static extern int InternalGetHashCode(object o);

		// Token: 0x06000FC5 RID: 4037
		[MethodImpl(4096)]
		internal extern IntPtr obj_address();

		// Token: 0x06000FC6 RID: 4038 RVA: 0x0004264C File Offset: 0x0004084C
		private void FieldGetter(string typeName, string fieldName, ref object val)
		{
		}

		// Token: 0x06000FC7 RID: 4039 RVA: 0x00042650 File Offset: 0x00040850
		private void FieldSetter(string typeName, string fieldName, object val)
		{
		}
	}
}
