﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x02000199 RID: 409
	[ComVisible(true)]
	[Serializable]
	public class ObjectDisposedException : InvalidOperationException
	{
		// Token: 0x06000FC8 RID: 4040 RVA: 0x00042654 File Offset: 0x00040854
		public ObjectDisposedException(string objectName)
			: base(Locale.GetText("The object was used after being disposed."))
		{
			this.obj_name = objectName;
			this.msg = Locale.GetText("The object was used after being disposed.");
		}

		// Token: 0x06000FC9 RID: 4041 RVA: 0x00042680 File Offset: 0x00040880
		public ObjectDisposedException(string objectName, string message)
			: base(message)
		{
			this.obj_name = objectName;
			this.msg = message;
		}

		// Token: 0x06000FCA RID: 4042 RVA: 0x00042698 File Offset: 0x00040898
		protected ObjectDisposedException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
			this.obj_name = info.GetString("ObjectName");
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000FCB RID: 4043 RVA: 0x000426B4 File Offset: 0x000408B4
		public override string Message
		{
			get
			{
				return this.msg;
			}
		}

		// Token: 0x06000FCC RID: 4044 RVA: 0x000426BC File Offset: 0x000408BC
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("ObjectName", this.obj_name);
		}

		// Token: 0x04000688 RID: 1672
		private string obj_name;

		// Token: 0x04000689 RID: 1673
		private string msg;
	}
}
