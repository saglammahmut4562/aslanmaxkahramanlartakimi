﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x0200019A RID: 410
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Constructor | AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Event | AttributeTargets.Interface | AttributeTargets.Delegate, Inherited = false)]
	[ComVisible(true)]
	[Serializable]
	public sealed class ObsoleteAttribute : Attribute
	{
		// Token: 0x06000FCD RID: 4045 RVA: 0x000426D8 File Offset: 0x000408D8
		public ObsoleteAttribute()
		{
		}

		// Token: 0x06000FCE RID: 4046 RVA: 0x000426E0 File Offset: 0x000408E0
		public ObsoleteAttribute(string message)
		{
			this._message = message;
		}

		// Token: 0x06000FCF RID: 4047 RVA: 0x000426F0 File Offset: 0x000408F0
		public ObsoleteAttribute(string message, bool error)
		{
			this._message = message;
			this._error = error;
		}

		// Token: 0x0400068A RID: 1674
		private string _message;

		// Token: 0x0400068B RID: 1675
		private bool _error;
	}
}
