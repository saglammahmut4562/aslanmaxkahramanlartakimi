﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200019B RID: 411
	[ComVisible(true)]
	[Serializable]
	public sealed class OperatingSystem : ICloneable, ISerializable
	{
		// Token: 0x06000FD0 RID: 4048 RVA: 0x00042708 File Offset: 0x00040908
		public OperatingSystem(PlatformID platform, Version version)
		{
			if (version == null)
			{
				throw new ArgumentNullException("version");
			}
			this._platform = platform;
			this._version = version;
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000FD1 RID: 4049 RVA: 0x00042740 File Offset: 0x00040940
		public PlatformID Platform
		{
			get
			{
				return this._platform;
			}
		}

		// Token: 0x06000FD2 RID: 4050 RVA: 0x00042748 File Offset: 0x00040948
		public object Clone()
		{
			return new OperatingSystem(this._platform, this._version);
		}

		// Token: 0x06000FD3 RID: 4051 RVA: 0x0004275C File Offset: 0x0004095C
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("_platform", this._platform);
			info.AddValue("_version", this._version);
			info.AddValue("_servicePack", this._servicePack);
		}

		// Token: 0x06000FD4 RID: 4052 RVA: 0x00042798 File Offset: 0x00040998
		public override string ToString()
		{
			int platform = (int)this._platform;
			string text;
			switch (platform)
			{
			case 0:
				text = "Microsoft Win32S";
				goto IL_0096;
			case 1:
				text = "Microsoft Windows 98";
				goto IL_0096;
			case 2:
				text = "Microsoft Windows NT";
				goto IL_0096;
			case 3:
				text = "Microsoft Windows CE";
				goto IL_0096;
			case 4:
				break;
			case 5:
				text = "XBox";
				goto IL_0096;
			case 6:
				text = "OSX";
				goto IL_0096;
			default:
				if (platform != 128)
				{
					text = Locale.GetText("<unknown>");
					goto IL_0096;
				}
				break;
			}
			text = "Unix";
			IL_0096:
			return text + " " + this._version.ToString();
		}

		// Token: 0x0400068C RID: 1676
		private PlatformID _platform;

		// Token: 0x0400068D RID: 1677
		private Version _version;

		// Token: 0x0400068E RID: 1678
		private string _servicePack = string.Empty;
	}
}
