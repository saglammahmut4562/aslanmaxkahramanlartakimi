﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200019C RID: 412
	[ComVisible(true)]
	[Serializable]
	public class OperationCanceledException : SystemException
	{
		// Token: 0x06000FD5 RID: 4053 RVA: 0x00042854 File Offset: 0x00040A54
		public OperationCanceledException()
			: base(Locale.GetText("The operation was canceled."))
		{
			base.HResult = -2146233029;
		}

		// Token: 0x06000FD6 RID: 4054 RVA: 0x00042874 File Offset: 0x00040A74
		protected OperationCanceledException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x0400068F RID: 1679
		private const int Result = -2146233029;
	}
}
