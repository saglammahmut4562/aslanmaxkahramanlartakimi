﻿using System;

namespace System
{
	// Token: 0x0200019D RID: 413
	[Serializable]
	internal sealed class OrdinalComparer : StringComparer
	{
		// Token: 0x06000FD7 RID: 4055 RVA: 0x00042880 File Offset: 0x00040A80
		public OrdinalComparer(bool ignoreCase)
		{
			this._ignoreCase = ignoreCase;
		}

		// Token: 0x06000FD8 RID: 4056 RVA: 0x00042890 File Offset: 0x00040A90
		public override int Compare(string x, string y)
		{
			if (this._ignoreCase)
			{
				return string.CompareOrdinalCaseInsensitiveUnchecked(x, 0, int.MaxValue, y, 0, int.MaxValue);
			}
			return string.CompareOrdinalUnchecked(x, 0, int.MaxValue, y, 0, int.MaxValue);
		}

		// Token: 0x06000FD9 RID: 4057 RVA: 0x000428C4 File Offset: 0x00040AC4
		public override bool Equals(string x, string y)
		{
			if (this._ignoreCase)
			{
				return this.Compare(x, y) == 0;
			}
			return x == y;
		}

		// Token: 0x06000FDA RID: 4058 RVA: 0x000428E4 File Offset: 0x00040AE4
		public override int GetHashCode(string s)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			if (this._ignoreCase)
			{
				return s.GetCaseInsensitiveHashCode();
			}
			return s.GetHashCode();
		}

		// Token: 0x04000690 RID: 1680
		private readonly bool _ignoreCase;
	}
}
