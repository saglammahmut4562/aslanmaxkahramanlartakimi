﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200019E RID: 414
	[ComVisible(true)]
	[Serializable]
	public class OutOfMemoryException : SystemException
	{
		// Token: 0x06000FDB RID: 4059 RVA: 0x00042910 File Offset: 0x00040B10
		public OutOfMemoryException()
			: base(Locale.GetText("Out of memory."))
		{
			base.HResult = -2147024882;
		}

		// Token: 0x06000FDC RID: 4060 RVA: 0x00042930 File Offset: 0x00040B30
		public OutOfMemoryException(string message)
			: base(message)
		{
			base.HResult = -2147024882;
		}

		// Token: 0x06000FDD RID: 4061 RVA: 0x00042944 File Offset: 0x00040B44
		public OutOfMemoryException(string message, Exception innerException)
			: base(message, innerException)
		{
			base.HResult = -2147024882;
		}

		// Token: 0x06000FDE RID: 4062 RVA: 0x0004295C File Offset: 0x00040B5C
		protected OutOfMemoryException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000691 RID: 1681
		private const int Result = -2147024882;
	}
}
