﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x0200019F RID: 415
	[ComVisible(true)]
	[Serializable]
	public class OverflowException : ArithmeticException
	{
		// Token: 0x06000FDF RID: 4063 RVA: 0x00042968 File Offset: 0x00040B68
		public OverflowException()
			: base(Locale.GetText("Number overflow."))
		{
			base.HResult = -2146233066;
		}

		// Token: 0x06000FE0 RID: 4064 RVA: 0x00042988 File Offset: 0x00040B88
		public OverflowException(string message)
			: base(message)
		{
			base.HResult = -2146233066;
		}

		// Token: 0x06000FE1 RID: 4065 RVA: 0x0004299C File Offset: 0x00040B9C
		protected OverflowException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x04000692 RID: 1682
		private const int Result = -2146233066;
	}
}
