﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x020001A0 RID: 416
	[AttributeUsage(AttributeTargets.Parameter)]
	[ComVisible(true)]
	public sealed class ParamArrayAttribute : Attribute
	{
	}
}
