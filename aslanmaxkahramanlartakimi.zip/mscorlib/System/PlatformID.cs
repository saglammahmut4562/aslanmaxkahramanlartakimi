﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x020001A1 RID: 417
	[ComVisible(true)]
	[Serializable]
	public enum PlatformID
	{
		// Token: 0x04000694 RID: 1684
		Win32S,
		// Token: 0x04000695 RID: 1685
		Win32Windows,
		// Token: 0x04000696 RID: 1686
		Win32NT,
		// Token: 0x04000697 RID: 1687
		WinCE,
		// Token: 0x04000698 RID: 1688
		Unix,
		// Token: 0x04000699 RID: 1689
		Xbox,
		// Token: 0x0400069A RID: 1690
		MacOSX
	}
}
