﻿using System;

namespace System
{
	// Token: 0x020001A2 RID: 418
	// (Invoke) Token: 0x06000FE4 RID: 4068
	public delegate bool Predicate<T>(T obj);
}
