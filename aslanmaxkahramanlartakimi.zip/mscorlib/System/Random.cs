﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x020001A3 RID: 419
	[ComVisible(true)]
	[Serializable]
	public class Random
	{
		// Token: 0x06000FE7 RID: 4071 RVA: 0x000429B0 File Offset: 0x00040BB0
		public Random()
			: this(Environment.TickCount)
		{
		}

		// Token: 0x06000FE8 RID: 4072 RVA: 0x000429C0 File Offset: 0x00040BC0
		public Random(int Seed)
		{
			int num = 161803398 - Math.Abs(Seed);
			this.SeedArray[55] = num;
			int num2 = 1;
			for (int i = 1; i < 55; i++)
			{
				int num3 = 21 * i % 55;
				this.SeedArray[num3] = num2;
				num2 = num - num2;
				if (num2 < 0)
				{
					num2 += int.MaxValue;
				}
				num = this.SeedArray[num3];
			}
			for (int j = 1; j < 5; j++)
			{
				for (int k = 1; k < 56; k++)
				{
					this.SeedArray[k] -= this.SeedArray[1 + (k + 30) % 55];
					if (this.SeedArray[k] < 0)
					{
						this.SeedArray[k] += int.MaxValue;
					}
				}
			}
			this.inext = 0;
			this.inextp = 31;
		}

		// Token: 0x06000FE9 RID: 4073 RVA: 0x00042ABC File Offset: 0x00040CBC
		protected virtual double Sample()
		{
			if (++this.inext >= 56)
			{
				this.inext = 1;
			}
			if (++this.inextp >= 56)
			{
				this.inextp = 1;
			}
			int num = this.SeedArray[this.inext] - this.SeedArray[this.inextp];
			if (num < 0)
			{
				num += int.MaxValue;
			}
			this.SeedArray[this.inext] = num;
			return (double)num * 4.656612875245797E-10;
		}

		// Token: 0x06000FEA RID: 4074 RVA: 0x00042B4C File Offset: 0x00040D4C
		public virtual int Next()
		{
			return (int)(this.Sample() * 2147483647.0);
		}

		// Token: 0x06000FEB RID: 4075 RVA: 0x00042B60 File Offset: 0x00040D60
		public virtual int Next(int maxValue)
		{
			if (maxValue < 0)
			{
				throw new ArgumentOutOfRangeException(Locale.GetText("Max value is less than min value."));
			}
			return (int)(this.Sample() * (double)maxValue);
		}

		// Token: 0x06000FEC RID: 4076 RVA: 0x00042B84 File Offset: 0x00040D84
		public virtual int Next(int minValue, int maxValue)
		{
			if (minValue > maxValue)
			{
				throw new ArgumentOutOfRangeException(Locale.GetText("Min value is greater than max value."));
			}
			uint num = (uint)(maxValue - minValue);
			if (num <= 1U)
			{
				return minValue;
			}
			return (int)((ulong)((uint)(this.Sample() * num)) + (ulong)((long)minValue));
		}

		// Token: 0x06000FED RID: 4077 RVA: 0x00042BC8 File Offset: 0x00040DC8
		public virtual double NextDouble()
		{
			return this.Sample();
		}

		// Token: 0x0400069B RID: 1691
		private const int MBIG = 2147483647;

		// Token: 0x0400069C RID: 1692
		private const int MSEED = 161803398;

		// Token: 0x0400069D RID: 1693
		private const int MZ = 0;

		// Token: 0x0400069E RID: 1694
		private int inext;

		// Token: 0x0400069F RID: 1695
		private int inextp;

		// Token: 0x040006A0 RID: 1696
		private int[] SeedArray = new int[56];
	}
}
