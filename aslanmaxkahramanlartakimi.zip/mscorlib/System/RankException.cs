﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System
{
	// Token: 0x020001A4 RID: 420
	[ComVisible(true)]
	[Serializable]
	public class RankException : SystemException
	{
		// Token: 0x06000FEE RID: 4078 RVA: 0x00042BD0 File Offset: 0x00040DD0
		public RankException()
			: base(Locale.GetText("Two arrays must have the same number of dimensions."))
		{
			base.HResult = -2146233065;
		}

		// Token: 0x06000FEF RID: 4079 RVA: 0x00042BF0 File Offset: 0x00040DF0
		public RankException(string message)
			: base(message)
		{
			base.HResult = -2146233065;
		}

		// Token: 0x06000FF0 RID: 4080 RVA: 0x00042C04 File Offset: 0x00040E04
		protected RankException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x040006A1 RID: 1697
		private const int Result = -2146233065;
	}
}
