﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x020001A5 RID: 421
	[ComVisible(true)]
	[Serializable]
	public sealed class AmbiguousMatchException : SystemException
	{
		// Token: 0x06000FF1 RID: 4081 RVA: 0x00042C10 File Offset: 0x00040E10
		public AmbiguousMatchException()
			: base("Ambiguous matching in method resolution")
		{
		}

		// Token: 0x06000FF2 RID: 4082 RVA: 0x00042C20 File Offset: 0x00040E20
		public AmbiguousMatchException(string message)
			: base(message)
		{
		}

		// Token: 0x06000FF3 RID: 4083 RVA: 0x00042C2C File Offset: 0x00040E2C
		internal AmbiguousMatchException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
