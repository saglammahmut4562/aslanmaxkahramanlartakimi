﻿using System;
using System.Collections;
using System.Configuration.Assemblies;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security;
using System.Security.Policy;

namespace System.Reflection
{
	// Token: 0x020001A6 RID: 422
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_Assembly))]
	[ComVisible(true)]
	[Serializable]
	public class Assembly : ICustomAttributeProvider, _Assembly
	{
		// Token: 0x06000FF4 RID: 4084 RVA: 0x00042C38 File Offset: 0x00040E38
		internal Assembly()
		{
			this.resolve_event_holder = new Assembly.ResolveEventHolder();
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06000FF5 RID: 4085 RVA: 0x00042C4C File Offset: 0x00040E4C
		// (remove) Token: 0x06000FF6 RID: 4086 RVA: 0x00042C5C File Offset: 0x00040E5C
		public event ModuleResolveEventHandler ModuleResolve
		{
			add
			{
				this.resolve_event_holder.ModuleResolve += value;
			}
			remove
			{
				this.resolve_event_holder.ModuleResolve -= value;
			}
		}

		// Token: 0x06000FF7 RID: 4087
		[MethodImpl(4096)]
		private extern string get_code_base(bool escaped);

		// Token: 0x06000FF8 RID: 4088
		[MethodImpl(4096)]
		private extern string get_fullname();

		// Token: 0x06000FF9 RID: 4089
		[MethodImpl(4096)]
		private extern string get_location();

		// Token: 0x06000FFA RID: 4090
		[MethodImpl(4096)]
		private extern string InternalImageRuntimeVersion();

		// Token: 0x06000FFB RID: 4091 RVA: 0x00042C6C File Offset: 0x00040E6C
		private string GetCodeBase(bool escaped)
		{
			return this.get_code_base(escaped);
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x06000FFC RID: 4092 RVA: 0x00042C84 File Offset: 0x00040E84
		public virtual string CodeBase
		{
			get
			{
				return this.GetCodeBase(false);
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x06000FFD RID: 4093 RVA: 0x00042C90 File Offset: 0x00040E90
		public virtual string EscapedCodeBase
		{
			get
			{
				return this.GetCodeBase(true);
			}
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000FFE RID: 4094 RVA: 0x00042C9C File Offset: 0x00040E9C
		public virtual string FullName
		{
			get
			{
				return this.ToString();
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06000FFF RID: 4095
		public virtual extern MethodInfo EntryPoint
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06001000 RID: 4096 RVA: 0x00042CA4 File Offset: 0x00040EA4
		public virtual Evidence Evidence
		{
			get
			{
				return this.UnprotectedGetEvidence();
			}
		}

		// Token: 0x06001001 RID: 4097 RVA: 0x00042CAC File Offset: 0x00040EAC
		internal Evidence UnprotectedGetEvidence()
		{
			if (this._evidence == null)
			{
				lock (this)
				{
					this._evidence = Evidence.GetDefaultHostEvidence(this);
				}
			}
			return this._evidence;
		}

		// Token: 0x06001002 RID: 4098
		[MethodImpl(4096)]
		private extern bool get_global_assembly_cache();

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06001003 RID: 4099 RVA: 0x00042CFC File Offset: 0x00040EFC
		public bool GlobalAssemblyCache
		{
			get
			{
				return this.get_global_assembly_cache();
			}
		}

		// Token: 0x1700025B RID: 603
		// (set) Token: 0x06001004 RID: 4100 RVA: 0x00042D04 File Offset: 0x00040F04
		internal bool FromByteArray
		{
			set
			{
				this.fromByteArray = value;
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x06001005 RID: 4101 RVA: 0x00042D10 File Offset: 0x00040F10
		public virtual string Location
		{
			get
			{
				if (this.fromByteArray)
				{
					return string.Empty;
				}
				return this.get_location();
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x06001006 RID: 4102 RVA: 0x00042D38 File Offset: 0x00040F38
		[ComVisible(false)]
		public virtual string ImageRuntimeVersion
		{
			get
			{
				return this.InternalImageRuntimeVersion();
			}
		}

		// Token: 0x06001007 RID: 4103 RVA: 0x00042D40 File Offset: 0x00040F40
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			UnitySerializationHolder.GetAssemblyData(this, info, context);
		}

		// Token: 0x06001008 RID: 4104 RVA: 0x00042D5C File Offset: 0x00040F5C
		public virtual bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x06001009 RID: 4105 RVA: 0x00042D68 File Offset: 0x00040F68
		public virtual object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x0600100A RID: 4106 RVA: 0x00042D74 File Offset: 0x00040F74
		public virtual object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x0600100B RID: 4107
		[MethodImpl(4096)]
		private extern object GetFilesInternal(string name, bool getResourceModules);

		// Token: 0x0600100C RID: 4108 RVA: 0x00042D80 File Offset: 0x00040F80
		public virtual FileStream[] GetFiles()
		{
			return this.GetFiles(false);
		}

		// Token: 0x0600100D RID: 4109 RVA: 0x00042D8C File Offset: 0x00040F8C
		public virtual FileStream[] GetFiles(bool getResourceModules)
		{
			string[] array = (string[])this.GetFilesInternal(null, getResourceModules);
			if (array == null)
			{
				return new FileStream[0];
			}
			string location = this.Location;
			FileStream[] array2;
			if (location != string.Empty)
			{
				array2 = new FileStream[array.Length + 1];
				array2[0] = new FileStream(location, FileMode.Open, FileAccess.Read);
				for (int i = 0; i < array.Length; i++)
				{
					array2[i + 1] = new FileStream(array[i], FileMode.Open, FileAccess.Read);
				}
			}
			else
			{
				array2 = new FileStream[array.Length];
				for (int j = 0; j < array.Length; j++)
				{
					array2[j] = new FileStream(array[j], FileMode.Open, FileAccess.Read);
				}
			}
			return array2;
		}

		// Token: 0x0600100E RID: 4110 RVA: 0x00042E3C File Offset: 0x0004103C
		public virtual FileStream GetFile(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException(null, "Name cannot be null.");
			}
			if (name.Length == 0)
			{
				throw new ArgumentException("Empty name is not valid");
			}
			string text = (string)this.GetFilesInternal(name, true);
			if (text != null)
			{
				return new FileStream(text, FileMode.Open, FileAccess.Read);
			}
			return null;
		}

		// Token: 0x0600100F RID: 4111
		[MethodImpl(4096)]
		internal extern IntPtr GetManifestResourceInternal(string name, out int size, out Module module);

		// Token: 0x06001010 RID: 4112 RVA: 0x00042E90 File Offset: 0x00041090
		public unsafe virtual Stream GetManifestResourceStream(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			if (name.Length == 0)
			{
				throw new ArgumentException("String cannot have zero length.", "name");
			}
			ManifestResourceInfo manifestResourceInfo = this.GetManifestResourceInfo(name);
			if (manifestResourceInfo == null)
			{
				return null;
			}
			if (manifestResourceInfo.ReferencedAssembly != null)
			{
				return manifestResourceInfo.ReferencedAssembly.GetManifestResourceStream(name);
			}
			if (manifestResourceInfo.FileName != null && manifestResourceInfo.ResourceLocation == (ResourceLocation)0)
			{
				if (this.fromByteArray)
				{
					throw new FileNotFoundException(manifestResourceInfo.FileName);
				}
				string directoryName = Path.GetDirectoryName(this.Location);
				string text = Path.Combine(directoryName, manifestResourceInfo.FileName);
				return new FileStream(text, FileMode.Open, FileAccess.Read);
			}
			else
			{
				int num;
				Module module;
				IntPtr manifestResourceInternal = this.GetManifestResourceInternal(name, out num, out module);
				if (manifestResourceInternal == (IntPtr)0)
				{
					return null;
				}
				UnmanagedMemoryStream unmanagedMemoryStream = new UnmanagedMemoryStream((byte*)(void*)manifestResourceInternal, (long)num);
				unmanagedMemoryStream.Closed += new Assembly.ResourceCloseHandler(module).OnClose;
				return unmanagedMemoryStream;
			}
		}

		// Token: 0x06001011 RID: 4113 RVA: 0x00042F8C File Offset: 0x0004118C
		public virtual Stream GetManifestResourceStream(Type type, string name)
		{
			string text;
			if (type != null)
			{
				text = type.Namespace;
			}
			else
			{
				if (name == null)
				{
					throw new ArgumentNullException("type");
				}
				text = null;
			}
			if (text == null || text.Length == 0)
			{
				return this.GetManifestResourceStream(name);
			}
			return this.GetManifestResourceStream(text + "." + name);
		}

		// Token: 0x06001012 RID: 4114
		[MethodImpl(4096)]
		internal virtual extern Type[] GetTypes(bool exportedOnly);

		// Token: 0x06001013 RID: 4115 RVA: 0x00042FEC File Offset: 0x000411EC
		public virtual Type[] GetTypes()
		{
			return this.GetTypes(false);
		}

		// Token: 0x06001014 RID: 4116 RVA: 0x00042FF8 File Offset: 0x000411F8
		public virtual Type[] GetExportedTypes()
		{
			return this.GetTypes(true);
		}

		// Token: 0x06001015 RID: 4117 RVA: 0x00043004 File Offset: 0x00041204
		public virtual Type GetType(string name, bool throwOnError)
		{
			return this.GetType(name, throwOnError, false);
		}

		// Token: 0x06001016 RID: 4118 RVA: 0x00043010 File Offset: 0x00041210
		public virtual Type GetType(string name)
		{
			return this.GetType(name, false, false);
		}

		// Token: 0x06001017 RID: 4119
		[MethodImpl(4096)]
		internal extern Type InternalGetType(Module module, string name, bool throwOnError, bool ignoreCase);

		// Token: 0x06001018 RID: 4120 RVA: 0x0004301C File Offset: 0x0004121C
		public Type GetType(string name, bool throwOnError, bool ignoreCase)
		{
			if (name == null)
			{
				throw new ArgumentNullException(name);
			}
			if (name.Length == 0)
			{
				throw new ArgumentException("name", "Name cannot be empty");
			}
			return this.InternalGetType(null, name, throwOnError, ignoreCase);
		}

		// Token: 0x06001019 RID: 4121
		[MethodImpl(4096)]
		internal static extern void InternalGetAssemblyName(string assemblyFile, AssemblyName aname);

		// Token: 0x0600101A RID: 4122
		[MethodImpl(4096)]
		private static extern void FillName(Assembly ass, AssemblyName aname);

		// Token: 0x0600101B RID: 4123 RVA: 0x00043050 File Offset: 0x00041250
		[MonoTODO("copiedName == true is not supported")]
		public virtual AssemblyName GetName(bool copiedName)
		{
			if (SecurityManager.SecurityEnabled)
			{
				this.GetCodeBase(true);
			}
			return this.UnprotectedGetName();
		}

		// Token: 0x0600101C RID: 4124 RVA: 0x0004306C File Offset: 0x0004126C
		public virtual AssemblyName GetName()
		{
			return this.GetName(false);
		}

		// Token: 0x0600101D RID: 4125 RVA: 0x00043078 File Offset: 0x00041278
		internal virtual AssemblyName UnprotectedGetName()
		{
			AssemblyName assemblyName = new AssemblyName();
			Assembly.FillName(this, assemblyName);
			return assemblyName;
		}

		// Token: 0x0600101E RID: 4126 RVA: 0x00043094 File Offset: 0x00041294
		public override string ToString()
		{
			if (this.assemblyName != null)
			{
				return this.assemblyName;
			}
			this.assemblyName = this.get_fullname();
			return this.assemblyName;
		}

		// Token: 0x0600101F RID: 4127 RVA: 0x000430BC File Offset: 0x000412BC
		public static string CreateQualifiedName(string assemblyName, string typeName)
		{
			return typeName + ", " + assemblyName;
		}

		// Token: 0x06001020 RID: 4128 RVA: 0x000430CC File Offset: 0x000412CC
		public static Assembly GetAssembly(Type type)
		{
			if (type != null)
			{
				return type.Assembly;
			}
			throw new ArgumentNullException("type");
		}

		// Token: 0x06001021 RID: 4129
		[MethodImpl(4096)]
		public static extern Assembly GetEntryAssembly();

		// Token: 0x06001022 RID: 4130 RVA: 0x000430E8 File Offset: 0x000412E8
		public Assembly GetSatelliteAssembly(CultureInfo culture)
		{
			return this.GetSatelliteAssembly(culture, null, true);
		}

		// Token: 0x06001023 RID: 4131 RVA: 0x000430F4 File Offset: 0x000412F4
		public Assembly GetSatelliteAssembly(CultureInfo culture, Version version)
		{
			return this.GetSatelliteAssembly(culture, version, true);
		}

		// Token: 0x06001024 RID: 4132 RVA: 0x00043100 File Offset: 0x00041300
		internal Assembly GetSatelliteAssemblyNoThrow(CultureInfo culture, Version version)
		{
			return this.GetSatelliteAssembly(culture, version, false);
		}

		// Token: 0x06001025 RID: 4133 RVA: 0x0004310C File Offset: 0x0004130C
		private Assembly GetSatelliteAssembly(CultureInfo culture, Version version, bool throwOnError)
		{
			if (culture == null)
			{
				throw new ArgumentException("culture");
			}
			AssemblyName name = this.GetName(true);
			if (version != null)
			{
				name.Version = version;
			}
			name.CultureInfo = culture;
			name.Name += ".resources";
			try
			{
				Assembly assembly = AppDomain.CurrentDomain.LoadSatellite(name, false);
				if (assembly != null)
				{
					return assembly;
				}
			}
			catch (FileNotFoundException)
			{
			}
			string directoryName = Path.GetDirectoryName(this.Location);
			string text = Path.Combine(directoryName, Path.Combine(culture.Name, name.Name + ".dll"));
			if (!throwOnError && !File.Exists(text))
			{
				return null;
			}
			return Assembly.LoadFrom(text);
		}

		// Token: 0x06001026 RID: 4134
		[MethodImpl(4096)]
		private static extern Assembly LoadFrom(string assemblyFile, bool refonly);

		// Token: 0x06001027 RID: 4135 RVA: 0x000431E4 File Offset: 0x000413E4
		public static Assembly LoadFrom(string assemblyFile)
		{
			return Assembly.LoadFrom(assemblyFile, false);
		}

		// Token: 0x06001028 RID: 4136 RVA: 0x000431F0 File Offset: 0x000413F0
		public static Assembly LoadFrom(string assemblyFile, Evidence securityEvidence)
		{
			return Assembly.LoadFrom(assemblyFile, false);
		}

		// Token: 0x06001029 RID: 4137 RVA: 0x00043208 File Offset: 0x00041408
		[MonoTODO("This overload is not currently implemented")]
		public static Assembly LoadFrom(string assemblyFile, Evidence securityEvidence, byte[] hashValue, AssemblyHashAlgorithm hashAlgorithm)
		{
			if (assemblyFile == null)
			{
				throw new ArgumentNullException("assemblyFile");
			}
			if (assemblyFile == string.Empty)
			{
				throw new ArgumentException("Name can't be the empty string", "assemblyFile");
			}
			throw new NotImplementedException();
		}

		// Token: 0x0600102A RID: 4138 RVA: 0x00043240 File Offset: 0x00041440
		public static Assembly LoadFile(string path, Evidence securityEvidence)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (path == string.Empty)
			{
				throw new ArgumentException("Path can't be empty", "path");
			}
			return Assembly.LoadFrom(path, securityEvidence);
		}

		// Token: 0x0600102B RID: 4139 RVA: 0x0004327C File Offset: 0x0004147C
		public static Assembly LoadFile(string path)
		{
			return Assembly.LoadFile(path, null);
		}

		// Token: 0x0600102C RID: 4140 RVA: 0x00043288 File Offset: 0x00041488
		public static Assembly Load(string assemblyString)
		{
			return AppDomain.CurrentDomain.Load(assemblyString);
		}

		// Token: 0x0600102D RID: 4141 RVA: 0x00043298 File Offset: 0x00041498
		public static Assembly Load(string assemblyString, Evidence assemblySecurity)
		{
			return AppDomain.CurrentDomain.Load(assemblyString, assemblySecurity);
		}

		// Token: 0x0600102E RID: 4142 RVA: 0x000432A8 File Offset: 0x000414A8
		public static Assembly Load(AssemblyName assemblyRef)
		{
			return AppDomain.CurrentDomain.Load(assemblyRef);
		}

		// Token: 0x0600102F RID: 4143 RVA: 0x000432B8 File Offset: 0x000414B8
		public static Assembly Load(AssemblyName assemblyRef, Evidence assemblySecurity)
		{
			return AppDomain.CurrentDomain.Load(assemblyRef, assemblySecurity);
		}

		// Token: 0x06001030 RID: 4144 RVA: 0x000432C8 File Offset: 0x000414C8
		public static Assembly Load(byte[] rawAssembly)
		{
			return AppDomain.CurrentDomain.Load(rawAssembly);
		}

		// Token: 0x06001031 RID: 4145 RVA: 0x000432D8 File Offset: 0x000414D8
		public static Assembly Load(byte[] rawAssembly, byte[] rawSymbolStore)
		{
			return AppDomain.CurrentDomain.Load(rawAssembly, rawSymbolStore);
		}

		// Token: 0x06001032 RID: 4146 RVA: 0x000432E8 File Offset: 0x000414E8
		public static Assembly Load(byte[] rawAssembly, byte[] rawSymbolStore, Evidence securityEvidence)
		{
			return AppDomain.CurrentDomain.Load(rawAssembly, rawSymbolStore, securityEvidence);
		}

		// Token: 0x06001033 RID: 4147 RVA: 0x000432F8 File Offset: 0x000414F8
		public static Assembly ReflectionOnlyLoad(byte[] rawAssembly)
		{
			return AppDomain.CurrentDomain.Load(rawAssembly, null, null, true);
		}

		// Token: 0x06001034 RID: 4148 RVA: 0x00043308 File Offset: 0x00041508
		public static Assembly ReflectionOnlyLoad(string assemblyString)
		{
			return AppDomain.CurrentDomain.Load(assemblyString, null, true);
		}

		// Token: 0x06001035 RID: 4149 RVA: 0x00043318 File Offset: 0x00041518
		public static Assembly ReflectionOnlyLoadFrom(string assemblyFile)
		{
			if (assemblyFile == null)
			{
				throw new ArgumentNullException("assemblyFile");
			}
			return Assembly.LoadFrom(assemblyFile, true);
		}

		// Token: 0x06001036 RID: 4150 RVA: 0x00043334 File Offset: 0x00041534
		[Obsolete("")]
		public static Assembly LoadWithPartialName(string partialName)
		{
			return Assembly.LoadWithPartialName(partialName, null);
		}

		// Token: 0x06001037 RID: 4151 RVA: 0x00043340 File Offset: 0x00041540
		[MonoTODO("Not implemented")]
		public Module LoadModule(string moduleName, byte[] rawModule)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06001038 RID: 4152 RVA: 0x00043348 File Offset: 0x00041548
		[MonoTODO("Not implemented")]
		public Module LoadModule(string moduleName, byte[] rawModule, byte[] rawSymbolStore)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06001039 RID: 4153
		[MethodImpl(4096)]
		private static extern Assembly load_with_partial_name(string name, Evidence e);

		// Token: 0x0600103A RID: 4154 RVA: 0x00043350 File Offset: 0x00041550
		[Obsolete("")]
		public static Assembly LoadWithPartialName(string partialName, Evidence securityEvidence)
		{
			return Assembly.LoadWithPartialName(partialName, securityEvidence, true);
		}

		// Token: 0x0600103B RID: 4155 RVA: 0x0004335C File Offset: 0x0004155C
		internal static Assembly LoadWithPartialName(string partialName, Evidence securityEvidence, bool oldBehavior)
		{
			if (!oldBehavior)
			{
				throw new NotImplementedException();
			}
			if (partialName == null)
			{
				throw new NullReferenceException();
			}
			return Assembly.load_with_partial_name(partialName, securityEvidence);
		}

		// Token: 0x0600103C RID: 4156 RVA: 0x00043380 File Offset: 0x00041580
		public object CreateInstance(string typeName)
		{
			return this.CreateInstance(typeName, false);
		}

		// Token: 0x0600103D RID: 4157 RVA: 0x0004338C File Offset: 0x0004158C
		public object CreateInstance(string typeName, bool ignoreCase)
		{
			Type type = this.GetType(typeName, false, ignoreCase);
			if (type == null)
			{
				return null;
			}
			object obj;
			try
			{
				obj = Activator.CreateInstance(type);
			}
			catch (InvalidOperationException)
			{
				throw new ArgumentException("It is illegal to invoke a method on a Type loaded via ReflectionOnly methods.");
			}
			return obj;
		}

		// Token: 0x0600103E RID: 4158 RVA: 0x000433E0 File Offset: 0x000415E0
		public object CreateInstance(string typeName, bool ignoreCase, BindingFlags bindingAttr, Binder binder, object[] args, CultureInfo culture, object[] activationAttributes)
		{
			Type type = this.GetType(typeName, false, ignoreCase);
			if (type == null)
			{
				return null;
			}
			object obj;
			try
			{
				obj = Activator.CreateInstance(type, bindingAttr, binder, args, culture, activationAttributes);
			}
			catch (InvalidOperationException)
			{
				throw new ArgumentException("It is illegal to invoke a method on a Type loaded via ReflectionOnly methods.");
			}
			return obj;
		}

		// Token: 0x0600103F RID: 4159 RVA: 0x0004343C File Offset: 0x0004163C
		public Module[] GetLoadedModules()
		{
			return this.GetLoadedModules(false);
		}

		// Token: 0x06001040 RID: 4160 RVA: 0x00043448 File Offset: 0x00041648
		public Module[] GetLoadedModules(bool getResourceModules)
		{
			return this.GetModules(getResourceModules);
		}

		// Token: 0x06001041 RID: 4161 RVA: 0x00043454 File Offset: 0x00041654
		public Module[] GetModules()
		{
			return this.GetModules(false);
		}

		// Token: 0x06001042 RID: 4162 RVA: 0x00043460 File Offset: 0x00041660
		public Module GetModule(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			if (name.Length == 0)
			{
				throw new ArgumentException("Name can't be empty");
			}
			Module[] modules = this.GetModules(true);
			foreach (Module module in modules)
			{
				if (module.ScopeName == name)
				{
					return module;
				}
			}
			return null;
		}

		// Token: 0x06001043 RID: 4163
		[MethodImpl(4096)]
		internal virtual extern Module[] GetModulesInternal();

		// Token: 0x06001044 RID: 4164 RVA: 0x000434CC File Offset: 0x000416CC
		public Module[] GetModules(bool getResourceModules)
		{
			Module[] modulesInternal = this.GetModulesInternal();
			if (!getResourceModules)
			{
				ArrayList arrayList = new ArrayList(modulesInternal.Length);
				foreach (Module module in modulesInternal)
				{
					if (!module.IsResource())
					{
						arrayList.Add(module);
					}
				}
				return (Module[])arrayList.ToArray(typeof(Module));
			}
			return modulesInternal;
		}

		// Token: 0x06001045 RID: 4165
		[MethodImpl(4096)]
		internal extern string[] GetNamespaces();

		// Token: 0x06001046 RID: 4166
		[MethodImpl(4096)]
		public virtual extern string[] GetManifestResourceNames();

		// Token: 0x06001047 RID: 4167
		[MethodImpl(4096)]
		public static extern Assembly GetExecutingAssembly();

		// Token: 0x06001048 RID: 4168
		[MethodImpl(4096)]
		public static extern Assembly GetCallingAssembly();

		// Token: 0x06001049 RID: 4169
		[MethodImpl(4096)]
		public extern AssemblyName[] GetReferencedAssemblies();

		// Token: 0x0600104A RID: 4170
		[MethodImpl(4096)]
		private extern bool GetManifestResourceInfoInternal(string name, ManifestResourceInfo info);

		// Token: 0x0600104B RID: 4171 RVA: 0x00043538 File Offset: 0x00041738
		public virtual ManifestResourceInfo GetManifestResourceInfo(string resourceName)
		{
			if (resourceName == null)
			{
				throw new ArgumentNullException("resourceName");
			}
			if (resourceName.Length == 0)
			{
				throw new ArgumentException("String cannot have zero length.");
			}
			ManifestResourceInfo manifestResourceInfo = new ManifestResourceInfo();
			bool manifestResourceInfoInternal = this.GetManifestResourceInfoInternal(resourceName, manifestResourceInfo);
			if (manifestResourceInfoInternal)
			{
				return manifestResourceInfo;
			}
			return null;
		}

		// Token: 0x0600104C RID: 4172
		[MethodImpl(4096)]
		internal static extern int MonoDebugger_GetMethodToken(MethodBase method);

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x0600104D RID: 4173 RVA: 0x00043584 File Offset: 0x00041784
		[MonoTODO("Always returns zero")]
		[ComVisible(false)]
		public long HostContext
		{
			get
			{
				return 0L;
			}
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x0600104E RID: 4174 RVA: 0x00043588 File Offset: 0x00041788
		[ComVisible(false)]
		public Module ManifestModule
		{
			get
			{
				return this.GetManifestModule();
			}
		}

		// Token: 0x0600104F RID: 4175 RVA: 0x00043590 File Offset: 0x00041790
		internal virtual Module GetManifestModule()
		{
			return this.GetManifestModuleInternal();
		}

		// Token: 0x06001050 RID: 4176
		[MethodImpl(4096)]
		internal extern Module GetManifestModuleInternal();

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x06001051 RID: 4177
		[ComVisible(false)]
		public virtual extern bool ReflectionOnly
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x06001052 RID: 4178 RVA: 0x00043598 File Offset: 0x00041798
		internal void Resolve()
		{
			lock (this)
			{
				this.LoadAssemblyPermissions();
				Evidence evidence = new Evidence(this.UnprotectedGetEvidence());
				evidence.AddHost(new PermissionRequestEvidence(this._minimum, this._optional, this._refuse));
				this._granted = SecurityManager.ResolvePolicy(evidence, this._minimum, this._optional, this._refuse, out this._denied);
			}
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x06001053 RID: 4179 RVA: 0x0004361C File Offset: 0x0004181C
		internal PermissionSet GrantedPermissionSet
		{
			get
			{
				if (this._granted == null)
				{
					if (SecurityManager.ResolvingPolicyLevel != null)
					{
						if (SecurityManager.ResolvingPolicyLevel.IsFullTrustAssembly(this))
						{
							return DefaultPolicies.FullTrust;
						}
						return null;
					}
					else
					{
						this.Resolve();
					}
				}
				return this._granted;
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x06001054 RID: 4180 RVA: 0x00043658 File Offset: 0x00041858
		internal PermissionSet DeniedPermissionSet
		{
			get
			{
				if (this._granted == null)
				{
					if (SecurityManager.ResolvingPolicyLevel != null)
					{
						if (SecurityManager.ResolvingPolicyLevel.IsFullTrustAssembly(this))
						{
							return null;
						}
						return DefaultPolicies.FullTrust;
					}
					else
					{
						this.Resolve();
					}
				}
				return this._denied;
			}
		}

		// Token: 0x06001055 RID: 4181
		[MethodImpl(4096)]
		internal static extern bool LoadPermissions(Assembly a, ref IntPtr minimum, ref int minLength, ref IntPtr optional, ref int optLength, ref IntPtr refused, ref int refLength);

		// Token: 0x06001056 RID: 4182 RVA: 0x00043694 File Offset: 0x00041894
		private void LoadAssemblyPermissions()
		{
			IntPtr zero = IntPtr.Zero;
			IntPtr zero2 = IntPtr.Zero;
			IntPtr zero3 = IntPtr.Zero;
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			if (Assembly.LoadPermissions(this, ref zero, ref num, ref zero2, ref num2, ref zero3, ref num3))
			{
				if (num > 0)
				{
					byte[] array = new byte[num];
					Marshal.Copy(zero, array, 0, num);
					this._minimum = SecurityManager.Decode(array);
				}
				if (num2 > 0)
				{
					byte[] array2 = new byte[num2];
					Marshal.Copy(zero2, array2, 0, num2);
					this._optional = SecurityManager.Decode(array2);
				}
				if (num3 > 0)
				{
					byte[] array3 = new byte[num3];
					Marshal.Copy(zero3, array3, 0, num3);
					this._refuse = SecurityManager.Decode(array3);
				}
			}
		}

		// Token: 0x06001057 RID: 4183 RVA: 0x0004374C File Offset: 0x0004194C
		virtual Type System.Runtime.InteropServices._Assembly.GetType()
		{
			return base.GetType();
		}

		// Token: 0x040006A2 RID: 1698
		private IntPtr _mono_assembly;

		// Token: 0x040006A3 RID: 1699
		private Assembly.ResolveEventHolder resolve_event_holder;

		// Token: 0x040006A4 RID: 1700
		private Evidence _evidence;

		// Token: 0x040006A5 RID: 1701
		internal PermissionSet _minimum;

		// Token: 0x040006A6 RID: 1702
		internal PermissionSet _optional;

		// Token: 0x040006A7 RID: 1703
		internal PermissionSet _refuse;

		// Token: 0x040006A8 RID: 1704
		private PermissionSet _granted;

		// Token: 0x040006A9 RID: 1705
		private PermissionSet _denied;

		// Token: 0x040006AA RID: 1706
		private bool fromByteArray;

		// Token: 0x040006AB RID: 1707
		private string assemblyName;

		// Token: 0x020001A7 RID: 423
		internal class ResolveEventHolder
		{
			// Token: 0x1400000D RID: 13
			// (add) Token: 0x06001059 RID: 4185 RVA: 0x0004375C File Offset: 0x0004195C
			// (remove) Token: 0x0600105A RID: 4186 RVA: 0x00043778 File Offset: 0x00041978
			public event ModuleResolveEventHandler ModuleResolve;
		}

		// Token: 0x020001A8 RID: 424
		private class ResourceCloseHandler
		{
			// Token: 0x0600105B RID: 4187 RVA: 0x00043794 File Offset: 0x00041994
			public ResourceCloseHandler(Module module)
			{
				this.module = module;
			}

			// Token: 0x0600105C RID: 4188 RVA: 0x000437A4 File Offset: 0x000419A4
			public void OnClose(object sender, EventArgs e)
			{
				this.module = null;
			}

			// Token: 0x040006AD RID: 1709
			private Module module;
		}
	}
}
