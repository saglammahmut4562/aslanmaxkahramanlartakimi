﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001A9 RID: 425
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyCompanyAttribute : Attribute
	{
		// Token: 0x0600105D RID: 4189 RVA: 0x000437B0 File Offset: 0x000419B0
		public AssemblyCompanyAttribute(string company)
		{
			this.name = company;
		}

		// Token: 0x040006AE RID: 1710
		private string name;
	}
}
