﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001AA RID: 426
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyConfigurationAttribute : Attribute
	{
		// Token: 0x0600105E RID: 4190 RVA: 0x000437C0 File Offset: 0x000419C0
		public AssemblyConfigurationAttribute(string configuration)
		{
			this.name = configuration;
		}

		// Token: 0x040006AF RID: 1711
		private string name;
	}
}
