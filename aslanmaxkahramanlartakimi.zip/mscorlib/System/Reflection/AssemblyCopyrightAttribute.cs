﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001AB RID: 427
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyCopyrightAttribute : Attribute
	{
		// Token: 0x0600105F RID: 4191 RVA: 0x000437D0 File Offset: 0x000419D0
		public AssemblyCopyrightAttribute(string copyright)
		{
			this.name = copyright;
		}

		// Token: 0x040006B0 RID: 1712
		private string name;
	}
}
