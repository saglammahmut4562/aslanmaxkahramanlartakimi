﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001AC RID: 428
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyCultureAttribute : Attribute
	{
		// Token: 0x06001060 RID: 4192 RVA: 0x000437E0 File Offset: 0x000419E0
		public AssemblyCultureAttribute(string culture)
		{
			this.name = culture;
		}

		// Token: 0x040006B1 RID: 1713
		private string name;
	}
}
