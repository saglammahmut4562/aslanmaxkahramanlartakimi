﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001AE RID: 430
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyDelaySignAttribute : Attribute
	{
		// Token: 0x06001062 RID: 4194 RVA: 0x00043800 File Offset: 0x00041A00
		public AssemblyDelaySignAttribute(bool delaySign)
		{
			this.delay = delaySign;
		}

		// Token: 0x040006B3 RID: 1715
		private bool delay;
	}
}
