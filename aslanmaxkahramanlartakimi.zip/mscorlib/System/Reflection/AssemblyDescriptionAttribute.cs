﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001AF RID: 431
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyDescriptionAttribute : Attribute
	{
		// Token: 0x06001063 RID: 4195 RVA: 0x00043810 File Offset: 0x00041A10
		public AssemblyDescriptionAttribute(string description)
		{
			this.name = description;
		}

		// Token: 0x040006B4 RID: 1716
		private string name;
	}
}
