﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B0 RID: 432
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyFileVersionAttribute : Attribute
	{
		// Token: 0x06001064 RID: 4196 RVA: 0x00043820 File Offset: 0x00041A20
		public AssemblyFileVersionAttribute(string version)
		{
			if (version == null)
			{
				throw new ArgumentNullException("version");
			}
			this.name = version;
		}

		// Token: 0x040006B5 RID: 1717
		private string name;
	}
}
