﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B1 RID: 433
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyInformationalVersionAttribute : Attribute
	{
		// Token: 0x06001065 RID: 4197 RVA: 0x00043840 File Offset: 0x00041A40
		public AssemblyInformationalVersionAttribute(string informationalVersion)
		{
			this.name = informationalVersion;
		}

		// Token: 0x040006B6 RID: 1718
		private string name;
	}
}
