﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B2 RID: 434
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyKeyFileAttribute : Attribute
	{
		// Token: 0x06001066 RID: 4198 RVA: 0x00043850 File Offset: 0x00041A50
		public AssemblyKeyFileAttribute(string keyFile)
		{
			this.name = keyFile;
		}

		// Token: 0x040006B7 RID: 1719
		private string name;
	}
}
