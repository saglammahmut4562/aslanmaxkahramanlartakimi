﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B3 RID: 435
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	public sealed class AssemblyKeyNameAttribute : Attribute
	{
		// Token: 0x06001067 RID: 4199 RVA: 0x00043860 File Offset: 0x00041A60
		public AssemblyKeyNameAttribute(string keyName)
		{
			this.name = keyName;
		}

		// Token: 0x040006B8 RID: 1720
		private string name;
	}
}
