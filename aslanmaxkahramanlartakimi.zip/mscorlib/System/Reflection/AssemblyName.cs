﻿using System;
using System.Configuration.Assemblies;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using Mono.Security.Cryptography;

namespace System.Reflection
{
	// Token: 0x020001B4 RID: 436
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_AssemblyName))]
	[Serializable]
	public sealed class AssemblyName : ICloneable, _AssemblyName, IDeserializationCallback, ISerializable
	{
		// Token: 0x06001068 RID: 4200 RVA: 0x00043870 File Offset: 0x00041A70
		public AssemblyName()
		{
			this.versioncompat = AssemblyVersionCompatibility.SameMachine;
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x00043880 File Offset: 0x00041A80
		public AssemblyName(string assemblyName)
		{
			if (assemblyName == null)
			{
				throw new ArgumentNullException("assemblyName");
			}
			if (assemblyName.Length < 1)
			{
				throw new ArgumentException("assemblyName cannot have zero length.");
			}
			if (!AssemblyName.ParseName(this, assemblyName))
			{
				throw new FileLoadException("The assembly name is invalid.");
			}
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x000438D4 File Offset: 0x00041AD4
		internal AssemblyName(SerializationInfo si, StreamingContext sc)
		{
			this.name = si.GetString("_Name");
			this.codebase = si.GetString("_CodeBase");
			this.version = (Version)si.GetValue("_Version", typeof(Version));
			this.publicKey = (byte[])si.GetValue("_PublicKey", typeof(byte[]));
			this.keyToken = (byte[])si.GetValue("_PublicKeyToken", typeof(byte[]));
			this.hashalg = (AssemblyHashAlgorithm)((int)si.GetValue("_HashAlgorithm", typeof(AssemblyHashAlgorithm)));
			this.keypair = (StrongNameKeyPair)si.GetValue("_StrongNameKeyPair", typeof(StrongNameKeyPair));
			this.versioncompat = (AssemblyVersionCompatibility)((int)si.GetValue("_VersionCompatibility", typeof(AssemblyVersionCompatibility)));
			this.flags = (AssemblyNameFlags)((int)si.GetValue("_Flags", typeof(AssemblyNameFlags)));
			int @int = si.GetInt32("_CultureInfo");
			if (@int != -1)
			{
				this.cultureinfo = new CultureInfo(@int);
			}
		}

		// Token: 0x0600106B RID: 4203
		[MethodImpl(4096)]
		private static extern bool ParseName(AssemblyName aname, string assemblyName);

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x0600106C RID: 4204 RVA: 0x00043A08 File Offset: 0x00041C08
		// (set) Token: 0x0600106D RID: 4205 RVA: 0x00043A10 File Offset: 0x00041C10
		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = value;
			}
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x0600106E RID: 4206 RVA: 0x00043A1C File Offset: 0x00041C1C
		public string CodeBase
		{
			get
			{
				return this.codebase;
			}
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x0600106F RID: 4207 RVA: 0x00043A24 File Offset: 0x00041C24
		// (set) Token: 0x06001070 RID: 4208 RVA: 0x00043A2C File Offset: 0x00041C2C
		public CultureInfo CultureInfo
		{
			get
			{
				return this.cultureinfo;
			}
			set
			{
				this.cultureinfo = value;
			}
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x06001071 RID: 4209 RVA: 0x00043A38 File Offset: 0x00041C38
		public AssemblyNameFlags Flags
		{
			get
			{
				return this.flags;
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x06001072 RID: 4210 RVA: 0x00043A40 File Offset: 0x00041C40
		public string FullName
		{
			get
			{
				if (this.name == null)
				{
					return string.Empty;
				}
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(this.name);
				if (this.Version != null)
				{
					stringBuilder.Append(", Version=");
					stringBuilder.Append(this.Version.ToString());
				}
				if (this.cultureinfo != null)
				{
					stringBuilder.Append(", Culture=");
					if (this.cultureinfo.LCID == CultureInfo.InvariantCulture.LCID)
					{
						stringBuilder.Append("neutral");
					}
					else
					{
						stringBuilder.Append(this.cultureinfo.Name);
					}
				}
				byte[] array = this.InternalGetPublicKeyToken();
				if (array != null)
				{
					if (array.Length == 0)
					{
						stringBuilder.Append(", PublicKeyToken=null");
					}
					else
					{
						stringBuilder.Append(", PublicKeyToken=");
						for (int i = 0; i < array.Length; i++)
						{
							stringBuilder.Append(array[i].ToString("x2"));
						}
					}
				}
				if ((this.Flags & AssemblyNameFlags.Retargetable) != AssemblyNameFlags.None)
				{
					stringBuilder.Append(", Retargetable=Yes");
				}
				return stringBuilder.ToString();
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06001073 RID: 4211 RVA: 0x00043B78 File Offset: 0x00041D78
		public StrongNameKeyPair KeyPair
		{
			get
			{
				return this.keypair;
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06001074 RID: 4212 RVA: 0x00043B80 File Offset: 0x00041D80
		// (set) Token: 0x06001075 RID: 4213 RVA: 0x00043B88 File Offset: 0x00041D88
		public Version Version
		{
			get
			{
				return this.version;
			}
			set
			{
				this.version = value;
				if (value == null)
				{
					this.major = (this.minor = (this.build = (this.revision = 0)));
				}
				else
				{
					this.major = value.Major;
					this.minor = value.Minor;
					this.build = value.Build;
					this.revision = value.Revision;
				}
			}
		}

		// Token: 0x06001076 RID: 4214 RVA: 0x00043C00 File Offset: 0x00041E00
		public override string ToString()
		{
			string fullName = this.FullName;
			return (fullName == null) ? base.ToString() : fullName;
		}

		// Token: 0x06001077 RID: 4215 RVA: 0x00043C28 File Offset: 0x00041E28
		public byte[] GetPublicKey()
		{
			return this.publicKey;
		}

		// Token: 0x06001078 RID: 4216 RVA: 0x00043C30 File Offset: 0x00041E30
		public byte[] GetPublicKeyToken()
		{
			if (this.keyToken != null)
			{
				return this.keyToken;
			}
			if (this.publicKey == null)
			{
				return null;
			}
			if (this.publicKey.Length == 0)
			{
				return new byte[0];
			}
			if (!this.IsPublicKeyValid)
			{
				throw new SecurityException("The public key is not valid.");
			}
			this.keyToken = this.ComputePublicKeyToken();
			return this.keyToken;
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x06001079 RID: 4217 RVA: 0x00043C98 File Offset: 0x00041E98
		private bool IsPublicKeyValid
		{
			get
			{
				if (this.publicKey.Length == 16)
				{
					int i = 0;
					int num = 0;
					while (i < this.publicKey.Length)
					{
						num += (int)this.publicKey[i++];
					}
					if (num == 4)
					{
						return true;
					}
				}
				byte b = this.publicKey[0];
				if (b != 6)
				{
					if (b != 7)
					{
						if (b == 0)
						{
							if (this.publicKey.Length > 12 && this.publicKey[12] == 6)
							{
								try
								{
									CryptoConvert.FromCapiPublicKeyBlob(this.publicKey, 12);
									return true;
								}
								catch (CryptographicException)
								{
								}
							}
						}
					}
				}
				else
				{
					try
					{
						CryptoConvert.FromCapiPublicKeyBlob(this.publicKey);
						return true;
					}
					catch (CryptographicException)
					{
					}
				}
				return false;
			}
		}

		// Token: 0x0600107A RID: 4218 RVA: 0x00043D90 File Offset: 0x00041F90
		private byte[] InternalGetPublicKeyToken()
		{
			if (this.keyToken != null)
			{
				return this.keyToken;
			}
			if (this.publicKey == null)
			{
				return null;
			}
			if (this.publicKey.Length == 0)
			{
				return new byte[0];
			}
			if (!this.IsPublicKeyValid)
			{
				throw new SecurityException("The public key is not valid.");
			}
			return this.ComputePublicKeyToken();
		}

		// Token: 0x0600107B RID: 4219 RVA: 0x00043DEC File Offset: 0x00041FEC
		private byte[] ComputePublicKeyToken()
		{
			HashAlgorithm hashAlgorithm = SHA1.Create();
			byte[] array = hashAlgorithm.ComputeHash(this.publicKey);
			byte[] array2 = new byte[8];
			Array.Copy(array, array.Length - 8, array2, 0, 8);
			Array.Reverse(array2, 0, 8);
			return array2;
		}

		// Token: 0x0600107C RID: 4220 RVA: 0x00043E2C File Offset: 0x0004202C
		public void SetPublicKey(byte[] publicKey)
		{
			if (publicKey == null)
			{
				this.flags ^= AssemblyNameFlags.PublicKey;
			}
			else
			{
				this.flags |= AssemblyNameFlags.PublicKey;
			}
			this.publicKey = publicKey;
		}

		// Token: 0x0600107D RID: 4221 RVA: 0x00043E5C File Offset: 0x0004205C
		public void SetPublicKeyToken(byte[] publicKeyToken)
		{
			this.keyToken = publicKeyToken;
		}

		// Token: 0x0600107E RID: 4222 RVA: 0x00043E68 File Offset: 0x00042068
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			info.AddValue("_Name", this.name);
			info.AddValue("_PublicKey", this.publicKey);
			info.AddValue("_PublicKeyToken", this.keyToken);
			info.AddValue("_CultureInfo", (this.cultureinfo == null) ? (-1) : this.cultureinfo.LCID);
			info.AddValue("_CodeBase", this.codebase);
			info.AddValue("_Version", this.Version);
			info.AddValue("_HashAlgorithm", this.hashalg);
			info.AddValue("_HashAlgorithmForControl", AssemblyHashAlgorithm.None);
			info.AddValue("_StrongNameKeyPair", this.keypair);
			info.AddValue("_VersionCompatibility", this.versioncompat);
			info.AddValue("_Flags", this.flags);
			info.AddValue("_HashForControl", null);
		}

		// Token: 0x0600107F RID: 4223 RVA: 0x00043F74 File Offset: 0x00042174
		public object Clone()
		{
			return new AssemblyName
			{
				name = this.name,
				codebase = this.codebase,
				major = this.major,
				minor = this.minor,
				build = this.build,
				revision = this.revision,
				version = this.version,
				cultureinfo = this.cultureinfo,
				flags = this.flags,
				hashalg = this.hashalg,
				keypair = this.keypair,
				publicKey = this.publicKey,
				keyToken = this.keyToken,
				versioncompat = this.versioncompat
			};
		}

		// Token: 0x06001080 RID: 4224 RVA: 0x00044030 File Offset: 0x00042230
		public void OnDeserialization(object sender)
		{
			this.Version = this.version;
		}

		// Token: 0x040006B9 RID: 1721
		private string name;

		// Token: 0x040006BA RID: 1722
		private string codebase;

		// Token: 0x040006BB RID: 1723
		private int major;

		// Token: 0x040006BC RID: 1724
		private int minor;

		// Token: 0x040006BD RID: 1725
		private int build;

		// Token: 0x040006BE RID: 1726
		private int revision;

		// Token: 0x040006BF RID: 1727
		private CultureInfo cultureinfo;

		// Token: 0x040006C0 RID: 1728
		private AssemblyNameFlags flags;

		// Token: 0x040006C1 RID: 1729
		private AssemblyHashAlgorithm hashalg;

		// Token: 0x040006C2 RID: 1730
		private StrongNameKeyPair keypair;

		// Token: 0x040006C3 RID: 1731
		private byte[] publicKey;

		// Token: 0x040006C4 RID: 1732
		private byte[] keyToken;

		// Token: 0x040006C5 RID: 1733
		private AssemblyVersionCompatibility versioncompat;

		// Token: 0x040006C6 RID: 1734
		private Version version;

		// Token: 0x040006C7 RID: 1735
		private ProcessorArchitecture processor_architecture;
	}
}
