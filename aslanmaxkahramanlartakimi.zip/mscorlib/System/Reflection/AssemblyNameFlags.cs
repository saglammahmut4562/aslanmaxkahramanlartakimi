﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B5 RID: 437
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum AssemblyNameFlags
	{
		// Token: 0x040006C9 RID: 1737
		None = 0,
		// Token: 0x040006CA RID: 1738
		PublicKey = 1,
		// Token: 0x040006CB RID: 1739
		Retargetable = 256,
		// Token: 0x040006CC RID: 1740
		EnableJITcompileOptimizer = 16384,
		// Token: 0x040006CD RID: 1741
		EnableJITcompileTracking = 32768
	}
}
