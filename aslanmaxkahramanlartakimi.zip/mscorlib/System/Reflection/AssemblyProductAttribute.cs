﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B6 RID: 438
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	public sealed class AssemblyProductAttribute : Attribute
	{
		// Token: 0x06001081 RID: 4225 RVA: 0x00044040 File Offset: 0x00042240
		public AssemblyProductAttribute(string product)
		{
			this.name = product;
		}

		// Token: 0x040006CE RID: 1742
		private string name;
	}
}
