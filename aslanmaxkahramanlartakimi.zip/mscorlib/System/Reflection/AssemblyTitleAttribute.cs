﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B7 RID: 439
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	public sealed class AssemblyTitleAttribute : Attribute
	{
		// Token: 0x06001082 RID: 4226 RVA: 0x00044050 File Offset: 0x00042250
		public AssemblyTitleAttribute(string title)
		{
			this.name = title;
		}

		// Token: 0x040006CF RID: 1743
		private string name;
	}
}
