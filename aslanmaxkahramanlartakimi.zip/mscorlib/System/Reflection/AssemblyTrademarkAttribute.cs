﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B8 RID: 440
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	public sealed class AssemblyTrademarkAttribute : Attribute
	{
		// Token: 0x06001083 RID: 4227 RVA: 0x00044060 File Offset: 0x00042260
		public AssemblyTrademarkAttribute(string trademark)
		{
			this.name = trademark;
		}

		// Token: 0x040006D0 RID: 1744
		private string name;
	}
}
