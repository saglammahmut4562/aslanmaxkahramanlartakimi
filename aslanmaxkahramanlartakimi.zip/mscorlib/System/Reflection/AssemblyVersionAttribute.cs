﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001B9 RID: 441
	[AttributeUsage(AttributeTargets.Assembly, Inherited = false)]
	[ComVisible(true)]
	public sealed class AssemblyVersionAttribute : Attribute
	{
		// Token: 0x06001084 RID: 4228 RVA: 0x00044070 File Offset: 0x00042270
		public AssemblyVersionAttribute(string version)
		{
			this.name = version;
		}

		// Token: 0x040006D1 RID: 1745
		private string name;
	}
}
