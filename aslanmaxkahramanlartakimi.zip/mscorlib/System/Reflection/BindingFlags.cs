﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001BC RID: 444
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum BindingFlags
	{
		// Token: 0x040006D4 RID: 1748
		Default = 0,
		// Token: 0x040006D5 RID: 1749
		IgnoreCase = 1,
		// Token: 0x040006D6 RID: 1750
		DeclaredOnly = 2,
		// Token: 0x040006D7 RID: 1751
		Instance = 4,
		// Token: 0x040006D8 RID: 1752
		Static = 8,
		// Token: 0x040006D9 RID: 1753
		Public = 16,
		// Token: 0x040006DA RID: 1754
		NonPublic = 32,
		// Token: 0x040006DB RID: 1755
		FlattenHierarchy = 64,
		// Token: 0x040006DC RID: 1756
		InvokeMethod = 256,
		// Token: 0x040006DD RID: 1757
		CreateInstance = 512,
		// Token: 0x040006DE RID: 1758
		GetField = 1024,
		// Token: 0x040006DF RID: 1759
		SetField = 2048,
		// Token: 0x040006E0 RID: 1760
		GetProperty = 4096,
		// Token: 0x040006E1 RID: 1761
		SetProperty = 8192,
		// Token: 0x040006E2 RID: 1762
		PutDispProperty = 16384,
		// Token: 0x040006E3 RID: 1763
		PutRefDispProperty = 32768,
		// Token: 0x040006E4 RID: 1764
		ExactBinding = 65536,
		// Token: 0x040006E5 RID: 1765
		SuppressChangeType = 131072,
		// Token: 0x040006E6 RID: 1766
		OptionalParamBinding = 262144,
		// Token: 0x040006E7 RID: 1767
		IgnoreReturn = 16777216
	}
}
