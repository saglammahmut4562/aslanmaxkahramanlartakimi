﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001BD RID: 445
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum CallingConventions
	{
		// Token: 0x040006E9 RID: 1769
		Standard = 1,
		// Token: 0x040006EA RID: 1770
		VarArgs = 2,
		// Token: 0x040006EB RID: 1771
		Any = 3,
		// Token: 0x040006EC RID: 1772
		HasThis = 32,
		// Token: 0x040006ED RID: 1773
		ExplicitThis = 64
	}
}
