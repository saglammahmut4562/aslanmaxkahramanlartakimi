﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001BE RID: 446
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_ConstructorInfo))]
	[Serializable]
	public abstract class ConstructorInfo : MethodBase, _ConstructorInfo
	{
		// Token: 0x1700026C RID: 620
		// (get) Token: 0x060010A1 RID: 4257 RVA: 0x00045104 File Offset: 0x00043304
		[ComVisible(true)]
		public override MemberTypes MemberType
		{
			get
			{
				return MemberTypes.Constructor;
			}
		}

		// Token: 0x060010A2 RID: 4258 RVA: 0x00045108 File Offset: 0x00043308
		[DebuggerStepThrough]
		[DebuggerHidden]
		public object Invoke(object[] parameters)
		{
			if (parameters == null)
			{
				parameters = new object[0];
			}
			return this.Invoke(BindingFlags.CreateInstance, null, parameters, null);
		}

		// Token: 0x060010A3 RID: 4259
		public abstract object Invoke(BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture);

		// Token: 0x040006EE RID: 1774
		[ComVisible(true)]
		public static readonly string ConstructorName = ".ctor";

		// Token: 0x040006EF RID: 1775
		[ComVisible(true)]
		public static readonly string TypeConstructorName = ".cctor";
	}
}
