﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001BF RID: 447
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Interface)]
	[ComVisible(true)]
	[Serializable]
	public sealed class DefaultMemberAttribute : Attribute
	{
		// Token: 0x060010A4 RID: 4260 RVA: 0x00045128 File Offset: 0x00043328
		public DefaultMemberAttribute(string memberName)
		{
			this.member_name = memberName;
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x060010A5 RID: 4261 RVA: 0x00045138 File Offset: 0x00043338
		public string MemberName
		{
			get
			{
				return this.member_name;
			}
		}

		// Token: 0x040006F0 RID: 1776
		private string member_name;
	}
}
