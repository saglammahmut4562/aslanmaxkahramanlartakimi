﻿using System;
using System.Text;

namespace System.Reflection.Emit
{
	// Token: 0x020001C0 RID: 448
	internal class ArrayType : DerivedType
	{
		// Token: 0x060010A6 RID: 4262 RVA: 0x00045140 File Offset: 0x00043340
		internal ArrayType(Type elementType, int rank)
			: base(elementType)
		{
			this.rank = rank;
		}

		// Token: 0x060010A7 RID: 4263 RVA: 0x00045150 File Offset: 0x00043350
		protected override bool IsArrayImpl()
		{
			return true;
		}

		// Token: 0x060010A8 RID: 4264 RVA: 0x00045154 File Offset: 0x00043354
		public override int GetArrayRank()
		{
			return (this.rank != 0) ? this.rank : 1;
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x060010A9 RID: 4265 RVA: 0x00045170 File Offset: 0x00043370
		public override Type BaseType
		{
			get
			{
				return typeof(Array);
			}
		}

		// Token: 0x060010AA RID: 4266 RVA: 0x0004517C File Offset: 0x0004337C
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			if (((ModuleBuilder)this.elementType.Module).assemblyb.IsCompilerContext)
			{
				return (this.elementType.Attributes & TypeAttributes.VisibilityMask) | TypeAttributes.Sealed | TypeAttributes.Serializable;
			}
			return this.elementType.Attributes;
		}

		// Token: 0x060010AB RID: 4267 RVA: 0x000451D0 File Offset: 0x000433D0
		internal override string FormatName(string elementName)
		{
			if (elementName == null)
			{
				return null;
			}
			StringBuilder stringBuilder = new StringBuilder(elementName);
			stringBuilder.Append("[");
			for (int i = 1; i < this.rank; i++)
			{
				stringBuilder.Append(",");
			}
			if (this.rank == 1)
			{
				stringBuilder.Append("*");
			}
			stringBuilder.Append("]");
			return stringBuilder.ToString();
		}

		// Token: 0x040006F1 RID: 1777
		private int rank;
	}
}
