﻿using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using Mono.Security;

namespace System.Reflection.Emit
{
	// Token: 0x020001C1 RID: 449
	[ComDefaultInterface(typeof(_AssemblyBuilder))]
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	public sealed class AssemblyBuilder : Assembly, _AssemblyBuilder
	{
		// Token: 0x060010AC RID: 4268 RVA: 0x00045248 File Offset: 0x00043448
		internal AssemblyBuilder(AssemblyName n, string directory, AssemblyBuilderAccess access, bool corlib_internal)
		{
			this.is_compiler_context = (access & (AssemblyBuilderAccess)2048) != (AssemblyBuilderAccess)0;
			access &= (AssemblyBuilderAccess)(-2049);
			if (!Enum.IsDefined(typeof(AssemblyBuilderAccess), access))
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, "Argument value {0} is not valid.", new object[] { (int)access }), "access");
			}
			this.name = n.Name;
			this.access = (uint)access;
			this.flags = (uint)n.Flags;
			if (this.IsSave && (directory == null || directory.Length == 0))
			{
				this.dir = Directory.GetCurrentDirectory();
			}
			else
			{
				this.dir = directory;
			}
			if (n.CultureInfo != null)
			{
				this.culture = n.CultureInfo.Name;
				this.versioninfo_culture = n.CultureInfo.Name;
			}
			Version version = n.Version;
			if (version != null)
			{
				this.version = version.ToString();
			}
			if (n.KeyPair != null)
			{
				this.sn = n.KeyPair.StrongName();
			}
			else
			{
				byte[] publicKey = n.GetPublicKey();
				if (publicKey != null && publicKey.Length > 0)
				{
					this.sn = new StrongName(publicKey);
				}
			}
			if (this.sn != null)
			{
				this.flags |= 1U;
			}
			this.corlib_internal = corlib_internal;
			if (this.sn != null)
			{
				this.pktoken = new byte[this.sn.PublicKeyToken.Length * 2];
				int num = 0;
				foreach (byte b in this.sn.PublicKeyToken)
				{
					string text = b.ToString("x2");
					this.pktoken[num++] = (byte)text[0];
					this.pktoken[num++] = (byte)text[1];
				}
			}
			AssemblyBuilder.basic_init(this);
		}

		// Token: 0x060010AD RID: 4269
		[MethodImpl(4096)]
		private static extern void basic_init(AssemblyBuilder ab);

		// Token: 0x1700026F RID: 623
		// (get) Token: 0x060010AE RID: 4270 RVA: 0x00045494 File Offset: 0x00043694
		public override string CodeBase
		{
			get
			{
				throw this.not_supported();
			}
		}

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x060010AF RID: 4271 RVA: 0x0004549C File Offset: 0x0004369C
		public override MethodInfo EntryPoint
		{
			get
			{
				return this.entry_point;
			}
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x060010B0 RID: 4272 RVA: 0x000454A4 File Offset: 0x000436A4
		public override string Location
		{
			get
			{
				throw this.not_supported();
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x060010B1 RID: 4273 RVA: 0x000454AC File Offset: 0x000436AC
		public override string ImageRuntimeVersion
		{
			get
			{
				return base.ImageRuntimeVersion;
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x060010B2 RID: 4274 RVA: 0x000454B4 File Offset: 0x000436B4
		[MonoTODO]
		public override bool ReflectionOnly
		{
			get
			{
				return base.ReflectionOnly;
			}
		}

		// Token: 0x060010B3 RID: 4275 RVA: 0x000454BC File Offset: 0x000436BC
		internal void AddPermissionRequests(PermissionSet required, PermissionSet optional, PermissionSet refused)
		{
		}

		// Token: 0x060010B4 RID: 4276 RVA: 0x000454C0 File Offset: 0x000436C0
		public ModuleBuilder DefineDynamicModule(string name)
		{
			return this.DefineDynamicModule(name, name, false, true);
		}

		// Token: 0x060010B5 RID: 4277 RVA: 0x000454CC File Offset: 0x000436CC
		public ModuleBuilder DefineDynamicModule(string name, bool emitSymbolInfo)
		{
			return this.DefineDynamicModule(name, name, emitSymbolInfo, true);
		}

		// Token: 0x060010B6 RID: 4278 RVA: 0x000454D8 File Offset: 0x000436D8
		private ModuleBuilder DefineDynamicModule(string name, string fileName, bool emitSymbolInfo, bool transient)
		{
			this.check_name_and_filename(name, fileName, false);
			if (!transient)
			{
				if (Path.GetExtension(fileName) == string.Empty)
				{
					throw new ArgumentException("Module file name '" + fileName + "' must have file extension.");
				}
				if (!this.IsSave)
				{
					throw new NotSupportedException("Persistable modules are not supported in a dynamic assembly created with AssemblyBuilderAccess.Run");
				}
				if (this.created)
				{
					throw new InvalidOperationException("Assembly was already saved.");
				}
			}
			ModuleBuilder moduleBuilder = new ModuleBuilder(this, name, fileName, emitSymbolInfo, transient);
			if (this.modules != null && this.is_module_only)
			{
				throw new InvalidOperationException("A module-only assembly can only contain one module.");
			}
			if (this.modules != null)
			{
				ModuleBuilder[] array = new ModuleBuilder[this.modules.Length + 1];
				Array.Copy(this.modules, array, this.modules.Length);
				this.modules = array;
			}
			else
			{
				this.modules = new ModuleBuilder[1];
			}
			this.modules[this.modules.Length - 1] = moduleBuilder;
			return moduleBuilder;
		}

		// Token: 0x060010B7 RID: 4279 RVA: 0x000455D4 File Offset: 0x000437D4
		public override Type[] GetExportedTypes()
		{
			throw this.not_supported();
		}

		// Token: 0x060010B8 RID: 4280 RVA: 0x000455DC File Offset: 0x000437DC
		public override FileStream GetFile(string name)
		{
			throw this.not_supported();
		}

		// Token: 0x060010B9 RID: 4281 RVA: 0x000455E4 File Offset: 0x000437E4
		public override FileStream[] GetFiles(bool getResourceModules)
		{
			throw this.not_supported();
		}

		// Token: 0x060010BA RID: 4282 RVA: 0x000455EC File Offset: 0x000437EC
		internal override Module[] GetModulesInternal()
		{
			if (this.modules == null)
			{
				return new Module[0];
			}
			return (Module[])this.modules.Clone();
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x00045610 File Offset: 0x00043810
		internal override Type[] GetTypes(bool exportedOnly)
		{
			Type[] array = null;
			if (this.modules != null)
			{
				for (int i = 0; i < this.modules.Length; i++)
				{
					Type[] types = this.modules[i].GetTypes();
					if (array == null)
					{
						array = types;
					}
					else
					{
						Type[] array2 = new Type[array.Length + types.Length];
						Array.Copy(array, 0, array2, 0, array.Length);
						Array.Copy(types, 0, array2, array.Length, types.Length);
					}
				}
			}
			if (this.loaded_modules != null)
			{
				for (int j = 0; j < this.loaded_modules.Length; j++)
				{
					Type[] types2 = this.loaded_modules[j].GetTypes();
					if (array == null)
					{
						array = types2;
					}
					else
					{
						Type[] array3 = new Type[array.Length + types2.Length];
						Array.Copy(array, 0, array3, 0, array.Length);
						Array.Copy(types2, 0, array3, array.Length, types2.Length);
					}
				}
			}
			return (array != null) ? array : Type.EmptyTypes;
		}

		// Token: 0x060010BC RID: 4284 RVA: 0x0004570C File Offset: 0x0004390C
		public override ManifestResourceInfo GetManifestResourceInfo(string resourceName)
		{
			throw this.not_supported();
		}

		// Token: 0x060010BD RID: 4285 RVA: 0x00045714 File Offset: 0x00043914
		public override string[] GetManifestResourceNames()
		{
			throw this.not_supported();
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x0004571C File Offset: 0x0004391C
		public override Stream GetManifestResourceStream(string name)
		{
			throw this.not_supported();
		}

		// Token: 0x060010BF RID: 4287 RVA: 0x00045724 File Offset: 0x00043924
		public override Stream GetManifestResourceStream(Type type, string name)
		{
			throw this.not_supported();
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x060010C0 RID: 4288 RVA: 0x0004572C File Offset: 0x0004392C
		internal bool IsCompilerContext
		{
			get
			{
				return this.is_compiler_context;
			}
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x060010C1 RID: 4289 RVA: 0x00045734 File Offset: 0x00043934
		internal bool IsSave
		{
			get
			{
				return this.access != 1U;
			}
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x060010C2 RID: 4290 RVA: 0x00045744 File Offset: 0x00043944
		internal bool IsRun
		{
			get
			{
				return this.access == 1U || this.access == 3U;
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x060010C3 RID: 4291 RVA: 0x00045760 File Offset: 0x00043960
		internal string AssemblyDir
		{
			get
			{
				return this.dir;
			}
		}

		// Token: 0x060010C4 RID: 4292 RVA: 0x00045768 File Offset: 0x00043968
		internal override Module GetManifestModule()
		{
			if (this.manifest_module == null)
			{
				this.manifest_module = this.DefineDynamicModule("Default Dynamic Module");
			}
			return this.manifest_module;
		}

		// Token: 0x060010C5 RID: 4293 RVA: 0x0004578C File Offset: 0x0004398C
		public void SetCustomAttribute(CustomAttributeBuilder customBuilder)
		{
			if (customBuilder == null)
			{
				throw new ArgumentNullException("customBuilder");
			}
			if (this.IsCompilerContext)
			{
				string fullName = customBuilder.Ctor.ReflectedType.FullName;
				if (fullName == "System.Reflection.AssemblyVersionAttribute")
				{
					this.version = this.create_assembly_version(customBuilder.string_arg());
					return;
				}
				if (fullName == "System.Reflection.AssemblyCultureAttribute")
				{
					this.culture = this.GetCultureString(customBuilder.string_arg());
				}
				else if (fullName == "System.Reflection.AssemblyAlgorithmIdAttribute")
				{
					byte[] array = customBuilder.Data;
					int num = 2;
					this.algid = (uint)array[num];
					this.algid |= (uint)((uint)array[num + 1] << 8);
					this.algid |= (uint)((uint)array[num + 2] << 16);
					this.algid |= (uint)((uint)array[num + 3] << 24);
				}
				else if (fullName == "System.Reflection.AssemblyFlagsAttribute")
				{
					byte[] array = customBuilder.Data;
					int num = 2;
					this.flags |= (uint)array[num];
					this.flags |= (uint)((uint)array[num + 1] << 8);
					this.flags |= (uint)((uint)array[num + 2] << 16);
					this.flags |= (uint)((uint)array[num + 3] << 24);
					if (this.sn == null)
					{
						this.flags &= 4294967294U;
					}
				}
			}
			if (this.cattrs != null)
			{
				CustomAttributeBuilder[] array2 = new CustomAttributeBuilder[this.cattrs.Length + 1];
				this.cattrs.CopyTo(array2, 0);
				array2[this.cattrs.Length] = customBuilder;
				this.cattrs = array2;
			}
			else
			{
				this.cattrs = new CustomAttributeBuilder[1];
				this.cattrs[0] = customBuilder;
			}
		}

		// Token: 0x060010C6 RID: 4294 RVA: 0x0004594C File Offset: 0x00043B4C
		private Exception not_supported()
		{
			return new NotSupportedException("The invoked member is not supported in a dynamic module.");
		}

		// Token: 0x060010C7 RID: 4295 RVA: 0x00045958 File Offset: 0x00043B58
		private void check_name_and_filename(string name, string fileName, bool fileNeedsToExists)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			if (fileName == null)
			{
				throw new ArgumentNullException("fileName");
			}
			if (name.Length == 0)
			{
				throw new ArgumentException("Empty name is not legal.", "name");
			}
			if (fileName.Length == 0)
			{
				throw new ArgumentException("Empty file name is not legal.", "fileName");
			}
			if (Path.GetFileName(fileName) != fileName)
			{
				throw new ArgumentException("fileName '" + fileName + "' must not include a path.", "fileName");
			}
			string text = fileName;
			if (this.dir != null)
			{
				text = Path.Combine(this.dir, fileName);
			}
			if (fileNeedsToExists && !File.Exists(text))
			{
				throw new FileNotFoundException("Could not find file '" + fileName + "'");
			}
			if (this.resources != null)
			{
				for (int i = 0; i < this.resources.Length; i++)
				{
					if (this.resources[i].filename == text)
					{
						throw new ArgumentException("Duplicate file name '" + fileName + "'");
					}
					if (this.resources[i].name == name)
					{
						throw new ArgumentException("Duplicate name '" + name + "'");
					}
				}
			}
			if (this.modules != null)
			{
				for (int j = 0; j < this.modules.Length; j++)
				{
					if (!this.modules[j].IsTransient() && this.modules[j].FileName == fileName)
					{
						throw new ArgumentException("Duplicate file name '" + fileName + "'");
					}
					if (this.modules[j].Name == name)
					{
						throw new ArgumentException("Duplicate name '" + name + "'");
					}
				}
			}
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x00045B44 File Offset: 0x00043D44
		private string create_assembly_version(string version)
		{
			string[] array = version.Split(new char[] { '.' });
			int[] array2 = new int[4];
			if (array.Length < 0 || array.Length > 4)
			{
				throw new ArgumentException("The version specified '" + version + "' is invalid");
			}
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i] == "*")
				{
					DateTime now = DateTime.Now;
					if (i == 2)
					{
						array2[2] = (now - new DateTime(2000, 1, 1)).Days;
						if (array.Length == 3)
						{
							array2[3] = (now.Second + now.Minute * 60 + now.Hour * 3600) / 2;
						}
					}
					else
					{
						if (i != 3)
						{
							throw new ArgumentException("The version specified '" + version + "' is invalid");
						}
						array2[3] = (now.Second + now.Minute * 60 + now.Hour * 3600) / 2;
					}
				}
				else
				{
					try
					{
						array2[i] = int.Parse(array[i]);
					}
					catch (FormatException)
					{
						throw new ArgumentException("The version specified '" + version + "' is invalid");
					}
				}
			}
			return string.Concat(new object[]
			{
				array2[0],
				".",
				array2[1],
				".",
				array2[2],
				".",
				array2[3]
			});
		}

		// Token: 0x060010C9 RID: 4297 RVA: 0x00045CF0 File Offset: 0x00043EF0
		private string GetCultureString(string str)
		{
			return (!(str == "neutral")) ? str : string.Empty;
		}

		// Token: 0x060010CA RID: 4298 RVA: 0x00045D10 File Offset: 0x00043F10
		internal override AssemblyName UnprotectedGetName()
		{
			AssemblyName assemblyName = base.UnprotectedGetName();
			if (this.sn != null)
			{
				assemblyName.SetPublicKey(this.sn.PublicKey);
				assemblyName.SetPublicKeyToken(this.sn.PublicKeyToken);
			}
			return assemblyName;
		}

		// Token: 0x040006F2 RID: 1778
		private const AssemblyBuilderAccess COMPILER_ACCESS = (AssemblyBuilderAccess)2048;

		// Token: 0x040006F3 RID: 1779
		private UIntPtr dynamic_assembly;

		// Token: 0x040006F4 RID: 1780
		private MethodInfo entry_point;

		// Token: 0x040006F5 RID: 1781
		private ModuleBuilder[] modules;

		// Token: 0x040006F6 RID: 1782
		private string name;

		// Token: 0x040006F7 RID: 1783
		private string dir;

		// Token: 0x040006F8 RID: 1784
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x040006F9 RID: 1785
		private MonoResource[] resources;

		// Token: 0x040006FA RID: 1786
		private byte[] public_key;

		// Token: 0x040006FB RID: 1787
		private string version;

		// Token: 0x040006FC RID: 1788
		private string culture;

		// Token: 0x040006FD RID: 1789
		private uint algid;

		// Token: 0x040006FE RID: 1790
		private uint flags;

		// Token: 0x040006FF RID: 1791
		private PEFileKinds pekind = PEFileKinds.Dll;

		// Token: 0x04000700 RID: 1792
		private bool delay_sign;

		// Token: 0x04000701 RID: 1793
		private uint access;

		// Token: 0x04000702 RID: 1794
		private Module[] loaded_modules;

		// Token: 0x04000703 RID: 1795
		private MonoWin32Resource[] win32_resources;

		// Token: 0x04000704 RID: 1796
		private RefEmitPermissionSet[] permissions_minimum;

		// Token: 0x04000705 RID: 1797
		private RefEmitPermissionSet[] permissions_optional;

		// Token: 0x04000706 RID: 1798
		private RefEmitPermissionSet[] permissions_refused;

		// Token: 0x04000707 RID: 1799
		private PortableExecutableKinds peKind;

		// Token: 0x04000708 RID: 1800
		private ImageFileMachine machine;

		// Token: 0x04000709 RID: 1801
		private bool corlib_internal;

		// Token: 0x0400070A RID: 1802
		private Type[] type_forwarders;

		// Token: 0x0400070B RID: 1803
		private byte[] pktoken;

		// Token: 0x0400070C RID: 1804
		internal Type corlib_object_type = typeof(object);

		// Token: 0x0400070D RID: 1805
		internal Type corlib_value_type = typeof(ValueType);

		// Token: 0x0400070E RID: 1806
		internal Type corlib_enum_type = typeof(Enum);

		// Token: 0x0400070F RID: 1807
		internal Type corlib_void_type = typeof(void);

		// Token: 0x04000710 RID: 1808
		private ArrayList resource_writers;

		// Token: 0x04000711 RID: 1809
		private Win32VersionResource version_res;

		// Token: 0x04000712 RID: 1810
		private bool created;

		// Token: 0x04000713 RID: 1811
		private bool is_module_only;

		// Token: 0x04000714 RID: 1812
		private StrongName sn;

		// Token: 0x04000715 RID: 1813
		private NativeResourceType native_resource;

		// Token: 0x04000716 RID: 1814
		private readonly bool is_compiler_context;

		// Token: 0x04000717 RID: 1815
		private string versioninfo_culture;

		// Token: 0x04000718 RID: 1816
		private ModuleBuilder manifest_module;
	}
}
