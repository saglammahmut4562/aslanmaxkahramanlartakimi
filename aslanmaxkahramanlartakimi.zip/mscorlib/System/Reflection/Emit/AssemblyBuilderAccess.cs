﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001C2 RID: 450
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum AssemblyBuilderAccess
	{
		// Token: 0x0400071A RID: 1818
		Run = 1,
		// Token: 0x0400071B RID: 1819
		Save = 2,
		// Token: 0x0400071C RID: 1820
		RunAndSave = 3,
		// Token: 0x0400071D RID: 1821
		ReflectionOnly = 6
	}
}
