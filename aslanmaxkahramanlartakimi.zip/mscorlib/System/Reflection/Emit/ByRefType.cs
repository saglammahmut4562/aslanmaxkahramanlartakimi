﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001C3 RID: 451
	internal class ByRefType : DerivedType
	{
		// Token: 0x060010CB RID: 4299 RVA: 0x00045D54 File Offset: 0x00043F54
		internal ByRefType(Type elementType)
			: base(elementType)
		{
		}

		// Token: 0x060010CC RID: 4300 RVA: 0x00045D60 File Offset: 0x00043F60
		protected override bool IsByRefImpl()
		{
			return true;
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x060010CD RID: 4301 RVA: 0x00045D64 File Offset: 0x00043F64
		public override Type BaseType
		{
			get
			{
				return typeof(Array);
			}
		}

		// Token: 0x060010CE RID: 4302 RVA: 0x00045D70 File Offset: 0x00043F70
		internal override string FormatName(string elementName)
		{
			if (elementName == null)
			{
				return null;
			}
			return elementName + "&";
		}

		// Token: 0x060010CF RID: 4303 RVA: 0x00045D88 File Offset: 0x00043F88
		public override Type MakeArrayType()
		{
			throw new ArgumentException("Cannot create an array type of a byref type");
		}

		// Token: 0x060010D0 RID: 4304 RVA: 0x00045D94 File Offset: 0x00043F94
		public override Type MakeArrayType(int rank)
		{
			throw new ArgumentException("Cannot create an array type of a byref type");
		}

		// Token: 0x060010D1 RID: 4305 RVA: 0x00045DA0 File Offset: 0x00043FA0
		public override Type MakeByRefType()
		{
			throw new ArgumentException("Cannot create a byref type of an already byref type");
		}

		// Token: 0x060010D2 RID: 4306 RVA: 0x00045DAC File Offset: 0x00043FAC
		public override Type MakePointerType()
		{
			throw new ArgumentException("Cannot create a pointer type of a byref type");
		}
	}
}
