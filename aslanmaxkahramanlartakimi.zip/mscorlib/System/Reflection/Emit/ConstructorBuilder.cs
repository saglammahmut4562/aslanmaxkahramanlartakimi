﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001C4 RID: 452
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_ConstructorBuilder))]
	public sealed class ConstructorBuilder : ConstructorInfo, _ConstructorBuilder
	{
		// Token: 0x060010D3 RID: 4307 RVA: 0x00045DB8 File Offset: 0x00043FB8
		internal ConstructorBuilder(TypeBuilder tb, MethodAttributes attributes, CallingConventions callingConvention, Type[] parameterTypes, Type[][] paramModReq, Type[][] paramModOpt)
		{
			this.attrs = attributes | MethodAttributes.SpecialName | MethodAttributes.RTSpecialName;
			this.call_conv = callingConvention;
			if (parameterTypes != null)
			{
				for (int i = 0; i < parameterTypes.Length; i++)
				{
					if (parameterTypes[i] == null)
					{
						throw new ArgumentException("Elements of the parameterTypes array cannot be null", "parameterTypes");
					}
				}
				this.parameters = new Type[parameterTypes.Length];
				Array.Copy(parameterTypes, this.parameters, parameterTypes.Length);
			}
			this.type = tb;
			this.paramModReq = paramModReq;
			this.paramModOpt = paramModOpt;
			this.table_idx = this.get_next_table_index(this, 6, true);
			((ModuleBuilder)tb.Module).RegisterToken(this, this.GetToken().Token);
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x060010D4 RID: 4308 RVA: 0x00045E88 File Offset: 0x00044088
		[MonoTODO]
		public override CallingConventions CallingConvention
		{
			get
			{
				return this.call_conv;
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x060010D5 RID: 4309 RVA: 0x00045E90 File Offset: 0x00044090
		internal TypeBuilder TypeBuilder
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x00045E98 File Offset: 0x00044098
		public override MethodImplAttributes GetMethodImplementationFlags()
		{
			return this.iattrs;
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x00045EA0 File Offset: 0x000440A0
		public override ParameterInfo[] GetParameters()
		{
			if (!this.type.is_created && !this.IsCompilerContext)
			{
				throw this.not_created();
			}
			return this.GetParametersInternal();
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x00045ECC File Offset: 0x000440CC
		internal ParameterInfo[] GetParametersInternal()
		{
			if (this.parameters == null)
			{
				return new ParameterInfo[0];
			}
			ParameterInfo[] array = new ParameterInfo[this.parameters.Length];
			for (int i = 0; i < this.parameters.Length; i++)
			{
				array[i] = new ParameterInfo((this.pinfo != null) ? this.pinfo[i + 1] : null, this.parameters[i], this, i + 1);
			}
			return array;
		}

		// Token: 0x060010D9 RID: 4313 RVA: 0x00045F44 File Offset: 0x00044144
		internal override int GetParameterCount()
		{
			if (this.parameters == null)
			{
				return 0;
			}
			return this.parameters.Length;
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x00045F5C File Offset: 0x0004415C
		public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			throw this.not_supported();
		}

		// Token: 0x060010DB RID: 4315 RVA: 0x00045F64 File Offset: 0x00044164
		public override object Invoke(BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			throw this.not_supported();
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x060010DC RID: 4316 RVA: 0x00045F6C File Offset: 0x0004416C
		public override RuntimeMethodHandle MethodHandle
		{
			get
			{
				throw this.not_supported();
			}
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x060010DD RID: 4317 RVA: 0x00045F74 File Offset: 0x00044174
		public override MethodAttributes Attributes
		{
			get
			{
				return this.attrs;
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x060010DE RID: 4318 RVA: 0x00045F7C File Offset: 0x0004417C
		public override Type ReflectedType
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x060010DF RID: 4319 RVA: 0x00045F84 File Offset: 0x00044184
		public override Type DeclaringType
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x060010E0 RID: 4320 RVA: 0x00045F8C File Offset: 0x0004418C
		public override string Name
		{
			get
			{
				return ((this.attrs & MethodAttributes.Static) == MethodAttributes.PrivateScope) ? ConstructorInfo.ConstructorName : ConstructorInfo.TypeConstructorName;
			}
		}

		// Token: 0x060010E1 RID: 4321 RVA: 0x00045FAC File Offset: 0x000441AC
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw this.not_supported();
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x00045FB4 File Offset: 0x000441B4
		public override object[] GetCustomAttributes(bool inherit)
		{
			if (this.type.is_created && this.IsCompilerContext)
			{
				return MonoCustomAttrs.GetCustomAttributes(this, inherit);
			}
			throw this.not_supported();
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x00045FE0 File Offset: 0x000441E0
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			if (this.type.is_created && this.IsCompilerContext)
			{
				return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
			}
			throw this.not_supported();
		}

		// Token: 0x060010E4 RID: 4324 RVA: 0x0004600C File Offset: 0x0004420C
		public ILGenerator GetILGenerator()
		{
			return this.GetILGenerator(64);
		}

		// Token: 0x060010E5 RID: 4325 RVA: 0x00046018 File Offset: 0x00044218
		public ILGenerator GetILGenerator(int streamSize)
		{
			if (this.ilgen != null)
			{
				return this.ilgen;
			}
			this.ilgen = new ILGenerator(this.type.Module, ((ModuleBuilder)this.type.Module).GetTokenGenerator(), streamSize);
			return this.ilgen;
		}

		// Token: 0x060010E6 RID: 4326 RVA: 0x0004606C File Offset: 0x0004426C
		public MethodToken GetToken()
		{
			return new MethodToken(100663296 | this.table_idx);
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x060010E7 RID: 4327 RVA: 0x00046080 File Offset: 0x00044280
		public override Module Module
		{
			get
			{
				return base.Module;
			}
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x00046088 File Offset: 0x00044288
		public override string ToString()
		{
			return "ConstructorBuilder ['" + this.type.Name + "']";
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x000460A4 File Offset: 0x000442A4
		internal void fixup()
		{
			if ((this.attrs & (MethodAttributes.Abstract | MethodAttributes.PinvokeImpl)) == MethodAttributes.PrivateScope && (this.iattrs & (MethodImplAttributes)4099) == MethodImplAttributes.IL && (this.ilgen == null || ILGenerator.Mono_GetCurrentOffset(this.ilgen) == 0))
			{
				throw new InvalidOperationException("Method '" + this.Name + "' does not have a method body.");
			}
			if (this.ilgen != null)
			{
				this.ilgen.label_fixup();
			}
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x00046120 File Offset: 0x00044320
		internal override int get_next_table_index(object obj, int table, bool inc)
		{
			return this.type.get_next_table_index(obj, table, inc);
		}

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x060010EB RID: 4331 RVA: 0x00046130 File Offset: 0x00044330
		private bool IsCompilerContext
		{
			get
			{
				ModuleBuilder moduleBuilder = (ModuleBuilder)this.TypeBuilder.Module;
				AssemblyBuilder assemblyBuilder = (AssemblyBuilder)moduleBuilder.Assembly;
				return assemblyBuilder.IsCompilerContext;
			}
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x00046160 File Offset: 0x00044360
		private Exception not_supported()
		{
			return new NotSupportedException("The invoked member is not supported in a dynamic module.");
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x0004616C File Offset: 0x0004436C
		private Exception not_created()
		{
			return new NotSupportedException("The type is not yet created.");
		}

		// Token: 0x0400071E RID: 1822
		private RuntimeMethodHandle mhandle;

		// Token: 0x0400071F RID: 1823
		private ILGenerator ilgen;

		// Token: 0x04000720 RID: 1824
		internal Type[] parameters;

		// Token: 0x04000721 RID: 1825
		private MethodAttributes attrs;

		// Token: 0x04000722 RID: 1826
		private MethodImplAttributes iattrs;

		// Token: 0x04000723 RID: 1827
		private int table_idx;

		// Token: 0x04000724 RID: 1828
		private CallingConventions call_conv;

		// Token: 0x04000725 RID: 1829
		private TypeBuilder type;

		// Token: 0x04000726 RID: 1830
		internal ParameterBuilder[] pinfo;

		// Token: 0x04000727 RID: 1831
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x04000728 RID: 1832
		private bool init_locals = true;

		// Token: 0x04000729 RID: 1833
		private Type[][] paramModReq;

		// Token: 0x0400072A RID: 1834
		private Type[][] paramModOpt;

		// Token: 0x0400072B RID: 1835
		private RefEmitPermissionSet[] permissions;
	}
}
