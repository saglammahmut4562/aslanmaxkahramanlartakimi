﻿using System;
using System.Globalization;

namespace System.Reflection.Emit
{
	// Token: 0x020001C5 RID: 453
	internal class ConstructorOnTypeBuilderInst : ConstructorInfo
	{
		// Token: 0x060010EE RID: 4334 RVA: 0x00046178 File Offset: 0x00044378
		public ConstructorOnTypeBuilderInst(MonoGenericClass instantiation, ConstructorBuilder cb)
		{
			this.instantiation = instantiation;
			this.cb = cb;
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x060010EF RID: 4335 RVA: 0x00046190 File Offset: 0x00044390
		public override Type DeclaringType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x060010F0 RID: 4336 RVA: 0x00046198 File Offset: 0x00044398
		public override string Name
		{
			get
			{
				return this.cb.Name;
			}
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x060010F1 RID: 4337 RVA: 0x000461A8 File Offset: 0x000443A8
		public override Type ReflectedType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x000461B0 File Offset: 0x000443B0
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return this.cb.IsDefined(attributeType, inherit);
		}

		// Token: 0x060010F3 RID: 4339 RVA: 0x000461C0 File Offset: 0x000443C0
		public override object[] GetCustomAttributes(bool inherit)
		{
			return this.cb.GetCustomAttributes(inherit);
		}

		// Token: 0x060010F4 RID: 4340 RVA: 0x000461D0 File Offset: 0x000443D0
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return this.cb.GetCustomAttributes(attributeType, inherit);
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x000461E0 File Offset: 0x000443E0
		public override MethodImplAttributes GetMethodImplementationFlags()
		{
			return this.cb.GetMethodImplementationFlags();
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x000461F0 File Offset: 0x000443F0
		public override ParameterInfo[] GetParameters()
		{
			if (!((ModuleBuilder)this.cb.Module).assemblyb.IsCompilerContext && !this.instantiation.generic_type.is_created)
			{
				throw new NotSupportedException();
			}
			ParameterInfo[] array = new ParameterInfo[this.cb.parameters.Length];
			for (int i = 0; i < this.cb.parameters.Length; i++)
			{
				Type type = this.instantiation.InflateType(this.cb.parameters[i]);
				array[i] = new ParameterInfo((this.cb.pinfo != null) ? this.cb.pinfo[i] : null, type, this, i + 1);
			}
			return array;
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x000462B4 File Offset: 0x000444B4
		internal override int GetParameterCount()
		{
			return this.cb.GetParameterCount();
		}

		// Token: 0x060010F8 RID: 4344 RVA: 0x000462C4 File Offset: 0x000444C4
		public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			return this.cb.Invoke(obj, invokeAttr, binder, parameters, culture);
		}

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x060010F9 RID: 4345 RVA: 0x000462D8 File Offset: 0x000444D8
		public override RuntimeMethodHandle MethodHandle
		{
			get
			{
				return this.cb.MethodHandle;
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x060010FA RID: 4346 RVA: 0x000462E8 File Offset: 0x000444E8
		public override MethodAttributes Attributes
		{
			get
			{
				return this.cb.Attributes;
			}
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x060010FB RID: 4347 RVA: 0x000462F8 File Offset: 0x000444F8
		public override CallingConventions CallingConvention
		{
			get
			{
				return this.cb.CallingConvention;
			}
		}

		// Token: 0x060010FC RID: 4348 RVA: 0x00046308 File Offset: 0x00044508
		public override Type[] GetGenericArguments()
		{
			return this.cb.GetGenericArguments();
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x060010FD RID: 4349 RVA: 0x00046318 File Offset: 0x00044518
		public override bool ContainsGenericParameters
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x060010FE RID: 4350 RVA: 0x0004631C File Offset: 0x0004451C
		public override bool IsGenericMethodDefinition
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x060010FF RID: 4351 RVA: 0x00046320 File Offset: 0x00044520
		public override bool IsGenericMethod
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06001100 RID: 4352 RVA: 0x00046324 File Offset: 0x00044524
		public override object Invoke(BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			throw new InvalidOperationException();
		}

		// Token: 0x0400072C RID: 1836
		private MonoGenericClass instantiation;

		// Token: 0x0400072D RID: 1837
		private ConstructorBuilder cb;
	}
}
