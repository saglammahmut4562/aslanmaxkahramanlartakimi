﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace System.Reflection.Emit
{
	// Token: 0x020001C6 RID: 454
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_CustomAttributeBuilder))]
	public class CustomAttributeBuilder : _CustomAttributeBuilder
	{
		// Token: 0x1700028B RID: 651
		// (get) Token: 0x06001101 RID: 4353 RVA: 0x0004632C File Offset: 0x0004452C
		internal ConstructorInfo Ctor
		{
			get
			{
				return this.ctor;
			}
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06001102 RID: 4354 RVA: 0x00046334 File Offset: 0x00044534
		internal byte[] Data
		{
			get
			{
				return this.data;
			}
		}

		// Token: 0x06001103 RID: 4355 RVA: 0x0004633C File Offset: 0x0004453C
		internal static int decode_len(byte[] data, int pos, out int rpos)
		{
			int num;
			if ((data[pos] & 128) == 0)
			{
				num = (int)(data[pos++] & 127);
			}
			else if ((data[pos] & 64) == 0)
			{
				num = ((int)(data[pos] & 63) << 8) + (int)data[pos + 1];
				pos += 2;
			}
			else
			{
				num = ((int)(data[pos] & 31) << 24) + ((int)data[pos + 1] << 16) + ((int)data[pos + 2] << 8) + (int)data[pos + 3];
				pos += 4;
			}
			rpos = pos;
			return num;
		}

		// Token: 0x06001104 RID: 4356 RVA: 0x000463B8 File Offset: 0x000445B8
		internal static string string_from_bytes(byte[] data, int pos, int len)
		{
			return Encoding.UTF8.GetString(data, pos, len);
		}

		// Token: 0x06001105 RID: 4357 RVA: 0x000463C8 File Offset: 0x000445C8
		internal string string_arg()
		{
			int num = 2;
			int num2 = CustomAttributeBuilder.decode_len(this.data, num, out num);
			return CustomAttributeBuilder.string_from_bytes(this.data, num, num2);
		}

		// Token: 0x0400072E RID: 1838
		private ConstructorInfo ctor;

		// Token: 0x0400072F RID: 1839
		private byte[] data;
	}
}
