﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001C7 RID: 455
	internal abstract class DerivedType : Type
	{
		// Token: 0x06001106 RID: 4358 RVA: 0x000463F4 File Offset: 0x000445F4
		internal DerivedType(Type elementType)
		{
			this.elementType = elementType;
		}

		// Token: 0x06001107 RID: 4359
		[MethodImpl(4096)]
		internal static extern void create_unmanaged_type(Type type);

		// Token: 0x06001108 RID: 4360
		internal abstract string FormatName(string elementName);

		// Token: 0x06001109 RID: 4361 RVA: 0x00046404 File Offset: 0x00044604
		public override Type[] GetInterfaces()
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600110A RID: 4362 RVA: 0x0004640C File Offset: 0x0004460C
		public override Type GetElementType()
		{
			return this.elementType;
		}

		// Token: 0x0600110B RID: 4363 RVA: 0x00046414 File Offset: 0x00044614
		public override EventInfo GetEvent(string name, BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600110C RID: 4364 RVA: 0x0004641C File Offset: 0x0004461C
		public override EventInfo[] GetEvents(BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600110D RID: 4365 RVA: 0x00046424 File Offset: 0x00044624
		public override FieldInfo GetField(string name, BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600110E RID: 4366 RVA: 0x0004642C File Offset: 0x0004462C
		public override FieldInfo[] GetFields(BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600110F RID: 4367 RVA: 0x00046434 File Offset: 0x00044634
		protected override MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001110 RID: 4368 RVA: 0x0004643C File Offset: 0x0004463C
		public override MethodInfo[] GetMethods(BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001111 RID: 4369 RVA: 0x00046444 File Offset: 0x00044644
		public override Type[] GetNestedTypes(BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001112 RID: 4370 RVA: 0x0004644C File Offset: 0x0004464C
		public override PropertyInfo[] GetProperties(BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001113 RID: 4371 RVA: 0x00046454 File Offset: 0x00044654
		protected override PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001114 RID: 4372 RVA: 0x0004645C File Offset: 0x0004465C
		protected override ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001115 RID: 4373 RVA: 0x00046464 File Offset: 0x00044664
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			return this.elementType.Attributes;
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x00046474 File Offset: 0x00044674
		protected override bool HasElementTypeImpl()
		{
			return true;
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x00046478 File Offset: 0x00044678
		protected override bool IsArrayImpl()
		{
			return false;
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x0004647C File Offset: 0x0004467C
		protected override bool IsByRefImpl()
		{
			return false;
		}

		// Token: 0x06001119 RID: 4377 RVA: 0x00046480 File Offset: 0x00044680
		protected override bool IsPointerImpl()
		{
			return false;
		}

		// Token: 0x0600111A RID: 4378 RVA: 0x00046484 File Offset: 0x00044684
		protected override bool IsPrimitiveImpl()
		{
			return false;
		}

		// Token: 0x0600111B RID: 4379 RVA: 0x00046488 File Offset: 0x00044688
		public override ConstructorInfo[] GetConstructors(BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600111C RID: 4380 RVA: 0x00046490 File Offset: 0x00044690
		public override object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600111D RID: 4381 RVA: 0x00046498 File Offset: 0x00044698
		public override bool IsInstanceOfType(object o)
		{
			return false;
		}

		// Token: 0x0600111E RID: 4382 RVA: 0x0004649C File Offset: 0x0004469C
		public override bool IsAssignableFrom(Type c)
		{
			return false;
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x0600111F RID: 4383 RVA: 0x000464A0 File Offset: 0x000446A0
		public override bool ContainsGenericParameters
		{
			get
			{
				return this.elementType.ContainsGenericParameters;
			}
		}

		// Token: 0x06001120 RID: 4384 RVA: 0x000464B0 File Offset: 0x000446B0
		public override Type MakeGenericType(params Type[] typeArguments)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001121 RID: 4385 RVA: 0x000464B8 File Offset: 0x000446B8
		public override Type MakeArrayType()
		{
			return new ArrayType(this, 0);
		}

		// Token: 0x06001122 RID: 4386 RVA: 0x000464C4 File Offset: 0x000446C4
		public override Type MakeArrayType(int rank)
		{
			if (rank < 1)
			{
				throw new IndexOutOfRangeException();
			}
			return new ArrayType(this, rank);
		}

		// Token: 0x06001123 RID: 4387 RVA: 0x000464DC File Offset: 0x000446DC
		public override Type MakeByRefType()
		{
			return new ByRefType(this);
		}

		// Token: 0x06001124 RID: 4388 RVA: 0x000464E4 File Offset: 0x000446E4
		public override Type MakePointerType()
		{
			return new PointerType(this);
		}

		// Token: 0x06001125 RID: 4389 RVA: 0x000464EC File Offset: 0x000446EC
		public override string ToString()
		{
			return this.FormatName(this.elementType.ToString());
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06001126 RID: 4390 RVA: 0x00046500 File Offset: 0x00044700
		public override Assembly Assembly
		{
			get
			{
				return this.elementType.Assembly;
			}
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x06001127 RID: 4391 RVA: 0x00046510 File Offset: 0x00044710
		public override string AssemblyQualifiedName
		{
			get
			{
				string text = this.FormatName(this.elementType.FullName);
				if (text == null)
				{
					return null;
				}
				return text + ", " + this.elementType.Assembly.FullName;
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06001128 RID: 4392 RVA: 0x00046554 File Offset: 0x00044754
		public override string FullName
		{
			get
			{
				return this.FormatName(this.elementType.FullName);
			}
		}

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x06001129 RID: 4393 RVA: 0x00046568 File Offset: 0x00044768
		public override string Name
		{
			get
			{
				return this.FormatName(this.elementType.Name);
			}
		}

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x0600112A RID: 4394 RVA: 0x0004657C File Offset: 0x0004477C
		public override Guid GUID
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x0600112B RID: 4395 RVA: 0x00046584 File Offset: 0x00044784
		public override Module Module
		{
			get
			{
				return this.elementType.Module;
			}
		}

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x0600112C RID: 4396 RVA: 0x00046594 File Offset: 0x00044794
		public override string Namespace
		{
			get
			{
				return this.elementType.Namespace;
			}
		}

		// Token: 0x17000295 RID: 661
		// (get) Token: 0x0600112D RID: 4397 RVA: 0x000465A4 File Offset: 0x000447A4
		public override RuntimeTypeHandle TypeHandle
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x0600112E RID: 4398 RVA: 0x000465AC File Offset: 0x000447AC
		public override Type UnderlyingSystemType
		{
			get
			{
				DerivedType.create_unmanaged_type(this);
				return this;
			}
		}

		// Token: 0x0600112F RID: 4399 RVA: 0x000465B8 File Offset: 0x000447B8
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x000465C0 File Offset: 0x000447C0
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001131 RID: 4401 RVA: 0x000465C8 File Offset: 0x000447C8
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x04000731 RID: 1841
		internal Type elementType;
	}
}
