﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001C8 RID: 456
	[ComVisible(true)]
	public sealed class DynamicMethod : MethodInfo
	{
		// Token: 0x06001132 RID: 4402 RVA: 0x000465D0 File Offset: 0x000447D0
		public DynamicMethod(string name, Type returnType, Type[] parameterTypes, Type owner)
			: this(name, returnType, parameterTypes, owner, false)
		{
		}

		// Token: 0x06001133 RID: 4403 RVA: 0x000465E0 File Offset: 0x000447E0
		public DynamicMethod(string name, Type returnType, Type[] parameterTypes, Type owner, bool skipVisibility)
			: this(name, MethodAttributes.FamANDAssem | MethodAttributes.Family | MethodAttributes.Static, CallingConventions.Standard, returnType, parameterTypes, owner, skipVisibility)
		{
		}

		// Token: 0x06001134 RID: 4404 RVA: 0x00046600 File Offset: 0x00044800
		public DynamicMethod(string name, MethodAttributes attributes, CallingConventions callingConvention, Type returnType, Type[] parameterTypes, Type owner, bool skipVisibility)
			: this(name, attributes, callingConvention, returnType, parameterTypes, owner, owner.Module, skipVisibility, false)
		{
		}

		// Token: 0x06001135 RID: 4405 RVA: 0x00046628 File Offset: 0x00044828
		private DynamicMethod(string name, MethodAttributes attributes, CallingConventions callingConvention, Type returnType, Type[] parameterTypes, Type owner, Module m, bool skipVisibility, bool anonHosted)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			if (returnType == null)
			{
				returnType = typeof(void);
			}
			if (m == null && !anonHosted)
			{
				throw new ArgumentNullException("m");
			}
			if (returnType.IsByRef)
			{
				throw new ArgumentException("Return type can't be a byref type", "returnType");
			}
			if (parameterTypes != null)
			{
				for (int i = 0; i < parameterTypes.Length; i++)
				{
					if (parameterTypes[i] == null)
					{
						throw new ArgumentException("Parameter " + i + " is null", "parameterTypes");
					}
				}
			}
			if (m == null)
			{
				m = DynamicMethod.AnonHostModuleHolder.anon_host_module;
			}
			this.name = name;
			this.attributes = attributes | MethodAttributes.Static;
			this.callingConvention = callingConvention;
			this.returnType = returnType;
			this.parameters = parameterTypes;
			this.owner = owner;
			this.module = m;
			this.skipVisibility = skipVisibility;
		}

		// Token: 0x06001136 RID: 4406
		[MethodImpl(4096)]
		private extern void create_dynamic_method(DynamicMethod m);

		// Token: 0x06001137 RID: 4407
		[MethodImpl(4096)]
		private extern void destroy_dynamic_method(DynamicMethod m);

		// Token: 0x06001138 RID: 4408 RVA: 0x00046730 File Offset: 0x00044930
		private void CreateDynMethod()
		{
			if (this.mhandle.Value == IntPtr.Zero)
			{
				if (this.ilgen == null || ILGenerator.Mono_GetCurrentOffset(this.ilgen) == 0)
				{
					throw new InvalidOperationException("Method '" + this.name + "' does not have a method body.");
				}
				this.ilgen.label_fixup();
				try
				{
					this.creating = true;
					if (this.refs != null)
					{
						for (int i = 0; i < this.refs.Length; i++)
						{
							if (this.refs[i] is DynamicMethod)
							{
								DynamicMethod dynamicMethod = (DynamicMethod)this.refs[i];
								if (!dynamicMethod.creating)
								{
									dynamicMethod.CreateDynMethod();
								}
							}
						}
					}
				}
				finally
				{
					this.creating = false;
				}
				this.create_dynamic_method(this);
			}
		}

		// Token: 0x06001139 RID: 4409 RVA: 0x00046818 File Offset: 0x00044A18
		~DynamicMethod()
		{
			this.destroy_dynamic_method(this);
		}

		// Token: 0x0600113A RID: 4410 RVA: 0x00046848 File Offset: 0x00044A48
		[ComVisible(true)]
		public Delegate CreateDelegate(Type delegateType)
		{
			if (delegateType == null)
			{
				throw new ArgumentNullException("delegateType");
			}
			if (this.deleg != null)
			{
				return this.deleg;
			}
			this.CreateDynMethod();
			this.deleg = Delegate.CreateDelegate(delegateType, this);
			return this.deleg;
		}

		// Token: 0x0600113B RID: 4411 RVA: 0x00046888 File Offset: 0x00044A88
		public override MethodInfo GetBaseDefinition()
		{
			return this;
		}

		// Token: 0x0600113C RID: 4412 RVA: 0x0004688C File Offset: 0x00044A8C
		[MonoTODO("Not implemented")]
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600113D RID: 4413 RVA: 0x00046894 File Offset: 0x00044A94
		[MonoTODO("Not implemented")]
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600113E RID: 4414 RVA: 0x0004689C File Offset: 0x00044A9C
		public ILGenerator GetILGenerator()
		{
			return this.GetILGenerator(64);
		}

		// Token: 0x0600113F RID: 4415 RVA: 0x000468A8 File Offset: 0x00044AA8
		public ILGenerator GetILGenerator(int streamSize)
		{
			if ((this.GetMethodImplementationFlags() & MethodImplAttributes.CodeTypeMask) != MethodImplAttributes.IL || (this.GetMethodImplementationFlags() & MethodImplAttributes.ManagedMask) != MethodImplAttributes.IL)
			{
				throw new InvalidOperationException("Method body should not exist.");
			}
			if (this.ilgen != null)
			{
				return this.ilgen;
			}
			this.ilgen = new ILGenerator(this.Module, new DynamicMethodTokenGenerator(this), streamSize);
			return this.ilgen;
		}

		// Token: 0x06001140 RID: 4416 RVA: 0x0004690C File Offset: 0x00044B0C
		public override MethodImplAttributes GetMethodImplementationFlags()
		{
			return MethodImplAttributes.IL;
		}

		// Token: 0x06001141 RID: 4417 RVA: 0x00046910 File Offset: 0x00044B10
		public override ParameterInfo[] GetParameters()
		{
			if (this.parameters == null)
			{
				return new ParameterInfo[0];
			}
			ParameterInfo[] array = new ParameterInfo[this.parameters.Length];
			for (int i = 0; i < this.parameters.Length; i++)
			{
				array[i] = new ParameterInfo((this.pinfo != null) ? this.pinfo[i + 1] : null, this.parameters[i], this, i + 1);
			}
			return array;
		}

		// Token: 0x06001142 RID: 4418 RVA: 0x00046988 File Offset: 0x00044B88
		public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			object obj2;
			try
			{
				this.CreateDynMethod();
				if (this.method == null)
				{
					this.method = new MonoMethod(this.mhandle);
				}
				obj2 = this.method.Invoke(obj, parameters);
			}
			catch (MethodAccessException ex)
			{
				throw new TargetInvocationException("Method cannot be invoked.", ex);
			}
			return obj2;
		}

		// Token: 0x06001143 RID: 4419 RVA: 0x000469F4 File Offset: 0x00044BF4
		[MonoTODO("Not implemented")]
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06001144 RID: 4420 RVA: 0x000469FC File Offset: 0x00044BFC
		public override string ToString()
		{
			string text = string.Empty;
			ParameterInfo[] array = this.GetParameters();
			for (int i = 0; i < array.Length; i++)
			{
				if (i > 0)
				{
					text += ", ";
				}
				text += array[i].ParameterType.Name;
			}
			return string.Concat(new string[]
			{
				this.ReturnType.Name,
				" ",
				this.Name,
				"(",
				text,
				")"
			});
		}

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x06001145 RID: 4421 RVA: 0x00046A90 File Offset: 0x00044C90
		public override MethodAttributes Attributes
		{
			get
			{
				return this.attributes;
			}
		}

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x06001146 RID: 4422 RVA: 0x00046A98 File Offset: 0x00044C98
		public override CallingConventions CallingConvention
		{
			get
			{
				return this.callingConvention;
			}
		}

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x06001147 RID: 4423 RVA: 0x00046AA0 File Offset: 0x00044CA0
		public override Type DeclaringType
		{
			get
			{
				return null;
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x06001148 RID: 4424 RVA: 0x00046AA4 File Offset: 0x00044CA4
		public override RuntimeMethodHandle MethodHandle
		{
			get
			{
				return this.mhandle;
			}
		}

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x06001149 RID: 4425 RVA: 0x00046AAC File Offset: 0x00044CAC
		public override Module Module
		{
			get
			{
				return this.module;
			}
		}

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x0600114A RID: 4426 RVA: 0x00046AB4 File Offset: 0x00044CB4
		public override string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x0600114B RID: 4427 RVA: 0x00046ABC File Offset: 0x00044CBC
		public override Type ReflectedType
		{
			get
			{
				return null;
			}
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x0600114C RID: 4428 RVA: 0x00046AC0 File Offset: 0x00044CC0
		public override Type ReturnType
		{
			get
			{
				return this.returnType;
			}
		}

		// Token: 0x0600114D RID: 4429 RVA: 0x00046AC8 File Offset: 0x00044CC8
		internal int AddRef(object reference)
		{
			if (this.refs == null)
			{
				this.refs = new object[4];
			}
			if (this.nrefs >= this.refs.Length - 1)
			{
				object[] array = new object[this.refs.Length * 2];
				Array.Copy(this.refs, array, this.refs.Length);
				this.refs = array;
			}
			this.refs[this.nrefs] = reference;
			this.refs[this.nrefs + 1] = null;
			this.nrefs += 2;
			return this.nrefs - 1;
		}

		// Token: 0x04000732 RID: 1842
		private RuntimeMethodHandle mhandle;

		// Token: 0x04000733 RID: 1843
		private string name;

		// Token: 0x04000734 RID: 1844
		private Type returnType;

		// Token: 0x04000735 RID: 1845
		private Type[] parameters;

		// Token: 0x04000736 RID: 1846
		private MethodAttributes attributes;

		// Token: 0x04000737 RID: 1847
		private CallingConventions callingConvention;

		// Token: 0x04000738 RID: 1848
		private Module module;

		// Token: 0x04000739 RID: 1849
		private bool skipVisibility;

		// Token: 0x0400073A RID: 1850
		private bool init_locals = true;

		// Token: 0x0400073B RID: 1851
		private ILGenerator ilgen;

		// Token: 0x0400073C RID: 1852
		private int nrefs;

		// Token: 0x0400073D RID: 1853
		private object[] refs;

		// Token: 0x0400073E RID: 1854
		private IntPtr referenced_by;

		// Token: 0x0400073F RID: 1855
		private Type owner;

		// Token: 0x04000740 RID: 1856
		private Delegate deleg;

		// Token: 0x04000741 RID: 1857
		private MonoMethod method;

		// Token: 0x04000742 RID: 1858
		private ParameterBuilder[] pinfo;

		// Token: 0x04000743 RID: 1859
		internal bool creating;

		// Token: 0x020001C9 RID: 457
		private class AnonHostModuleHolder
		{
			// Token: 0x0600114E RID: 4430 RVA: 0x00046B60 File Offset: 0x00044D60
			static AnonHostModuleHolder()
			{
				AssemblyName assemblyName = new AssemblyName();
				assemblyName.Name = "Anonymously Hosted DynamicMethods Assembly";
				AssemblyBuilder assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
				DynamicMethod.AnonHostModuleHolder.anon_host_module = assemblyBuilder.GetManifestModule();
			}

			// Token: 0x04000744 RID: 1860
			public static Module anon_host_module;
		}
	}
}
