﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001CA RID: 458
	internal class DynamicMethodTokenGenerator : TokenGenerator
	{
		// Token: 0x0600114F RID: 4431 RVA: 0x00046B98 File Offset: 0x00044D98
		public DynamicMethodTokenGenerator(DynamicMethod m)
		{
			this.m = m;
		}

		// Token: 0x06001150 RID: 4432 RVA: 0x00046BA8 File Offset: 0x00044DA8
		public int GetToken(string str)
		{
			return this.m.AddRef(str);
		}

		// Token: 0x06001151 RID: 4433 RVA: 0x00046BB8 File Offset: 0x00044DB8
		public int GetToken(MethodInfo method, Type[] opt_param_types)
		{
			throw new InvalidOperationException();
		}

		// Token: 0x06001152 RID: 4434 RVA: 0x00046BC0 File Offset: 0x00044DC0
		public int GetToken(MemberInfo member)
		{
			return this.m.AddRef(member);
		}

		// Token: 0x04000745 RID: 1861
		private DynamicMethod m;
	}
}
