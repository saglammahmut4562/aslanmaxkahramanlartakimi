﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001CB RID: 459
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_EnumBuilder))]
	public sealed class EnumBuilder : Type, _EnumBuilder
	{
		// Token: 0x1700029F RID: 671
		// (get) Token: 0x06001153 RID: 4435 RVA: 0x00046BD0 File Offset: 0x00044DD0
		public override Assembly Assembly
		{
			get
			{
				return this._tb.Assembly;
			}
		}

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x06001154 RID: 4436 RVA: 0x00046BE0 File Offset: 0x00044DE0
		public override string AssemblyQualifiedName
		{
			get
			{
				return this._tb.AssemblyQualifiedName;
			}
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x06001155 RID: 4437 RVA: 0x00046BF0 File Offset: 0x00044DF0
		public override Type BaseType
		{
			get
			{
				return this._tb.BaseType;
			}
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x06001156 RID: 4438 RVA: 0x00046C00 File Offset: 0x00044E00
		public override Type DeclaringType
		{
			get
			{
				return this._tb.DeclaringType;
			}
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x06001157 RID: 4439 RVA: 0x00046C10 File Offset: 0x00044E10
		public override string FullName
		{
			get
			{
				return this._tb.FullName;
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x06001158 RID: 4440 RVA: 0x00046C20 File Offset: 0x00044E20
		public override Guid GUID
		{
			get
			{
				return this._tb.GUID;
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x06001159 RID: 4441 RVA: 0x00046C30 File Offset: 0x00044E30
		public override Module Module
		{
			get
			{
				return this._tb.Module;
			}
		}

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x0600115A RID: 4442 RVA: 0x00046C40 File Offset: 0x00044E40
		public override string Name
		{
			get
			{
				return this._tb.Name;
			}
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x0600115B RID: 4443 RVA: 0x00046C50 File Offset: 0x00044E50
		public override string Namespace
		{
			get
			{
				return this._tb.Namespace;
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x0600115C RID: 4444 RVA: 0x00046C60 File Offset: 0x00044E60
		public override Type ReflectedType
		{
			get
			{
				return this._tb.ReflectedType;
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x0600115D RID: 4445 RVA: 0x00046C70 File Offset: 0x00044E70
		public override RuntimeTypeHandle TypeHandle
		{
			get
			{
				return this._tb.TypeHandle;
			}
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x0600115E RID: 4446 RVA: 0x00046C80 File Offset: 0x00044E80
		public override Type UnderlyingSystemType
		{
			get
			{
				return this._underlyingType;
			}
		}

		// Token: 0x0600115F RID: 4447 RVA: 0x00046C88 File Offset: 0x00044E88
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			return this._tb.attrs;
		}

		// Token: 0x06001160 RID: 4448 RVA: 0x00046C98 File Offset: 0x00044E98
		protected override ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			return this._tb.GetConstructor(bindingAttr, binder, callConvention, types, modifiers);
		}

		// Token: 0x06001161 RID: 4449 RVA: 0x00046CAC File Offset: 0x00044EAC
		[ComVisible(true)]
		public override ConstructorInfo[] GetConstructors(BindingFlags bindingAttr)
		{
			return this._tb.GetConstructors(bindingAttr);
		}

		// Token: 0x06001162 RID: 4450 RVA: 0x00046CBC File Offset: 0x00044EBC
		public override object[] GetCustomAttributes(bool inherit)
		{
			return this._tb.GetCustomAttributes(inherit);
		}

		// Token: 0x06001163 RID: 4451 RVA: 0x00046CCC File Offset: 0x00044ECC
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return this._tb.GetCustomAttributes(attributeType, inherit);
		}

		// Token: 0x06001164 RID: 4452 RVA: 0x00046CDC File Offset: 0x00044EDC
		public override Type GetElementType()
		{
			return this._tb.GetElementType();
		}

		// Token: 0x06001165 RID: 4453 RVA: 0x00046CEC File Offset: 0x00044EEC
		public override EventInfo GetEvent(string name, BindingFlags bindingAttr)
		{
			return this._tb.GetEvent(name, bindingAttr);
		}

		// Token: 0x06001166 RID: 4454 RVA: 0x00046CFC File Offset: 0x00044EFC
		public override EventInfo[] GetEvents(BindingFlags bindingAttr)
		{
			return this._tb.GetEvents(bindingAttr);
		}

		// Token: 0x06001167 RID: 4455 RVA: 0x00046D0C File Offset: 0x00044F0C
		public override FieldInfo GetField(string name, BindingFlags bindingAttr)
		{
			return this._tb.GetField(name, bindingAttr);
		}

		// Token: 0x06001168 RID: 4456 RVA: 0x00046D1C File Offset: 0x00044F1C
		public override FieldInfo[] GetFields(BindingFlags bindingAttr)
		{
			return this._tb.GetFields(bindingAttr);
		}

		// Token: 0x06001169 RID: 4457 RVA: 0x00046D2C File Offset: 0x00044F2C
		public override Type[] GetInterfaces()
		{
			return this._tb.GetInterfaces();
		}

		// Token: 0x0600116A RID: 4458 RVA: 0x00046D3C File Offset: 0x00044F3C
		public override MemberInfo[] GetMember(string name, MemberTypes type, BindingFlags bindingAttr)
		{
			return this._tb.GetMember(name, type, bindingAttr);
		}

		// Token: 0x0600116B RID: 4459 RVA: 0x00046D4C File Offset: 0x00044F4C
		protected override MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			if (types == null)
			{
				return this._tb.GetMethod(name, bindingAttr);
			}
			return this._tb.GetMethod(name, bindingAttr, binder, callConvention, types, modifiers);
		}

		// Token: 0x0600116C RID: 4460 RVA: 0x00046D78 File Offset: 0x00044F78
		public override MethodInfo[] GetMethods(BindingFlags bindingAttr)
		{
			return this._tb.GetMethods(bindingAttr);
		}

		// Token: 0x0600116D RID: 4461 RVA: 0x00046D88 File Offset: 0x00044F88
		public override Type[] GetNestedTypes(BindingFlags bindingAttr)
		{
			return this._tb.GetNestedTypes(bindingAttr);
		}

		// Token: 0x0600116E RID: 4462 RVA: 0x00046D98 File Offset: 0x00044F98
		public override PropertyInfo[] GetProperties(BindingFlags bindingAttr)
		{
			return this._tb.GetProperties(bindingAttr);
		}

		// Token: 0x0600116F RID: 4463 RVA: 0x00046DA8 File Offset: 0x00044FA8
		protected override PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
		{
			throw this.CreateNotSupportedException();
		}

		// Token: 0x06001170 RID: 4464 RVA: 0x00046DB0 File Offset: 0x00044FB0
		protected override bool HasElementTypeImpl()
		{
			return this._tb.HasElementType;
		}

		// Token: 0x06001171 RID: 4465 RVA: 0x00046DC0 File Offset: 0x00044FC0
		public override object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters)
		{
			return this._tb.InvokeMember(name, invokeAttr, binder, target, args, modifiers, culture, namedParameters);
		}

		// Token: 0x06001172 RID: 4466 RVA: 0x00046DE8 File Offset: 0x00044FE8
		protected override bool IsArrayImpl()
		{
			return false;
		}

		// Token: 0x06001173 RID: 4467 RVA: 0x00046DEC File Offset: 0x00044FEC
		protected override bool IsByRefImpl()
		{
			return false;
		}

		// Token: 0x06001174 RID: 4468 RVA: 0x00046DF0 File Offset: 0x00044FF0
		protected override bool IsPointerImpl()
		{
			return false;
		}

		// Token: 0x06001175 RID: 4469 RVA: 0x00046DF4 File Offset: 0x00044FF4
		protected override bool IsPrimitiveImpl()
		{
			return false;
		}

		// Token: 0x06001176 RID: 4470 RVA: 0x00046DF8 File Offset: 0x00044FF8
		protected override bool IsValueTypeImpl()
		{
			return true;
		}

		// Token: 0x06001177 RID: 4471 RVA: 0x00046DFC File Offset: 0x00044FFC
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return this._tb.IsDefined(attributeType, inherit);
		}

		// Token: 0x06001178 RID: 4472 RVA: 0x00046E0C File Offset: 0x0004500C
		public override Type MakeArrayType()
		{
			return new ArrayType(this, 0);
		}

		// Token: 0x06001179 RID: 4473 RVA: 0x00046E18 File Offset: 0x00045018
		public override Type MakeArrayType(int rank)
		{
			if (rank < 1)
			{
				throw new IndexOutOfRangeException();
			}
			return new ArrayType(this, rank);
		}

		// Token: 0x0600117A RID: 4474 RVA: 0x00046E30 File Offset: 0x00045030
		public override Type MakeByRefType()
		{
			return new ByRefType(this);
		}

		// Token: 0x0600117B RID: 4475 RVA: 0x00046E38 File Offset: 0x00045038
		public override Type MakePointerType()
		{
			return new PointerType(this);
		}

		// Token: 0x0600117C RID: 4476 RVA: 0x00046E40 File Offset: 0x00045040
		private Exception CreateNotSupportedException()
		{
			return new NotSupportedException("The invoked member is not supported in a dynamic module.");
		}

		// Token: 0x04000746 RID: 1862
		private TypeBuilder _tb;

		// Token: 0x04000747 RID: 1863
		private FieldBuilder _underlyingField;

		// Token: 0x04000748 RID: 1864
		private Type _underlyingType;
	}
}
