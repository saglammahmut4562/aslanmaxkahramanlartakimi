﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001CC RID: 460
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_EventBuilder))]
	public sealed class EventBuilder : _EventBuilder
	{
		// Token: 0x04000749 RID: 1865
		internal string name;

		// Token: 0x0400074A RID: 1866
		private Type type;

		// Token: 0x0400074B RID: 1867
		private TypeBuilder typeb;

		// Token: 0x0400074C RID: 1868
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x0400074D RID: 1869
		internal MethodBuilder add_method;

		// Token: 0x0400074E RID: 1870
		internal MethodBuilder remove_method;

		// Token: 0x0400074F RID: 1871
		internal MethodBuilder raise_method;

		// Token: 0x04000750 RID: 1872
		internal MethodBuilder[] other_methods;

		// Token: 0x04000751 RID: 1873
		internal EventAttributes attrs;

		// Token: 0x04000752 RID: 1874
		private int table_idx;
	}
}
