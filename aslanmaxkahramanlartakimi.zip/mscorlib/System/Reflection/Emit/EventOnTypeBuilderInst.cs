﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001CD RID: 461
	internal class EventOnTypeBuilderInst : EventInfo
	{
		// Token: 0x0600117D RID: 4477 RVA: 0x00046E4C File Offset: 0x0004504C
		internal EventOnTypeBuilderInst(MonoGenericClass instantiation, EventBuilder evt)
		{
			this.instantiation = instantiation;
			this.evt = evt;
		}

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x0600117E RID: 4478 RVA: 0x00046E64 File Offset: 0x00045064
		public override EventAttributes Attributes
		{
			get
			{
				return this.evt.attrs;
			}
		}

		// Token: 0x0600117F RID: 4479 RVA: 0x00046E74 File Offset: 0x00045074
		public override MethodInfo GetAddMethod(bool nonPublic)
		{
			if (this.evt.add_method == null || (!nonPublic && !this.evt.add_method.IsPublic))
			{
				return null;
			}
			return TypeBuilder.GetMethod(this.instantiation, this.evt.add_method);
		}

		// Token: 0x06001180 RID: 4480 RVA: 0x00046EC4 File Offset: 0x000450C4
		public override MethodInfo GetRemoveMethod(bool nonPublic)
		{
			if (this.evt.remove_method == null || (!nonPublic && !this.evt.remove_method.IsPublic))
			{
				return null;
			}
			return TypeBuilder.GetMethod(this.instantiation, this.evt.remove_method);
		}

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x06001181 RID: 4481 RVA: 0x00046F14 File Offset: 0x00045114
		public override Type DeclaringType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x06001182 RID: 4482 RVA: 0x00046F1C File Offset: 0x0004511C
		public override string Name
		{
			get
			{
				return this.evt.name;
			}
		}

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x06001183 RID: 4483 RVA: 0x00046F2C File Offset: 0x0004512C
		public override Type ReflectedType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x06001184 RID: 4484 RVA: 0x00046F34 File Offset: 0x00045134
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001185 RID: 4485 RVA: 0x00046F3C File Offset: 0x0004513C
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001186 RID: 4486 RVA: 0x00046F44 File Offset: 0x00045144
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x04000753 RID: 1875
		private MonoGenericClass instantiation;

		// Token: 0x04000754 RID: 1876
		private EventBuilder evt;
	}
}
