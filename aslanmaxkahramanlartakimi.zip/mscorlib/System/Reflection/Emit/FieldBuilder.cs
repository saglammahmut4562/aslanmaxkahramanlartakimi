﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001CE RID: 462
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_FieldBuilder))]
	[ClassInterface(ClassInterfaceType.None)]
	public sealed class FieldBuilder : FieldInfo, _FieldBuilder
	{
		// Token: 0x170002AF RID: 687
		// (get) Token: 0x06001187 RID: 4487 RVA: 0x00046F4C File Offset: 0x0004514C
		public override FieldAttributes Attributes
		{
			get
			{
				return this.attrs;
			}
		}

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x06001188 RID: 4488 RVA: 0x00046F54 File Offset: 0x00045154
		public override Type DeclaringType
		{
			get
			{
				return this.typeb;
			}
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x06001189 RID: 4489 RVA: 0x00046F5C File Offset: 0x0004515C
		public override RuntimeFieldHandle FieldHandle
		{
			get
			{
				throw this.CreateNotSupportedException();
			}
		}

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x0600118A RID: 4490 RVA: 0x00046F64 File Offset: 0x00045164
		public override Type FieldType
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x0600118B RID: 4491 RVA: 0x00046F6C File Offset: 0x0004516C
		public override string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x0600118C RID: 4492 RVA: 0x00046F74 File Offset: 0x00045174
		public override Type ReflectedType
		{
			get
			{
				return this.typeb;
			}
		}

		// Token: 0x0600118D RID: 4493 RVA: 0x00046F7C File Offset: 0x0004517C
		public override object[] GetCustomAttributes(bool inherit)
		{
			if (this.typeb.is_created)
			{
				return MonoCustomAttrs.GetCustomAttributes(this, inherit);
			}
			throw this.CreateNotSupportedException();
		}

		// Token: 0x0600118E RID: 4494 RVA: 0x00046F9C File Offset: 0x0004519C
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			if (this.typeb.is_created)
			{
				return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
			}
			throw this.CreateNotSupportedException();
		}

		// Token: 0x0600118F RID: 4495 RVA: 0x00046FC0 File Offset: 0x000451C0
		public override object GetValue(object obj)
		{
			throw this.CreateNotSupportedException();
		}

		// Token: 0x06001190 RID: 4496 RVA: 0x00046FC8 File Offset: 0x000451C8
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw this.CreateNotSupportedException();
		}

		// Token: 0x06001191 RID: 4497 RVA: 0x00046FD0 File Offset: 0x000451D0
		internal override int GetFieldOffset()
		{
			return 0;
		}

		// Token: 0x06001192 RID: 4498 RVA: 0x00046FD4 File Offset: 0x000451D4
		public override void SetValue(object obj, object val, BindingFlags invokeAttr, Binder binder, CultureInfo culture)
		{
			throw this.CreateNotSupportedException();
		}

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x06001193 RID: 4499 RVA: 0x00046FDC File Offset: 0x000451DC
		internal override UnmanagedMarshal UMarshal
		{
			get
			{
				return this.marshal_info;
			}
		}

		// Token: 0x06001194 RID: 4500 RVA: 0x00046FE4 File Offset: 0x000451E4
		private Exception CreateNotSupportedException()
		{
			return new NotSupportedException("The invoked member is not supported in a dynamic module.");
		}

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x06001195 RID: 4501 RVA: 0x00046FF0 File Offset: 0x000451F0
		public override Module Module
		{
			get
			{
				return base.Module;
			}
		}

		// Token: 0x04000755 RID: 1877
		private FieldAttributes attrs;

		// Token: 0x04000756 RID: 1878
		private Type type;

		// Token: 0x04000757 RID: 1879
		private string name;

		// Token: 0x04000758 RID: 1880
		private object def_value;

		// Token: 0x04000759 RID: 1881
		private int offset;

		// Token: 0x0400075A RID: 1882
		private int table_idx;

		// Token: 0x0400075B RID: 1883
		internal TypeBuilder typeb;

		// Token: 0x0400075C RID: 1884
		private byte[] rva_data;

		// Token: 0x0400075D RID: 1885
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x0400075E RID: 1886
		private UnmanagedMarshal marshal_info;

		// Token: 0x0400075F RID: 1887
		private RuntimeFieldHandle handle;

		// Token: 0x04000760 RID: 1888
		private Type[] modReq;

		// Token: 0x04000761 RID: 1889
		private Type[] modOpt;
	}
}
