﻿using System;
using System.Globalization;

namespace System.Reflection.Emit
{
	// Token: 0x020001CF RID: 463
	internal class FieldOnTypeBuilderInst : FieldInfo
	{
		// Token: 0x06001196 RID: 4502 RVA: 0x00046FF8 File Offset: 0x000451F8
		public FieldOnTypeBuilderInst(MonoGenericClass instantiation, FieldBuilder fb)
		{
			this.instantiation = instantiation;
			this.fb = fb;
		}

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x06001197 RID: 4503 RVA: 0x00047010 File Offset: 0x00045210
		public override Type DeclaringType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x06001198 RID: 4504 RVA: 0x00047018 File Offset: 0x00045218
		public override string Name
		{
			get
			{
				return this.fb.Name;
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x06001199 RID: 4505 RVA: 0x00047028 File Offset: 0x00045228
		public override Type ReflectedType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x0600119A RID: 4506 RVA: 0x00047030 File Offset: 0x00045230
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600119B RID: 4507 RVA: 0x00047038 File Offset: 0x00045238
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600119C RID: 4508 RVA: 0x00047040 File Offset: 0x00045240
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600119D RID: 4509 RVA: 0x00047048 File Offset: 0x00045248
		public override string ToString()
		{
			if (!((ModuleBuilder)this.instantiation.generic_type.Module).assemblyb.IsCompilerContext)
			{
				return this.fb.FieldType.ToString() + " " + this.Name;
			}
			return this.FieldType.ToString() + " " + this.Name;
		}

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x0600119E RID: 4510 RVA: 0x000470B8 File Offset: 0x000452B8
		public override FieldAttributes Attributes
		{
			get
			{
				return this.fb.Attributes;
			}
		}

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x0600119F RID: 4511 RVA: 0x000470C8 File Offset: 0x000452C8
		public override RuntimeFieldHandle FieldHandle
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x060011A0 RID: 4512 RVA: 0x000470D0 File Offset: 0x000452D0
		public override Type FieldType
		{
			get
			{
				if (!((ModuleBuilder)this.instantiation.generic_type.Module).assemblyb.IsCompilerContext)
				{
					throw new NotSupportedException();
				}
				return this.instantiation.InflateType(this.fb.FieldType);
			}
		}

		// Token: 0x060011A1 RID: 4513 RVA: 0x00047120 File Offset: 0x00045320
		public override object GetValue(object obj)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060011A2 RID: 4514 RVA: 0x00047128 File Offset: 0x00045328
		public override void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, CultureInfo culture)
		{
			throw new NotSupportedException();
		}

		// Token: 0x04000762 RID: 1890
		internal MonoGenericClass instantiation;

		// Token: 0x04000763 RID: 1891
		internal FieldBuilder fb;
	}
}
