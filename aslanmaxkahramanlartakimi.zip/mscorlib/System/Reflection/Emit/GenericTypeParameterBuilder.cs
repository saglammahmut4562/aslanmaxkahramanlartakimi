﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001D0 RID: 464
	[ComVisible(true)]
	public sealed class GenericTypeParameterBuilder : Type
	{
		// Token: 0x060011A3 RID: 4515 RVA: 0x00047130 File Offset: 0x00045330
		[ComVisible(true)]
		public override bool IsSubclassOf(Type c)
		{
			if (!((ModuleBuilder)this.tbuilder.Module).assemblyb.IsCompilerContext)
			{
				throw this.not_supported();
			}
			return this.BaseType != null && (this.BaseType == c || this.BaseType.IsSubclassOf(c));
		}

		// Token: 0x060011A4 RID: 4516 RVA: 0x0004718C File Offset: 0x0004538C
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			if (((ModuleBuilder)this.tbuilder.Module).assemblyb.IsCompilerContext)
			{
				return TypeAttributes.Public;
			}
			throw this.not_supported();
		}

		// Token: 0x060011A5 RID: 4517 RVA: 0x000471B8 File Offset: 0x000453B8
		protected override ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			throw this.not_supported();
		}

		// Token: 0x060011A6 RID: 4518 RVA: 0x000471C0 File Offset: 0x000453C0
		[ComVisible(true)]
		public override ConstructorInfo[] GetConstructors(BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011A7 RID: 4519 RVA: 0x000471C8 File Offset: 0x000453C8
		public override EventInfo GetEvent(string name, BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011A8 RID: 4520 RVA: 0x000471D0 File Offset: 0x000453D0
		public override EventInfo[] GetEvents(BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011A9 RID: 4521 RVA: 0x000471D8 File Offset: 0x000453D8
		public override FieldInfo GetField(string name, BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011AA RID: 4522 RVA: 0x000471E0 File Offset: 0x000453E0
		public override FieldInfo[] GetFields(BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011AB RID: 4523 RVA: 0x000471E8 File Offset: 0x000453E8
		public override Type[] GetInterfaces()
		{
			throw this.not_supported();
		}

		// Token: 0x060011AC RID: 4524 RVA: 0x000471F0 File Offset: 0x000453F0
		public override MemberInfo[] GetMember(string name, MemberTypes type, BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011AD RID: 4525 RVA: 0x000471F8 File Offset: 0x000453F8
		public override MethodInfo[] GetMethods(BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011AE RID: 4526 RVA: 0x00047200 File Offset: 0x00045400
		protected override MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			throw this.not_supported();
		}

		// Token: 0x060011AF RID: 4527 RVA: 0x00047208 File Offset: 0x00045408
		public override Type[] GetNestedTypes(BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011B0 RID: 4528 RVA: 0x00047210 File Offset: 0x00045410
		public override PropertyInfo[] GetProperties(BindingFlags bindingAttr)
		{
			throw this.not_supported();
		}

		// Token: 0x060011B1 RID: 4529 RVA: 0x00047218 File Offset: 0x00045418
		protected override PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
		{
			throw this.not_supported();
		}

		// Token: 0x060011B2 RID: 4530 RVA: 0x00047220 File Offset: 0x00045420
		protected override bool HasElementTypeImpl()
		{
			return false;
		}

		// Token: 0x060011B3 RID: 4531 RVA: 0x00047224 File Offset: 0x00045424
		public override bool IsAssignableFrom(Type c)
		{
			throw this.not_supported();
		}

		// Token: 0x060011B4 RID: 4532 RVA: 0x0004722C File Offset: 0x0004542C
		public override bool IsInstanceOfType(object o)
		{
			throw this.not_supported();
		}

		// Token: 0x060011B5 RID: 4533 RVA: 0x00047234 File Offset: 0x00045434
		protected override bool IsArrayImpl()
		{
			return false;
		}

		// Token: 0x060011B6 RID: 4534 RVA: 0x00047238 File Offset: 0x00045438
		protected override bool IsByRefImpl()
		{
			return false;
		}

		// Token: 0x060011B7 RID: 4535 RVA: 0x0004723C File Offset: 0x0004543C
		protected override bool IsPointerImpl()
		{
			return false;
		}

		// Token: 0x060011B8 RID: 4536 RVA: 0x00047240 File Offset: 0x00045440
		protected override bool IsPrimitiveImpl()
		{
			return false;
		}

		// Token: 0x060011B9 RID: 4537 RVA: 0x00047244 File Offset: 0x00045444
		protected override bool IsValueTypeImpl()
		{
			return this.base_type != null && this.base_type.IsValueType;
		}

		// Token: 0x060011BA RID: 4538 RVA: 0x00047264 File Offset: 0x00045464
		public override object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters)
		{
			throw this.not_supported();
		}

		// Token: 0x060011BB RID: 4539 RVA: 0x0004726C File Offset: 0x0004546C
		public override Type GetElementType()
		{
			throw this.not_supported();
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x060011BC RID: 4540 RVA: 0x00047274 File Offset: 0x00045474
		public override Type UnderlyingSystemType
		{
			get
			{
				return this;
			}
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x060011BD RID: 4541 RVA: 0x00047278 File Offset: 0x00045478
		public override Assembly Assembly
		{
			get
			{
				return this.tbuilder.Assembly;
			}
		}

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x060011BE RID: 4542 RVA: 0x00047288 File Offset: 0x00045488
		public override string AssemblyQualifiedName
		{
			get
			{
				return null;
			}
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x060011BF RID: 4543 RVA: 0x0004728C File Offset: 0x0004548C
		public override Type BaseType
		{
			get
			{
				return this.base_type;
			}
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x060011C0 RID: 4544 RVA: 0x00047294 File Offset: 0x00045494
		public override string FullName
		{
			get
			{
				return null;
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x060011C1 RID: 4545 RVA: 0x00047298 File Offset: 0x00045498
		public override Guid GUID
		{
			get
			{
				throw this.not_supported();
			}
		}

		// Token: 0x060011C2 RID: 4546 RVA: 0x000472A0 File Offset: 0x000454A0
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw this.not_supported();
		}

		// Token: 0x060011C3 RID: 4547 RVA: 0x000472A8 File Offset: 0x000454A8
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw this.not_supported();
		}

		// Token: 0x060011C4 RID: 4548 RVA: 0x000472B0 File Offset: 0x000454B0
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw this.not_supported();
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x060011C5 RID: 4549 RVA: 0x000472B8 File Offset: 0x000454B8
		public override string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x060011C6 RID: 4550 RVA: 0x000472C0 File Offset: 0x000454C0
		public override string Namespace
		{
			get
			{
				return null;
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x060011C7 RID: 4551 RVA: 0x000472C4 File Offset: 0x000454C4
		public override Module Module
		{
			get
			{
				return this.tbuilder.Module;
			}
		}

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x060011C8 RID: 4552 RVA: 0x000472D4 File Offset: 0x000454D4
		public override Type DeclaringType
		{
			get
			{
				return (this.mbuilder == null) ? this.tbuilder : this.mbuilder.DeclaringType;
			}
		}

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x060011C9 RID: 4553 RVA: 0x000472F8 File Offset: 0x000454F8
		public override Type ReflectedType
		{
			get
			{
				return this.DeclaringType;
			}
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x060011CA RID: 4554 RVA: 0x00047300 File Offset: 0x00045500
		public override RuntimeTypeHandle TypeHandle
		{
			get
			{
				throw this.not_supported();
			}
		}

		// Token: 0x060011CB RID: 4555 RVA: 0x00047308 File Offset: 0x00045508
		public override Type[] GetGenericArguments()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x060011CC RID: 4556 RVA: 0x00047310 File Offset: 0x00045510
		public override Type GetGenericTypeDefinition()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x060011CD RID: 4557 RVA: 0x00047318 File Offset: 0x00045518
		public override bool ContainsGenericParameters
		{
			get
			{
				return true;
			}
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x060011CE RID: 4558 RVA: 0x0004731C File Offset: 0x0004551C
		public override bool IsGenericParameter
		{
			get
			{
				return true;
			}
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x060011CF RID: 4559 RVA: 0x00047320 File Offset: 0x00045520
		public override bool IsGenericType
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x060011D0 RID: 4560 RVA: 0x00047324 File Offset: 0x00045524
		public override bool IsGenericTypeDefinition
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x060011D1 RID: 4561 RVA: 0x00047328 File Offset: 0x00045528
		public override int GenericParameterPosition
		{
			get
			{
				return this.index;
			}
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x060011D2 RID: 4562 RVA: 0x00047330 File Offset: 0x00045530
		public override MethodBase DeclaringMethod
		{
			get
			{
				return this.mbuilder;
			}
		}

		// Token: 0x060011D3 RID: 4563 RVA: 0x00047338 File Offset: 0x00045538
		private Exception not_supported()
		{
			return new NotSupportedException();
		}

		// Token: 0x060011D4 RID: 4564 RVA: 0x00047340 File Offset: 0x00045540
		public override string ToString()
		{
			return this.name;
		}

		// Token: 0x060011D5 RID: 4565 RVA: 0x00047348 File Offset: 0x00045548
		[MonoTODO]
		public override bool Equals(object o)
		{
			return base.Equals(o);
		}

		// Token: 0x060011D6 RID: 4566 RVA: 0x00047354 File Offset: 0x00045554
		[MonoTODO]
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		// Token: 0x060011D7 RID: 4567 RVA: 0x0004735C File Offset: 0x0004555C
		public override Type MakeArrayType()
		{
			return new ArrayType(this, 0);
		}

		// Token: 0x060011D8 RID: 4568 RVA: 0x00047368 File Offset: 0x00045568
		public override Type MakeArrayType(int rank)
		{
			if (rank < 1)
			{
				throw new IndexOutOfRangeException();
			}
			return new ArrayType(this, rank);
		}

		// Token: 0x060011D9 RID: 4569 RVA: 0x00047380 File Offset: 0x00045580
		public override Type MakeByRefType()
		{
			return new ByRefType(this);
		}

		// Token: 0x060011DA RID: 4570 RVA: 0x00047388 File Offset: 0x00045588
		[MonoTODO]
		public override Type MakeGenericType(params Type[] typeArguments)
		{
			return base.MakeGenericType(typeArguments);
		}

		// Token: 0x060011DB RID: 4571 RVA: 0x00047394 File Offset: 0x00045594
		public override Type MakePointerType()
		{
			return new PointerType(this);
		}

		// Token: 0x04000764 RID: 1892
		private TypeBuilder tbuilder;

		// Token: 0x04000765 RID: 1893
		private MethodBuilder mbuilder;

		// Token: 0x04000766 RID: 1894
		private string name;

		// Token: 0x04000767 RID: 1895
		private int index;

		// Token: 0x04000768 RID: 1896
		private Type base_type;

		// Token: 0x04000769 RID: 1897
		private Type[] iface_constraints;

		// Token: 0x0400076A RID: 1898
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x0400076B RID: 1899
		private GenericParameterAttributes attrs;
	}
}
