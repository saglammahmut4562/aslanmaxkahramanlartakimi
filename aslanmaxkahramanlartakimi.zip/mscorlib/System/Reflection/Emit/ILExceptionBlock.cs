﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001D1 RID: 465
	internal struct ILExceptionBlock
	{
		// Token: 0x0400076C RID: 1900
		public const int CATCH = 0;

		// Token: 0x0400076D RID: 1901
		public const int FILTER = 1;

		// Token: 0x0400076E RID: 1902
		public const int FINALLY = 2;

		// Token: 0x0400076F RID: 1903
		public const int FAULT = 4;

		// Token: 0x04000770 RID: 1904
		public const int FILTER_START = -1;

		// Token: 0x04000771 RID: 1905
		internal Type extype;

		// Token: 0x04000772 RID: 1906
		internal int type;

		// Token: 0x04000773 RID: 1907
		internal int start;

		// Token: 0x04000774 RID: 1908
		internal int len;

		// Token: 0x04000775 RID: 1909
		internal int filter_offset;
	}
}
