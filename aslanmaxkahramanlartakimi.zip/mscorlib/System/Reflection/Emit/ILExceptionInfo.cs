﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001D2 RID: 466
	internal struct ILExceptionInfo
	{
		// Token: 0x04000776 RID: 1910
		private ILExceptionBlock[] handlers;

		// Token: 0x04000777 RID: 1911
		internal int start;

		// Token: 0x04000778 RID: 1912
		private int len;

		// Token: 0x04000779 RID: 1913
		internal Label end;
	}
}
