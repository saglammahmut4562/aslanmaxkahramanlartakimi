﻿using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001D3 RID: 467
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_ILGenerator))]
	[ComVisible(true)]
	public class ILGenerator : _ILGenerator
	{
		// Token: 0x060011DC RID: 4572 RVA: 0x0004739C File Offset: 0x0004559C
		internal ILGenerator(Module m, TokenGenerator token_gen, int size)
		{
			if (size < 0)
			{
				size = 128;
			}
			this.code = new byte[size];
			this.token_fixups = new ILTokenInfo[8];
			this.module = m;
			this.token_gen = token_gen;
		}

		// Token: 0x060011DE RID: 4574 RVA: 0x000473EC File Offset: 0x000455EC
		private void add_token_fixup(MemberInfo mi)
		{
			if (this.num_token_fixups == this.token_fixups.Length)
			{
				ILTokenInfo[] array = new ILTokenInfo[this.num_token_fixups * 2];
				this.token_fixups.CopyTo(array, 0);
				this.token_fixups = array;
			}
			this.token_fixups[this.num_token_fixups].member = mi;
			this.token_fixups[this.num_token_fixups++].code_pos = this.code_len;
		}

		// Token: 0x060011DF RID: 4575 RVA: 0x0004746C File Offset: 0x0004566C
		private void make_room(int nbytes)
		{
			if (this.code_len + nbytes < this.code.Length)
			{
				return;
			}
			byte[] array = new byte[(this.code_len + nbytes) * 2 + 128];
			Array.Copy(this.code, 0, array, 0, this.code.Length);
			this.code = array;
		}

		// Token: 0x060011E0 RID: 4576 RVA: 0x000474C4 File Offset: 0x000456C4
		private void emit_int(int val)
		{
			this.code[this.code_len++] = (byte)(val & 255);
			this.code[this.code_len++] = (byte)((val >> 8) & 255);
			this.code[this.code_len++] = (byte)((val >> 16) & 255);
			this.code[this.code_len++] = (byte)((val >> 24) & 255);
		}

		// Token: 0x060011E1 RID: 4577 RVA: 0x0004755C File Offset: 0x0004575C
		private void ll_emit(OpCode opcode)
		{
			if (opcode.Size == 2)
			{
				this.code[this.code_len++] = opcode.op1;
			}
			this.code[this.code_len++] = opcode.op2;
			switch (opcode.StackBehaviourPush)
			{
			case StackBehaviour.Push1:
			case StackBehaviour.Pushi:
			case StackBehaviour.Pushi8:
			case StackBehaviour.Pushr4:
			case StackBehaviour.Pushr8:
			case StackBehaviour.Pushref:
			case StackBehaviour.Varpush:
				this.cur_stack++;
				break;
			case StackBehaviour.Push1_push1:
				this.cur_stack += 2;
				break;
			}
			if (this.max_stack < this.cur_stack)
			{
				this.max_stack = this.cur_stack;
			}
			switch (opcode.StackBehaviourPop)
			{
			case StackBehaviour.Pop1:
			case StackBehaviour.Popi:
			case StackBehaviour.Popref:
				this.cur_stack--;
				break;
			case StackBehaviour.Pop1_pop1:
			case StackBehaviour.Popi_pop1:
			case StackBehaviour.Popi_popi:
			case StackBehaviour.Popi_popi8:
			case StackBehaviour.Popi_popr4:
			case StackBehaviour.Popi_popr8:
			case StackBehaviour.Popref_pop1:
			case StackBehaviour.Popref_popi:
				this.cur_stack -= 2;
				break;
			case StackBehaviour.Popi_popi_popi:
			case StackBehaviour.Popref_popi_popi:
			case StackBehaviour.Popref_popi_popi8:
			case StackBehaviour.Popref_popi_popr4:
			case StackBehaviour.Popref_popi_popr8:
			case StackBehaviour.Popref_popi_popref:
				this.cur_stack -= 3;
				break;
			}
		}

		// Token: 0x060011E2 RID: 4578 RVA: 0x000476EC File Offset: 0x000458EC
		private static int target_len(OpCode opcode)
		{
			if (opcode.OperandType == OperandType.InlineBrTarget)
			{
				return 4;
			}
			return 1;
		}

		// Token: 0x060011E3 RID: 4579 RVA: 0x00047700 File Offset: 0x00045900
		public virtual LocalBuilder DeclareLocal(Type localType)
		{
			return this.DeclareLocal(localType, false);
		}

		// Token: 0x060011E4 RID: 4580 RVA: 0x0004770C File Offset: 0x0004590C
		public virtual LocalBuilder DeclareLocal(Type localType, bool pinned)
		{
			if (localType == null)
			{
				throw new ArgumentNullException("localType");
			}
			if (localType.IsUserType)
			{
				throw new NotSupportedException("User defined subclasses of System.Type are not yet supported.");
			}
			LocalBuilder localBuilder = new LocalBuilder(localType, this);
			localBuilder.is_pinned = pinned;
			if (this.locals != null)
			{
				LocalBuilder[] array = new LocalBuilder[this.locals.Length + 1];
				Array.Copy(this.locals, array, this.locals.Length);
				array[this.locals.Length] = localBuilder;
				this.locals = array;
			}
			else
			{
				this.locals = new LocalBuilder[1];
				this.locals[0] = localBuilder;
			}
			localBuilder.position = (ushort)(this.locals.Length - 1);
			return localBuilder;
		}

		// Token: 0x060011E5 RID: 4581 RVA: 0x000477BC File Offset: 0x000459BC
		public virtual Label DefineLabel()
		{
			if (this.labels == null)
			{
				this.labels = new ILGenerator.LabelData[4];
			}
			else if (this.num_labels >= this.labels.Length)
			{
				ILGenerator.LabelData[] array = new ILGenerator.LabelData[this.labels.Length * 2];
				Array.Copy(this.labels, array, this.labels.Length);
				this.labels = array;
			}
			this.labels[this.num_labels] = new ILGenerator.LabelData(-1, 0);
			return new Label(this.num_labels++);
		}

		// Token: 0x060011E6 RID: 4582 RVA: 0x00047858 File Offset: 0x00045A58
		public virtual void Emit(OpCode opcode)
		{
			this.make_room(2);
			this.ll_emit(opcode);
		}

		// Token: 0x060011E7 RID: 4583 RVA: 0x00047868 File Offset: 0x00045A68
		public virtual void Emit(OpCode opcode, byte arg)
		{
			this.make_room(3);
			this.ll_emit(opcode);
			this.code[this.code_len++] = arg;
		}

		// Token: 0x060011E8 RID: 4584 RVA: 0x0004789C File Offset: 0x00045A9C
		[ComVisible(true)]
		public virtual void Emit(OpCode opcode, ConstructorInfo con)
		{
			int token = this.token_gen.GetToken(con);
			this.make_room(6);
			this.ll_emit(opcode);
			if (con.DeclaringType.Module == this.module)
			{
				this.add_token_fixup(con);
			}
			this.emit_int(token);
			if (opcode.StackBehaviourPop == StackBehaviour.Varpop)
			{
				this.cur_stack -= con.GetParameterCount();
			}
		}

		// Token: 0x060011E9 RID: 4585 RVA: 0x0004790C File Offset: 0x00045B0C
		public virtual void Emit(OpCode opcode, FieldInfo field)
		{
			int token = this.token_gen.GetToken(field);
			this.make_room(6);
			this.ll_emit(opcode);
			if (field.DeclaringType.Module == this.module)
			{
				this.add_token_fixup(field);
			}
			this.emit_int(token);
		}

		// Token: 0x060011EA RID: 4586 RVA: 0x00047958 File Offset: 0x00045B58
		public virtual void Emit(OpCode opcode, int arg)
		{
			this.make_room(6);
			this.ll_emit(opcode);
			this.emit_int(arg);
		}

		// Token: 0x060011EB RID: 4587 RVA: 0x00047970 File Offset: 0x00045B70
		public virtual void Emit(OpCode opcode, Label label)
		{
			int num = ILGenerator.target_len(opcode);
			this.make_room(6);
			this.ll_emit(opcode);
			if (this.cur_stack > this.labels[label.label].maxStack)
			{
				this.labels[label.label].maxStack = this.cur_stack;
			}
			if (this.fixups == null)
			{
				this.fixups = new ILGenerator.LabelFixup[4];
			}
			else if (this.num_fixups >= this.fixups.Length)
			{
				ILGenerator.LabelFixup[] array = new ILGenerator.LabelFixup[this.fixups.Length * 2];
				Array.Copy(this.fixups, array, this.fixups.Length);
				this.fixups = array;
			}
			this.fixups[this.num_fixups].offset = num;
			this.fixups[this.num_fixups].pos = this.code_len;
			this.fixups[this.num_fixups].label_idx = label.label;
			this.num_fixups++;
			this.code_len += num;
		}

		// Token: 0x060011EC RID: 4588 RVA: 0x00047A98 File Offset: 0x00045C98
		public virtual void Emit(OpCode opcode, LocalBuilder local)
		{
			if (local == null)
			{
				throw new ArgumentNullException("local");
			}
			uint position = (uint)local.position;
			bool flag = false;
			bool flag2 = false;
			this.make_room(6);
			if (local.ilgen != this)
			{
				throw new ArgumentException("Trying to emit a local from a different ILGenerator.");
			}
			if (opcode.StackBehaviourPop == StackBehaviour.Pop1)
			{
				this.cur_stack--;
				flag2 = true;
			}
			else
			{
				this.cur_stack++;
				if (this.cur_stack > this.max_stack)
				{
					this.max_stack = this.cur_stack;
				}
				flag = opcode.StackBehaviourPush == StackBehaviour.Pushi;
			}
			if (flag)
			{
				if (position < 256U)
				{
					this.code[this.code_len++] = 18;
					this.code[this.code_len++] = (byte)position;
				}
				else
				{
					this.code[this.code_len++] = 254;
					this.code[this.code_len++] = 13;
					this.code[this.code_len++] = (byte)(position & 255U);
					this.code[this.code_len++] = (byte)((position >> 8) & 255U);
				}
			}
			else if (flag2)
			{
				if (position < 4U)
				{
					this.code[this.code_len++] = (byte)(10U + position);
				}
				else if (position < 256U)
				{
					this.code[this.code_len++] = 19;
					this.code[this.code_len++] = (byte)position;
				}
				else
				{
					this.code[this.code_len++] = 254;
					this.code[this.code_len++] = 14;
					this.code[this.code_len++] = (byte)(position & 255U);
					this.code[this.code_len++] = (byte)((position >> 8) & 255U);
				}
			}
			else if (position < 4U)
			{
				this.code[this.code_len++] = (byte)(6U + position);
			}
			else if (position < 256U)
			{
				this.code[this.code_len++] = 17;
				this.code[this.code_len++] = (byte)position;
			}
			else
			{
				this.code[this.code_len++] = 254;
				this.code[this.code_len++] = 12;
				this.code[this.code_len++] = (byte)(position & 255U);
				this.code[this.code_len++] = (byte)((position >> 8) & 255U);
			}
		}

		// Token: 0x060011ED RID: 4589 RVA: 0x00047DD8 File Offset: 0x00045FD8
		public virtual void Emit(OpCode opcode, MethodInfo meth)
		{
			if (meth == null)
			{
				throw new ArgumentNullException("meth");
			}
			if (meth is DynamicMethod && (opcode == OpCodes.Ldftn || opcode == OpCodes.Ldvirtftn || opcode == OpCodes.Ldtoken))
			{
				throw new ArgumentException("Ldtoken, Ldftn and Ldvirtftn OpCodes cannot target DynamicMethods.");
			}
			int token = this.token_gen.GetToken(meth);
			this.make_room(6);
			this.ll_emit(opcode);
			Type declaringType = meth.DeclaringType;
			if (declaringType != null && declaringType.Module == this.module)
			{
				this.add_token_fixup(meth);
			}
			this.emit_int(token);
			if (meth.ReturnType != ILGenerator.void_type)
			{
				this.cur_stack++;
			}
			if (opcode.StackBehaviourPop == StackBehaviour.Varpop)
			{
				this.cur_stack -= meth.GetParameterCount();
			}
		}

		// Token: 0x060011EE RID: 4590 RVA: 0x00047EC4 File Offset: 0x000460C4
		private void Emit(OpCode opcode, MethodInfo method, int token)
		{
			this.make_room(6);
			this.ll_emit(opcode);
			Type declaringType = method.DeclaringType;
			if (declaringType != null && declaringType.Module == this.module)
			{
				this.add_token_fixup(method);
			}
			this.emit_int(token);
			if (method.ReturnType != ILGenerator.void_type)
			{
				this.cur_stack++;
			}
			if (opcode.StackBehaviourPop == StackBehaviour.Varpop)
			{
				this.cur_stack -= method.GetParameterCount();
			}
		}

		// Token: 0x060011EF RID: 4591 RVA: 0x00047F4C File Offset: 0x0004614C
		public virtual void Emit(OpCode opcode, string str)
		{
			int token = this.token_gen.GetToken(str);
			this.make_room(6);
			this.ll_emit(opcode);
			this.emit_int(token);
		}

		// Token: 0x060011F0 RID: 4592 RVA: 0x00047F7C File Offset: 0x0004617C
		public virtual void Emit(OpCode opcode, Type cls)
		{
			this.make_room(6);
			this.ll_emit(opcode);
			this.emit_int(this.token_gen.GetToken(cls));
		}

		// Token: 0x060011F1 RID: 4593 RVA: 0x00047FA0 File Offset: 0x000461A0
		[MonoLimitation("vararg methods are not supported")]
		public virtual void EmitCall(OpCode opcode, MethodInfo methodInfo, Type[] optionalParameterTypes)
		{
			if (methodInfo == null)
			{
				throw new ArgumentNullException("methodInfo");
			}
			short value = opcode.Value;
			if (value != OpCodes.Call.Value && value != OpCodes.Callvirt.Value)
			{
				throw new NotSupportedException("Only Call and CallVirt are allowed");
			}
			if ((methodInfo.CallingConvention & CallingConventions.VarArgs) == (CallingConventions)0)
			{
				optionalParameterTypes = null;
			}
			if (optionalParameterTypes == null)
			{
				this.Emit(opcode, methodInfo);
				return;
			}
			if ((methodInfo.CallingConvention & CallingConventions.VarArgs) == (CallingConventions)0)
			{
				throw new InvalidOperationException("Method is not VarArgs method and optional types were passed");
			}
			int token = this.token_gen.GetToken(methodInfo, optionalParameterTypes);
			this.Emit(opcode, methodInfo, token);
		}

		// Token: 0x060011F2 RID: 4594 RVA: 0x00048048 File Offset: 0x00046248
		public virtual void MarkLabel(Label loc)
		{
			if (loc.label < 0 || loc.label >= this.num_labels)
			{
				throw new ArgumentException("The label is not valid");
			}
			if (this.labels[loc.label].addr >= 0)
			{
				throw new ArgumentException("The label was already defined");
			}
			this.labels[loc.label].addr = this.code_len;
			if (this.labels[loc.label].maxStack > this.cur_stack)
			{
				this.cur_stack = this.labels[loc.label].maxStack;
			}
		}

		// Token: 0x060011F3 RID: 4595 RVA: 0x00048104 File Offset: 0x00046304
		internal void label_fixup()
		{
			for (int i = 0; i < this.num_fixups; i++)
			{
				if (this.labels[this.fixups[i].label_idx].addr < 0)
				{
					throw new ArgumentException("Label not marked");
				}
				int num = this.labels[this.fixups[i].label_idx].addr - (this.fixups[i].pos + this.fixups[i].offset);
				if (this.fixups[i].offset == 1)
				{
					this.code[this.fixups[i].pos] = (byte)((sbyte)num);
				}
				else
				{
					int num2 = this.code_len;
					this.code_len = this.fixups[i].pos;
					this.emit_int(num);
					this.code_len = num2;
				}
			}
		}

		// Token: 0x060011F4 RID: 4596 RVA: 0x00048204 File Offset: 0x00046404
		[Obsolete("Use ILOffset")]
		internal static int Mono_GetCurrentOffset(ILGenerator ig)
		{
			return ig.code_len;
		}

		// Token: 0x0400077A RID: 1914
		private const int defaultFixupSize = 4;

		// Token: 0x0400077B RID: 1915
		private const int defaultLabelsSize = 4;

		// Token: 0x0400077C RID: 1916
		private const int defaultExceptionStackSize = 2;

		// Token: 0x0400077D RID: 1917
		private static readonly Type void_type = typeof(void);

		// Token: 0x0400077E RID: 1918
		private byte[] code;

		// Token: 0x0400077F RID: 1919
		private int code_len;

		// Token: 0x04000780 RID: 1920
		private int max_stack;

		// Token: 0x04000781 RID: 1921
		private int cur_stack;

		// Token: 0x04000782 RID: 1922
		private LocalBuilder[] locals;

		// Token: 0x04000783 RID: 1923
		private ILExceptionInfo[] ex_handlers;

		// Token: 0x04000784 RID: 1924
		private int num_token_fixups;

		// Token: 0x04000785 RID: 1925
		private ILTokenInfo[] token_fixups;

		// Token: 0x04000786 RID: 1926
		private ILGenerator.LabelData[] labels;

		// Token: 0x04000787 RID: 1927
		private int num_labels;

		// Token: 0x04000788 RID: 1928
		private ILGenerator.LabelFixup[] fixups;

		// Token: 0x04000789 RID: 1929
		private int num_fixups;

		// Token: 0x0400078A RID: 1930
		internal Module module;

		// Token: 0x0400078B RID: 1931
		private int cur_block;

		// Token: 0x0400078C RID: 1932
		private Stack open_blocks;

		// Token: 0x0400078D RID: 1933
		private TokenGenerator token_gen;

		// Token: 0x0400078E RID: 1934
		private ArrayList sequencePointLists;

		// Token: 0x0400078F RID: 1935
		private SequencePointList currentSequence;

		// Token: 0x020001D4 RID: 468
		private struct LabelData
		{
			// Token: 0x060011F5 RID: 4597 RVA: 0x0004820C File Offset: 0x0004640C
			public LabelData(int addr, int maxStack)
			{
				this.addr = addr;
				this.maxStack = maxStack;
			}

			// Token: 0x04000790 RID: 1936
			public int addr;

			// Token: 0x04000791 RID: 1937
			public int maxStack;
		}

		// Token: 0x020001D5 RID: 469
		private struct LabelFixup
		{
			// Token: 0x04000792 RID: 1938
			public int offset;

			// Token: 0x04000793 RID: 1939
			public int pos;

			// Token: 0x04000794 RID: 1940
			public int label_idx;
		}
	}
}
