﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001D6 RID: 470
	internal struct ILTokenInfo
	{
		// Token: 0x04000795 RID: 1941
		public MemberInfo member;

		// Token: 0x04000796 RID: 1942
		public int code_pos;
	}
}
