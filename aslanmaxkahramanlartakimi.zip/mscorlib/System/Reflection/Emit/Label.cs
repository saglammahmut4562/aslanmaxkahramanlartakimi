﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001D7 RID: 471
	[ComVisible(true)]
	[Serializable]
	public struct Label
	{
		// Token: 0x060011F6 RID: 4598 RVA: 0x0004821C File Offset: 0x0004641C
		internal Label(int val)
		{
			this.label = val;
		}

		// Token: 0x060011F7 RID: 4599 RVA: 0x00048228 File Offset: 0x00046428
		public override bool Equals(object obj)
		{
			bool flag = obj is Label;
			if (flag)
			{
				Label label = (Label)obj;
				flag = this.label == label.label;
			}
			return flag;
		}

		// Token: 0x060011F8 RID: 4600 RVA: 0x00048260 File Offset: 0x00046460
		public override int GetHashCode()
		{
			return this.label.GetHashCode();
		}

		// Token: 0x04000797 RID: 1943
		internal int label;
	}
}
