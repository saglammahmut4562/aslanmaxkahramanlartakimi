﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001D8 RID: 472
	[ComDefaultInterface(typeof(_LocalBuilder))]
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	public sealed class LocalBuilder : LocalVariableInfo, _LocalBuilder
	{
		// Token: 0x060011F9 RID: 4601 RVA: 0x00048270 File Offset: 0x00046470
		internal LocalBuilder(Type t, ILGenerator ilgen)
		{
			this.type = t;
			this.ilgen = ilgen;
		}

		// Token: 0x04000798 RID: 1944
		private string name;

		// Token: 0x04000799 RID: 1945
		internal ILGenerator ilgen;

		// Token: 0x0400079A RID: 1946
		private int startOffset;

		// Token: 0x0400079B RID: 1947
		private int endOffset;
	}
}
