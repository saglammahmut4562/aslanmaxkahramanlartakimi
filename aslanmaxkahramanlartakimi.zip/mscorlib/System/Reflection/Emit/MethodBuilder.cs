﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001D9 RID: 473
	[ComDefaultInterface(typeof(_MethodBuilder))]
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	public sealed class MethodBuilder : MethodInfo, _MethodBuilder
	{
		// Token: 0x060011FA RID: 4602 RVA: 0x00048288 File Offset: 0x00046488
		internal MethodBuilder(TypeBuilder tb, string name, MethodAttributes attributes, CallingConventions callingConvention, Type returnType, Type[] returnModReq, Type[] returnModOpt, Type[] parameterTypes, Type[][] paramModReq, Type[][] paramModOpt)
		{
			this.name = name;
			this.attrs = attributes;
			this.call_conv = callingConvention;
			this.rtype = returnType;
			this.returnModReq = returnModReq;
			this.returnModOpt = returnModOpt;
			this.paramModReq = paramModReq;
			this.paramModOpt = paramModOpt;
			if ((attributes & MethodAttributes.Static) == MethodAttributes.PrivateScope)
			{
				this.call_conv |= CallingConventions.HasThis;
			}
			if (parameterTypes != null)
			{
				for (int i = 0; i < parameterTypes.Length; i++)
				{
					if (parameterTypes[i] == null)
					{
						throw new ArgumentException("Elements of the parameterTypes array cannot be null", "parameterTypes");
					}
				}
				this.parameters = new Type[parameterTypes.Length];
				Array.Copy(parameterTypes, this.parameters, parameterTypes.Length);
			}
			this.type = tb;
			this.table_idx = this.get_next_table_index(this, 6, true);
			((ModuleBuilder)tb.Module).RegisterToken(this, this.GetToken().Token);
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x060011FB RID: 4603 RVA: 0x00048384 File Offset: 0x00046584
		public override bool ContainsGenericParameters
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x060011FC RID: 4604 RVA: 0x0004838C File Offset: 0x0004658C
		public override RuntimeMethodHandle MethodHandle
		{
			get
			{
				throw this.NotSupported();
			}
		}

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x060011FD RID: 4605 RVA: 0x00048394 File Offset: 0x00046594
		public override Type ReturnType
		{
			get
			{
				return this.rtype;
			}
		}

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x060011FE RID: 4606 RVA: 0x0004839C File Offset: 0x0004659C
		public override Type ReflectedType
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x060011FF RID: 4607 RVA: 0x000483A4 File Offset: 0x000465A4
		public override Type DeclaringType
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x06001200 RID: 4608 RVA: 0x000483AC File Offset: 0x000465AC
		public override string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x06001201 RID: 4609 RVA: 0x000483B4 File Offset: 0x000465B4
		public override MethodAttributes Attributes
		{
			get
			{
				return this.attrs;
			}
		}

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x06001202 RID: 4610 RVA: 0x000483BC File Offset: 0x000465BC
		public override CallingConventions CallingConvention
		{
			get
			{
				return this.call_conv;
			}
		}

		// Token: 0x06001203 RID: 4611 RVA: 0x000483C4 File Offset: 0x000465C4
		public MethodToken GetToken()
		{
			return new MethodToken(100663296 | this.table_idx);
		}

		// Token: 0x06001204 RID: 4612 RVA: 0x000483D8 File Offset: 0x000465D8
		public override MethodInfo GetBaseDefinition()
		{
			return this;
		}

		// Token: 0x06001205 RID: 4613 RVA: 0x000483DC File Offset: 0x000465DC
		public override MethodImplAttributes GetMethodImplementationFlags()
		{
			return this.iattrs;
		}

		// Token: 0x06001206 RID: 4614 RVA: 0x000483E4 File Offset: 0x000465E4
		public override ParameterInfo[] GetParameters()
		{
			if (!this.type.is_created)
			{
				throw this.NotSupported();
			}
			if (this.parameters == null)
			{
				return null;
			}
			ParameterInfo[] array = new ParameterInfo[this.parameters.Length];
			for (int i = 0; i < this.parameters.Length; i++)
			{
				array[i] = new ParameterInfo((this.pinfo != null) ? this.pinfo[i + 1] : null, this.parameters[i], this, i + 1);
			}
			return array;
		}

		// Token: 0x06001207 RID: 4615 RVA: 0x0004846C File Offset: 0x0004666C
		internal override int GetParameterCount()
		{
			if (this.parameters == null)
			{
				return 0;
			}
			return this.parameters.Length;
		}

		// Token: 0x06001208 RID: 4616 RVA: 0x00048484 File Offset: 0x00046684
		public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			throw this.NotSupported();
		}

		// Token: 0x06001209 RID: 4617 RVA: 0x0004848C File Offset: 0x0004668C
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw this.NotSupported();
		}

		// Token: 0x0600120A RID: 4618 RVA: 0x00048494 File Offset: 0x00046694
		public override object[] GetCustomAttributes(bool inherit)
		{
			if (this.type.is_created)
			{
				return MonoCustomAttrs.GetCustomAttributes(this, inherit);
			}
			throw this.NotSupported();
		}

		// Token: 0x0600120B RID: 4619 RVA: 0x000484B4 File Offset: 0x000466B4
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			if (this.type.is_created)
			{
				return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
			}
			throw this.NotSupported();
		}

		// Token: 0x0600120C RID: 4620 RVA: 0x000484D8 File Offset: 0x000466D8
		public ILGenerator GetILGenerator()
		{
			return this.GetILGenerator(64);
		}

		// Token: 0x0600120D RID: 4621 RVA: 0x000484E4 File Offset: 0x000466E4
		public ILGenerator GetILGenerator(int size)
		{
			if ((this.iattrs & MethodImplAttributes.CodeTypeMask) != MethodImplAttributes.IL || (this.iattrs & MethodImplAttributes.ManagedMask) != MethodImplAttributes.IL)
			{
				throw new InvalidOperationException("Method body should not exist.");
			}
			if (this.ilgen != null)
			{
				return this.ilgen;
			}
			this.ilgen = new ILGenerator(this.type.Module, ((ModuleBuilder)this.type.Module).GetTokenGenerator(), size);
			return this.ilgen;
		}

		// Token: 0x0600120E RID: 4622 RVA: 0x0004855C File Offset: 0x0004675C
		internal void check_override()
		{
			if (this.override_method != null && this.override_method.IsVirtual && !this.IsVirtual)
			{
				throw new TypeLoadException(string.Format("Method '{0}' override '{1}' but it is not virtual", this.name, this.override_method));
			}
		}

		// Token: 0x0600120F RID: 4623 RVA: 0x000485AC File Offset: 0x000467AC
		internal void fixup()
		{
			if ((this.attrs & (MethodAttributes.Abstract | MethodAttributes.PinvokeImpl)) == MethodAttributes.PrivateScope && (this.iattrs & (MethodImplAttributes)4099) == MethodImplAttributes.IL && (this.ilgen == null || ILGenerator.Mono_GetCurrentOffset(this.ilgen) == 0) && (this.code == null || this.code.Length == 0))
			{
				throw new InvalidOperationException(string.Format("Method '{0}.{1}' does not have a method body.", this.DeclaringType.FullName, this.Name));
			}
			if (this.ilgen != null)
			{
				this.ilgen.label_fixup();
			}
		}

		// Token: 0x06001210 RID: 4624 RVA: 0x00048648 File Offset: 0x00046848
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"MethodBuilder [",
				this.type.Name,
				"::",
				this.name,
				"]"
			});
		}

		// Token: 0x06001211 RID: 4625 RVA: 0x00048684 File Offset: 0x00046884
		[MonoTODO]
		public override bool Equals(object obj)
		{
			return base.Equals(obj);
		}

		// Token: 0x06001212 RID: 4626 RVA: 0x00048690 File Offset: 0x00046890
		public override int GetHashCode()
		{
			return this.name.GetHashCode();
		}

		// Token: 0x06001213 RID: 4627 RVA: 0x000486A0 File Offset: 0x000468A0
		internal override int get_next_table_index(object obj, int table, bool inc)
		{
			return this.type.get_next_table_index(obj, table, inc);
		}

		// Token: 0x06001214 RID: 4628 RVA: 0x000486B0 File Offset: 0x000468B0
		internal void set_override(MethodInfo mdecl)
		{
			this.override_method = mdecl;
		}

		// Token: 0x06001215 RID: 4629 RVA: 0x000486BC File Offset: 0x000468BC
		private Exception NotSupported()
		{
			return new NotSupportedException("The invoked member is not supported in a dynamic module.");
		}

		// Token: 0x06001216 RID: 4630
		[MethodImpl(4096)]
		public override extern MethodInfo MakeGenericMethod(params Type[] typeArguments);

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x06001217 RID: 4631 RVA: 0x000486C8 File Offset: 0x000468C8
		public override bool IsGenericMethodDefinition
		{
			get
			{
				return this.generic_params != null;
			}
		}

		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x06001218 RID: 4632 RVA: 0x000486D8 File Offset: 0x000468D8
		public override bool IsGenericMethod
		{
			get
			{
				return this.generic_params != null;
			}
		}

		// Token: 0x06001219 RID: 4633 RVA: 0x000486E8 File Offset: 0x000468E8
		public override MethodInfo GetGenericMethodDefinition()
		{
			if (!this.IsGenericMethodDefinition)
			{
				throw new InvalidOperationException();
			}
			return this;
		}

		// Token: 0x0600121A RID: 4634 RVA: 0x000486FC File Offset: 0x000468FC
		public override Type[] GetGenericArguments()
		{
			if (this.generic_params == null)
			{
				return Type.EmptyTypes;
			}
			Type[] array = new Type[this.generic_params.Length];
			for (int i = 0; i < this.generic_params.Length; i++)
			{
				array[i] = this.generic_params[i];
			}
			return array;
		}

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x0600121B RID: 4635 RVA: 0x00048750 File Offset: 0x00046950
		public override Module Module
		{
			get
			{
				return base.Module;
			}
		}

		// Token: 0x0400079C RID: 1948
		private RuntimeMethodHandle mhandle;

		// Token: 0x0400079D RID: 1949
		private Type rtype;

		// Token: 0x0400079E RID: 1950
		internal Type[] parameters;

		// Token: 0x0400079F RID: 1951
		private MethodAttributes attrs;

		// Token: 0x040007A0 RID: 1952
		private MethodImplAttributes iattrs;

		// Token: 0x040007A1 RID: 1953
		private string name;

		// Token: 0x040007A2 RID: 1954
		private int table_idx;

		// Token: 0x040007A3 RID: 1955
		private byte[] code;

		// Token: 0x040007A4 RID: 1956
		private ILGenerator ilgen;

		// Token: 0x040007A5 RID: 1957
		private TypeBuilder type;

		// Token: 0x040007A6 RID: 1958
		internal ParameterBuilder[] pinfo;

		// Token: 0x040007A7 RID: 1959
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x040007A8 RID: 1960
		private MethodInfo override_method;

		// Token: 0x040007A9 RID: 1961
		private string pi_dll;

		// Token: 0x040007AA RID: 1962
		private string pi_entry;

		// Token: 0x040007AB RID: 1963
		private CharSet charset;

		// Token: 0x040007AC RID: 1964
		private uint extra_flags;

		// Token: 0x040007AD RID: 1965
		private CallingConvention native_cc;

		// Token: 0x040007AE RID: 1966
		private CallingConventions call_conv;

		// Token: 0x040007AF RID: 1967
		private bool init_locals = true;

		// Token: 0x040007B0 RID: 1968
		private IntPtr generic_container;

		// Token: 0x040007B1 RID: 1969
		internal GenericTypeParameterBuilder[] generic_params;

		// Token: 0x040007B2 RID: 1970
		private Type[] returnModReq;

		// Token: 0x040007B3 RID: 1971
		private Type[] returnModOpt;

		// Token: 0x040007B4 RID: 1972
		private Type[][] paramModReq;

		// Token: 0x040007B5 RID: 1973
		private Type[][] paramModOpt;

		// Token: 0x040007B6 RID: 1974
		private RefEmitPermissionSet[] permissions;
	}
}
