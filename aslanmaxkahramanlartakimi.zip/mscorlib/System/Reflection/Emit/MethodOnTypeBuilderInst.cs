﻿using System;
using System.Globalization;
using System.Text;

namespace System.Reflection.Emit
{
	// Token: 0x020001DA RID: 474
	internal class MethodOnTypeBuilderInst : MethodInfo
	{
		// Token: 0x0600121C RID: 4636 RVA: 0x00048758 File Offset: 0x00046958
		public MethodOnTypeBuilderInst(MonoGenericClass instantiation, MethodBuilder mb)
		{
			this.instantiation = instantiation;
			this.mb = mb;
		}

		// Token: 0x0600121D RID: 4637 RVA: 0x00048770 File Offset: 0x00046970
		internal MethodOnTypeBuilderInst(MethodOnTypeBuilderInst gmd, Type[] typeArguments)
		{
			this.instantiation = gmd.instantiation;
			this.mb = gmd.mb;
			this.method_arguments = new Type[typeArguments.Length];
			typeArguments.CopyTo(this.method_arguments, 0);
			this.generic_method_definition = gmd;
		}

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x0600121E RID: 4638 RVA: 0x000487C0 File Offset: 0x000469C0
		public override Type DeclaringType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x0600121F RID: 4639 RVA: 0x000487C8 File Offset: 0x000469C8
		public override string Name
		{
			get
			{
				return this.mb.Name;
			}
		}

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x06001220 RID: 4640 RVA: 0x000487D8 File Offset: 0x000469D8
		public override Type ReflectedType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x06001221 RID: 4641 RVA: 0x000487E0 File Offset: 0x000469E0
		public override Type ReturnType
		{
			get
			{
				if (!((ModuleBuilder)this.mb.Module).assemblyb.IsCompilerContext)
				{
					return this.mb.ReturnType;
				}
				return this.instantiation.InflateType(this.mb.ReturnType, this.method_arguments);
			}
		}

		// Token: 0x06001222 RID: 4642 RVA: 0x00048834 File Offset: 0x00046A34
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001223 RID: 4643 RVA: 0x0004883C File Offset: 0x00046A3C
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001224 RID: 4644 RVA: 0x00048844 File Offset: 0x00046A44
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06001225 RID: 4645 RVA: 0x0004884C File Offset: 0x00046A4C
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(this.ReturnType.ToString());
			stringBuilder.Append(" ");
			stringBuilder.Append(this.mb.Name);
			stringBuilder.Append("(");
			if (((ModuleBuilder)this.mb.Module).assemblyb.IsCompilerContext)
			{
				ParameterInfo[] parameters = this.GetParameters();
				for (int i = 0; i < parameters.Length; i++)
				{
					if (i > 0)
					{
						stringBuilder.Append(", ");
					}
					stringBuilder.Append(parameters[i].ParameterType);
				}
			}
			stringBuilder.Append(")");
			return stringBuilder.ToString();
		}

		// Token: 0x06001226 RID: 4646 RVA: 0x00048904 File Offset: 0x00046B04
		public override MethodImplAttributes GetMethodImplementationFlags()
		{
			return this.mb.GetMethodImplementationFlags();
		}

		// Token: 0x06001227 RID: 4647 RVA: 0x00048914 File Offset: 0x00046B14
		public override ParameterInfo[] GetParameters()
		{
			if (!((ModuleBuilder)this.mb.Module).assemblyb.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			ParameterInfo[] array = new ParameterInfo[this.mb.parameters.Length];
			for (int i = 0; i < this.mb.parameters.Length; i++)
			{
				Type type = this.instantiation.InflateType(this.mb.parameters[i], this.method_arguments);
				array[i] = new ParameterInfo((this.mb.pinfo != null) ? this.mb.pinfo[i + 1] : null, type, this, i + 1);
			}
			return array;
		}

		// Token: 0x06001228 RID: 4648 RVA: 0x000489CC File Offset: 0x00046BCC
		internal override int GetParameterCount()
		{
			return this.mb.GetParameterCount();
		}

		// Token: 0x06001229 RID: 4649 RVA: 0x000489DC File Offset: 0x00046BDC
		public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			throw new NotSupportedException();
		}

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x0600122A RID: 4650 RVA: 0x000489E4 File Offset: 0x00046BE4
		public override RuntimeMethodHandle MethodHandle
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x0600122B RID: 4651 RVA: 0x000489EC File Offset: 0x00046BEC
		public override MethodAttributes Attributes
		{
			get
			{
				return this.mb.Attributes;
			}
		}

		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x0600122C RID: 4652 RVA: 0x000489FC File Offset: 0x00046BFC
		public override CallingConventions CallingConvention
		{
			get
			{
				return this.mb.CallingConvention;
			}
		}

		// Token: 0x0600122D RID: 4653 RVA: 0x00048A0C File Offset: 0x00046C0C
		public override MethodInfo MakeGenericMethod(params Type[] typeArguments)
		{
			if (this.mb.generic_params == null || this.method_arguments != null)
			{
				throw new NotSupportedException();
			}
			if (typeArguments == null)
			{
				throw new ArgumentNullException("typeArguments");
			}
			for (int i = 0; i < typeArguments.Length; i++)
			{
				if (typeArguments[i] == null)
				{
					throw new ArgumentNullException("typeArguments");
				}
			}
			if (this.mb.generic_params.Length != typeArguments.Length)
			{
				throw new ArgumentException("Invalid argument array length");
			}
			return new MethodOnTypeBuilderInst(this, typeArguments);
		}

		// Token: 0x0600122E RID: 4654 RVA: 0x00048AA0 File Offset: 0x00046CA0
		public override Type[] GetGenericArguments()
		{
			if (this.mb.generic_params == null)
			{
				return null;
			}
			Type[] array = this.method_arguments ?? this.mb.generic_params;
			Type[] array2 = new Type[array.Length];
			array.CopyTo(array2, 0);
			return array2;
		}

		// Token: 0x0600122F RID: 4655 RVA: 0x00048AEC File Offset: 0x00046CEC
		public override MethodInfo GetGenericMethodDefinition()
		{
			return this.generic_method_definition ?? this.mb;
		}

		// Token: 0x170002E1 RID: 737
		// (get) Token: 0x06001230 RID: 4656 RVA: 0x00048B04 File Offset: 0x00046D04
		public override bool ContainsGenericParameters
		{
			get
			{
				if (this.mb.generic_params == null)
				{
					throw new NotSupportedException();
				}
				if (this.method_arguments == null)
				{
					return true;
				}
				foreach (Type type in this.method_arguments)
				{
					if (type.ContainsGenericParameters)
					{
						return true;
					}
				}
				return false;
			}
		}

		// Token: 0x170002E2 RID: 738
		// (get) Token: 0x06001231 RID: 4657 RVA: 0x00048B64 File Offset: 0x00046D64
		public override bool IsGenericMethodDefinition
		{
			get
			{
				return this.mb.generic_params != null && this.method_arguments == null;
			}
		}

		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x06001232 RID: 4658 RVA: 0x00048B84 File Offset: 0x00046D84
		public override bool IsGenericMethod
		{
			get
			{
				return this.mb.generic_params != null;
			}
		}

		// Token: 0x06001233 RID: 4659 RVA: 0x00048B98 File Offset: 0x00046D98
		public override MethodInfo GetBaseDefinition()
		{
			throw new NotSupportedException();
		}

		// Token: 0x040007B8 RID: 1976
		private MonoGenericClass instantiation;

		// Token: 0x040007B9 RID: 1977
		internal MethodBuilder mb;

		// Token: 0x040007BA RID: 1978
		private Type[] method_arguments;

		// Token: 0x040007BB RID: 1979
		private MethodOnTypeBuilderInst generic_method_definition;
	}
}
