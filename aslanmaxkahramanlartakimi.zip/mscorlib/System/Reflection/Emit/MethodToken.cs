﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001DB RID: 475
	[ComVisible(true)]
	[Serializable]
	public struct MethodToken
	{
		// Token: 0x06001234 RID: 4660 RVA: 0x00048BA0 File Offset: 0x00046DA0
		internal MethodToken(int val)
		{
			this.tokValue = val;
		}

		// Token: 0x06001236 RID: 4662 RVA: 0x00048BC8 File Offset: 0x00046DC8
		public override bool Equals(object obj)
		{
			bool flag = obj is MethodToken;
			if (flag)
			{
				MethodToken methodToken = (MethodToken)obj;
				flag = this.tokValue == methodToken.tokValue;
			}
			return flag;
		}

		// Token: 0x06001237 RID: 4663 RVA: 0x00048C00 File Offset: 0x00046E00
		public override int GetHashCode()
		{
			return this.tokValue;
		}

		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x06001238 RID: 4664 RVA: 0x00048C08 File Offset: 0x00046E08
		public int Token
		{
			get
			{
				return this.tokValue;
			}
		}

		// Token: 0x040007BC RID: 1980
		internal int tokValue;

		// Token: 0x040007BD RID: 1981
		public static readonly MethodToken Empty = default(MethodToken);
	}
}
