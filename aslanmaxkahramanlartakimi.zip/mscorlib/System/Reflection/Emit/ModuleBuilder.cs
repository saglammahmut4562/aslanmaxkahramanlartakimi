﻿using System;
using System.Collections;
using System.Diagnostics.SymbolStore;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001DC RID: 476
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_ModuleBuilder))]
	[ComVisible(true)]
	public class ModuleBuilder : Module, _ModuleBuilder
	{
		// Token: 0x06001239 RID: 4665 RVA: 0x00048C10 File Offset: 0x00046E10
		internal ModuleBuilder(AssemblyBuilder assb, string name, string fullyqname, bool emitSymbolInfo, bool transient)
		{
			this.scopename = name;
			this.name = name;
			this.fqname = fullyqname;
			this.assemblyb = assb;
			this.assembly = assb;
			this.transient = transient;
			this.guid = Guid.FastNewGuidArray();
			this.table_idx = this.get_next_table_index(this, 0, true);
			this.name_cache = new Hashtable();
			ModuleBuilder.basic_init(this);
			this.CreateGlobalType();
			if (assb.IsRun)
			{
				TypeBuilder typeBuilder = new TypeBuilder(this, TypeAttributes.Abstract, 16777215);
				Type type = typeBuilder.CreateType();
				ModuleBuilder.set_wrappers_type(this, type);
			}
			if (emitSymbolInfo)
			{
				Assembly assembly = Assembly.LoadWithPartialName("Mono.CompilerServices.SymbolWriter");
				if (assembly == null)
				{
					throw new ExecutionEngineException("The assembly for default symbol writer cannot be loaded");
				}
				Type type2 = assembly.GetType("Mono.CompilerServices.SymbolWriter.SymbolWriterImpl");
				if (type2 == null)
				{
					throw new ExecutionEngineException("The type that implements the default symbol writer interface cannot be found");
				}
				this.symbolWriter = (ISymbolWriter)Activator.CreateInstance(type2, new object[] { this });
				string text = this.fqname;
				if (this.assemblyb.AssemblyDir != null)
				{
					text = Path.Combine(this.assemblyb.AssemblyDir, text);
				}
				this.symbolWriter.Initialize(IntPtr.Zero, text, true);
			}
		}

		// Token: 0x0600123B RID: 4667
		[MethodImpl(4096)]
		private static extern void basic_init(ModuleBuilder ab);

		// Token: 0x0600123C RID: 4668
		[MethodImpl(4096)]
		private static extern void set_wrappers_type(ModuleBuilder mb, Type ab);

		// Token: 0x0600123D RID: 4669 RVA: 0x00048D74 File Offset: 0x00046F74
		public bool IsTransient()
		{
			return this.transient;
		}

		// Token: 0x0600123E RID: 4670 RVA: 0x00048D7C File Offset: 0x00046F7C
		public TypeBuilder DefineType(string name, TypeAttributes attr, Type parent)
		{
			return this.DefineType(name, attr, parent, null);
		}

		// Token: 0x0600123F RID: 4671 RVA: 0x00048D88 File Offset: 0x00046F88
		private void AddType(TypeBuilder tb)
		{
			if (this.types != null)
			{
				if (this.types.Length == this.num_types)
				{
					TypeBuilder[] array = new TypeBuilder[this.types.Length * 2];
					Array.Copy(this.types, array, this.num_types);
					this.types = array;
				}
			}
			else
			{
				this.types = new TypeBuilder[1];
			}
			this.types[this.num_types] = tb;
			this.num_types++;
		}

		// Token: 0x06001240 RID: 4672 RVA: 0x00048E0C File Offset: 0x0004700C
		private TypeBuilder DefineType(string name, TypeAttributes attr, Type parent, Type[] interfaces, PackingSize packingSize, int typesize)
		{
			if (this.name_cache.ContainsKey(name))
			{
				throw new ArgumentException("Duplicate type name within an assembly.");
			}
			TypeBuilder typeBuilder = new TypeBuilder(this, name, attr, parent, interfaces, packingSize, typesize, null);
			this.AddType(typeBuilder);
			this.name_cache.Add(name, typeBuilder);
			return typeBuilder;
		}

		// Token: 0x06001241 RID: 4673 RVA: 0x00048E5C File Offset: 0x0004705C
		[ComVisible(true)]
		public TypeBuilder DefineType(string name, TypeAttributes attr, Type parent, Type[] interfaces)
		{
			return this.DefineType(name, attr, parent, interfaces, PackingSize.Unspecified, 0);
		}

		// Token: 0x06001242 RID: 4674 RVA: 0x00048E6C File Offset: 0x0004706C
		[ComVisible(true)]
		public override Type GetType(string className)
		{
			return this.GetType(className, false, false);
		}

		// Token: 0x06001243 RID: 4675 RVA: 0x00048E78 File Offset: 0x00047078
		private TypeBuilder search_in_array(TypeBuilder[] arr, int validElementsInArray, string className)
		{
			for (int i = 0; i < validElementsInArray; i++)
			{
				if (string.Compare(className, arr[i].FullName, true, CultureInfo.InvariantCulture) == 0)
				{
					return arr[i];
				}
			}
			return null;
		}

		// Token: 0x06001244 RID: 4676 RVA: 0x00048EB8 File Offset: 0x000470B8
		private TypeBuilder search_nested_in_array(TypeBuilder[] arr, int validElementsInArray, string className)
		{
			for (int i = 0; i < validElementsInArray; i++)
			{
				if (string.Compare(className, arr[i].Name, true, CultureInfo.InvariantCulture) == 0)
				{
					return arr[i];
				}
			}
			return null;
		}

		// Token: 0x06001245 RID: 4677
		[MethodImpl(4096)]
		private static extern Type create_modified_type(TypeBuilder tb, string modifiers);

		// Token: 0x06001246 RID: 4678 RVA: 0x00048EF8 File Offset: 0x000470F8
		private TypeBuilder GetMaybeNested(TypeBuilder t, string className)
		{
			int num = className.IndexOf('+');
			if (num >= 0)
			{
				if (t.subtypes != null)
				{
					string text = className.Substring(0, num);
					string text2 = className.Substring(num + 1);
					TypeBuilder typeBuilder = this.search_nested_in_array(t.subtypes, t.subtypes.Length, text);
					if (typeBuilder != null)
					{
						return this.GetMaybeNested(typeBuilder, text2);
					}
				}
				return null;
			}
			if (t.subtypes != null)
			{
				return this.search_nested_in_array(t.subtypes, t.subtypes.Length, className);
			}
			return null;
		}

		// Token: 0x06001247 RID: 4679 RVA: 0x00048F7C File Offset: 0x0004717C
		[ComVisible(true)]
		public override Type GetType(string className, bool throwOnError, bool ignoreCase)
		{
			if (className == null)
			{
				throw new ArgumentNullException("className");
			}
			if (className.Length == 0)
			{
				throw new ArgumentException("className");
			}
			string text = className;
			TypeBuilder typeBuilder = null;
			if (this.types == null && throwOnError)
			{
				throw new TypeLoadException(className);
			}
			int num = className.IndexOfAny(ModuleBuilder.type_modifiers);
			string text2;
			if (num >= 0)
			{
				text2 = className.Substring(num);
				className = className.Substring(0, num);
			}
			else
			{
				text2 = null;
			}
			if (!ignoreCase)
			{
				typeBuilder = this.name_cache[className] as TypeBuilder;
			}
			else
			{
				num = className.IndexOf('+');
				if (num < 0)
				{
					if (this.types != null)
					{
						typeBuilder = this.search_in_array(this.types, this.num_types, className);
					}
				}
				else
				{
					string text3 = className.Substring(0, num);
					string text4 = className.Substring(num + 1);
					typeBuilder = this.search_in_array(this.types, this.num_types, text3);
					if (typeBuilder != null)
					{
						typeBuilder = this.GetMaybeNested(typeBuilder, text4);
					}
				}
			}
			if (typeBuilder == null && throwOnError)
			{
				throw new TypeLoadException(text);
			}
			if (typeBuilder != null && text2 != null)
			{
				Type type = ModuleBuilder.create_modified_type(typeBuilder, text2);
				typeBuilder = type as TypeBuilder;
				if (typeBuilder == null)
				{
					return type;
				}
			}
			if (typeBuilder != null && typeBuilder.is_created)
			{
				return typeBuilder.CreateType();
			}
			return typeBuilder;
		}

		// Token: 0x06001248 RID: 4680 RVA: 0x000490D8 File Offset: 0x000472D8
		internal int get_next_table_index(object obj, int table, bool inc)
		{
			if (this.table_indexes == null)
			{
				this.table_indexes = new int[64];
				for (int i = 0; i < 64; i++)
				{
					this.table_indexes[i] = 1;
				}
				this.table_indexes[2] = 2;
			}
			if (inc)
			{
				return this.table_indexes[table]++;
			}
			return this.table_indexes[table];
		}

		// Token: 0x06001249 RID: 4681 RVA: 0x00049148 File Offset: 0x00047348
		public override Type[] GetTypes()
		{
			if (this.types == null)
			{
				return Type.EmptyTypes;
			}
			int num = this.num_types;
			Type[] array = new Type[num];
			Array.Copy(this.types, array, num);
			for (int i = 0; i < array.Length; i++)
			{
				if (this.types[i].is_created)
				{
					array[i] = this.types[i].CreateType();
				}
			}
			return array;
		}

		// Token: 0x0600124A RID: 4682
		[MethodImpl(4096)]
		private static extern int getUSIndex(ModuleBuilder mb, string str);

		// Token: 0x0600124B RID: 4683
		[MethodImpl(4096)]
		private static extern int getToken(ModuleBuilder mb, object obj);

		// Token: 0x0600124C RID: 4684
		[MethodImpl(4096)]
		private static extern int getMethodToken(ModuleBuilder mb, MethodInfo method, Type[] opt_param_types);

		// Token: 0x0600124D RID: 4685 RVA: 0x000491B8 File Offset: 0x000473B8
		internal int GetToken(string str)
		{
			if (this.us_string_cache.Contains(str))
			{
				return (int)this.us_string_cache[str];
			}
			int usindex = ModuleBuilder.getUSIndex(this, str);
			this.us_string_cache[str] = usindex;
			return usindex;
		}

		// Token: 0x0600124E RID: 4686 RVA: 0x00049204 File Offset: 0x00047404
		internal int GetToken(MemberInfo member)
		{
			return ModuleBuilder.getToken(this, member);
		}

		// Token: 0x0600124F RID: 4687 RVA: 0x00049210 File Offset: 0x00047410
		internal int GetToken(MethodInfo method, Type[] opt_param_types)
		{
			return ModuleBuilder.getMethodToken(this, method, opt_param_types);
		}

		// Token: 0x06001250 RID: 4688
		[MethodImpl(4096)]
		internal extern void RegisterToken(object obj, int token);

		// Token: 0x06001251 RID: 4689 RVA: 0x0004921C File Offset: 0x0004741C
		internal TokenGenerator GetTokenGenerator()
		{
			if (this.token_gen == null)
			{
				this.token_gen = new ModuleBuilderTokenGenerator(this);
			}
			return this.token_gen;
		}

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x06001252 RID: 4690 RVA: 0x0004923C File Offset: 0x0004743C
		internal string FileName
		{
			get
			{
				return this.fqname;
			}
		}

		// Token: 0x06001253 RID: 4691 RVA: 0x00049244 File Offset: 0x00047444
		internal void CreateGlobalType()
		{
			if (this.global_type == null)
			{
				this.global_type = new TypeBuilder(this, TypeAttributes.NotPublic, 1);
			}
		}

		// Token: 0x040007BE RID: 1982
		private UIntPtr dynamic_image;

		// Token: 0x040007BF RID: 1983
		private int num_types;

		// Token: 0x040007C0 RID: 1984
		private TypeBuilder[] types;

		// Token: 0x040007C1 RID: 1985
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x040007C2 RID: 1986
		private byte[] guid;

		// Token: 0x040007C3 RID: 1987
		private int table_idx;

		// Token: 0x040007C4 RID: 1988
		internal AssemblyBuilder assemblyb;

		// Token: 0x040007C5 RID: 1989
		private MethodBuilder[] global_methods;

		// Token: 0x040007C6 RID: 1990
		private FieldBuilder[] global_fields;

		// Token: 0x040007C7 RID: 1991
		private bool is_main;

		// Token: 0x040007C8 RID: 1992
		private MonoResource[] resources;

		// Token: 0x040007C9 RID: 1993
		private TypeBuilder global_type;

		// Token: 0x040007CA RID: 1994
		private Type global_type_created;

		// Token: 0x040007CB RID: 1995
		private Hashtable name_cache;

		// Token: 0x040007CC RID: 1996
		private Hashtable us_string_cache = new Hashtable();

		// Token: 0x040007CD RID: 1997
		private int[] table_indexes;

		// Token: 0x040007CE RID: 1998
		private bool transient;

		// Token: 0x040007CF RID: 1999
		private ModuleBuilderTokenGenerator token_gen;

		// Token: 0x040007D0 RID: 2000
		private Hashtable resource_writers;

		// Token: 0x040007D1 RID: 2001
		private ISymbolWriter symbolWriter;

		// Token: 0x040007D2 RID: 2002
		private static readonly char[] type_modifiers = new char[] { '&', '[', '*' };
	}
}
