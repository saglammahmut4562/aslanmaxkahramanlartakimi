﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001DD RID: 477
	internal class ModuleBuilderTokenGenerator : TokenGenerator
	{
		// Token: 0x06001254 RID: 4692 RVA: 0x00049260 File Offset: 0x00047460
		public ModuleBuilderTokenGenerator(ModuleBuilder mb)
		{
			this.mb = mb;
		}

		// Token: 0x06001255 RID: 4693 RVA: 0x00049270 File Offset: 0x00047470
		public int GetToken(string str)
		{
			return this.mb.GetToken(str);
		}

		// Token: 0x06001256 RID: 4694 RVA: 0x00049280 File Offset: 0x00047480
		public int GetToken(MemberInfo member)
		{
			return this.mb.GetToken(member);
		}

		// Token: 0x06001257 RID: 4695 RVA: 0x00049290 File Offset: 0x00047490
		public int GetToken(MethodInfo method, Type[] opt_param_types)
		{
			return this.mb.GetToken(method, opt_param_types);
		}

		// Token: 0x040007D3 RID: 2003
		private ModuleBuilder mb;
	}
}
