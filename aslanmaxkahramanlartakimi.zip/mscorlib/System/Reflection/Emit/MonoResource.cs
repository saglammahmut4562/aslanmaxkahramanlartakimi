﻿using System;
using System.IO;

namespace System.Reflection.Emit
{
	// Token: 0x020001DE RID: 478
	internal struct MonoResource
	{
		// Token: 0x040007D4 RID: 2004
		public byte[] data;

		// Token: 0x040007D5 RID: 2005
		public string name;

		// Token: 0x040007D6 RID: 2006
		public string filename;

		// Token: 0x040007D7 RID: 2007
		public ResourceAttributes attrs;

		// Token: 0x040007D8 RID: 2008
		public int offset;

		// Token: 0x040007D9 RID: 2009
		public Stream stream;
	}
}
