﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001DF RID: 479
	internal struct MonoWin32Resource
	{
		// Token: 0x040007DA RID: 2010
		public int res_type;

		// Token: 0x040007DB RID: 2011
		public int res_id;

		// Token: 0x040007DC RID: 2012
		public int lang_id;

		// Token: 0x040007DD RID: 2013
		public byte[] data;
	}
}
