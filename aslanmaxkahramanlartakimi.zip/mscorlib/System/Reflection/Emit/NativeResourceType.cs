﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001E0 RID: 480
	internal enum NativeResourceType
	{
		// Token: 0x040007DF RID: 2015
		None,
		// Token: 0x040007E0 RID: 2016
		Unmanaged,
		// Token: 0x040007E1 RID: 2017
		Assembly,
		// Token: 0x040007E2 RID: 2018
		Explicit
	}
}
