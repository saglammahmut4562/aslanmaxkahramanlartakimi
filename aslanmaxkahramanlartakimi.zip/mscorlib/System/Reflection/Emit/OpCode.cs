﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001E1 RID: 481
	[ComVisible(true)]
	public struct OpCode
	{
		// Token: 0x06001258 RID: 4696 RVA: 0x000492A0 File Offset: 0x000474A0
		internal OpCode(int p, int q)
		{
			this.op1 = (byte)(p & 255);
			this.op2 = (byte)((p >> 8) & 255);
			this.push = (byte)((p >> 16) & 255);
			this.pop = (byte)((p >> 24) & 255);
			this.size = (byte)(q & 255);
			this.type = (byte)((q >> 8) & 255);
			this.args = (byte)((q >> 16) & 255);
			this.flow = (byte)((q >> 24) & 255);
		}

		// Token: 0x06001259 RID: 4697 RVA: 0x00049330 File Offset: 0x00047530
		public override int GetHashCode()
		{
			return this.Name.GetHashCode();
		}

		// Token: 0x0600125A RID: 4698 RVA: 0x00049340 File Offset: 0x00047540
		public override bool Equals(object obj)
		{
			if (obj == null || !(obj is OpCode))
			{
				return false;
			}
			OpCode opCode = (OpCode)obj;
			return opCode.op1 == this.op1 && opCode.op2 == this.op2;
		}

		// Token: 0x0600125B RID: 4699 RVA: 0x0004938C File Offset: 0x0004758C
		public override string ToString()
		{
			return this.Name;
		}

		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x0600125C RID: 4700 RVA: 0x00049394 File Offset: 0x00047594
		public string Name
		{
			get
			{
				if (this.op1 == 255)
				{
					return OpCodeNames.names[(int)this.op2];
				}
				return OpCodeNames.names[256 + (int)this.op2];
			}
		}

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x0600125D RID: 4701 RVA: 0x000493C8 File Offset: 0x000475C8
		public int Size
		{
			get
			{
				return (int)this.size;
			}
		}

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x0600125E RID: 4702 RVA: 0x000493D0 File Offset: 0x000475D0
		public OperandType OperandType
		{
			get
			{
				return (OperandType)this.args;
			}
		}

		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x0600125F RID: 4703 RVA: 0x000493D8 File Offset: 0x000475D8
		public StackBehaviour StackBehaviourPop
		{
			get
			{
				return (StackBehaviour)this.pop;
			}
		}

		// Token: 0x170002EA RID: 746
		// (get) Token: 0x06001260 RID: 4704 RVA: 0x000493E0 File Offset: 0x000475E0
		public StackBehaviour StackBehaviourPush
		{
			get
			{
				return (StackBehaviour)this.push;
			}
		}

		// Token: 0x170002EB RID: 747
		// (get) Token: 0x06001261 RID: 4705 RVA: 0x000493E8 File Offset: 0x000475E8
		public short Value
		{
			get
			{
				if (this.size == 1)
				{
					return (short)this.op2;
				}
				return (short)(((int)this.op1 << 8) | (int)this.op2);
			}
		}

		// Token: 0x06001262 RID: 4706 RVA: 0x00049410 File Offset: 0x00047610
		public static bool operator ==(OpCode a, OpCode b)
		{
			return a.op1 == b.op1 && a.op2 == b.op2;
		}

		// Token: 0x040007E3 RID: 2019
		internal byte op1;

		// Token: 0x040007E4 RID: 2020
		internal byte op2;

		// Token: 0x040007E5 RID: 2021
		private byte push;

		// Token: 0x040007E6 RID: 2022
		private byte pop;

		// Token: 0x040007E7 RID: 2023
		private byte size;

		// Token: 0x040007E8 RID: 2024
		private byte type;

		// Token: 0x040007E9 RID: 2025
		private byte args;

		// Token: 0x040007EA RID: 2026
		private byte flow;
	}
}
