﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001E3 RID: 483
	[ComVisible(true)]
	public class OpCodes
	{
		// Token: 0x040007EC RID: 2028
		public static readonly OpCode Nop = new OpCode(1179903, 84215041);

		// Token: 0x040007ED RID: 2029
		public static readonly OpCode Break = new OpCode(1180159, 17106177);

		// Token: 0x040007EE RID: 2030
		public static readonly OpCode Ldarg_0 = new OpCode(1245951, 84214017);

		// Token: 0x040007EF RID: 2031
		public static readonly OpCode Ldarg_1 = new OpCode(1246207, 84214017);

		// Token: 0x040007F0 RID: 2032
		public static readonly OpCode Ldarg_2 = new OpCode(1246463, 84214017);

		// Token: 0x040007F1 RID: 2033
		public static readonly OpCode Ldarg_3 = new OpCode(1246719, 84214017);

		// Token: 0x040007F2 RID: 2034
		public static readonly OpCode Ldloc_0 = new OpCode(1246975, 84214017);

		// Token: 0x040007F3 RID: 2035
		public static readonly OpCode Ldloc_1 = new OpCode(1247231, 84214017);

		// Token: 0x040007F4 RID: 2036
		public static readonly OpCode Ldloc_2 = new OpCode(1247487, 84214017);

		// Token: 0x040007F5 RID: 2037
		public static readonly OpCode Ldloc_3 = new OpCode(1247743, 84214017);

		// Token: 0x040007F6 RID: 2038
		public static readonly OpCode Stloc_0 = new OpCode(17959679, 84214017);

		// Token: 0x040007F7 RID: 2039
		public static readonly OpCode Stloc_1 = new OpCode(17959935, 84214017);

		// Token: 0x040007F8 RID: 2040
		public static readonly OpCode Stloc_2 = new OpCode(17960191, 84214017);

		// Token: 0x040007F9 RID: 2041
		public static readonly OpCode Stloc_3 = new OpCode(17960447, 84214017);

		// Token: 0x040007FA RID: 2042
		public static readonly OpCode Ldarg_S = new OpCode(1249023, 85065985);

		// Token: 0x040007FB RID: 2043
		public static readonly OpCode Ldarga_S = new OpCode(1380351, 85065985);

		// Token: 0x040007FC RID: 2044
		public static readonly OpCode Starg_S = new OpCode(17961215, 85065985);

		// Token: 0x040007FD RID: 2045
		public static readonly OpCode Ldloc_S = new OpCode(1249791, 85065985);

		// Token: 0x040007FE RID: 2046
		public static readonly OpCode Ldloca_S = new OpCode(1381119, 85065985);

		// Token: 0x040007FF RID: 2047
		public static readonly OpCode Stloc_S = new OpCode(17961983, 85065985);

		// Token: 0x04000800 RID: 2048
		public static readonly OpCode Ldnull = new OpCode(1643775, 84215041);

		// Token: 0x04000801 RID: 2049
		public static readonly OpCode Ldc_I4_M1 = new OpCode(1381887, 84214017);

		// Token: 0x04000802 RID: 2050
		public static readonly OpCode Ldc_I4_0 = new OpCode(1382143, 84214017);

		// Token: 0x04000803 RID: 2051
		public static readonly OpCode Ldc_I4_1 = new OpCode(1382399, 84214017);

		// Token: 0x04000804 RID: 2052
		public static readonly OpCode Ldc_I4_2 = new OpCode(1382655, 84214017);

		// Token: 0x04000805 RID: 2053
		public static readonly OpCode Ldc_I4_3 = new OpCode(1382911, 84214017);

		// Token: 0x04000806 RID: 2054
		public static readonly OpCode Ldc_I4_4 = new OpCode(1383167, 84214017);

		// Token: 0x04000807 RID: 2055
		public static readonly OpCode Ldc_I4_5 = new OpCode(1383423, 84214017);

		// Token: 0x04000808 RID: 2056
		public static readonly OpCode Ldc_I4_6 = new OpCode(1383679, 84214017);

		// Token: 0x04000809 RID: 2057
		public static readonly OpCode Ldc_I4_7 = new OpCode(1383935, 84214017);

		// Token: 0x0400080A RID: 2058
		public static readonly OpCode Ldc_I4_8 = new OpCode(1384191, 84214017);

		// Token: 0x0400080B RID: 2059
		public static readonly OpCode Ldc_I4_S = new OpCode(1384447, 84934913);

		// Token: 0x0400080C RID: 2060
		public static readonly OpCode Ldc_I4 = new OpCode(1384703, 84018433);

		// Token: 0x0400080D RID: 2061
		public static readonly OpCode Ldc_I8 = new OpCode(1450495, 84083969);

		// Token: 0x0400080E RID: 2062
		public static readonly OpCode Ldc_R4 = new OpCode(1516287, 85001473);

		// Token: 0x0400080F RID: 2063
		public static readonly OpCode Ldc_R8 = new OpCode(1582079, 84346113);

		// Token: 0x04000810 RID: 2064
		public static readonly OpCode Dup = new OpCode(18097663, 84215041);

		// Token: 0x04000811 RID: 2065
		public static readonly OpCode Pop = new OpCode(17966847, 84215041);

		// Token: 0x04000812 RID: 2066
		public static readonly OpCode Jmp = new OpCode(1189887, 33817857);

		// Token: 0x04000813 RID: 2067
		public static readonly OpCode Call = new OpCode(437987583, 33817857);

		// Token: 0x04000814 RID: 2068
		public static readonly OpCode Calli = new OpCode(437987839, 34145537);

		// Token: 0x04000815 RID: 2069
		public static readonly OpCode Ret = new OpCode(437398271, 117769473);

		// Token: 0x04000816 RID: 2070
		public static readonly OpCode Br_S = new OpCode(1190911, 983297);

		// Token: 0x04000817 RID: 2071
		public static readonly OpCode Brfalse_S = new OpCode(51522815, 51314945);

		// Token: 0x04000818 RID: 2072
		public static readonly OpCode Brtrue_S = new OpCode(51523071, 51314945);

		// Token: 0x04000819 RID: 2073
		public static readonly OpCode Beq_S = new OpCode(34746111, 51314945);

		// Token: 0x0400081A RID: 2074
		public static readonly OpCode Bge_S = new OpCode(34746367, 51314945);

		// Token: 0x0400081B RID: 2075
		public static readonly OpCode Bgt_S = new OpCode(34746623, 51314945);

		// Token: 0x0400081C RID: 2076
		public static readonly OpCode Ble_S = new OpCode(34746879, 51314945);

		// Token: 0x0400081D RID: 2077
		public static readonly OpCode Blt_S = new OpCode(34747135, 51314945);

		// Token: 0x0400081E RID: 2078
		public static readonly OpCode Bne_Un_S = new OpCode(34747391, 51314945);

		// Token: 0x0400081F RID: 2079
		public static readonly OpCode Bge_Un_S = new OpCode(34747647, 51314945);

		// Token: 0x04000820 RID: 2080
		public static readonly OpCode Bgt_Un_S = new OpCode(34747903, 51314945);

		// Token: 0x04000821 RID: 2081
		public static readonly OpCode Ble_Un_S = new OpCode(34748159, 51314945);

		// Token: 0x04000822 RID: 2082
		public static readonly OpCode Blt_Un_S = new OpCode(34748415, 51314945);

		// Token: 0x04000823 RID: 2083
		public static readonly OpCode Br = new OpCode(1194239, 1281);

		// Token: 0x04000824 RID: 2084
		public static readonly OpCode Brfalse = new OpCode(51526143, 50332929);

		// Token: 0x04000825 RID: 2085
		public static readonly OpCode Brtrue = new OpCode(51526399, 50332929);

		// Token: 0x04000826 RID: 2086
		public static readonly OpCode Beq = new OpCode(34749439, 50331905);

		// Token: 0x04000827 RID: 2087
		public static readonly OpCode Bge = new OpCode(34749695, 50331905);

		// Token: 0x04000828 RID: 2088
		public static readonly OpCode Bgt = new OpCode(34749951, 50331905);

		// Token: 0x04000829 RID: 2089
		public static readonly OpCode Ble = new OpCode(34750207, 50331905);

		// Token: 0x0400082A RID: 2090
		public static readonly OpCode Blt = new OpCode(34750463, 50331905);

		// Token: 0x0400082B RID: 2091
		public static readonly OpCode Bne_Un = new OpCode(34750719, 50331905);

		// Token: 0x0400082C RID: 2092
		public static readonly OpCode Bge_Un = new OpCode(34750975, 50331905);

		// Token: 0x0400082D RID: 2093
		public static readonly OpCode Bgt_Un = new OpCode(34751231, 50331905);

		// Token: 0x0400082E RID: 2094
		public static readonly OpCode Ble_Un = new OpCode(34751487, 50331905);

		// Token: 0x0400082F RID: 2095
		public static readonly OpCode Blt_Un = new OpCode(34751743, 50331905);

		// Token: 0x04000830 RID: 2096
		public static readonly OpCode Switch = new OpCode(51529215, 51053825);

		// Token: 0x04000831 RID: 2097
		public static readonly OpCode Ldind_I1 = new OpCode(51726079, 84215041);

		// Token: 0x04000832 RID: 2098
		public static readonly OpCode Ldind_U1 = new OpCode(51726335, 84215041);

		// Token: 0x04000833 RID: 2099
		public static readonly OpCode Ldind_I2 = new OpCode(51726591, 84215041);

		// Token: 0x04000834 RID: 2100
		public static readonly OpCode Ldind_U2 = new OpCode(51726847, 84215041);

		// Token: 0x04000835 RID: 2101
		public static readonly OpCode Ldind_I4 = new OpCode(51727103, 84215041);

		// Token: 0x04000836 RID: 2102
		public static readonly OpCode Ldind_U4 = new OpCode(51727359, 84215041);

		// Token: 0x04000837 RID: 2103
		public static readonly OpCode Ldind_I8 = new OpCode(51793151, 84215041);

		// Token: 0x04000838 RID: 2104
		public static readonly OpCode Ldind_I = new OpCode(51727871, 84215041);

		// Token: 0x04000839 RID: 2105
		public static readonly OpCode Ldind_R4 = new OpCode(51859199, 84215041);

		// Token: 0x0400083A RID: 2106
		public static readonly OpCode Ldind_R8 = new OpCode(51924991, 84215041);

		// Token: 0x0400083B RID: 2107
		public static readonly OpCode Ldind_Ref = new OpCode(51990783, 84215041);

		// Token: 0x0400083C RID: 2108
		public static readonly OpCode Stind_Ref = new OpCode(85086719, 84215041);

		// Token: 0x0400083D RID: 2109
		public static readonly OpCode Stind_I1 = new OpCode(85086975, 84215041);

		// Token: 0x0400083E RID: 2110
		public static readonly OpCode Stind_I2 = new OpCode(85087231, 84215041);

		// Token: 0x0400083F RID: 2111
		public static readonly OpCode Stind_I4 = new OpCode(85087487, 84215041);

		// Token: 0x04000840 RID: 2112
		public static readonly OpCode Stind_I8 = new OpCode(101864959, 84215041);

		// Token: 0x04000841 RID: 2113
		public static readonly OpCode Stind_R4 = new OpCode(135419647, 84215041);

		// Token: 0x04000842 RID: 2114
		public static readonly OpCode Stind_R8 = new OpCode(152197119, 84215041);

		// Token: 0x04000843 RID: 2115
		public static readonly OpCode Add = new OpCode(34822399, 84215041);

		// Token: 0x04000844 RID: 2116
		public static readonly OpCode Sub = new OpCode(34822655, 84215041);

		// Token: 0x04000845 RID: 2117
		public static readonly OpCode Mul = new OpCode(34822911, 84215041);

		// Token: 0x04000846 RID: 2118
		public static readonly OpCode Div = new OpCode(34823167, 84215041);

		// Token: 0x04000847 RID: 2119
		public static readonly OpCode Div_Un = new OpCode(34823423, 84215041);

		// Token: 0x04000848 RID: 2120
		public static readonly OpCode Rem = new OpCode(34823679, 84215041);

		// Token: 0x04000849 RID: 2121
		public static readonly OpCode Rem_Un = new OpCode(34823935, 84215041);

		// Token: 0x0400084A RID: 2122
		public static readonly OpCode And = new OpCode(34824191, 84215041);

		// Token: 0x0400084B RID: 2123
		public static readonly OpCode Or = new OpCode(34824447, 84215041);

		// Token: 0x0400084C RID: 2124
		public static readonly OpCode Xor = new OpCode(34824703, 84215041);

		// Token: 0x0400084D RID: 2125
		public static readonly OpCode Shl = new OpCode(34824959, 84215041);

		// Token: 0x0400084E RID: 2126
		public static readonly OpCode Shr = new OpCode(34825215, 84215041);

		// Token: 0x0400084F RID: 2127
		public static readonly OpCode Shr_Un = new OpCode(34825471, 84215041);

		// Token: 0x04000850 RID: 2128
		public static readonly OpCode Neg = new OpCode(18048511, 84215041);

		// Token: 0x04000851 RID: 2129
		public static readonly OpCode Not = new OpCode(18048767, 84215041);

		// Token: 0x04000852 RID: 2130
		public static readonly OpCode Conv_I1 = new OpCode(18180095, 84215041);

		// Token: 0x04000853 RID: 2131
		public static readonly OpCode Conv_I2 = new OpCode(18180351, 84215041);

		// Token: 0x04000854 RID: 2132
		public static readonly OpCode Conv_I4 = new OpCode(18180607, 84215041);

		// Token: 0x04000855 RID: 2133
		public static readonly OpCode Conv_I8 = new OpCode(18246399, 84215041);

		// Token: 0x04000856 RID: 2134
		public static readonly OpCode Conv_R4 = new OpCode(18312191, 84215041);

		// Token: 0x04000857 RID: 2135
		public static readonly OpCode Conv_R8 = new OpCode(18377983, 84215041);

		// Token: 0x04000858 RID: 2136
		public static readonly OpCode Conv_U4 = new OpCode(18181631, 84215041);

		// Token: 0x04000859 RID: 2137
		public static readonly OpCode Conv_U8 = new OpCode(18247423, 84215041);

		// Token: 0x0400085A RID: 2138
		public static readonly OpCode Callvirt = new OpCode(438005759, 33817345);

		// Token: 0x0400085B RID: 2139
		public static readonly OpCode Cpobj = new OpCode(85094655, 84738817);

		// Token: 0x0400085C RID: 2140
		public static readonly OpCode Ldobj = new OpCode(51606015, 84738817);

		// Token: 0x0400085D RID: 2141
		public static readonly OpCode Ldstr = new OpCode(1667839, 84542209);

		// Token: 0x0400085E RID: 2142
		public static readonly OpCode Newobj = new OpCode(437875711, 33817345);

		// Token: 0x0400085F RID: 2143
		[ComVisible(true)]
		public static readonly OpCode Castclass = new OpCode(169440511, 84738817);

		// Token: 0x04000860 RID: 2144
		public static readonly OpCode Isinst = new OpCode(169178623, 84738817);

		// Token: 0x04000861 RID: 2145
		public static readonly OpCode Conv_R_Un = new OpCode(18380543, 84215041);

		// Token: 0x04000862 RID: 2146
		public static readonly OpCode Unbox = new OpCode(169179647, 84739329);

		// Token: 0x04000863 RID: 2147
		public static readonly OpCode Throw = new OpCode(168983295, 134546177);

		// Token: 0x04000864 RID: 2148
		public static readonly OpCode Ldfld = new OpCode(169049087, 83952385);

		// Token: 0x04000865 RID: 2149
		public static readonly OpCode Ldflda = new OpCode(169180415, 83952385);

		// Token: 0x04000866 RID: 2150
		public static readonly OpCode Stfld = new OpCode(185761279, 83952385);

		// Token: 0x04000867 RID: 2151
		public static readonly OpCode Ldsfld = new OpCode(1277695, 83952385);

		// Token: 0x04000868 RID: 2152
		public static readonly OpCode Ldsflda = new OpCode(1409023, 83952385);

		// Token: 0x04000869 RID: 2153
		public static readonly OpCode Stsfld = new OpCode(17989887, 83952385);

		// Token: 0x0400086A RID: 2154
		public static readonly OpCode Stobj = new OpCode(68321791, 84739329);

		// Token: 0x0400086B RID: 2155
		public static readonly OpCode Conv_Ovf_I1_Un = new OpCode(18187007, 84215041);

		// Token: 0x0400086C RID: 2156
		public static readonly OpCode Conv_Ovf_I2_Un = new OpCode(18187263, 84215041);

		// Token: 0x0400086D RID: 2157
		public static readonly OpCode Conv_Ovf_I4_Un = new OpCode(18187519, 84215041);

		// Token: 0x0400086E RID: 2158
		public static readonly OpCode Conv_Ovf_I8_Un = new OpCode(18253311, 84215041);

		// Token: 0x0400086F RID: 2159
		public static readonly OpCode Conv_Ovf_U1_Un = new OpCode(18188031, 84215041);

		// Token: 0x04000870 RID: 2160
		public static readonly OpCode Conv_Ovf_U2_Un = new OpCode(18188287, 84215041);

		// Token: 0x04000871 RID: 2161
		public static readonly OpCode Conv_Ovf_U4_Un = new OpCode(18188543, 84215041);

		// Token: 0x04000872 RID: 2162
		public static readonly OpCode Conv_Ovf_U8_Un = new OpCode(18254335, 84215041);

		// Token: 0x04000873 RID: 2163
		public static readonly OpCode Conv_Ovf_I_Un = new OpCode(18189055, 84215041);

		// Token: 0x04000874 RID: 2164
		public static readonly OpCode Conv_Ovf_U_Un = new OpCode(18189311, 84215041);

		// Token: 0x04000875 RID: 2165
		public static readonly OpCode Box = new OpCode(18451711, 84739329);

		// Token: 0x04000876 RID: 2166
		public static readonly OpCode Newarr = new OpCode(52006399, 84738817);

		// Token: 0x04000877 RID: 2167
		public static readonly OpCode Ldlen = new OpCode(169185023, 84214529);

		// Token: 0x04000878 RID: 2168
		public static readonly OpCode Ldelema = new OpCode(202739711, 84738817);

		// Token: 0x04000879 RID: 2169
		public static readonly OpCode Ldelem_I1 = new OpCode(202739967, 84214529);

		// Token: 0x0400087A RID: 2170
		public static readonly OpCode Ldelem_U1 = new OpCode(202740223, 84214529);

		// Token: 0x0400087B RID: 2171
		public static readonly OpCode Ldelem_I2 = new OpCode(202740479, 84214529);

		// Token: 0x0400087C RID: 2172
		public static readonly OpCode Ldelem_U2 = new OpCode(202740735, 84214529);

		// Token: 0x0400087D RID: 2173
		public static readonly OpCode Ldelem_I4 = new OpCode(202740991, 84214529);

		// Token: 0x0400087E RID: 2174
		public static readonly OpCode Ldelem_U4 = new OpCode(202741247, 84214529);

		// Token: 0x0400087F RID: 2175
		public static readonly OpCode Ldelem_I8 = new OpCode(202807039, 84214529);

		// Token: 0x04000880 RID: 2176
		public static readonly OpCode Ldelem_I = new OpCode(202741759, 84214529);

		// Token: 0x04000881 RID: 2177
		public static readonly OpCode Ldelem_R4 = new OpCode(202873087, 84214529);

		// Token: 0x04000882 RID: 2178
		public static readonly OpCode Ldelem_R8 = new OpCode(202938879, 84214529);

		// Token: 0x04000883 RID: 2179
		public static readonly OpCode Ldelem_Ref = new OpCode(203004671, 84214529);

		// Token: 0x04000884 RID: 2180
		public static readonly OpCode Stelem_I = new OpCode(219323391, 84214529);

		// Token: 0x04000885 RID: 2181
		public static readonly OpCode Stelem_I1 = new OpCode(219323647, 84214529);

		// Token: 0x04000886 RID: 2182
		public static readonly OpCode Stelem_I2 = new OpCode(219323903, 84214529);

		// Token: 0x04000887 RID: 2183
		public static readonly OpCode Stelem_I4 = new OpCode(219324159, 84214529);

		// Token: 0x04000888 RID: 2184
		public static readonly OpCode Stelem_I8 = new OpCode(236101631, 84214529);

		// Token: 0x04000889 RID: 2185
		public static readonly OpCode Stelem_R4 = new OpCode(252879103, 84214529);

		// Token: 0x0400088A RID: 2186
		public static readonly OpCode Stelem_R8 = new OpCode(269656575, 84214529);

		// Token: 0x0400088B RID: 2187
		public static readonly OpCode Stelem_Ref = new OpCode(286434047, 84214529);

		// Token: 0x0400088C RID: 2188
		public static readonly OpCode Ldelem = new OpCode(202613759, 84738817);

		// Token: 0x0400088D RID: 2189
		public static readonly OpCode Stelem = new OpCode(470983935, 84738817);

		// Token: 0x0400088E RID: 2190
		public static readonly OpCode Unbox_Any = new OpCode(169059839, 84738817);

		// Token: 0x0400088F RID: 2191
		public static readonly OpCode Conv_Ovf_I1 = new OpCode(18199551, 84215041);

		// Token: 0x04000890 RID: 2192
		public static readonly OpCode Conv_Ovf_U1 = new OpCode(18199807, 84215041);

		// Token: 0x04000891 RID: 2193
		public static readonly OpCode Conv_Ovf_I2 = new OpCode(18200063, 84215041);

		// Token: 0x04000892 RID: 2194
		public static readonly OpCode Conv_Ovf_U2 = new OpCode(18200319, 84215041);

		// Token: 0x04000893 RID: 2195
		public static readonly OpCode Conv_Ovf_I4 = new OpCode(18200575, 84215041);

		// Token: 0x04000894 RID: 2196
		public static readonly OpCode Conv_Ovf_U4 = new OpCode(18200831, 84215041);

		// Token: 0x04000895 RID: 2197
		public static readonly OpCode Conv_Ovf_I8 = new OpCode(18266623, 84215041);

		// Token: 0x04000896 RID: 2198
		public static readonly OpCode Conv_Ovf_U8 = new OpCode(18266879, 84215041);

		// Token: 0x04000897 RID: 2199
		public static readonly OpCode Refanyval = new OpCode(18203391, 84739329);

		// Token: 0x04000898 RID: 2200
		public static readonly OpCode Ckfinite = new OpCode(18400255, 84215041);

		// Token: 0x04000899 RID: 2201
		public static readonly OpCode Mkrefany = new OpCode(51627775, 84739329);

		// Token: 0x0400089A RID: 2202
		public static readonly OpCode Ldtoken = new OpCode(1429759, 84673793);

		// Token: 0x0400089B RID: 2203
		public static readonly OpCode Conv_U2 = new OpCode(18207231, 84215041);

		// Token: 0x0400089C RID: 2204
		public static readonly OpCode Conv_U1 = new OpCode(18207487, 84215041);

		// Token: 0x0400089D RID: 2205
		public static readonly OpCode Conv_I = new OpCode(18207743, 84215041);

		// Token: 0x0400089E RID: 2206
		public static readonly OpCode Conv_Ovf_I = new OpCode(18207999, 84215041);

		// Token: 0x0400089F RID: 2207
		public static readonly OpCode Conv_Ovf_U = new OpCode(18208255, 84215041);

		// Token: 0x040008A0 RID: 2208
		public static readonly OpCode Add_Ovf = new OpCode(34854655, 84215041);

		// Token: 0x040008A1 RID: 2209
		public static readonly OpCode Add_Ovf_Un = new OpCode(34854911, 84215041);

		// Token: 0x040008A2 RID: 2210
		public static readonly OpCode Mul_Ovf = new OpCode(34855167, 84215041);

		// Token: 0x040008A3 RID: 2211
		public static readonly OpCode Mul_Ovf_Un = new OpCode(34855423, 84215041);

		// Token: 0x040008A4 RID: 2212
		public static readonly OpCode Sub_Ovf = new OpCode(34855679, 84215041);

		// Token: 0x040008A5 RID: 2213
		public static readonly OpCode Sub_Ovf_Un = new OpCode(34855935, 84215041);

		// Token: 0x040008A6 RID: 2214
		public static readonly OpCode Endfinally = new OpCode(1236223, 117769473);

		// Token: 0x040008A7 RID: 2215
		public static readonly OpCode Leave = new OpCode(1236479, 1281);

		// Token: 0x040008A8 RID: 2216
		public static readonly OpCode Leave_S = new OpCode(1236735, 984321);

		// Token: 0x040008A9 RID: 2217
		public static readonly OpCode Stind_I = new OpCode(85123071, 84215041);

		// Token: 0x040008AA RID: 2218
		public static readonly OpCode Conv_U = new OpCode(18211071, 84215041);

		// Token: 0x040008AB RID: 2219
		public static readonly OpCode Prefix7 = new OpCode(1243391, 67437057);

		// Token: 0x040008AC RID: 2220
		public static readonly OpCode Prefix6 = new OpCode(1243647, 67437057);

		// Token: 0x040008AD RID: 2221
		public static readonly OpCode Prefix5 = new OpCode(1243903, 67437057);

		// Token: 0x040008AE RID: 2222
		public static readonly OpCode Prefix4 = new OpCode(1244159, 67437057);

		// Token: 0x040008AF RID: 2223
		public static readonly OpCode Prefix3 = new OpCode(1244415, 67437057);

		// Token: 0x040008B0 RID: 2224
		public static readonly OpCode Prefix2 = new OpCode(1244671, 67437057);

		// Token: 0x040008B1 RID: 2225
		public static readonly OpCode Prefix1 = new OpCode(1244927, 67437057);

		// Token: 0x040008B2 RID: 2226
		public static readonly OpCode Prefixref = new OpCode(1245183, 67437057);

		// Token: 0x040008B3 RID: 2227
		public static readonly OpCode Arglist = new OpCode(1376510, 84215042);

		// Token: 0x040008B4 RID: 2228
		public static readonly OpCode Ceq = new OpCode(34931198, 84215042);

		// Token: 0x040008B5 RID: 2229
		public static readonly OpCode Cgt = new OpCode(34931454, 84215042);

		// Token: 0x040008B6 RID: 2230
		public static readonly OpCode Cgt_Un = new OpCode(34931710, 84215042);

		// Token: 0x040008B7 RID: 2231
		public static readonly OpCode Clt = new OpCode(34931966, 84215042);

		// Token: 0x040008B8 RID: 2232
		public static readonly OpCode Clt_Un = new OpCode(34932222, 84215042);

		// Token: 0x040008B9 RID: 2233
		public static readonly OpCode Ldftn = new OpCode(1378046, 84149506);

		// Token: 0x040008BA RID: 2234
		public static readonly OpCode Ldvirtftn = new OpCode(169150462, 84149506);

		// Token: 0x040008BB RID: 2235
		public static readonly OpCode Ldarg = new OpCode(1247742, 84804866);

		// Token: 0x040008BC RID: 2236
		public static readonly OpCode Ldarga = new OpCode(1379070, 84804866);

		// Token: 0x040008BD RID: 2237
		public static readonly OpCode Starg = new OpCode(17959934, 84804866);

		// Token: 0x040008BE RID: 2238
		public static readonly OpCode Ldloc = new OpCode(1248510, 84804866);

		// Token: 0x040008BF RID: 2239
		public static readonly OpCode Ldloca = new OpCode(1379838, 84804866);

		// Token: 0x040008C0 RID: 2240
		public static readonly OpCode Stloc = new OpCode(17960702, 84804866);

		// Token: 0x040008C1 RID: 2241
		public static readonly OpCode Localloc = new OpCode(51711998, 84215042);

		// Token: 0x040008C2 RID: 2242
		public static readonly OpCode Endfilter = new OpCode(51515902, 117769474);

		// Token: 0x040008C3 RID: 2243
		public static readonly OpCode Unaligned = new OpCode(1184510, 68158466);

		// Token: 0x040008C4 RID: 2244
		public static readonly OpCode Volatile = new OpCode(1184766, 67437570);

		// Token: 0x040008C5 RID: 2245
		public static readonly OpCode Tailcall = new OpCode(1185022, 67437570);

		// Token: 0x040008C6 RID: 2246
		public static readonly OpCode Initobj = new OpCode(51516926, 84738818);

		// Token: 0x040008C7 RID: 2247
		public static readonly OpCode Constrained = new OpCode(1185534, 67961858);

		// Token: 0x040008C8 RID: 2248
		public static readonly OpCode Cpblk = new OpCode(118626302, 84215042);

		// Token: 0x040008C9 RID: 2249
		public static readonly OpCode Initblk = new OpCode(118626558, 84215042);

		// Token: 0x040008CA RID: 2250
		public static readonly OpCode Rethrow = new OpCode(1186558, 134546178);

		// Token: 0x040008CB RID: 2251
		public static readonly OpCode Sizeof = new OpCode(1383678, 84739330);

		// Token: 0x040008CC RID: 2252
		public static readonly OpCode Refanytype = new OpCode(18161150, 84215042);

		// Token: 0x040008CD RID: 2253
		public static readonly OpCode Readonly = new OpCode(1187582, 67437570);
	}
}
