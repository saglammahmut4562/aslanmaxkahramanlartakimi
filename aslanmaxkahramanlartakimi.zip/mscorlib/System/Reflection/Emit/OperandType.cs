﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001E4 RID: 484
	[ComVisible(true)]
	[Serializable]
	public enum OperandType
	{
		// Token: 0x040008CF RID: 2255
		InlineBrTarget,
		// Token: 0x040008D0 RID: 2256
		InlineField,
		// Token: 0x040008D1 RID: 2257
		InlineI,
		// Token: 0x040008D2 RID: 2258
		InlineI8,
		// Token: 0x040008D3 RID: 2259
		InlineMethod,
		// Token: 0x040008D4 RID: 2260
		InlineNone,
		// Token: 0x040008D5 RID: 2261
		[Obsolete("This API has been deprecated.")]
		InlinePhi,
		// Token: 0x040008D6 RID: 2262
		InlineR,
		// Token: 0x040008D7 RID: 2263
		InlineSig = 9,
		// Token: 0x040008D8 RID: 2264
		InlineString,
		// Token: 0x040008D9 RID: 2265
		InlineSwitch,
		// Token: 0x040008DA RID: 2266
		InlineTok,
		// Token: 0x040008DB RID: 2267
		InlineType,
		// Token: 0x040008DC RID: 2268
		InlineVar,
		// Token: 0x040008DD RID: 2269
		ShortInlineBrTarget,
		// Token: 0x040008DE RID: 2270
		ShortInlineI,
		// Token: 0x040008DF RID: 2271
		ShortInlineR,
		// Token: 0x040008E0 RID: 2272
		ShortInlineVar
	}
}
