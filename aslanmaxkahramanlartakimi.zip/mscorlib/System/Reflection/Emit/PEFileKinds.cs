﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001E7 RID: 487
	[ComVisible(true)]
	[Serializable]
	public enum PEFileKinds
	{
		// Token: 0x040008F4 RID: 2292
		Dll = 1,
		// Token: 0x040008F5 RID: 2293
		ConsoleApplication,
		// Token: 0x040008F6 RID: 2294
		WindowApplication
	}
}
