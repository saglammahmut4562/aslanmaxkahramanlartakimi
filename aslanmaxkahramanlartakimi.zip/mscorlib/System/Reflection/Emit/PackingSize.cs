﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001E5 RID: 485
	[ComVisible(true)]
	[Serializable]
	public enum PackingSize
	{
		// Token: 0x040008E2 RID: 2274
		Unspecified,
		// Token: 0x040008E3 RID: 2275
		Size1,
		// Token: 0x040008E4 RID: 2276
		Size2,
		// Token: 0x040008E5 RID: 2277
		Size4 = 4,
		// Token: 0x040008E6 RID: 2278
		Size8 = 8,
		// Token: 0x040008E7 RID: 2279
		Size16 = 16,
		// Token: 0x040008E8 RID: 2280
		Size32 = 32,
		// Token: 0x040008E9 RID: 2281
		Size64 = 64,
		// Token: 0x040008EA RID: 2282
		Size128 = 128
	}
}
