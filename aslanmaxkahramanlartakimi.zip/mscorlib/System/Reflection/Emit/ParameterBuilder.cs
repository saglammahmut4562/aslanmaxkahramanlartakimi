﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001E6 RID: 486
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_ParameterBuilder))]
	[ComVisible(true)]
	public class ParameterBuilder : _ParameterBuilder
	{
		// Token: 0x170002EC RID: 748
		// (get) Token: 0x06001265 RID: 4709 RVA: 0x0004AF24 File Offset: 0x00049124
		public virtual int Attributes
		{
			get
			{
				return (int)this.attrs;
			}
		}

		// Token: 0x170002ED RID: 749
		// (get) Token: 0x06001266 RID: 4710 RVA: 0x0004AF2C File Offset: 0x0004912C
		public virtual string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x170002EE RID: 750
		// (get) Token: 0x06001267 RID: 4711 RVA: 0x0004AF34 File Offset: 0x00049134
		public virtual int Position
		{
			get
			{
				return this.position;
			}
		}

		// Token: 0x040008EB RID: 2283
		private MethodBase methodb;

		// Token: 0x040008EC RID: 2284
		private string name;

		// Token: 0x040008ED RID: 2285
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x040008EE RID: 2286
		private UnmanagedMarshal marshal_info;

		// Token: 0x040008EF RID: 2287
		private ParameterAttributes attrs;

		// Token: 0x040008F0 RID: 2288
		private int position;

		// Token: 0x040008F1 RID: 2289
		private int table_idx;

		// Token: 0x040008F2 RID: 2290
		private object def_value;
	}
}
