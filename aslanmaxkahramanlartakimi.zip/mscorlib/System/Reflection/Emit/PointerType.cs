﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001E8 RID: 488
	internal class PointerType : DerivedType
	{
		// Token: 0x06001268 RID: 4712 RVA: 0x0004AF3C File Offset: 0x0004913C
		internal PointerType(Type elementType)
			: base(elementType)
		{
		}

		// Token: 0x06001269 RID: 4713 RVA: 0x0004AF48 File Offset: 0x00049148
		protected override bool IsPointerImpl()
		{
			return true;
		}

		// Token: 0x170002EF RID: 751
		// (get) Token: 0x0600126A RID: 4714 RVA: 0x0004AF4C File Offset: 0x0004914C
		public override Type BaseType
		{
			get
			{
				return typeof(Array);
			}
		}

		// Token: 0x0600126B RID: 4715 RVA: 0x0004AF58 File Offset: 0x00049158
		internal override string FormatName(string elementName)
		{
			if (elementName == null)
			{
				return null;
			}
			return elementName + "*";
		}
	}
}
