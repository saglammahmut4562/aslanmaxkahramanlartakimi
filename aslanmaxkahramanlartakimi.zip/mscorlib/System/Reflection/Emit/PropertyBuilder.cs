﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001E9 RID: 489
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_PropertyBuilder))]
	public sealed class PropertyBuilder : PropertyInfo, _PropertyBuilder
	{
		// Token: 0x170002F0 RID: 752
		// (get) Token: 0x0600126C RID: 4716 RVA: 0x0004AF70 File Offset: 0x00049170
		public override PropertyAttributes Attributes
		{
			get
			{
				return this.attrs;
			}
		}

		// Token: 0x170002F1 RID: 753
		// (get) Token: 0x0600126D RID: 4717 RVA: 0x0004AF78 File Offset: 0x00049178
		public override bool CanRead
		{
			get
			{
				return this.get_method != null;
			}
		}

		// Token: 0x170002F2 RID: 754
		// (get) Token: 0x0600126E RID: 4718 RVA: 0x0004AF88 File Offset: 0x00049188
		public override bool CanWrite
		{
			get
			{
				return this.set_method != null;
			}
		}

		// Token: 0x170002F3 RID: 755
		// (get) Token: 0x0600126F RID: 4719 RVA: 0x0004AF98 File Offset: 0x00049198
		public override Type DeclaringType
		{
			get
			{
				return this.typeb;
			}
		}

		// Token: 0x170002F4 RID: 756
		// (get) Token: 0x06001270 RID: 4720 RVA: 0x0004AFA0 File Offset: 0x000491A0
		public override string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x170002F5 RID: 757
		// (get) Token: 0x06001271 RID: 4721 RVA: 0x0004AFA8 File Offset: 0x000491A8
		public override Type PropertyType
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x170002F6 RID: 758
		// (get) Token: 0x06001272 RID: 4722 RVA: 0x0004AFB0 File Offset: 0x000491B0
		public override Type ReflectedType
		{
			get
			{
				return this.typeb;
			}
		}

		// Token: 0x06001273 RID: 4723 RVA: 0x0004AFB8 File Offset: 0x000491B8
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw this.not_supported();
		}

		// Token: 0x06001274 RID: 4724 RVA: 0x0004AFC0 File Offset: 0x000491C0
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw this.not_supported();
		}

		// Token: 0x06001275 RID: 4725 RVA: 0x0004AFC8 File Offset: 0x000491C8
		public override MethodInfo GetGetMethod(bool nonPublic)
		{
			return this.get_method;
		}

		// Token: 0x06001276 RID: 4726 RVA: 0x0004AFD0 File Offset: 0x000491D0
		public override ParameterInfo[] GetIndexParameters()
		{
			throw this.not_supported();
		}

		// Token: 0x06001277 RID: 4727 RVA: 0x0004AFD8 File Offset: 0x000491D8
		public override MethodInfo GetSetMethod(bool nonPublic)
		{
			return this.set_method;
		}

		// Token: 0x06001278 RID: 4728 RVA: 0x0004AFE0 File Offset: 0x000491E0
		public override object GetValue(object obj, object[] index)
		{
			return null;
		}

		// Token: 0x06001279 RID: 4729 RVA: 0x0004AFE4 File Offset: 0x000491E4
		public override object GetValue(object obj, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
		{
			throw this.not_supported();
		}

		// Token: 0x0600127A RID: 4730 RVA: 0x0004AFEC File Offset: 0x000491EC
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw this.not_supported();
		}

		// Token: 0x0600127B RID: 4731 RVA: 0x0004AFF4 File Offset: 0x000491F4
		public override void SetValue(object obj, object value, object[] index)
		{
		}

		// Token: 0x0600127C RID: 4732 RVA: 0x0004AFF8 File Offset: 0x000491F8
		public override void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
		{
		}

		// Token: 0x170002F7 RID: 759
		// (get) Token: 0x0600127D RID: 4733 RVA: 0x0004AFFC File Offset: 0x000491FC
		public override Module Module
		{
			get
			{
				return base.Module;
			}
		}

		// Token: 0x0600127E RID: 4734 RVA: 0x0004B004 File Offset: 0x00049204
		private Exception not_supported()
		{
			return new NotSupportedException("The invoked member is not supported in a dynamic module.");
		}

		// Token: 0x040008F7 RID: 2295
		private PropertyAttributes attrs;

		// Token: 0x040008F8 RID: 2296
		private string name;

		// Token: 0x040008F9 RID: 2297
		private Type type;

		// Token: 0x040008FA RID: 2298
		private Type[] parameters;

		// Token: 0x040008FB RID: 2299
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x040008FC RID: 2300
		private object def_value;

		// Token: 0x040008FD RID: 2301
		private MethodBuilder set_method;

		// Token: 0x040008FE RID: 2302
		private MethodBuilder get_method;

		// Token: 0x040008FF RID: 2303
		private int table_idx;

		// Token: 0x04000900 RID: 2304
		internal TypeBuilder typeb;

		// Token: 0x04000901 RID: 2305
		private Type[] returnModReq;

		// Token: 0x04000902 RID: 2306
		private Type[] returnModOpt;

		// Token: 0x04000903 RID: 2307
		private Type[][] paramModReq;

		// Token: 0x04000904 RID: 2308
		private Type[][] paramModOpt;
	}
}
