﻿using System;
using System.Globalization;

namespace System.Reflection.Emit
{
	// Token: 0x020001EA RID: 490
	internal class PropertyOnTypeBuilderInst : PropertyInfo
	{
		// Token: 0x0600127F RID: 4735 RVA: 0x0004B010 File Offset: 0x00049210
		internal PropertyOnTypeBuilderInst(MonoGenericClass instantiation, PropertyInfo prop)
		{
			this.instantiation = instantiation;
			this.prop = prop;
		}

		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x06001280 RID: 4736 RVA: 0x0004B028 File Offset: 0x00049228
		public override PropertyAttributes Attributes
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x06001281 RID: 4737 RVA: 0x0004B030 File Offset: 0x00049230
		public override bool CanRead
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x06001282 RID: 4738 RVA: 0x0004B038 File Offset: 0x00049238
		public override bool CanWrite
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x170002FB RID: 763
		// (get) Token: 0x06001283 RID: 4739 RVA: 0x0004B040 File Offset: 0x00049240
		public override Type PropertyType
		{
			get
			{
				return this.instantiation.InflateType(this.prop.PropertyType);
			}
		}

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06001284 RID: 4740 RVA: 0x0004B058 File Offset: 0x00049258
		public override Type DeclaringType
		{
			get
			{
				return this.instantiation.InflateType(this.prop.DeclaringType);
			}
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06001285 RID: 4741 RVA: 0x0004B070 File Offset: 0x00049270
		public override Type ReflectedType
		{
			get
			{
				return this.instantiation;
			}
		}

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x06001286 RID: 4742 RVA: 0x0004B078 File Offset: 0x00049278
		public override string Name
		{
			get
			{
				return this.prop.Name;
			}
		}

		// Token: 0x06001287 RID: 4743 RVA: 0x0004B088 File Offset: 0x00049288
		public override MethodInfo GetGetMethod(bool nonPublic)
		{
			MethodInfo methodInfo = this.prop.GetGetMethod(nonPublic);
			if (methodInfo != null && this.prop.DeclaringType == this.instantiation.generic_type)
			{
				methodInfo = TypeBuilder.GetMethod(this.instantiation, methodInfo);
			}
			return methodInfo;
		}

		// Token: 0x06001288 RID: 4744 RVA: 0x0004B0D4 File Offset: 0x000492D4
		public override ParameterInfo[] GetIndexParameters()
		{
			MethodInfo getMethod = this.GetGetMethod(true);
			if (getMethod != null)
			{
				return getMethod.GetParameters();
			}
			return new ParameterInfo[0];
		}

		// Token: 0x06001289 RID: 4745 RVA: 0x0004B0FC File Offset: 0x000492FC
		public override MethodInfo GetSetMethod(bool nonPublic)
		{
			MethodInfo methodInfo = this.prop.GetSetMethod(nonPublic);
			if (methodInfo != null && this.prop.DeclaringType == this.instantiation.generic_type)
			{
				methodInfo = TypeBuilder.GetMethod(this.instantiation, methodInfo);
			}
			return methodInfo;
		}

		// Token: 0x0600128A RID: 4746 RVA: 0x0004B148 File Offset: 0x00049348
		public override string ToString()
		{
			return string.Format("{0} {1}", this.PropertyType, this.Name);
		}

		// Token: 0x0600128B RID: 4747 RVA: 0x0004B160 File Offset: 0x00049360
		public override object GetValue(object obj, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600128C RID: 4748 RVA: 0x0004B168 File Offset: 0x00049368
		public override void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600128D RID: 4749 RVA: 0x0004B170 File Offset: 0x00049370
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600128E RID: 4750 RVA: 0x0004B178 File Offset: 0x00049378
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600128F RID: 4751 RVA: 0x0004B180 File Offset: 0x00049380
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x04000905 RID: 2309
		private MonoGenericClass instantiation;

		// Token: 0x04000906 RID: 2310
		private PropertyInfo prop;
	}
}
