﻿using System;
using System.Security.Permissions;

namespace System.Reflection.Emit
{
	// Token: 0x020001EB RID: 491
	internal struct RefEmitPermissionSet
	{
		// Token: 0x04000907 RID: 2311
		public SecurityAction action;

		// Token: 0x04000908 RID: 2312
		public string pset;
	}
}
