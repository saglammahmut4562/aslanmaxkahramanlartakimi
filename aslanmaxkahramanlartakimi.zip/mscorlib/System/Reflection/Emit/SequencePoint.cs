﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001EC RID: 492
	internal struct SequencePoint
	{
		// Token: 0x04000909 RID: 2313
		public int Offset;

		// Token: 0x0400090A RID: 2314
		public int Line;

		// Token: 0x0400090B RID: 2315
		public int Col;

		// Token: 0x0400090C RID: 2316
		public int EndLine;

		// Token: 0x0400090D RID: 2317
		public int EndCol;
	}
}
