﻿using System;
using System.Diagnostics.SymbolStore;

namespace System.Reflection.Emit
{
	// Token: 0x020001ED RID: 493
	internal class SequencePointList
	{
		// Token: 0x0400090E RID: 2318
		private const int arrayGrow = 10;

		// Token: 0x0400090F RID: 2319
		private ISymbolDocumentWriter doc;

		// Token: 0x04000910 RID: 2320
		private SequencePoint[] points;

		// Token: 0x04000911 RID: 2321
		private int count;
	}
}
