﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001EE RID: 494
	[ComVisible(true)]
	[Serializable]
	public enum StackBehaviour
	{
		// Token: 0x04000913 RID: 2323
		Pop0,
		// Token: 0x04000914 RID: 2324
		Pop1,
		// Token: 0x04000915 RID: 2325
		Pop1_pop1,
		// Token: 0x04000916 RID: 2326
		Popi,
		// Token: 0x04000917 RID: 2327
		Popi_pop1,
		// Token: 0x04000918 RID: 2328
		Popi_popi,
		// Token: 0x04000919 RID: 2329
		Popi_popi8,
		// Token: 0x0400091A RID: 2330
		Popi_popi_popi,
		// Token: 0x0400091B RID: 2331
		Popi_popr4,
		// Token: 0x0400091C RID: 2332
		Popi_popr8,
		// Token: 0x0400091D RID: 2333
		Popref,
		// Token: 0x0400091E RID: 2334
		Popref_pop1,
		// Token: 0x0400091F RID: 2335
		Popref_popi,
		// Token: 0x04000920 RID: 2336
		Popref_popi_popi,
		// Token: 0x04000921 RID: 2337
		Popref_popi_popi8,
		// Token: 0x04000922 RID: 2338
		Popref_popi_popr4,
		// Token: 0x04000923 RID: 2339
		Popref_popi_popr8,
		// Token: 0x04000924 RID: 2340
		Popref_popi_popref,
		// Token: 0x04000925 RID: 2341
		Push0,
		// Token: 0x04000926 RID: 2342
		Push1,
		// Token: 0x04000927 RID: 2343
		Push1_push1,
		// Token: 0x04000928 RID: 2344
		Pushi,
		// Token: 0x04000929 RID: 2345
		Pushi8,
		// Token: 0x0400092A RID: 2346
		Pushr4,
		// Token: 0x0400092B RID: 2347
		Pushr8,
		// Token: 0x0400092C RID: 2348
		Pushref,
		// Token: 0x0400092D RID: 2349
		Varpop,
		// Token: 0x0400092E RID: 2350
		Varpush,
		// Token: 0x0400092F RID: 2351
		Popref_popi_pop1
	}
}
