﻿using System;

namespace System.Reflection.Emit
{
	// Token: 0x020001EF RID: 495
	internal interface TokenGenerator
	{
		// Token: 0x06001290 RID: 4752
		int GetToken(string str);

		// Token: 0x06001291 RID: 4753
		int GetToken(MemberInfo member);

		// Token: 0x06001292 RID: 4754
		int GetToken(MethodInfo method, Type[] opt_param_types);
	}
}
