﻿using System;
using System.Collections;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001F0 RID: 496
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_TypeBuilder))]
	public sealed class TypeBuilder : Type, _TypeBuilder
	{
		// Token: 0x06001293 RID: 4755 RVA: 0x0004B188 File Offset: 0x00049388
		internal TypeBuilder(ModuleBuilder mb, TypeAttributes attr, int table_idx)
		{
			this.parent = null;
			this.attrs = attr;
			this.class_size = 0;
			this.table_idx = table_idx;
			this.fullname = (this.tname = ((table_idx != 1) ? ("type_" + table_idx) : "<Module>"));
			this.nspace = string.Empty;
			this.pmodule = mb;
			this.setup_internal_class(this);
		}

		// Token: 0x06001294 RID: 4756 RVA: 0x0004B200 File Offset: 0x00049400
		internal TypeBuilder(ModuleBuilder mb, string name, TypeAttributes attr, Type parent, Type[] interfaces, PackingSize packing_size, int type_size, Type nesting_type)
		{
			this.parent = parent;
			this.attrs = attr;
			this.class_size = type_size;
			this.packing_size = packing_size;
			this.nesting_type = nesting_type;
			this.check_name("fullname", name);
			if (parent == null && (attr & TypeAttributes.ClassSemanticsMask) != TypeAttributes.NotPublic && (attr & TypeAttributes.Abstract) == TypeAttributes.NotPublic)
			{
				throw new InvalidOperationException("Interface must be declared abstract.");
			}
			int num = name.LastIndexOf('.');
			if (num != -1)
			{
				this.tname = name.Substring(num + 1);
				this.nspace = name.Substring(0, num);
			}
			else
			{
				this.tname = name;
				this.nspace = string.Empty;
			}
			if (interfaces != null)
			{
				this.interfaces = new Type[interfaces.Length];
				Array.Copy(interfaces, this.interfaces, interfaces.Length);
			}
			this.pmodule = mb;
			if ((attr & TypeAttributes.ClassSemanticsMask) == TypeAttributes.NotPublic && parent == null && !this.IsCompilerContext)
			{
				this.parent = typeof(object);
			}
			this.table_idx = mb.get_next_table_index(this, 2, true);
			this.setup_internal_class(this);
			this.fullname = this.GetFullName();
		}

		// Token: 0x06001295 RID: 4757 RVA: 0x0004B32C File Offset: 0x0004952C
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			return this.attrs;
		}

		// Token: 0x06001296 RID: 4758
		[MethodImpl(4096)]
		private extern void setup_internal_class(TypeBuilder tb);

		// Token: 0x06001297 RID: 4759
		[MethodImpl(4096)]
		private extern void create_generic_class();

		// Token: 0x06001298 RID: 4760
		[MethodImpl(4096)]
		private extern EventInfo get_event_info(EventBuilder eb);

		// Token: 0x170002FF RID: 767
		// (get) Token: 0x06001299 RID: 4761 RVA: 0x0004B334 File Offset: 0x00049534
		public override Assembly Assembly
		{
			get
			{
				return this.pmodule.Assembly;
			}
		}

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x0600129A RID: 4762 RVA: 0x0004B344 File Offset: 0x00049544
		public override string AssemblyQualifiedName
		{
			get
			{
				return this.fullname + ", " + this.Assembly.FullName;
			}
		}

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x0600129B RID: 4763 RVA: 0x0004B364 File Offset: 0x00049564
		public override Type BaseType
		{
			get
			{
				return this.parent;
			}
		}

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x0600129C RID: 4764 RVA: 0x0004B36C File Offset: 0x0004956C
		public override Type DeclaringType
		{
			get
			{
				return this.nesting_type;
			}
		}

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x0600129D RID: 4765 RVA: 0x0004B374 File Offset: 0x00049574
		public override Type UnderlyingSystemType
		{
			get
			{
				if (this.is_created)
				{
					return this.created.UnderlyingSystemType;
				}
				if (!this.IsEnum || this.IsCompilerContext)
				{
					return this;
				}
				if (this.underlying_type != null)
				{
					return this.underlying_type;
				}
				throw new InvalidOperationException("Enumeration type is not defined.");
			}
		}

		// Token: 0x0600129E RID: 4766 RVA: 0x0004B3CC File Offset: 0x000495CC
		private string GetFullName()
		{
			if (this.nesting_type != null)
			{
				return this.nesting_type.FullName + "+" + this.tname;
			}
			if (this.nspace != null && this.nspace.Length > 0)
			{
				return this.nspace + "." + this.tname;
			}
			return this.tname;
		}

		// Token: 0x17000304 RID: 772
		// (get) Token: 0x0600129F RID: 4767 RVA: 0x0004B43C File Offset: 0x0004963C
		public override string FullName
		{
			get
			{
				return this.fullname;
			}
		}

		// Token: 0x17000305 RID: 773
		// (get) Token: 0x060012A0 RID: 4768 RVA: 0x0004B444 File Offset: 0x00049644
		public override Guid GUID
		{
			get
			{
				this.check_created();
				return this.created.GUID;
			}
		}

		// Token: 0x17000306 RID: 774
		// (get) Token: 0x060012A1 RID: 4769 RVA: 0x0004B458 File Offset: 0x00049658
		public override Module Module
		{
			get
			{
				return this.pmodule;
			}
		}

		// Token: 0x17000307 RID: 775
		// (get) Token: 0x060012A2 RID: 4770 RVA: 0x0004B460 File Offset: 0x00049660
		public override string Name
		{
			get
			{
				return this.tname;
			}
		}

		// Token: 0x17000308 RID: 776
		// (get) Token: 0x060012A3 RID: 4771 RVA: 0x0004B468 File Offset: 0x00049668
		public override string Namespace
		{
			get
			{
				return this.nspace;
			}
		}

		// Token: 0x17000309 RID: 777
		// (get) Token: 0x060012A4 RID: 4772 RVA: 0x0004B470 File Offset: 0x00049670
		public override Type ReflectedType
		{
			get
			{
				return this.nesting_type;
			}
		}

		// Token: 0x060012A5 RID: 4773 RVA: 0x0004B478 File Offset: 0x00049678
		protected override ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			this.check_created();
			if (this.created != typeof(object))
			{
				return this.created.GetConstructor(bindingAttr, binder, callConvention, types, modifiers);
			}
			if (this.ctors == null)
			{
				return null;
			}
			ConstructorBuilder constructorBuilder = null;
			int num = 0;
			foreach (ConstructorBuilder constructorBuilder2 in this.ctors)
			{
				if (callConvention == CallingConventions.Any || constructorBuilder2.CallingConvention == callConvention)
				{
					constructorBuilder = constructorBuilder2;
					num++;
				}
			}
			if (num == 0)
			{
				return null;
			}
			if (types != null)
			{
				MethodBase[] array2 = new MethodBase[num];
				if (num == 1)
				{
					array2[0] = constructorBuilder;
				}
				else
				{
					num = 0;
					foreach (ConstructorBuilder constructorInfo in this.ctors)
					{
						if (callConvention == CallingConventions.Any || constructorInfo.CallingConvention == callConvention)
						{
							array2[num++] = constructorInfo;
						}
					}
				}
				if (binder == null)
				{
					binder = Binder.DefaultBinder;
				}
				return (ConstructorInfo)binder.SelectMethod(bindingAttr, array2, types, modifiers);
			}
			if (num > 1)
			{
				throw new AmbiguousMatchException();
			}
			return constructorBuilder;
		}

		// Token: 0x060012A6 RID: 4774 RVA: 0x0004B5AC File Offset: 0x000497AC
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			if (!this.is_created && !this.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x060012A7 RID: 4775 RVA: 0x0004B5D4 File Offset: 0x000497D4
		public override object[] GetCustomAttributes(bool inherit)
		{
			this.check_created();
			return this.created.GetCustomAttributes(inherit);
		}

		// Token: 0x060012A8 RID: 4776 RVA: 0x0004B5E8 File Offset: 0x000497E8
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			this.check_created();
			return this.created.GetCustomAttributes(attributeType, inherit);
		}

		// Token: 0x060012A9 RID: 4777 RVA: 0x0004B600 File Offset: 0x00049800
		[ComVisible(true)]
		public ConstructorBuilder DefineConstructor(MethodAttributes attributes, CallingConventions callingConvention, Type[] parameterTypes)
		{
			return this.DefineConstructor(attributes, callingConvention, parameterTypes, null, null);
		}

		// Token: 0x060012AA RID: 4778 RVA: 0x0004B610 File Offset: 0x00049810
		[ComVisible(true)]
		public ConstructorBuilder DefineConstructor(MethodAttributes attributes, CallingConventions callingConvention, Type[] parameterTypes, Type[][] requiredCustomModifiers, Type[][] optionalCustomModifiers)
		{
			this.check_not_created();
			ConstructorBuilder constructorBuilder = new ConstructorBuilder(this, attributes, callingConvention, parameterTypes, requiredCustomModifiers, optionalCustomModifiers);
			if (this.ctors != null)
			{
				ConstructorBuilder[] array = new ConstructorBuilder[this.ctors.Length + 1];
				Array.Copy(this.ctors, array, this.ctors.Length);
				array[this.ctors.Length] = constructorBuilder;
				this.ctors = array;
			}
			else
			{
				this.ctors = new ConstructorBuilder[1];
				this.ctors[0] = constructorBuilder;
			}
			return constructorBuilder;
		}

		// Token: 0x060012AB RID: 4779 RVA: 0x0004B690 File Offset: 0x00049890
		[ComVisible(true)]
		public ConstructorBuilder DefineDefaultConstructor(MethodAttributes attributes)
		{
			Type corlib_object_type;
			if (this.parent != null)
			{
				corlib_object_type = this.parent;
			}
			else
			{
				corlib_object_type = this.pmodule.assemblyb.corlib_object_type;
			}
			ConstructorInfo constructor = corlib_object_type.GetConstructor(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, Type.EmptyTypes, null);
			if (constructor == null)
			{
				throw new NotSupportedException("Parent does not have a default constructor. The default constructor must be explicitly defined.");
			}
			ConstructorBuilder constructorBuilder = this.DefineConstructor(attributes, CallingConventions.Standard, Type.EmptyTypes);
			ILGenerator ilgenerator = constructorBuilder.GetILGenerator();
			ilgenerator.Emit(OpCodes.Ldarg_0);
			ilgenerator.Emit(OpCodes.Call, constructor);
			ilgenerator.Emit(OpCodes.Ret);
			return constructorBuilder;
		}

		// Token: 0x060012AC RID: 4780 RVA: 0x0004B720 File Offset: 0x00049920
		private void append_method(MethodBuilder mb)
		{
			if (this.methods != null)
			{
				if (this.methods.Length == this.num_methods)
				{
					MethodBuilder[] array = new MethodBuilder[this.methods.Length * 2];
					Array.Copy(this.methods, array, this.num_methods);
					this.methods = array;
				}
			}
			else
			{
				this.methods = new MethodBuilder[1];
			}
			this.methods[this.num_methods] = mb;
			this.num_methods++;
		}

		// Token: 0x060012AD RID: 4781 RVA: 0x0004B7A4 File Offset: 0x000499A4
		public MethodBuilder DefineMethod(string name, MethodAttributes attributes, Type returnType, Type[] parameterTypes)
		{
			return this.DefineMethod(name, attributes, CallingConventions.Standard, returnType, parameterTypes);
		}

		// Token: 0x060012AE RID: 4782 RVA: 0x0004B7B4 File Offset: 0x000499B4
		public MethodBuilder DefineMethod(string name, MethodAttributes attributes, CallingConventions callingConvention, Type returnType, Type[] parameterTypes)
		{
			return this.DefineMethod(name, attributes, callingConvention, returnType, null, null, parameterTypes, null, null);
		}

		// Token: 0x060012AF RID: 4783 RVA: 0x0004B7D4 File Offset: 0x000499D4
		public MethodBuilder DefineMethod(string name, MethodAttributes attributes, CallingConventions callingConvention, Type returnType, Type[] returnTypeRequiredCustomModifiers, Type[] returnTypeOptionalCustomModifiers, Type[] parameterTypes, Type[][] parameterTypeRequiredCustomModifiers, Type[][] parameterTypeOptionalCustomModifiers)
		{
			this.check_name("name", name);
			this.check_not_created();
			if (this.IsInterface && ((attributes & MethodAttributes.Abstract) == MethodAttributes.PrivateScope || (attributes & MethodAttributes.Virtual) == MethodAttributes.PrivateScope) && (attributes & MethodAttributes.Static) == MethodAttributes.PrivateScope)
			{
				throw new ArgumentException("Interface method must be abstract and virtual.");
			}
			if (returnType == null)
			{
				returnType = this.pmodule.assemblyb.corlib_void_type;
			}
			MethodBuilder methodBuilder = new MethodBuilder(this, name, attributes, callingConvention, returnType, returnTypeRequiredCustomModifiers, returnTypeOptionalCustomModifiers, parameterTypes, parameterTypeRequiredCustomModifiers, parameterTypeOptionalCustomModifiers);
			this.append_method(methodBuilder);
			return methodBuilder;
		}

		// Token: 0x060012B0 RID: 4784 RVA: 0x0004B860 File Offset: 0x00049A60
		public void DefineMethodOverride(MethodInfo methodInfoBody, MethodInfo methodInfoDeclaration)
		{
			if (methodInfoBody == null)
			{
				throw new ArgumentNullException("methodInfoBody");
			}
			if (methodInfoDeclaration == null)
			{
				throw new ArgumentNullException("methodInfoDeclaration");
			}
			this.check_not_created();
			if (methodInfoBody.DeclaringType != this)
			{
				throw new ArgumentException("method body must belong to this type");
			}
			if (methodInfoBody is MethodBuilder)
			{
				MethodBuilder methodBuilder = (MethodBuilder)methodInfoBody;
				methodBuilder.set_override(methodInfoDeclaration);
			}
		}

		// Token: 0x060012B1 RID: 4785
		[MethodImpl(4096)]
		private extern Type create_runtime_class(TypeBuilder tb);

		// Token: 0x060012B2 RID: 4786 RVA: 0x0004B8C8 File Offset: 0x00049AC8
		private bool is_nested_in(Type t)
		{
			while (t != null)
			{
				if (t == this)
				{
					return true;
				}
				t = t.DeclaringType;
			}
			return false;
		}

		// Token: 0x060012B3 RID: 4787 RVA: 0x0004B8E8 File Offset: 0x00049AE8
		private bool has_ctor_method()
		{
			MethodAttributes methodAttributes = MethodAttributes.SpecialName | MethodAttributes.RTSpecialName;
			for (int i = 0; i < this.num_methods; i++)
			{
				MethodBuilder methodBuilder = this.methods[i];
				if (methodBuilder.Name == ConstructorInfo.ConstructorName && (methodBuilder.Attributes & methodAttributes) == methodAttributes)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060012B4 RID: 4788 RVA: 0x0004B944 File Offset: 0x00049B44
		public Type CreateType()
		{
			if (this.createTypeCalled)
			{
				return this.created;
			}
			if (!this.IsInterface && this.parent == null && this != this.pmodule.assemblyb.corlib_object_type && this.FullName != "<Module>")
			{
				this.SetParent(this.pmodule.assemblyb.corlib_object_type);
			}
			this.create_generic_class();
			if (this.fields != null)
			{
				foreach (FieldBuilder fieldBuilder in this.fields)
				{
					if (fieldBuilder != null)
					{
						Type fieldType = fieldBuilder.FieldType;
						if (!fieldBuilder.IsStatic && fieldType is TypeBuilder && fieldType.IsValueType && fieldType != this && this.is_nested_in(fieldType))
						{
							TypeBuilder typeBuilder = (TypeBuilder)fieldType;
							if (!typeBuilder.is_created)
							{
								AppDomain.CurrentDomain.DoTypeResolve(typeBuilder);
								if (!typeBuilder.is_created)
								{
								}
							}
						}
					}
				}
			}
			if (this.parent != null && this.parent.IsSealed)
			{
				throw new TypeLoadException(string.Concat(new object[] { "Could not load type '", this.FullName, "' from assembly '", this.Assembly, "' because the parent type is sealed." }));
			}
			if (this.parent == this.pmodule.assemblyb.corlib_enum_type && this.methods != null)
			{
				throw new TypeLoadException(string.Concat(new object[] { "Could not load type '", this.FullName, "' from assembly '", this.Assembly, "' because it is an enum with methods." }));
			}
			if (this.methods != null)
			{
				bool flag = !this.IsAbstract;
				for (int j = 0; j < this.num_methods; j++)
				{
					MethodBuilder methodBuilder = this.methods[j];
					if (flag && methodBuilder.IsAbstract)
					{
						throw new InvalidOperationException("Type is concrete but has abstract method " + methodBuilder);
					}
					methodBuilder.check_override();
					methodBuilder.fixup();
				}
			}
			if (!this.IsInterface && !this.IsValueType && this.ctors == null && this.tname != "<Module>" && ((this.GetAttributeFlagsImpl() & TypeAttributes.Abstract) | TypeAttributes.Sealed) != (TypeAttributes.Abstract | TypeAttributes.Sealed) && !this.has_ctor_method())
			{
				this.DefineDefaultConstructor(MethodAttributes.Public);
			}
			if (this.ctors != null)
			{
				foreach (ConstructorBuilder constructorBuilder in this.ctors)
				{
					constructorBuilder.fixup();
				}
			}
			this.createTypeCalled = true;
			this.created = this.create_runtime_class(this);
			if (this.created != null)
			{
				return this.created;
			}
			return this;
		}

		// Token: 0x060012B5 RID: 4789 RVA: 0x0004BC4C File Offset: 0x00049E4C
		[ComVisible(true)]
		public override ConstructorInfo[] GetConstructors(BindingFlags bindingAttr)
		{
			if (this.is_created)
			{
				return this.created.GetConstructors(bindingAttr);
			}
			if (!this.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			return this.GetConstructorsInternal(bindingAttr);
		}

		// Token: 0x060012B6 RID: 4790 RVA: 0x0004BC80 File Offset: 0x00049E80
		internal ConstructorInfo[] GetConstructorsInternal(BindingFlags bindingAttr)
		{
			if (this.ctors == null)
			{
				return new ConstructorInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			foreach (ConstructorBuilder constructorBuilder in this.ctors)
			{
				bool flag = false;
				MethodAttributes attributes = constructorBuilder.Attributes;
				if ((attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
				{
					if ((bindingAttr & BindingFlags.Public) != BindingFlags.Default)
					{
						flag = true;
					}
				}
				else if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
				{
					flag = true;
				}
				if (flag)
				{
					flag = false;
					if ((attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
					{
						if ((bindingAttr & BindingFlags.Static) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bindingAttr & BindingFlags.Instance) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						arrayList.Add(constructorBuilder);
					}
				}
			}
			ConstructorInfo[] array2 = new ConstructorInfo[arrayList.Count];
			arrayList.CopyTo(array2);
			return array2;
		}

		// Token: 0x060012B7 RID: 4791 RVA: 0x0004BD54 File Offset: 0x00049F54
		public override Type GetElementType()
		{
			throw new NotSupportedException();
		}

		// Token: 0x060012B8 RID: 4792 RVA: 0x0004BD5C File Offset: 0x00049F5C
		public override EventInfo GetEvent(string name, BindingFlags bindingAttr)
		{
			this.check_created();
			return this.created.GetEvent(name, bindingAttr);
		}

		// Token: 0x060012B9 RID: 4793 RVA: 0x0004BD74 File Offset: 0x00049F74
		public override EventInfo[] GetEvents(BindingFlags bindingAttr)
		{
			if (this.is_created)
			{
				return this.created.GetEvents(bindingAttr);
			}
			if (!this.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			return new EventInfo[0];
		}

		// Token: 0x060012BA RID: 4794 RVA: 0x0004BDA8 File Offset: 0x00049FA8
		internal EventInfo[] GetEvents_internal(BindingFlags bindingAttr)
		{
			if (this.events == null)
			{
				return new EventInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			foreach (EventBuilder eventBuilder in this.events)
			{
				if (eventBuilder != null)
				{
					EventInfo eventInfo = this.get_event_info(eventBuilder);
					bool flag = false;
					MethodInfo methodInfo = eventInfo.GetAddMethod(true);
					if (methodInfo == null)
					{
						methodInfo = eventInfo.GetRemoveMethod(true);
					}
					if (methodInfo != null)
					{
						MethodAttributes attributes = methodInfo.Attributes;
						if ((attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
						{
							if ((bindingAttr & BindingFlags.Public) != BindingFlags.Default)
							{
								flag = true;
							}
						}
						else if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
						{
							flag = true;
						}
						if (flag)
						{
							flag = false;
							if ((attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
							{
								if ((bindingAttr & BindingFlags.Static) != BindingFlags.Default)
								{
									flag = true;
								}
							}
							else if ((bindingAttr & BindingFlags.Instance) != BindingFlags.Default)
							{
								flag = true;
							}
							if (flag)
							{
								arrayList.Add(eventInfo);
							}
						}
					}
				}
			}
			EventInfo[] array2 = new EventInfo[arrayList.Count];
			arrayList.CopyTo(array2);
			return array2;
		}

		// Token: 0x060012BB RID: 4795 RVA: 0x0004BEB8 File Offset: 0x0004A0B8
		public override FieldInfo GetField(string name, BindingFlags bindingAttr)
		{
			if (this.created != null)
			{
				return this.created.GetField(name, bindingAttr);
			}
			if (this.fields == null)
			{
				return null;
			}
			foreach (FieldBuilder fieldInfo in this.fields)
			{
				if (fieldInfo != null)
				{
					if (!(fieldInfo.Name != name))
					{
						bool flag = false;
						FieldAttributes attributes = fieldInfo.Attributes;
						if ((attributes & FieldAttributes.FieldAccessMask) == FieldAttributes.Public)
						{
							if ((bindingAttr & BindingFlags.Public) != BindingFlags.Default)
							{
								flag = true;
							}
						}
						else if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
						{
							flag = true;
						}
						if (flag)
						{
							flag = false;
							if ((attributes & FieldAttributes.Static) != FieldAttributes.PrivateScope)
							{
								if ((bindingAttr & BindingFlags.Static) != BindingFlags.Default)
								{
									flag = true;
								}
							}
							else if ((bindingAttr & BindingFlags.Instance) != BindingFlags.Default)
							{
								flag = true;
							}
							if (flag)
							{
								return fieldInfo;
							}
						}
					}
				}
			}
			return null;
		}

		// Token: 0x060012BC RID: 4796 RVA: 0x0004BF9C File Offset: 0x0004A19C
		public override FieldInfo[] GetFields(BindingFlags bindingAttr)
		{
			if (this.created != null)
			{
				return this.created.GetFields(bindingAttr);
			}
			if (this.fields == null)
			{
				return new FieldInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			foreach (FieldBuilder fieldInfo in this.fields)
			{
				if (fieldInfo != null)
				{
					bool flag = false;
					FieldAttributes attributes = fieldInfo.Attributes;
					if ((attributes & FieldAttributes.FieldAccessMask) == FieldAttributes.Public)
					{
						if ((bindingAttr & BindingFlags.Public) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						flag = false;
						if ((attributes & FieldAttributes.Static) != FieldAttributes.PrivateScope)
						{
							if ((bindingAttr & BindingFlags.Static) != BindingFlags.Default)
							{
								flag = true;
							}
						}
						else if ((bindingAttr & BindingFlags.Instance) != BindingFlags.Default)
						{
							flag = true;
						}
						if (flag)
						{
							arrayList.Add(fieldInfo);
						}
					}
				}
			}
			FieldInfo[] array2 = new FieldInfo[arrayList.Count];
			arrayList.CopyTo(array2);
			return array2;
		}

		// Token: 0x060012BD RID: 4797 RVA: 0x0004C094 File Offset: 0x0004A294
		public override Type[] GetInterfaces()
		{
			if (this.is_created)
			{
				return this.created.GetInterfaces();
			}
			if (this.interfaces != null)
			{
				Type[] array = new Type[this.interfaces.Length];
				this.interfaces.CopyTo(array, 0);
				return array;
			}
			return Type.EmptyTypes;
		}

		// Token: 0x060012BE RID: 4798 RVA: 0x0004C0E8 File Offset: 0x0004A2E8
		public override MemberInfo[] GetMember(string name, MemberTypes type, BindingFlags bindingAttr)
		{
			this.check_created();
			return this.created.GetMember(name, type, bindingAttr);
		}

		// Token: 0x060012BF RID: 4799 RVA: 0x0004C100 File Offset: 0x0004A300
		private MethodInfo[] GetMethodsByName(string name, BindingFlags bindingAttr, bool ignoreCase, Type reflected_type)
		{
			MethodInfo[] array2;
			if ((bindingAttr & BindingFlags.DeclaredOnly) == BindingFlags.Default && this.parent != null)
			{
				MethodInfo[] array = this.parent.GetMethods(bindingAttr);
				ArrayList arrayList = new ArrayList(array.Length);
				bool flag = (bindingAttr & BindingFlags.FlattenHierarchy) != BindingFlags.Default;
				foreach (MethodInfo methodInfo in array)
				{
					MethodAttributes methodAttributes = methodInfo.Attributes;
					if (!methodInfo.IsStatic || flag)
					{
						bool flag2;
						switch (methodAttributes & MethodAttributes.MemberAccessMask)
						{
						case MethodAttributes.Private:
							flag2 = false;
							break;
						case MethodAttributes.FamANDAssem:
						case MethodAttributes.Family:
						case MethodAttributes.FamORAssem:
							goto IL_00B6;
						case MethodAttributes.Assembly:
							flag2 = (bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default;
							break;
						case MethodAttributes.Public:
							flag2 = (bindingAttr & BindingFlags.Public) != BindingFlags.Default;
							break;
						default:
							goto IL_00B6;
						}
						IL_00C6:
						if (flag2)
						{
							arrayList.Add(methodInfo);
							goto IL_00D6;
						}
						goto IL_00D6;
						IL_00B6:
						flag2 = (bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default;
						goto IL_00C6;
					}
					IL_00D6:;
				}
				if (this.methods == null)
				{
					array2 = new MethodInfo[arrayList.Count];
					arrayList.CopyTo(array2);
				}
				else
				{
					array2 = new MethodInfo[this.methods.Length + arrayList.Count];
					arrayList.CopyTo(array2, 0);
					this.methods.CopyTo(array2, arrayList.Count);
				}
			}
			else
			{
				array2 = this.methods;
			}
			if (array2 == null)
			{
				return new MethodInfo[0];
			}
			ArrayList arrayList2 = new ArrayList();
			foreach (MethodInfo methodInfo2 in array2)
			{
				if (methodInfo2 != null)
				{
					if (name == null || string.Compare(methodInfo2.Name, name, ignoreCase) == 0)
					{
						bool flag2 = false;
						MethodAttributes methodAttributes = methodInfo2.Attributes;
						if ((methodAttributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
						{
							if ((bindingAttr & BindingFlags.Public) != BindingFlags.Default)
							{
								flag2 = true;
							}
						}
						else if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
						{
							flag2 = true;
						}
						if (flag2)
						{
							flag2 = false;
							if ((methodAttributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
							{
								if ((bindingAttr & BindingFlags.Static) != BindingFlags.Default)
								{
									flag2 = true;
								}
							}
							else if ((bindingAttr & BindingFlags.Instance) != BindingFlags.Default)
							{
								flag2 = true;
							}
							if (flag2)
							{
								arrayList2.Add(methodInfo2);
							}
						}
					}
				}
			}
			MethodInfo[] array4 = new MethodInfo[arrayList2.Count];
			arrayList2.CopyTo(array4);
			return array4;
		}

		// Token: 0x060012C0 RID: 4800 RVA: 0x0004C344 File Offset: 0x0004A544
		public override MethodInfo[] GetMethods(BindingFlags bindingAttr)
		{
			return this.GetMethodsByName(null, bindingAttr, false, this);
		}

		// Token: 0x060012C1 RID: 4801 RVA: 0x0004C350 File Offset: 0x0004A550
		protected override MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			this.check_created();
			bool flag = (bindingAttr & BindingFlags.IgnoreCase) != BindingFlags.Default;
			MethodInfo[] methodsByName = this.GetMethodsByName(name, bindingAttr, flag, this);
			MethodInfo methodInfo = null;
			int num = ((types == null) ? 0 : types.Length);
			int num2 = 0;
			foreach (MethodInfo methodInfo2 in methodsByName)
			{
				if (callConvention == CallingConventions.Any || (methodInfo2.CallingConvention & callConvention) == callConvention)
				{
					methodInfo = methodInfo2;
					num2++;
				}
			}
			if (num2 == 0)
			{
				return null;
			}
			if (num2 == 1 && num == 0)
			{
				return methodInfo;
			}
			MethodBase[] array2 = new MethodBase[num2];
			if (num2 == 1)
			{
				array2[0] = methodInfo;
			}
			else
			{
				num2 = 0;
				foreach (MethodInfo methodInfo3 in methodsByName)
				{
					if (callConvention == CallingConventions.Any || (methodInfo3.CallingConvention & callConvention) == callConvention)
					{
						array2[num2++] = methodInfo3;
					}
				}
			}
			if (types == null)
			{
				return (MethodInfo)Binder.FindMostDerivedMatch(array2);
			}
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			return (MethodInfo)binder.SelectMethod(bindingAttr, array2, types, modifiers);
		}

		// Token: 0x060012C2 RID: 4802 RVA: 0x0004C490 File Offset: 0x0004A690
		public override Type[] GetNestedTypes(BindingFlags bindingAttr)
		{
			if (!this.is_created && !this.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			ArrayList arrayList = new ArrayList();
			if (this.subtypes == null)
			{
				return Type.EmptyTypes;
			}
			foreach (TypeBuilder typeBuilder in this.subtypes)
			{
				bool flag = false;
				if ((typeBuilder.attrs & TypeAttributes.VisibilityMask) == TypeAttributes.NestedPublic)
				{
					if ((bindingAttr & BindingFlags.Public) != BindingFlags.Default)
					{
						flag = true;
					}
				}
				else if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
				{
					flag = true;
				}
				if (flag)
				{
					arrayList.Add(typeBuilder);
				}
			}
			Type[] array2 = new Type[arrayList.Count];
			arrayList.CopyTo(array2);
			return array2;
		}

		// Token: 0x060012C3 RID: 4803 RVA: 0x0004C54C File Offset: 0x0004A74C
		public override PropertyInfo[] GetProperties(BindingFlags bindingAttr)
		{
			if (this.is_created)
			{
				return this.created.GetProperties(bindingAttr);
			}
			if (this.properties == null)
			{
				return new PropertyInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			foreach (PropertyBuilder propertyInfo in this.properties)
			{
				bool flag = false;
				MethodInfo methodInfo = propertyInfo.GetGetMethod(true);
				if (methodInfo == null)
				{
					methodInfo = propertyInfo.GetSetMethod(true);
				}
				if (methodInfo != null)
				{
					MethodAttributes attributes = methodInfo.Attributes;
					if ((attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
					{
						if ((bindingAttr & BindingFlags.Public) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						flag = false;
						if ((attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
						{
							if ((bindingAttr & BindingFlags.Static) != BindingFlags.Default)
							{
								flag = true;
							}
						}
						else if ((bindingAttr & BindingFlags.Instance) != BindingFlags.Default)
						{
							flag = true;
						}
						if (flag)
						{
							arrayList.Add(propertyInfo);
						}
					}
				}
			}
			PropertyInfo[] array2 = new PropertyInfo[arrayList.Count];
			arrayList.CopyTo(array2);
			return array2;
		}

		// Token: 0x060012C4 RID: 4804 RVA: 0x0004C65C File Offset: 0x0004A85C
		protected override PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
		{
			throw this.not_supported();
		}

		// Token: 0x060012C5 RID: 4805 RVA: 0x0004C664 File Offset: 0x0004A864
		protected override bool HasElementTypeImpl()
		{
			return this.is_created && this.created.HasElementType;
		}

		// Token: 0x060012C6 RID: 4806 RVA: 0x0004C680 File Offset: 0x0004A880
		public override object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters)
		{
			this.check_created();
			return this.created.InvokeMember(name, invokeAttr, binder, target, args, modifiers, culture, namedParameters);
		}

		// Token: 0x060012C7 RID: 4807 RVA: 0x0004C6AC File Offset: 0x0004A8AC
		protected override bool IsArrayImpl()
		{
			return false;
		}

		// Token: 0x060012C8 RID: 4808 RVA: 0x0004C6B0 File Offset: 0x0004A8B0
		protected override bool IsByRefImpl()
		{
			return false;
		}

		// Token: 0x060012C9 RID: 4809 RVA: 0x0004C6B4 File Offset: 0x0004A8B4
		protected override bool IsPointerImpl()
		{
			return false;
		}

		// Token: 0x060012CA RID: 4810 RVA: 0x0004C6B8 File Offset: 0x0004A8B8
		protected override bool IsPrimitiveImpl()
		{
			return false;
		}

		// Token: 0x060012CB RID: 4811 RVA: 0x0004C6BC File Offset: 0x0004A8BC
		protected override bool IsValueTypeImpl()
		{
			return (Type.type_is_subtype_of(this, this.pmodule.assemblyb.corlib_value_type, false) || Type.type_is_subtype_of(this, typeof(ValueType), false)) && this != this.pmodule.assemblyb.corlib_value_type && this != this.pmodule.assemblyb.corlib_enum_type;
		}

		// Token: 0x060012CC RID: 4812 RVA: 0x0004C72C File Offset: 0x0004A92C
		public override Type MakeArrayType()
		{
			return new ArrayType(this, 0);
		}

		// Token: 0x060012CD RID: 4813 RVA: 0x0004C738 File Offset: 0x0004A938
		public override Type MakeArrayType(int rank)
		{
			if (rank < 1)
			{
				throw new IndexOutOfRangeException();
			}
			return new ArrayType(this, rank);
		}

		// Token: 0x060012CE RID: 4814 RVA: 0x0004C750 File Offset: 0x0004A950
		public override Type MakeByRefType()
		{
			return new ByRefType(this);
		}

		// Token: 0x060012CF RID: 4815 RVA: 0x0004C758 File Offset: 0x0004A958
		[MonoTODO]
		public override Type MakeGenericType(params Type[] typeArguments)
		{
			return base.MakeGenericType(typeArguments);
		}

		// Token: 0x060012D0 RID: 4816 RVA: 0x0004C764 File Offset: 0x0004A964
		public override Type MakePointerType()
		{
			return new PointerType(this);
		}

		// Token: 0x1700030A RID: 778
		// (get) Token: 0x060012D1 RID: 4817 RVA: 0x0004C76C File Offset: 0x0004A96C
		public override RuntimeTypeHandle TypeHandle
		{
			get
			{
				this.check_created();
				return this.created.TypeHandle;
			}
		}

		// Token: 0x060012D2 RID: 4818 RVA: 0x0004C780 File Offset: 0x0004A980
		public void SetParent(Type parent)
		{
			this.check_not_created();
			if (parent == null)
			{
				if ((this.attrs & TypeAttributes.ClassSemanticsMask) != TypeAttributes.NotPublic)
				{
					if ((this.attrs & TypeAttributes.Abstract) == TypeAttributes.NotPublic)
					{
						throw new InvalidOperationException("Interface must be declared abstract.");
					}
					this.parent = null;
				}
				else
				{
					this.parent = typeof(object);
				}
			}
			else
			{
				this.parent = parent;
			}
			this.setup_internal_class(this);
		}

		// Token: 0x060012D3 RID: 4819 RVA: 0x0004C7F4 File Offset: 0x0004A9F4
		internal int get_next_table_index(object obj, int table, bool inc)
		{
			return this.pmodule.get_next_table_index(obj, table, inc);
		}

		// Token: 0x1700030B RID: 779
		// (get) Token: 0x060012D4 RID: 4820 RVA: 0x0004C804 File Offset: 0x0004AA04
		internal bool IsCompilerContext
		{
			get
			{
				return this.pmodule.assemblyb.IsCompilerContext;
			}
		}

		// Token: 0x1700030C RID: 780
		// (get) Token: 0x060012D5 RID: 4821 RVA: 0x0004C818 File Offset: 0x0004AA18
		internal bool is_created
		{
			get
			{
				return this.created != null;
			}
		}

		// Token: 0x060012D6 RID: 4822 RVA: 0x0004C828 File Offset: 0x0004AA28
		private Exception not_supported()
		{
			return new NotSupportedException("The invoked member is not supported in a dynamic module.");
		}

		// Token: 0x060012D7 RID: 4823 RVA: 0x0004C834 File Offset: 0x0004AA34
		private void check_not_created()
		{
			if (this.is_created)
			{
				throw new InvalidOperationException("Unable to change after type has been created.");
			}
		}

		// Token: 0x060012D8 RID: 4824 RVA: 0x0004C84C File Offset: 0x0004AA4C
		private void check_created()
		{
			if (!this.is_created)
			{
				throw this.not_supported();
			}
		}

		// Token: 0x060012D9 RID: 4825 RVA: 0x0004C860 File Offset: 0x0004AA60
		private void check_name(string argName, string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException(argName);
			}
			if (name.Length == 0)
			{
				throw new ArgumentException("Empty name is not legal", argName);
			}
			if (name[0] == '\0')
			{
				throw new ArgumentException("Illegal name", argName);
			}
		}

		// Token: 0x060012DA RID: 4826 RVA: 0x0004C8A0 File Offset: 0x0004AAA0
		public override string ToString()
		{
			return this.FullName;
		}

		// Token: 0x060012DB RID: 4827 RVA: 0x0004C8A8 File Offset: 0x0004AAA8
		[MonoTODO]
		public override bool IsAssignableFrom(Type c)
		{
			return base.IsAssignableFrom(c);
		}

		// Token: 0x060012DC RID: 4828 RVA: 0x0004C8B4 File Offset: 0x0004AAB4
		[MonoTODO]
		[ComVisible(true)]
		public override bool IsSubclassOf(Type c)
		{
			return base.IsSubclassOf(c);
		}

		// Token: 0x060012DD RID: 4829 RVA: 0x0004C8C0 File Offset: 0x0004AAC0
		[MonoTODO("arrays")]
		internal bool IsAssignableTo(Type c)
		{
			if (c == this)
			{
				return true;
			}
			if (c.IsInterface)
			{
				if (this.parent != null && this.is_created && c.IsAssignableFrom(this.parent))
				{
					return true;
				}
				if (this.interfaces == null)
				{
					return false;
				}
				foreach (Type type in this.interfaces)
				{
					if (c.IsAssignableFrom(type))
					{
						return true;
					}
				}
				if (!this.is_created)
				{
					return false;
				}
			}
			if (this.parent == null)
			{
				return c == typeof(object);
			}
			return c.IsAssignableFrom(this.parent);
		}

		// Token: 0x060012DE RID: 4830 RVA: 0x0004C978 File Offset: 0x0004AB78
		public override Type[] GetGenericArguments()
		{
			if (this.generic_params == null)
			{
				return null;
			}
			Type[] array = new Type[this.generic_params.Length];
			this.generic_params.CopyTo(array, 0);
			return array;
		}

		// Token: 0x060012DF RID: 4831 RVA: 0x0004C9B0 File Offset: 0x0004ABB0
		public override Type GetGenericTypeDefinition()
		{
			if (this.generic_params == null)
			{
				throw new InvalidOperationException("Type is not generic");
			}
			return this;
		}

		// Token: 0x1700030D RID: 781
		// (get) Token: 0x060012E0 RID: 4832 RVA: 0x0004C9CC File Offset: 0x0004ABCC
		public override bool ContainsGenericParameters
		{
			get
			{
				return this.generic_params != null;
			}
		}

		// Token: 0x1700030E RID: 782
		// (get) Token: 0x060012E1 RID: 4833
		public override extern bool IsGenericParameter
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700030F RID: 783
		// (get) Token: 0x060012E2 RID: 4834 RVA: 0x0004C9DC File Offset: 0x0004ABDC
		public override bool IsGenericTypeDefinition
		{
			get
			{
				return this.generic_params != null;
			}
		}

		// Token: 0x17000310 RID: 784
		// (get) Token: 0x060012E3 RID: 4835 RVA: 0x0004C9EC File Offset: 0x0004ABEC
		public override bool IsGenericType
		{
			get
			{
				return this.IsGenericTypeDefinition;
			}
		}

		// Token: 0x17000311 RID: 785
		// (get) Token: 0x060012E4 RID: 4836 RVA: 0x0004C9F4 File Offset: 0x0004ABF4
		[MonoTODO]
		public override int GenericParameterPosition
		{
			get
			{
				return 0;
			}
		}

		// Token: 0x17000312 RID: 786
		// (get) Token: 0x060012E5 RID: 4837 RVA: 0x0004C9F8 File Offset: 0x0004ABF8
		public override MethodBase DeclaringMethod
		{
			get
			{
				return null;
			}
		}

		// Token: 0x060012E6 RID: 4838 RVA: 0x0004C9FC File Offset: 0x0004ABFC
		public static ConstructorInfo GetConstructor(Type type, ConstructorInfo constructor)
		{
			if (type == null)
			{
				throw new ArgumentException("Type is not generic", "type");
			}
			ConstructorInfo constructor2 = type.GetConstructor(constructor);
			if (constructor2 == null)
			{
				throw new ArgumentException("constructor not found");
			}
			return constructor2;
		}

		// Token: 0x060012E7 RID: 4839 RVA: 0x0004CA3C File Offset: 0x0004AC3C
		private static bool IsValidGetMethodType(Type type)
		{
			if (type is TypeBuilder || type is MonoGenericClass)
			{
				return true;
			}
			if (type.Module is ModuleBuilder)
			{
				return true;
			}
			if (type.IsGenericParameter)
			{
				return false;
			}
			Type[] genericArguments = type.GetGenericArguments();
			if (genericArguments == null)
			{
				return false;
			}
			for (int i = 0; i < genericArguments.Length; i++)
			{
				if (TypeBuilder.IsValidGetMethodType(genericArguments[i]))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060012E8 RID: 4840 RVA: 0x0004CAB4 File Offset: 0x0004ACB4
		public static MethodInfo GetMethod(Type type, MethodInfo method)
		{
			if (!TypeBuilder.IsValidGetMethodType(type))
			{
				throw new ArgumentException("type is not TypeBuilder but " + type.GetType(), "type");
			}
			if (!type.IsGenericType)
			{
				throw new ArgumentException("type is not a generic type", "type");
			}
			if (!method.DeclaringType.IsGenericTypeDefinition)
			{
				throw new ArgumentException("method declaring type is not a generic type definition", "method");
			}
			if (method.DeclaringType != type.GetGenericTypeDefinition())
			{
				throw new ArgumentException("method declaring type is not the generic type definition of type", "method");
			}
			MethodInfo method2 = type.GetMethod(method);
			if (method2 == null)
			{
				throw new ArgumentException(string.Format("method {0} not found in type {1}", method.Name, type));
			}
			return method2;
		}

		// Token: 0x060012E9 RID: 4841 RVA: 0x0004CB6C File Offset: 0x0004AD6C
		public static FieldInfo GetField(Type type, FieldInfo field)
		{
			FieldInfo field2 = type.GetField(field);
			if (field2 == null)
			{
				throw new Exception("field not found");
			}
			return field2;
		}

		// Token: 0x04000930 RID: 2352
		public const int UnspecifiedTypeSize = 0;

		// Token: 0x04000931 RID: 2353
		private string tname;

		// Token: 0x04000932 RID: 2354
		private string nspace;

		// Token: 0x04000933 RID: 2355
		private Type parent;

		// Token: 0x04000934 RID: 2356
		private Type nesting_type;

		// Token: 0x04000935 RID: 2357
		internal Type[] interfaces;

		// Token: 0x04000936 RID: 2358
		internal int num_methods;

		// Token: 0x04000937 RID: 2359
		internal MethodBuilder[] methods;

		// Token: 0x04000938 RID: 2360
		internal ConstructorBuilder[] ctors;

		// Token: 0x04000939 RID: 2361
		internal PropertyBuilder[] properties;

		// Token: 0x0400093A RID: 2362
		internal int num_fields;

		// Token: 0x0400093B RID: 2363
		internal FieldBuilder[] fields;

		// Token: 0x0400093C RID: 2364
		internal EventBuilder[] events;

		// Token: 0x0400093D RID: 2365
		private CustomAttributeBuilder[] cattrs;

		// Token: 0x0400093E RID: 2366
		internal TypeBuilder[] subtypes;

		// Token: 0x0400093F RID: 2367
		internal TypeAttributes attrs;

		// Token: 0x04000940 RID: 2368
		private int table_idx;

		// Token: 0x04000941 RID: 2369
		private ModuleBuilder pmodule;

		// Token: 0x04000942 RID: 2370
		private int class_size;

		// Token: 0x04000943 RID: 2371
		private PackingSize packing_size;

		// Token: 0x04000944 RID: 2372
		private IntPtr generic_container;

		// Token: 0x04000945 RID: 2373
		private GenericTypeParameterBuilder[] generic_params;

		// Token: 0x04000946 RID: 2374
		private RefEmitPermissionSet[] permissions;

		// Token: 0x04000947 RID: 2375
		private Type created;

		// Token: 0x04000948 RID: 2376
		private string fullname;

		// Token: 0x04000949 RID: 2377
		private bool createTypeCalled;

		// Token: 0x0400094A RID: 2378
		private Type underlying_type;
	}
}
