﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection.Emit
{
	// Token: 0x020001F1 RID: 497
	[Obsolete("An alternate API is available: Emit the MarshalAs custom attribute instead.")]
	[ComVisible(true)]
	[Serializable]
	public sealed class UnmanagedMarshal
	{
		// Token: 0x060012EA RID: 4842 RVA: 0x0004CB94 File Offset: 0x0004AD94
		internal MarshalAsAttribute ToMarshalAsAttribute()
		{
			MarshalAsAttribute marshalAsAttribute = new MarshalAsAttribute(this.t);
			marshalAsAttribute.ArraySubType = this.tbase;
			marshalAsAttribute.MarshalCookie = this.mcookie;
			marshalAsAttribute.MarshalType = this.marshaltype;
			marshalAsAttribute.MarshalTypeRef = this.marshaltyperef;
			if (this.count == -1)
			{
				marshalAsAttribute.SizeConst = 0;
			}
			else
			{
				marshalAsAttribute.SizeConst = this.count;
			}
			if (this.param_num == -1)
			{
				marshalAsAttribute.SizeParamIndex = 0;
			}
			else
			{
				marshalAsAttribute.SizeParamIndex = (short)this.param_num;
			}
			return marshalAsAttribute;
		}

		// Token: 0x0400094C RID: 2380
		private int count;

		// Token: 0x0400094D RID: 2381
		private UnmanagedType t;

		// Token: 0x0400094E RID: 2382
		private UnmanagedType tbase;

		// Token: 0x0400094F RID: 2383
		private string guid;

		// Token: 0x04000950 RID: 2384
		private string mcookie;

		// Token: 0x04000951 RID: 2385
		private string marshaltype;

		// Token: 0x04000952 RID: 2386
		private Type marshaltyperef;

		// Token: 0x04000953 RID: 2387
		private int param_num;

		// Token: 0x04000954 RID: 2388
		private bool has_size;
	}
}
