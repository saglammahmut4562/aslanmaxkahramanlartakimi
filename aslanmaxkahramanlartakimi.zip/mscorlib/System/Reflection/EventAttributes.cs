﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001F2 RID: 498
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum EventAttributes
	{
		// Token: 0x04000956 RID: 2390
		None = 0,
		// Token: 0x04000957 RID: 2391
		SpecialName = 512,
		// Token: 0x04000958 RID: 2392
		ReservedMask = 1024,
		// Token: 0x04000959 RID: 2393
		RTSpecialName = 1024
	}
}
