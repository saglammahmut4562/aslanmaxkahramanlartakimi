﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001F3 RID: 499
	[ClassInterface(ClassInterfaceType.None)]
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_EventInfo))]
	[Serializable]
	public abstract class EventInfo : MemberInfo, _EventInfo
	{
		// Token: 0x17000313 RID: 787
		// (get) Token: 0x060012EC RID: 4844
		public abstract EventAttributes Attributes { get; }

		// Token: 0x17000314 RID: 788
		// (get) Token: 0x060012ED RID: 4845 RVA: 0x0004CC30 File Offset: 0x0004AE30
		public Type EventHandlerType
		{
			get
			{
				MethodInfo addMethod = this.GetAddMethod(true);
				ParameterInfo[] parameters = addMethod.GetParameters();
				if (parameters.Length > 0)
				{
					return parameters[0].ParameterType;
				}
				return null;
			}
		}

		// Token: 0x17000315 RID: 789
		// (get) Token: 0x060012EE RID: 4846 RVA: 0x0004CC64 File Offset: 0x0004AE64
		public override MemberTypes MemberType
		{
			get
			{
				return MemberTypes.Event;
			}
		}

		// Token: 0x060012EF RID: 4847
		public abstract MethodInfo GetAddMethod(bool nonPublic);

		// Token: 0x060012F0 RID: 4848
		public abstract MethodInfo GetRemoveMethod(bool nonPublic);

		// Token: 0x0400095A RID: 2394
		private EventInfo.AddEventAdapter cached_add_event;

		// Token: 0x020001F4 RID: 500
		// (Invoke) Token: 0x060012F2 RID: 4850
		private delegate void AddEventAdapter(object _this, Delegate dele);
	}
}
