﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001F5 RID: 501
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum FieldAttributes
	{
		// Token: 0x0400095C RID: 2396
		FieldAccessMask = 7,
		// Token: 0x0400095D RID: 2397
		PrivateScope = 0,
		// Token: 0x0400095E RID: 2398
		Private = 1,
		// Token: 0x0400095F RID: 2399
		FamANDAssem = 2,
		// Token: 0x04000960 RID: 2400
		Assembly = 3,
		// Token: 0x04000961 RID: 2401
		Family = 4,
		// Token: 0x04000962 RID: 2402
		FamORAssem = 5,
		// Token: 0x04000963 RID: 2403
		Public = 6,
		// Token: 0x04000964 RID: 2404
		Static = 16,
		// Token: 0x04000965 RID: 2405
		InitOnly = 32,
		// Token: 0x04000966 RID: 2406
		Literal = 64,
		// Token: 0x04000967 RID: 2407
		NotSerialized = 128,
		// Token: 0x04000968 RID: 2408
		HasFieldRVA = 256,
		// Token: 0x04000969 RID: 2409
		SpecialName = 512,
		// Token: 0x0400096A RID: 2410
		RTSpecialName = 1024,
		// Token: 0x0400096B RID: 2411
		HasFieldMarshal = 4096,
		// Token: 0x0400096C RID: 2412
		PinvokeImpl = 8192,
		// Token: 0x0400096D RID: 2413
		HasDefault = 32768,
		// Token: 0x0400096E RID: 2414
		ReservedMask = 38144
	}
}
