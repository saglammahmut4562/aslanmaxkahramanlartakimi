﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001F6 RID: 502
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_FieldInfo))]
	[ClassInterface(ClassInterfaceType.None)]
	[Serializable]
	public abstract class FieldInfo : MemberInfo, _FieldInfo
	{
		// Token: 0x17000316 RID: 790
		// (get) Token: 0x060012F6 RID: 4854
		public abstract FieldAttributes Attributes { get; }

		// Token: 0x17000317 RID: 791
		// (get) Token: 0x060012F7 RID: 4855
		public abstract RuntimeFieldHandle FieldHandle { get; }

		// Token: 0x17000318 RID: 792
		// (get) Token: 0x060012F8 RID: 4856
		public abstract Type FieldType { get; }

		// Token: 0x060012F9 RID: 4857
		public abstract object GetValue(object obj);

		// Token: 0x17000319 RID: 793
		// (get) Token: 0x060012FA RID: 4858 RVA: 0x0004CC70 File Offset: 0x0004AE70
		public override MemberTypes MemberType
		{
			get
			{
				return MemberTypes.Field;
			}
		}

		// Token: 0x1700031A RID: 794
		// (get) Token: 0x060012FB RID: 4859 RVA: 0x0004CC74 File Offset: 0x0004AE74
		public bool IsLiteral
		{
			get
			{
				return (this.Attributes & FieldAttributes.Literal) != FieldAttributes.PrivateScope;
			}
		}

		// Token: 0x1700031B RID: 795
		// (get) Token: 0x060012FC RID: 4860 RVA: 0x0004CC88 File Offset: 0x0004AE88
		public bool IsStatic
		{
			get
			{
				return (this.Attributes & FieldAttributes.Static) != FieldAttributes.PrivateScope;
			}
		}

		// Token: 0x1700031C RID: 796
		// (get) Token: 0x060012FD RID: 4861 RVA: 0x0004CC9C File Offset: 0x0004AE9C
		public bool IsInitOnly
		{
			get
			{
				return (this.Attributes & FieldAttributes.InitOnly) != FieldAttributes.PrivateScope;
			}
		}

		// Token: 0x1700031D RID: 797
		// (get) Token: 0x060012FE RID: 4862 RVA: 0x0004CCB0 File Offset: 0x0004AEB0
		public bool IsPublic
		{
			get
			{
				return (this.Attributes & FieldAttributes.FieldAccessMask) == FieldAttributes.Public;
			}
		}

		// Token: 0x1700031E RID: 798
		// (get) Token: 0x060012FF RID: 4863 RVA: 0x0004CCC0 File Offset: 0x0004AEC0
		public bool IsPrivate
		{
			get
			{
				return (this.Attributes & FieldAttributes.FieldAccessMask) == FieldAttributes.Private;
			}
		}

		// Token: 0x1700031F RID: 799
		// (get) Token: 0x06001300 RID: 4864 RVA: 0x0004CCD0 File Offset: 0x0004AED0
		public bool IsNotSerialized
		{
			get
			{
				return (this.Attributes & FieldAttributes.NotSerialized) == FieldAttributes.NotSerialized;
			}
		}

		// Token: 0x06001301 RID: 4865
		public abstract void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, CultureInfo culture);

		// Token: 0x06001302 RID: 4866 RVA: 0x0004CCE8 File Offset: 0x0004AEE8
		[DebuggerStepThrough]
		[DebuggerHidden]
		public void SetValue(object obj, object value)
		{
			this.SetValue(obj, value, BindingFlags.Default, null, null);
		}

		// Token: 0x06001303 RID: 4867
		[MethodImpl(4096)]
		private static extern FieldInfo internal_from_handle_type(IntPtr field_handle, IntPtr type_handle);

		// Token: 0x06001304 RID: 4868 RVA: 0x0004CCF8 File Offset: 0x0004AEF8
		public static FieldInfo GetFieldFromHandle(RuntimeFieldHandle handle)
		{
			if (handle.Value == IntPtr.Zero)
			{
				throw new ArgumentException("The handle is invalid.");
			}
			return FieldInfo.internal_from_handle_type(handle.Value, IntPtr.Zero);
		}

		// Token: 0x06001305 RID: 4869 RVA: 0x0004CD2C File Offset: 0x0004AF2C
		internal virtual int GetFieldOffset()
		{
			throw new SystemException("This method should not be called");
		}

		// Token: 0x06001306 RID: 4870
		[MethodImpl(4096)]
		private extern UnmanagedMarshal GetUnmanagedMarshal();

		// Token: 0x17000320 RID: 800
		// (get) Token: 0x06001307 RID: 4871 RVA: 0x0004CD38 File Offset: 0x0004AF38
		internal virtual UnmanagedMarshal UMarshal
		{
			get
			{
				return this.GetUnmanagedMarshal();
			}
		}

		// Token: 0x06001308 RID: 4872 RVA: 0x0004CD40 File Offset: 0x0004AF40
		internal object[] GetPseudoCustomAttributes()
		{
			int num = 0;
			if (this.IsNotSerialized)
			{
				num++;
			}
			if (this.DeclaringType.IsExplicitLayout)
			{
				num++;
			}
			UnmanagedMarshal umarshal = this.UMarshal;
			if (umarshal != null)
			{
				num++;
			}
			if (num == 0)
			{
				return null;
			}
			object[] array = new object[num];
			num = 0;
			if (this.IsNotSerialized)
			{
				array[num++] = new NonSerializedAttribute();
			}
			if (this.DeclaringType.IsExplicitLayout)
			{
				array[num++] = new FieldOffsetAttribute(this.GetFieldOffset());
			}
			if (umarshal != null)
			{
				array[num++] = umarshal.ToMarshalAsAttribute();
			}
			return array;
		}
	}
}
