﻿using System;

namespace System.Reflection
{
	// Token: 0x020001F7 RID: 503
	[Flags]
	public enum GenericParameterAttributes
	{
		// Token: 0x04000970 RID: 2416
		Covariant = 1,
		// Token: 0x04000971 RID: 2417
		Contravariant = 2,
		// Token: 0x04000972 RID: 2418
		VarianceMask = 3,
		// Token: 0x04000973 RID: 2419
		None = 0,
		// Token: 0x04000974 RID: 2420
		ReferenceTypeConstraint = 4,
		// Token: 0x04000975 RID: 2421
		NotNullableValueTypeConstraint = 8,
		// Token: 0x04000976 RID: 2422
		DefaultConstructorConstraint = 16,
		// Token: 0x04000977 RID: 2423
		SpecialConstraintMask = 28
	}
}
