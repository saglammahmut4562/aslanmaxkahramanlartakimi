﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001F8 RID: 504
	[ComVisible(true)]
	public interface ICustomAttributeProvider
	{
		// Token: 0x06001309 RID: 4873
		object[] GetCustomAttributes(bool inherit);

		// Token: 0x0600130A RID: 4874
		object[] GetCustomAttributes(Type attributeType, bool inherit);

		// Token: 0x0600130B RID: 4875
		bool IsDefined(Type attributeType, bool inherit);
	}
}
