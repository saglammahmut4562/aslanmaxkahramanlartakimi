﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001FA RID: 506
	[ComVisible(true)]
	[Guid("AFBF15E5-C37C-11d2-B88E-00A0C9B471B8")]
	public interface IReflect
	{
		// Token: 0x17000321 RID: 801
		// (get) Token: 0x0600130C RID: 4876
		Type UnderlyingSystemType { get; }

		// Token: 0x0600130D RID: 4877
		FieldInfo GetField(string name, BindingFlags bindingAttr);

		// Token: 0x0600130E RID: 4878
		FieldInfo[] GetFields(BindingFlags bindingAttr);

		// Token: 0x0600130F RID: 4879
		MemberInfo[] GetMember(string name, BindingFlags bindingAttr);

		// Token: 0x06001310 RID: 4880
		MethodInfo GetMethod(string name, BindingFlags bindingAttr);

		// Token: 0x06001311 RID: 4881
		MethodInfo GetMethod(string name, BindingFlags bindingAttr, Binder binder, Type[] types, ParameterModifier[] modifiers);

		// Token: 0x06001312 RID: 4882
		MethodInfo[] GetMethods(BindingFlags bindingAttr);

		// Token: 0x06001313 RID: 4883
		PropertyInfo[] GetProperties(BindingFlags bindingAttr);

		// Token: 0x06001314 RID: 4884
		PropertyInfo GetProperty(string name, BindingFlags bindingAttr);

		// Token: 0x06001315 RID: 4885
		PropertyInfo GetProperty(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers);

		// Token: 0x06001316 RID: 4886
		object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters);
	}
}
