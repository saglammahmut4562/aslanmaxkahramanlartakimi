﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001F9 RID: 505
	[ComVisible(true)]
	[Serializable]
	public enum ImageFileMachine
	{
		// Token: 0x04000979 RID: 2425
		I386 = 332,
		// Token: 0x0400097A RID: 2426
		IA64 = 512,
		// Token: 0x0400097B RID: 2427
		AMD64 = 34404
	}
}
