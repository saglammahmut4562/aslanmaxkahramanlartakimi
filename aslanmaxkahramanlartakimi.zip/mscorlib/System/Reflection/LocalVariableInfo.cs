﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001FB RID: 507
	[ComVisible(true)]
	public class LocalVariableInfo
	{
		// Token: 0x06001317 RID: 4887 RVA: 0x0004CDE4 File Offset: 0x0004AFE4
		internal LocalVariableInfo()
		{
		}

		// Token: 0x06001318 RID: 4888 RVA: 0x0004CDEC File Offset: 0x0004AFEC
		public override string ToString()
		{
			if (this.is_pinned)
			{
				return string.Format("{0} ({1}) (pinned)", this.type, this.position);
			}
			return string.Format("{0} ({1})", this.type, this.position);
		}

		// Token: 0x0400097C RID: 2428
		internal Type type;

		// Token: 0x0400097D RID: 2429
		internal bool is_pinned;

		// Token: 0x0400097E RID: 2430
		internal ushort position;
	}
}
