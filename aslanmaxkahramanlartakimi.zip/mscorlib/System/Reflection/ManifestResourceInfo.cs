﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001FC RID: 508
	[ComVisible(true)]
	public class ManifestResourceInfo
	{
		// Token: 0x06001319 RID: 4889 RVA: 0x0004CE3C File Offset: 0x0004B03C
		internal ManifestResourceInfo()
		{
		}

		// Token: 0x17000322 RID: 802
		// (get) Token: 0x0600131A RID: 4890 RVA: 0x0004CE44 File Offset: 0x0004B044
		public virtual string FileName
		{
			get
			{
				return this._filename;
			}
		}

		// Token: 0x17000323 RID: 803
		// (get) Token: 0x0600131B RID: 4891 RVA: 0x0004CE4C File Offset: 0x0004B04C
		public virtual Assembly ReferencedAssembly
		{
			get
			{
				return this._assembly;
			}
		}

		// Token: 0x17000324 RID: 804
		// (get) Token: 0x0600131C RID: 4892 RVA: 0x0004CE54 File Offset: 0x0004B054
		public virtual ResourceLocation ResourceLocation
		{
			get
			{
				return this._location;
			}
		}

		// Token: 0x0400097F RID: 2431
		private Assembly _assembly;

		// Token: 0x04000980 RID: 2432
		private string _filename;

		// Token: 0x04000981 RID: 2433
		private ResourceLocation _location;
	}
}
