﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x020001FE RID: 510
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_MemberInfo))]
	[ComVisible(true)]
	[Serializable]
	public abstract class MemberInfo : ICustomAttributeProvider, _MemberInfo
	{
		// Token: 0x17000325 RID: 805
		// (get) Token: 0x06001322 RID: 4898
		public abstract Type DeclaringType { get; }

		// Token: 0x17000326 RID: 806
		// (get) Token: 0x06001323 RID: 4899
		public abstract MemberTypes MemberType { get; }

		// Token: 0x17000327 RID: 807
		// (get) Token: 0x06001324 RID: 4900
		public abstract string Name { get; }

		// Token: 0x17000328 RID: 808
		// (get) Token: 0x06001325 RID: 4901
		public abstract Type ReflectedType { get; }

		// Token: 0x17000329 RID: 809
		// (get) Token: 0x06001326 RID: 4902 RVA: 0x0004CE64 File Offset: 0x0004B064
		public virtual Module Module
		{
			get
			{
				return this.DeclaringType.Module;
			}
		}

		// Token: 0x06001327 RID: 4903
		public abstract bool IsDefined(Type attributeType, bool inherit);

		// Token: 0x06001328 RID: 4904
		public abstract object[] GetCustomAttributes(bool inherit);

		// Token: 0x06001329 RID: 4905
		public abstract object[] GetCustomAttributes(Type attributeType, bool inherit);
	}
}
