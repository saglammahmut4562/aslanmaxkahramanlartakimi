﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000200 RID: 512
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum MemberTypes
	{
		// Token: 0x04000989 RID: 2441
		Constructor = 1,
		// Token: 0x0400098A RID: 2442
		Event = 2,
		// Token: 0x0400098B RID: 2443
		Field = 4,
		// Token: 0x0400098C RID: 2444
		Method = 8,
		// Token: 0x0400098D RID: 2445
		Property = 16,
		// Token: 0x0400098E RID: 2446
		TypeInfo = 32,
		// Token: 0x0400098F RID: 2447
		Custom = 64,
		// Token: 0x04000990 RID: 2448
		NestedType = 128,
		// Token: 0x04000991 RID: 2449
		All = 191
	}
}
