﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000201 RID: 513
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum MethodAttributes
	{
		// Token: 0x04000993 RID: 2451
		MemberAccessMask = 7,
		// Token: 0x04000994 RID: 2452
		PrivateScope = 0,
		// Token: 0x04000995 RID: 2453
		Private = 1,
		// Token: 0x04000996 RID: 2454
		FamANDAssem = 2,
		// Token: 0x04000997 RID: 2455
		Assembly = 3,
		// Token: 0x04000998 RID: 2456
		Family = 4,
		// Token: 0x04000999 RID: 2457
		FamORAssem = 5,
		// Token: 0x0400099A RID: 2458
		Public = 6,
		// Token: 0x0400099B RID: 2459
		Static = 16,
		// Token: 0x0400099C RID: 2460
		Final = 32,
		// Token: 0x0400099D RID: 2461
		Virtual = 64,
		// Token: 0x0400099E RID: 2462
		HideBySig = 128,
		// Token: 0x0400099F RID: 2463
		VtableLayoutMask = 256,
		// Token: 0x040009A0 RID: 2464
		CheckAccessOnOverride = 512,
		// Token: 0x040009A1 RID: 2465
		ReuseSlot = 0,
		// Token: 0x040009A2 RID: 2466
		NewSlot = 256,
		// Token: 0x040009A3 RID: 2467
		Abstract = 1024,
		// Token: 0x040009A4 RID: 2468
		SpecialName = 2048,
		// Token: 0x040009A5 RID: 2469
		PinvokeImpl = 8192,
		// Token: 0x040009A6 RID: 2470
		UnmanagedExport = 8,
		// Token: 0x040009A7 RID: 2471
		RTSpecialName = 4096,
		// Token: 0x040009A8 RID: 2472
		ReservedMask = 53248,
		// Token: 0x040009A9 RID: 2473
		HasSecurity = 16384,
		// Token: 0x040009AA RID: 2474
		RequireSecObject = 32768
	}
}
