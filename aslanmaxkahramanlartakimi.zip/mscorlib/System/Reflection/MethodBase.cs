﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000202 RID: 514
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_MethodBase))]
	[ClassInterface(ClassInterfaceType.None)]
	[Serializable]
	public abstract class MethodBase : MemberInfo, _MethodBase
	{
		// Token: 0x06001330 RID: 4912 RVA: 0x0004D200 File Offset: 0x0004B400
		internal static MethodBase GetMethodFromHandleNoGenericCheck(RuntimeMethodHandle handle)
		{
			return MethodBase.GetMethodFromIntPtr(handle.Value, IntPtr.Zero);
		}

		// Token: 0x06001331 RID: 4913 RVA: 0x0004D214 File Offset: 0x0004B414
		private static MethodBase GetMethodFromIntPtr(IntPtr handle, IntPtr declaringType)
		{
			if (handle == IntPtr.Zero)
			{
				throw new ArgumentException("The handle is invalid.");
			}
			MethodBase methodFromHandleInternalType = MethodBase.GetMethodFromHandleInternalType(handle, declaringType);
			if (methodFromHandleInternalType == null)
			{
				throw new ArgumentException("The handle is invalid.");
			}
			return methodFromHandleInternalType;
		}

		// Token: 0x06001332 RID: 4914 RVA: 0x0004D258 File Offset: 0x0004B458
		public static MethodBase GetMethodFromHandle(RuntimeMethodHandle handle)
		{
			MethodBase methodFromIntPtr = MethodBase.GetMethodFromIntPtr(handle.Value, IntPtr.Zero);
			Type declaringType = methodFromIntPtr.DeclaringType;
			if (declaringType.IsGenericType || declaringType.IsGenericTypeDefinition)
			{
				throw new ArgumentException("Cannot resolve method because it's declared in a generic class.");
			}
			return methodFromIntPtr;
		}

		// Token: 0x06001333 RID: 4915
		[MethodImpl(4096)]
		private static extern MethodBase GetMethodFromHandleInternalType(IntPtr method_handle, IntPtr type_handle);

		// Token: 0x06001334 RID: 4916
		public abstract MethodImplAttributes GetMethodImplementationFlags();

		// Token: 0x06001335 RID: 4917
		public abstract ParameterInfo[] GetParameters();

		// Token: 0x06001336 RID: 4918 RVA: 0x0004D2A0 File Offset: 0x0004B4A0
		internal virtual int GetParameterCount()
		{
			ParameterInfo[] parameters = this.GetParameters();
			if (parameters == null)
			{
				return 0;
			}
			return parameters.Length;
		}

		// Token: 0x06001337 RID: 4919 RVA: 0x0004D2C0 File Offset: 0x0004B4C0
		[DebuggerStepThrough]
		[DebuggerHidden]
		public object Invoke(object obj, object[] parameters)
		{
			return this.Invoke(obj, BindingFlags.Default, null, parameters, null);
		}

		// Token: 0x06001338 RID: 4920
		public abstract object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture);

		// Token: 0x1700032A RID: 810
		// (get) Token: 0x06001339 RID: 4921
		public abstract RuntimeMethodHandle MethodHandle { get; }

		// Token: 0x1700032B RID: 811
		// (get) Token: 0x0600133A RID: 4922
		public abstract MethodAttributes Attributes { get; }

		// Token: 0x1700032C RID: 812
		// (get) Token: 0x0600133B RID: 4923 RVA: 0x0004D2D0 File Offset: 0x0004B4D0
		public virtual CallingConventions CallingConvention
		{
			get
			{
				return CallingConventions.Standard;
			}
		}

		// Token: 0x1700032D RID: 813
		// (get) Token: 0x0600133C RID: 4924 RVA: 0x0004D2D4 File Offset: 0x0004B4D4
		public bool IsPublic
		{
			get
			{
				return (this.Attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public;
			}
		}

		// Token: 0x1700032E RID: 814
		// (get) Token: 0x0600133D RID: 4925 RVA: 0x0004D2E4 File Offset: 0x0004B4E4
		public bool IsStatic
		{
			get
			{
				return (this.Attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope;
			}
		}

		// Token: 0x1700032F RID: 815
		// (get) Token: 0x0600133E RID: 4926 RVA: 0x0004D2F8 File Offset: 0x0004B4F8
		public bool IsVirtual
		{
			get
			{
				return (this.Attributes & MethodAttributes.Virtual) != MethodAttributes.PrivateScope;
			}
		}

		// Token: 0x17000330 RID: 816
		// (get) Token: 0x0600133F RID: 4927 RVA: 0x0004D30C File Offset: 0x0004B50C
		public bool IsAbstract
		{
			get
			{
				return (this.Attributes & MethodAttributes.Abstract) != MethodAttributes.PrivateScope;
			}
		}

		// Token: 0x06001340 RID: 4928 RVA: 0x0004D320 File Offset: 0x0004B520
		internal virtual int get_next_table_index(object obj, int table, bool inc)
		{
			if (this is MethodBuilder)
			{
				MethodBuilder methodBuilder = (MethodBuilder)this;
				return methodBuilder.get_next_table_index(obj, table, inc);
			}
			if (this is ConstructorBuilder)
			{
				ConstructorBuilder constructorBuilder = (ConstructorBuilder)this;
				return constructorBuilder.get_next_table_index(obj, table, inc);
			}
			throw new Exception("Method is not a builder method");
		}

		// Token: 0x06001341 RID: 4929 RVA: 0x0004D370 File Offset: 0x0004B570
		[ComVisible(true)]
		public virtual Type[] GetGenericArguments()
		{
			throw new NotSupportedException();
		}

		// Token: 0x17000331 RID: 817
		// (get) Token: 0x06001342 RID: 4930 RVA: 0x0004D378 File Offset: 0x0004B578
		public virtual bool ContainsGenericParameters
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000332 RID: 818
		// (get) Token: 0x06001343 RID: 4931 RVA: 0x0004D37C File Offset: 0x0004B57C
		public virtual bool IsGenericMethodDefinition
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000333 RID: 819
		// (get) Token: 0x06001344 RID: 4932 RVA: 0x0004D380 File Offset: 0x0004B580
		public virtual bool IsGenericMethod
		{
			get
			{
				return false;
			}
		}
	}
}
