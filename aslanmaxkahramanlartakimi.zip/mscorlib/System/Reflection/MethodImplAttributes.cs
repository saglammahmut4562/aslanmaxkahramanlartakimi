﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000203 RID: 515
	[ComVisible(true)]
	[Serializable]
	public enum MethodImplAttributes
	{
		// Token: 0x040009AC RID: 2476
		CodeTypeMask = 3,
		// Token: 0x040009AD RID: 2477
		IL = 0,
		// Token: 0x040009AE RID: 2478
		Native,
		// Token: 0x040009AF RID: 2479
		OPTIL,
		// Token: 0x040009B0 RID: 2480
		Runtime,
		// Token: 0x040009B1 RID: 2481
		ManagedMask,
		// Token: 0x040009B2 RID: 2482
		Unmanaged = 4,
		// Token: 0x040009B3 RID: 2483
		Managed = 0,
		// Token: 0x040009B4 RID: 2484
		ForwardRef = 16,
		// Token: 0x040009B5 RID: 2485
		PreserveSig = 128,
		// Token: 0x040009B6 RID: 2486
		InternalCall = 4096,
		// Token: 0x040009B7 RID: 2487
		Synchronized = 32,
		// Token: 0x040009B8 RID: 2488
		NoInlining = 8,
		// Token: 0x040009B9 RID: 2489
		MaxMethodImplVal = 65535
	}
}
