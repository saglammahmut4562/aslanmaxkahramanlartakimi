﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000204 RID: 516
	[ComVisible(true)]
	[ComDefaultInterface(typeof(_MethodInfo))]
	[ClassInterface(ClassInterfaceType.None)]
	[Serializable]
	public abstract class MethodInfo : MethodBase, _MethodInfo
	{
		// Token: 0x06001346 RID: 4934
		public abstract MethodInfo GetBaseDefinition();

		// Token: 0x17000334 RID: 820
		// (get) Token: 0x06001347 RID: 4935 RVA: 0x0004D38C File Offset: 0x0004B58C
		public override MemberTypes MemberType
		{
			get
			{
				return MemberTypes.Method;
			}
		}

		// Token: 0x17000335 RID: 821
		// (get) Token: 0x06001348 RID: 4936 RVA: 0x0004D390 File Offset: 0x0004B590
		public virtual Type ReturnType
		{
			get
			{
				return null;
			}
		}

		// Token: 0x06001349 RID: 4937 RVA: 0x0004D394 File Offset: 0x0004B594
		[ComVisible(true)]
		public virtual MethodInfo GetGenericMethodDefinition()
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600134A RID: 4938 RVA: 0x0004D39C File Offset: 0x0004B59C
		public virtual MethodInfo MakeGenericMethod(params Type[] typeArguments)
		{
			throw new NotSupportedException(base.GetType().ToString());
		}

		// Token: 0x0600134B RID: 4939 RVA: 0x0004D3B0 File Offset: 0x0004B5B0
		[ComVisible(true)]
		public override Type[] GetGenericArguments()
		{
			return Type.EmptyTypes;
		}

		// Token: 0x17000336 RID: 822
		// (get) Token: 0x0600134C RID: 4940 RVA: 0x0004D3B8 File Offset: 0x0004B5B8
		public override bool IsGenericMethod
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000337 RID: 823
		// (get) Token: 0x0600134D RID: 4941 RVA: 0x0004D3BC File Offset: 0x0004B5BC
		public override bool IsGenericMethodDefinition
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000338 RID: 824
		// (get) Token: 0x0600134E RID: 4942 RVA: 0x0004D3C0 File Offset: 0x0004B5C0
		public override bool ContainsGenericParameters
		{
			get
			{
				return false;
			}
		}
	}
}
