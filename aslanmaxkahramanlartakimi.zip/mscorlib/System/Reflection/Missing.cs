﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x02000205 RID: 517
	[ComVisible(true)]
	[Serializable]
	public sealed class Missing : ISerializable
	{
		// Token: 0x0600134F RID: 4943 RVA: 0x0004D3C4 File Offset: 0x0004B5C4
		internal Missing()
		{
		}

		// Token: 0x06001351 RID: 4945 RVA: 0x0004D3D8 File Offset: 0x0004B5D8
		[MonoTODO]
		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
		}

		// Token: 0x040009BA RID: 2490
		public static readonly Missing Value = new Missing();
	}
}
