﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x02000206 RID: 518
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_Module))]
	[ComVisible(true)]
	[Serializable]
	public class Module : ICustomAttributeProvider, _Module, ISerializable
	{
		// Token: 0x06001352 RID: 4946 RVA: 0x0004D3DC File Offset: 0x0004B5DC
		internal Module()
		{
		}

		// Token: 0x17000339 RID: 825
		// (get) Token: 0x06001354 RID: 4948 RVA: 0x0004D408 File Offset: 0x0004B608
		public Assembly Assembly
		{
			get
			{
				return this.assembly;
			}
		}

		// Token: 0x1700033A RID: 826
		// (get) Token: 0x06001355 RID: 4949 RVA: 0x0004D410 File Offset: 0x0004B610
		public string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x1700033B RID: 827
		// (get) Token: 0x06001356 RID: 4950 RVA: 0x0004D418 File Offset: 0x0004B618
		public string ScopeName
		{
			get
			{
				return this.scopename;
			}
		}

		// Token: 0x06001357 RID: 4951 RVA: 0x0004D420 File Offset: 0x0004B620
		public virtual object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x06001358 RID: 4952 RVA: 0x0004D42C File Offset: 0x0004B62C
		public virtual object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x06001359 RID: 4953 RVA: 0x0004D438 File Offset: 0x0004B638
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (info == null)
			{
				throw new ArgumentNullException("info");
			}
			UnitySerializationHolder.GetModuleData(this, info, context);
		}

		// Token: 0x0600135A RID: 4954 RVA: 0x0004D454 File Offset: 0x0004B654
		[ComVisible(true)]
		public virtual Type GetType(string className)
		{
			return this.GetType(className, false, false);
		}

		// Token: 0x0600135B RID: 4955 RVA: 0x0004D460 File Offset: 0x0004B660
		[ComVisible(true)]
		public virtual Type GetType(string className, bool throwOnError, bool ignoreCase)
		{
			if (className == null)
			{
				throw new ArgumentNullException("className");
			}
			if (className == string.Empty)
			{
				throw new ArgumentException("Type name can't be empty");
			}
			return this.assembly.InternalGetType(this, className, throwOnError, ignoreCase);
		}

		// Token: 0x0600135C RID: 4956
		[MethodImpl(4096)]
		private extern Type[] InternalGetTypes();

		// Token: 0x0600135D RID: 4957 RVA: 0x0004D4A0 File Offset: 0x0004B6A0
		public virtual Type[] GetTypes()
		{
			return this.InternalGetTypes();
		}

		// Token: 0x0600135E RID: 4958 RVA: 0x0004D4A8 File Offset: 0x0004B6A8
		public virtual bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x0600135F RID: 4959 RVA: 0x0004D4B4 File Offset: 0x0004B6B4
		public bool IsResource()
		{
			return this.is_resource;
		}

		// Token: 0x06001360 RID: 4960 RVA: 0x0004D4BC File Offset: 0x0004B6BC
		public override string ToString()
		{
			return this.name;
		}

		// Token: 0x06001361 RID: 4961 RVA: 0x0004D4C4 File Offset: 0x0004B6C4
		private static bool filter_by_type_name(Type m, object filterCriteria)
		{
			string text = (string)filterCriteria;
			if (text.EndsWith("*"))
			{
				return m.Name.StartsWith(text.Substring(0, text.Length - 1));
			}
			return m.Name == text;
		}

		// Token: 0x06001362 RID: 4962 RVA: 0x0004D510 File Offset: 0x0004B710
		private static bool filter_by_type_name_ignore_case(Type m, object filterCriteria)
		{
			string text = (string)filterCriteria;
			if (text.EndsWith("*"))
			{
				return m.Name.ToLower().StartsWith(text.Substring(0, text.Length - 1).ToLower());
			}
			return string.Compare(m.Name, text, true) == 0;
		}

		// Token: 0x06001363 RID: 4963
		[MethodImpl(4096)]
		internal extern IntPtr GetHINSTANCE();

		// Token: 0x040009BB RID: 2491
		private const BindingFlags defaultBindingFlags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public;

		// Token: 0x040009BC RID: 2492
		public static readonly TypeFilter FilterTypeName = new TypeFilter(Module.filter_by_type_name);

		// Token: 0x040009BD RID: 2493
		public static readonly TypeFilter FilterTypeNameIgnoreCase = new TypeFilter(Module.filter_by_type_name_ignore_case);

		// Token: 0x040009BE RID: 2494
		private IntPtr _impl;

		// Token: 0x040009BF RID: 2495
		internal Assembly assembly;

		// Token: 0x040009C0 RID: 2496
		internal string fqname;

		// Token: 0x040009C1 RID: 2497
		internal string name;

		// Token: 0x040009C2 RID: 2498
		internal string scopename;

		// Token: 0x040009C3 RID: 2499
		internal bool is_resource;

		// Token: 0x040009C4 RID: 2500
		internal int token;
	}
}
