﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Text;

namespace System.Reflection
{
	// Token: 0x02000208 RID: 520
	internal class MonoCMethod : ConstructorInfo, ISerializable
	{
		// Token: 0x06001369 RID: 4969 RVA: 0x0004D574 File Offset: 0x0004B774
		public override MethodImplAttributes GetMethodImplementationFlags()
		{
			return MonoMethodInfo.GetMethodImplementationFlags(this.mhandle);
		}

		// Token: 0x0600136A RID: 4970 RVA: 0x0004D584 File Offset: 0x0004B784
		public override ParameterInfo[] GetParameters()
		{
			return MonoMethodInfo.GetParametersInfo(this.mhandle, this);
		}

		// Token: 0x0600136B RID: 4971
		[MethodImpl(4096)]
		internal extern object InternalInvoke(object obj, object[] parameters, out Exception exc);

		// Token: 0x0600136C RID: 4972 RVA: 0x0004D594 File Offset: 0x0004B794
		public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			ParameterInfo[] parameters2 = this.GetParameters();
			if ((parameters == null && parameters2.Length != 0) || (parameters != null && parameters.Length != parameters2.Length))
			{
				throw new TargetParameterCountException("parameters do not match signature");
			}
			if ((invokeAttr & BindingFlags.ExactBinding) == BindingFlags.Default)
			{
				if (!Binder.ConvertArgs(binder, parameters, parameters2, culture))
				{
					throw new ArgumentException("failed to convert parameters");
				}
			}
			else
			{
				for (int i = 0; i < parameters2.Length; i++)
				{
					if (parameters[i].GetType() != parameters2[i].ParameterType)
					{
						throw new ArgumentException("parameters do not match signature");
					}
				}
			}
			if (obj == null && this.DeclaringType.ContainsGenericParameters)
			{
				throw new MemberAccessException("Cannot create an instance of " + this.DeclaringType + " because Type.ContainsGenericParameters is true.");
			}
			if ((invokeAttr & BindingFlags.CreateInstance) != BindingFlags.Default && this.DeclaringType.IsAbstract)
			{
				throw new MemberAccessException(string.Format("Cannot create an instance of {0} because it is an abstract class", this.DeclaringType));
			}
			Exception ex = null;
			object obj2 = null;
			try
			{
				obj2 = this.InternalInvoke(obj, parameters, out ex);
			}
			catch (MethodAccessException)
			{
				throw;
			}
			catch (Exception ex2)
			{
				throw new TargetInvocationException(ex2);
			}
			if (ex != null)
			{
				throw ex;
			}
			return (obj != null) ? null : obj2;
		}

		// Token: 0x0600136D RID: 4973 RVA: 0x0004D704 File Offset: 0x0004B904
		public override object Invoke(BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			return this.Invoke(null, invokeAttr, binder, parameters, culture);
		}

		// Token: 0x1700033C RID: 828
		// (get) Token: 0x0600136E RID: 4974 RVA: 0x0004D714 File Offset: 0x0004B914
		public override RuntimeMethodHandle MethodHandle
		{
			get
			{
				return new RuntimeMethodHandle(this.mhandle);
			}
		}

		// Token: 0x1700033D RID: 829
		// (get) Token: 0x0600136F RID: 4975 RVA: 0x0004D724 File Offset: 0x0004B924
		public override MethodAttributes Attributes
		{
			get
			{
				return MonoMethodInfo.GetAttributes(this.mhandle);
			}
		}

		// Token: 0x1700033E RID: 830
		// (get) Token: 0x06001370 RID: 4976 RVA: 0x0004D734 File Offset: 0x0004B934
		public override CallingConventions CallingConvention
		{
			get
			{
				return MonoMethodInfo.GetCallingConvention(this.mhandle);
			}
		}

		// Token: 0x1700033F RID: 831
		// (get) Token: 0x06001371 RID: 4977 RVA: 0x0004D744 File Offset: 0x0004B944
		public override Type ReflectedType
		{
			get
			{
				return this.reftype;
			}
		}

		// Token: 0x17000340 RID: 832
		// (get) Token: 0x06001372 RID: 4978 RVA: 0x0004D74C File Offset: 0x0004B94C
		public override Type DeclaringType
		{
			get
			{
				return MonoMethodInfo.GetDeclaringType(this.mhandle);
			}
		}

		// Token: 0x17000341 RID: 833
		// (get) Token: 0x06001373 RID: 4979 RVA: 0x0004D75C File Offset: 0x0004B95C
		public override string Name
		{
			get
			{
				if (this.name != null)
				{
					return this.name;
				}
				return MonoMethod.get_name(this);
			}
		}

		// Token: 0x06001374 RID: 4980 RVA: 0x0004D778 File Offset: 0x0004B978
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x06001375 RID: 4981 RVA: 0x0004D784 File Offset: 0x0004B984
		public override object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x06001376 RID: 4982 RVA: 0x0004D790 File Offset: 0x0004B990
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x06001377 RID: 4983 RVA: 0x0004D79C File Offset: 0x0004B99C
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("Void ");
			stringBuilder.Append(this.Name);
			stringBuilder.Append("(");
			ParameterInfo[] parameters = this.GetParameters();
			for (int i = 0; i < parameters.Length; i++)
			{
				if (i > 0)
				{
					stringBuilder.Append(", ");
				}
				stringBuilder.Append(parameters[i].ParameterType.Name);
			}
			if (this.CallingConvention == CallingConventions.Any)
			{
				stringBuilder.Append(", ...");
			}
			stringBuilder.Append(")");
			return stringBuilder.ToString();
		}

		// Token: 0x06001378 RID: 4984 RVA: 0x0004D840 File Offset: 0x0004BA40
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			MemberInfoSerializationHolder.Serialize(info, this.Name, this.ReflectedType, this.ToString(), MemberTypes.Constructor);
		}

		// Token: 0x040009C5 RID: 2501
		internal IntPtr mhandle;

		// Token: 0x040009C6 RID: 2502
		private string name;

		// Token: 0x040009C7 RID: 2503
		private Type reftype;
	}
}
