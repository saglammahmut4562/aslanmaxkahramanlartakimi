﻿using System;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x02000209 RID: 521
	[Serializable]
	internal sealed class MonoEvent : EventInfo, ISerializable
	{
		// Token: 0x17000342 RID: 834
		// (get) Token: 0x0600137A RID: 4986 RVA: 0x0004D864 File Offset: 0x0004BA64
		public override EventAttributes Attributes
		{
			get
			{
				return MonoEventInfo.GetEventInfo(this).attrs;
			}
		}

		// Token: 0x0600137B RID: 4987 RVA: 0x0004D880 File Offset: 0x0004BA80
		public override MethodInfo GetAddMethod(bool nonPublic)
		{
			MonoEventInfo eventInfo = MonoEventInfo.GetEventInfo(this);
			if (nonPublic || (eventInfo.add_method != null && eventInfo.add_method.IsPublic))
			{
				return eventInfo.add_method;
			}
			return null;
		}

		// Token: 0x0600137C RID: 4988 RVA: 0x0004D8C0 File Offset: 0x0004BAC0
		public override MethodInfo GetRemoveMethod(bool nonPublic)
		{
			MonoEventInfo eventInfo = MonoEventInfo.GetEventInfo(this);
			if (nonPublic || (eventInfo.remove_method != null && eventInfo.remove_method.IsPublic))
			{
				return eventInfo.remove_method;
			}
			return null;
		}

		// Token: 0x17000343 RID: 835
		// (get) Token: 0x0600137D RID: 4989 RVA: 0x0004D900 File Offset: 0x0004BB00
		public override Type DeclaringType
		{
			get
			{
				return MonoEventInfo.GetEventInfo(this).declaring_type;
			}
		}

		// Token: 0x17000344 RID: 836
		// (get) Token: 0x0600137E RID: 4990 RVA: 0x0004D91C File Offset: 0x0004BB1C
		public override Type ReflectedType
		{
			get
			{
				return MonoEventInfo.GetEventInfo(this).reflected_type;
			}
		}

		// Token: 0x17000345 RID: 837
		// (get) Token: 0x0600137F RID: 4991 RVA: 0x0004D938 File Offset: 0x0004BB38
		public override string Name
		{
			get
			{
				return MonoEventInfo.GetEventInfo(this).name;
			}
		}

		// Token: 0x06001380 RID: 4992 RVA: 0x0004D954 File Offset: 0x0004BB54
		public override string ToString()
		{
			return this.EventHandlerType + " " + this.Name;
		}

		// Token: 0x06001381 RID: 4993 RVA: 0x0004D96C File Offset: 0x0004BB6C
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x06001382 RID: 4994 RVA: 0x0004D978 File Offset: 0x0004BB78
		public override object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x06001383 RID: 4995 RVA: 0x0004D984 File Offset: 0x0004BB84
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x06001384 RID: 4996 RVA: 0x0004D990 File Offset: 0x0004BB90
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			MemberInfoSerializationHolder.Serialize(info, this.Name, this.ReflectedType, this.ToString(), MemberTypes.Event);
		}

		// Token: 0x040009C8 RID: 2504
		private IntPtr klass;

		// Token: 0x040009C9 RID: 2505
		private IntPtr handle;
	}
}
