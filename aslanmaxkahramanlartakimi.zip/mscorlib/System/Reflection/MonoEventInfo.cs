﻿using System;
using System.Runtime.CompilerServices;

namespace System.Reflection
{
	// Token: 0x0200020A RID: 522
	internal struct MonoEventInfo
	{
		// Token: 0x06001385 RID: 4997
		[MethodImpl(4096)]
		private static extern void get_event_info(MonoEvent ev, out MonoEventInfo info);

		// Token: 0x06001386 RID: 4998 RVA: 0x0004D9AC File Offset: 0x0004BBAC
		internal static MonoEventInfo GetEventInfo(MonoEvent ev)
		{
			MonoEventInfo monoEventInfo;
			MonoEventInfo.get_event_info(ev, out monoEventInfo);
			return monoEventInfo;
		}

		// Token: 0x040009CA RID: 2506
		public Type declaring_type;

		// Token: 0x040009CB RID: 2507
		public Type reflected_type;

		// Token: 0x040009CC RID: 2508
		public string name;

		// Token: 0x040009CD RID: 2509
		public MethodInfo add_method;

		// Token: 0x040009CE RID: 2510
		public MethodInfo remove_method;

		// Token: 0x040009CF RID: 2511
		public MethodInfo raise_method;

		// Token: 0x040009D0 RID: 2512
		public EventAttributes attrs;

		// Token: 0x040009D1 RID: 2513
		public MethodInfo[] other_methods;
	}
}
