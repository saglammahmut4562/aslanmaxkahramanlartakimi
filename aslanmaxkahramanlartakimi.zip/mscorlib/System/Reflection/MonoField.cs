﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x0200020B RID: 523
	[Serializable]
	internal class MonoField : FieldInfo, ISerializable
	{
		// Token: 0x17000346 RID: 838
		// (get) Token: 0x06001388 RID: 5000 RVA: 0x0004D9CC File Offset: 0x0004BBCC
		public override FieldAttributes Attributes
		{
			get
			{
				return this.attrs;
			}
		}

		// Token: 0x17000347 RID: 839
		// (get) Token: 0x06001389 RID: 5001 RVA: 0x0004D9D4 File Offset: 0x0004BBD4
		public override RuntimeFieldHandle FieldHandle
		{
			get
			{
				return this.fhandle;
			}
		}

		// Token: 0x17000348 RID: 840
		// (get) Token: 0x0600138A RID: 5002 RVA: 0x0004D9DC File Offset: 0x0004BBDC
		public override Type FieldType
		{
			get
			{
				return this.type;
			}
		}

		// Token: 0x0600138B RID: 5003
		[MethodImpl(4096)]
		private extern Type GetParentType(bool declaring);

		// Token: 0x17000349 RID: 841
		// (get) Token: 0x0600138C RID: 5004 RVA: 0x0004D9E4 File Offset: 0x0004BBE4
		public override Type ReflectedType
		{
			get
			{
				return this.GetParentType(false);
			}
		}

		// Token: 0x1700034A RID: 842
		// (get) Token: 0x0600138D RID: 5005 RVA: 0x0004D9F0 File Offset: 0x0004BBF0
		public override Type DeclaringType
		{
			get
			{
				return this.GetParentType(true);
			}
		}

		// Token: 0x1700034B RID: 843
		// (get) Token: 0x0600138E RID: 5006 RVA: 0x0004D9FC File Offset: 0x0004BBFC
		public override string Name
		{
			get
			{
				return this.name;
			}
		}

		// Token: 0x0600138F RID: 5007 RVA: 0x0004DA04 File Offset: 0x0004BC04
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x06001390 RID: 5008 RVA: 0x0004DA10 File Offset: 0x0004BC10
		public override object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x06001391 RID: 5009 RVA: 0x0004DA1C File Offset: 0x0004BC1C
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x06001392 RID: 5010
		[MethodImpl(4096)]
		internal override extern int GetFieldOffset();

		// Token: 0x06001393 RID: 5011
		[MethodImpl(4096)]
		private extern object GetValueInternal(object obj);

		// Token: 0x06001394 RID: 5012 RVA: 0x0004DA28 File Offset: 0x0004BC28
		public override object GetValue(object obj)
		{
			if (!this.IsStatic && obj == null)
			{
				throw new TargetException("Non-static field requires a target");
			}
			if (!this.IsLiteral)
			{
				this.CheckGeneric();
			}
			return this.GetValueInternal(obj);
		}

		// Token: 0x06001395 RID: 5013 RVA: 0x0004DA60 File Offset: 0x0004BC60
		public override string ToString()
		{
			return string.Format("{0} {1}", this.type, this.name);
		}

		// Token: 0x06001396 RID: 5014
		[MethodImpl(4096)]
		private static extern void SetValueInternal(FieldInfo fi, object obj, object value);

		// Token: 0x06001397 RID: 5015 RVA: 0x0004DA78 File Offset: 0x0004BC78
		public override void SetValue(object obj, object val, BindingFlags invokeAttr, Binder binder, CultureInfo culture)
		{
			if (!this.IsStatic && obj == null)
			{
				throw new TargetException("Non-static field requires a target");
			}
			if (this.IsLiteral)
			{
				throw new FieldAccessException("Cannot set a constant field");
			}
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			this.CheckGeneric();
			if (val != null)
			{
				object obj2 = binder.ChangeType(val, this.type, culture);
				if (obj2 == null)
				{
					throw new ArgumentException(string.Concat(new object[]
					{
						"Object type ",
						val.GetType(),
						" cannot be converted to target type: ",
						this.type
					}), "val");
				}
				val = obj2;
			}
			MonoField.SetValueInternal(this, obj, val);
		}

		// Token: 0x06001398 RID: 5016 RVA: 0x0004DB2C File Offset: 0x0004BD2C
		internal MonoField Clone(string newName)
		{
			return new MonoField
			{
				name = newName,
				type = this.type,
				attrs = this.attrs,
				klass = this.klass,
				fhandle = this.fhandle
			};
		}

		// Token: 0x06001399 RID: 5017 RVA: 0x0004DB78 File Offset: 0x0004BD78
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			MemberInfoSerializationHolder.Serialize(info, this.Name, this.ReflectedType, this.ToString(), MemberTypes.Field);
		}

		// Token: 0x0600139A RID: 5018 RVA: 0x0004DB94 File Offset: 0x0004BD94
		private void CheckGeneric()
		{
			if (this.DeclaringType.ContainsGenericParameters)
			{
				throw new InvalidOperationException("Late bound operations cannot be performed on fields with types for which Type.ContainsGenericParameters is true.");
			}
		}

		// Token: 0x040009D2 RID: 2514
		internal IntPtr klass;

		// Token: 0x040009D3 RID: 2515
		internal RuntimeFieldHandle fhandle;

		// Token: 0x040009D4 RID: 2516
		private string name;

		// Token: 0x040009D5 RID: 2517
		private Type type;

		// Token: 0x040009D6 RID: 2518
		private FieldAttributes attrs;
	}
}
