﻿using System;
using System.Runtime.CompilerServices;

namespace System.Reflection
{
	// Token: 0x0200020D RID: 525
	[Serializable]
	internal class MonoGenericCMethod : MonoCMethod
	{
		// Token: 0x060013CA RID: 5066 RVA: 0x0004EB64 File Offset: 0x0004CD64
		internal MonoGenericCMethod()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x17000353 RID: 851
		// (get) Token: 0x060013CB RID: 5067
		public override extern Type ReflectedType
		{
			[MethodImpl(4096)]
			get;
		}
	}
}
