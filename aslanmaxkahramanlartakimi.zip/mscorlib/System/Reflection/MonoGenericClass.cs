﻿using System;
using System.Collections;
using System.Globalization;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;

namespace System.Reflection
{
	// Token: 0x0200020C RID: 524
	internal class MonoGenericClass : MonoType
	{
		// Token: 0x0600139B RID: 5019
		[MethodImpl(4096)]
		private extern void initialize(MethodInfo[] methods, ConstructorInfo[] ctors, FieldInfo[] fields, PropertyInfo[] properties, EventInfo[] events);

		// Token: 0x0600139C RID: 5020 RVA: 0x0004DBB4 File Offset: 0x0004BDB4
		private void initialize()
		{
			if (this.initialized)
			{
				return;
			}
			MonoGenericClass monoGenericClass = this.GetParentType() as MonoGenericClass;
			if (monoGenericClass != null)
			{
				monoGenericClass.initialize();
			}
			EventInfo[] events_internal = this.generic_type.GetEvents_internal(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			this.event_count = events_internal.Length;
			this.initialize(this.generic_type.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic), this.generic_type.GetConstructorsInternal(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic), this.generic_type.GetFields(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic), this.generic_type.GetProperties(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic), events_internal);
			this.initialized = true;
		}

		// Token: 0x0600139D RID: 5021 RVA: 0x0004DC40 File Offset: 0x0004BE40
		private Type GetParentType()
		{
			return this.InflateType(this.generic_type.BaseType);
		}

		// Token: 0x0600139E RID: 5022 RVA: 0x0004DC54 File Offset: 0x0004BE54
		internal Type InflateType(Type type)
		{
			return this.InflateType(type, null);
		}

		// Token: 0x0600139F RID: 5023 RVA: 0x0004DC60 File Offset: 0x0004BE60
		internal Type InflateType(Type type, Type[] method_args)
		{
			if (type == null)
			{
				return null;
			}
			if (!type.IsGenericParameter && !type.ContainsGenericParameters)
			{
				return type;
			}
			if (type.IsGenericParameter)
			{
				if (type.DeclaringMethod == null)
				{
					return this.type_arguments[type.GenericParameterPosition];
				}
				if (method_args != null)
				{
					return method_args[type.GenericParameterPosition];
				}
				return type;
			}
			else
			{
				if (type.IsPointer)
				{
					return this.InflateType(type.GetElementType(), method_args).MakePointerType();
				}
				if (type.IsByRef)
				{
					return this.InflateType(type.GetElementType(), method_args).MakeByRefType();
				}
				if (!type.IsArray)
				{
					Type[] genericArguments = type.GetGenericArguments();
					for (int i = 0; i < genericArguments.Length; i++)
					{
						genericArguments[i] = this.InflateType(genericArguments[i], method_args);
					}
					Type type2 = ((!type.IsGenericTypeDefinition) ? type.GetGenericTypeDefinition() : type);
					return type2.MakeGenericType(genericArguments);
				}
				if (type.GetArrayRank() > 1)
				{
					return this.InflateType(type.GetElementType(), method_args).MakeArrayType(type.GetArrayRank());
				}
				if (type.ToString().EndsWith("[*]", StringComparison.Ordinal))
				{
					return this.InflateType(type.GetElementType(), method_args).MakeArrayType(1);
				}
				return this.InflateType(type.GetElementType(), method_args).MakeArrayType();
			}
		}

		// Token: 0x1700034C RID: 844
		// (get) Token: 0x060013A0 RID: 5024 RVA: 0x0004DDB4 File Offset: 0x0004BFB4
		public override Type BaseType
		{
			get
			{
				Type parentType = this.GetParentType();
				return (parentType == null) ? this.generic_type.BaseType : parentType;
			}
		}

		// Token: 0x060013A1 RID: 5025 RVA: 0x0004DDE0 File Offset: 0x0004BFE0
		private Type[] GetInterfacesInternal()
		{
			if (this.generic_type.interfaces == null)
			{
				return new Type[0];
			}
			Type[] array = new Type[this.generic_type.interfaces.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = this.InflateType(this.generic_type.interfaces[i]);
			}
			return array;
		}

		// Token: 0x060013A2 RID: 5026 RVA: 0x0004DE44 File Offset: 0x0004C044
		public override Type[] GetInterfaces()
		{
			if (!this.generic_type.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			return this.GetInterfacesInternal();
		}

		// Token: 0x060013A3 RID: 5027 RVA: 0x0004DE64 File Offset: 0x0004C064
		protected override bool IsValueTypeImpl()
		{
			return this.generic_type.IsValueType;
		}

		// Token: 0x060013A4 RID: 5028 RVA: 0x0004DE74 File Offset: 0x0004C074
		internal override MethodInfo GetMethod(MethodInfo fromNoninstanciated)
		{
			this.initialize();
			if (!(fromNoninstanciated is MethodBuilder))
			{
				throw new InvalidOperationException("Inflating non MethodBuilder objects is not supported: " + fromNoninstanciated.GetType());
			}
			MethodBuilder methodBuilder = (MethodBuilder)fromNoninstanciated;
			if (this.methods == null)
			{
				this.methods = new Hashtable();
			}
			if (!this.methods.ContainsKey(methodBuilder))
			{
				this.methods[methodBuilder] = new MethodOnTypeBuilderInst(this, methodBuilder);
			}
			return (MethodInfo)this.methods[methodBuilder];
		}

		// Token: 0x060013A5 RID: 5029 RVA: 0x0004DEFC File Offset: 0x0004C0FC
		internal override ConstructorInfo GetConstructor(ConstructorInfo fromNoninstanciated)
		{
			this.initialize();
			if (!(fromNoninstanciated is ConstructorBuilder))
			{
				throw new InvalidOperationException("Inflating non ConstructorBuilder objects is not supported: " + fromNoninstanciated.GetType());
			}
			ConstructorBuilder constructorBuilder = (ConstructorBuilder)fromNoninstanciated;
			if (this.ctors == null)
			{
				this.ctors = new Hashtable();
			}
			if (!this.ctors.ContainsKey(constructorBuilder))
			{
				this.ctors[constructorBuilder] = new ConstructorOnTypeBuilderInst(this, constructorBuilder);
			}
			return (ConstructorInfo)this.ctors[constructorBuilder];
		}

		// Token: 0x060013A6 RID: 5030 RVA: 0x0004DF84 File Offset: 0x0004C184
		internal override FieldInfo GetField(FieldInfo fromNoninstanciated)
		{
			this.initialize();
			if (!(fromNoninstanciated is FieldBuilder))
			{
				throw new InvalidOperationException("Inflating non FieldBuilder objects is not supported: " + fromNoninstanciated.GetType());
			}
			FieldBuilder fieldBuilder = (FieldBuilder)fromNoninstanciated;
			if (this.fields == null)
			{
				this.fields = new Hashtable();
			}
			if (!this.fields.ContainsKey(fieldBuilder))
			{
				this.fields[fieldBuilder] = new FieldOnTypeBuilderInst(this, fieldBuilder);
			}
			return (FieldInfo)this.fields[fieldBuilder];
		}

		// Token: 0x060013A7 RID: 5031 RVA: 0x0004E00C File Offset: 0x0004C20C
		public override MethodInfo[] GetMethods(BindingFlags bf)
		{
			if (!this.generic_type.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			ArrayList arrayList = new ArrayList();
			Type type = this;
			for (;;)
			{
				MonoGenericClass monoGenericClass = type as MonoGenericClass;
				if (monoGenericClass != null)
				{
					arrayList.AddRange(monoGenericClass.GetMethodsInternal(bf, this));
				}
				else
				{
					if (!(type is TypeBuilder))
					{
						break;
					}
					arrayList.AddRange(type.GetMethods(bf));
				}
				if ((bf & BindingFlags.DeclaredOnly) != BindingFlags.Default)
				{
					goto Block_4;
				}
				type = type.BaseType;
				if (type == null)
				{
					goto IL_0091;
				}
			}
			MonoType monoType = (MonoType)type;
			arrayList.AddRange(monoType.GetMethodsByName(null, bf, false, this));
			Block_4:
			IL_0091:
			MethodInfo[] array = new MethodInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013A8 RID: 5032 RVA: 0x0004E0C4 File Offset: 0x0004C2C4
		private MethodInfo[] GetMethodsInternal(BindingFlags bf, MonoGenericClass reftype)
		{
			if (this.generic_type.num_methods == 0)
			{
				return new MethodInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			this.initialize();
			for (int i = 0; i < this.generic_type.num_methods; i++)
			{
				MethodInfo methodInfo = this.generic_type.methods[i];
				bool flag = false;
				MethodAttributes attributes = methodInfo.Attributes;
				if ((attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
				{
					if ((bf & BindingFlags.Public) != BindingFlags.Default)
					{
						flag = true;
					}
				}
				else if ((bf & BindingFlags.NonPublic) != BindingFlags.Default)
				{
					flag = true;
				}
				if (flag)
				{
					flag = false;
					if ((attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
					{
						if ((bf & BindingFlags.Static) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bf & BindingFlags.Instance) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						methodInfo = TypeBuilder.GetMethod(this, methodInfo);
						arrayList.Add(methodInfo);
					}
				}
			}
			MethodInfo[] array = new MethodInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013A9 RID: 5033 RVA: 0x0004E1B8 File Offset: 0x0004C3B8
		public override ConstructorInfo[] GetConstructors(BindingFlags bf)
		{
			if (!this.generic_type.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			ArrayList arrayList = new ArrayList();
			Type type = this;
			for (;;)
			{
				MonoGenericClass monoGenericClass = type as MonoGenericClass;
				if (monoGenericClass != null)
				{
					arrayList.AddRange(monoGenericClass.GetConstructorsInternal(bf, this));
				}
				else
				{
					if (!(type is TypeBuilder))
					{
						break;
					}
					arrayList.AddRange(type.GetConstructors(bf));
				}
				if ((bf & BindingFlags.DeclaredOnly) != BindingFlags.Default)
				{
					goto Block_4;
				}
				type = type.BaseType;
				if (type == null)
				{
					goto IL_008F;
				}
			}
			MonoType monoType = (MonoType)type;
			arrayList.AddRange(monoType.GetConstructors_internal(bf, this));
			Block_4:
			IL_008F:
			ConstructorInfo[] array = new ConstructorInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013AA RID: 5034 RVA: 0x0004E26C File Offset: 0x0004C46C
		private ConstructorInfo[] GetConstructorsInternal(BindingFlags bf, MonoGenericClass reftype)
		{
			if (this.generic_type.ctors == null)
			{
				return new ConstructorInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			this.initialize();
			for (int i = 0; i < this.generic_type.ctors.Length; i++)
			{
				ConstructorInfo constructorInfo = this.generic_type.ctors[i];
				bool flag = false;
				MethodAttributes attributes = constructorInfo.Attributes;
				if ((attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
				{
					if ((bf & BindingFlags.Public) != BindingFlags.Default)
					{
						flag = true;
					}
				}
				else if ((bf & BindingFlags.NonPublic) != BindingFlags.Default)
				{
					flag = true;
				}
				if (flag)
				{
					flag = false;
					if ((attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
					{
						if ((bf & BindingFlags.Static) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bf & BindingFlags.Instance) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						arrayList.Add(TypeBuilder.GetConstructor(this, constructorInfo));
					}
				}
			}
			ConstructorInfo[] array = new ConstructorInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013AB RID: 5035 RVA: 0x0004E358 File Offset: 0x0004C558
		public override FieldInfo[] GetFields(BindingFlags bf)
		{
			if (!this.generic_type.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			ArrayList arrayList = new ArrayList();
			Type type = this;
			for (;;)
			{
				MonoGenericClass monoGenericClass = type as MonoGenericClass;
				if (monoGenericClass != null)
				{
					arrayList.AddRange(monoGenericClass.GetFieldsInternal(bf, this));
				}
				else
				{
					if (!(type is TypeBuilder))
					{
						break;
					}
					arrayList.AddRange(type.GetFields(bf));
				}
				if ((bf & BindingFlags.DeclaredOnly) != BindingFlags.Default)
				{
					goto Block_4;
				}
				type = type.BaseType;
				if (type == null)
				{
					goto IL_008F;
				}
			}
			MonoType monoType = (MonoType)type;
			arrayList.AddRange(monoType.GetFields_internal(bf, this));
			Block_4:
			IL_008F:
			FieldInfo[] array = new FieldInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013AC RID: 5036 RVA: 0x0004E40C File Offset: 0x0004C60C
		private FieldInfo[] GetFieldsInternal(BindingFlags bf, MonoGenericClass reftype)
		{
			if (this.generic_type.num_fields == 0)
			{
				return new FieldInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			this.initialize();
			for (int i = 0; i < this.generic_type.num_fields; i++)
			{
				FieldInfo fieldInfo = this.generic_type.fields[i];
				bool flag = false;
				FieldAttributes attributes = fieldInfo.Attributes;
				if ((attributes & FieldAttributes.FieldAccessMask) == FieldAttributes.Public)
				{
					if ((bf & BindingFlags.Public) != BindingFlags.Default)
					{
						flag = true;
					}
				}
				else if ((bf & BindingFlags.NonPublic) != BindingFlags.Default)
				{
					flag = true;
				}
				if (flag)
				{
					flag = false;
					if ((attributes & FieldAttributes.Static) != FieldAttributes.PrivateScope)
					{
						if ((bf & BindingFlags.Static) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bf & BindingFlags.Instance) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						arrayList.Add(TypeBuilder.GetField(this, fieldInfo));
					}
				}
			}
			FieldInfo[] array = new FieldInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013AD RID: 5037 RVA: 0x0004E4F8 File Offset: 0x0004C6F8
		public override PropertyInfo[] GetProperties(BindingFlags bf)
		{
			if (!this.generic_type.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			ArrayList arrayList = new ArrayList();
			Type type = this;
			for (;;)
			{
				MonoGenericClass monoGenericClass = type as MonoGenericClass;
				if (monoGenericClass != null)
				{
					arrayList.AddRange(monoGenericClass.GetPropertiesInternal(bf, this));
				}
				else
				{
					if (!(type is TypeBuilder))
					{
						break;
					}
					arrayList.AddRange(type.GetProperties(bf));
				}
				if ((bf & BindingFlags.DeclaredOnly) != BindingFlags.Default)
				{
					goto Block_4;
				}
				type = type.BaseType;
				if (type == null)
				{
					goto IL_0091;
				}
			}
			MonoType monoType = (MonoType)type;
			arrayList.AddRange(monoType.GetPropertiesByName(null, bf, false, this));
			Block_4:
			IL_0091:
			PropertyInfo[] array = new PropertyInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013AE RID: 5038 RVA: 0x0004E5B0 File Offset: 0x0004C7B0
		private PropertyInfo[] GetPropertiesInternal(BindingFlags bf, MonoGenericClass reftype)
		{
			if (this.generic_type.properties == null)
			{
				return new PropertyInfo[0];
			}
			ArrayList arrayList = new ArrayList();
			this.initialize();
			foreach (PropertyBuilder propertyInfo in this.generic_type.properties)
			{
				bool flag = false;
				MethodInfo methodInfo = propertyInfo.GetGetMethod(true);
				if (methodInfo == null)
				{
					methodInfo = propertyInfo.GetSetMethod(true);
				}
				if (methodInfo != null)
				{
					MethodAttributes attributes = methodInfo.Attributes;
					if ((attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
					{
						if ((bf & BindingFlags.Public) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bf & BindingFlags.NonPublic) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						flag = false;
						if ((attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
						{
							if ((bf & BindingFlags.Static) != BindingFlags.Default)
							{
								flag = true;
							}
						}
						else if ((bf & BindingFlags.Instance) != BindingFlags.Default)
						{
							flag = true;
						}
						if (flag)
						{
							arrayList.Add(new PropertyOnTypeBuilderInst(reftype, propertyInfo));
						}
					}
				}
			}
			PropertyInfo[] array = new PropertyInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013AF RID: 5039 RVA: 0x0004E6C0 File Offset: 0x0004C8C0
		public override EventInfo[] GetEvents(BindingFlags bf)
		{
			if (!this.generic_type.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			ArrayList arrayList = new ArrayList();
			Type type = this;
			for (;;)
			{
				MonoGenericClass monoGenericClass = type as MonoGenericClass;
				if (monoGenericClass != null)
				{
					arrayList.AddRange(monoGenericClass.GetEventsInternal(bf, this));
				}
				else
				{
					if (!(type is TypeBuilder))
					{
						break;
					}
					arrayList.AddRange(type.GetEvents(bf));
				}
				if ((bf & BindingFlags.DeclaredOnly) != BindingFlags.Default)
				{
					goto Block_4;
				}
				type = type.BaseType;
				if (type == null)
				{
					goto IL_008E;
				}
			}
			MonoType monoType = (MonoType)type;
			arrayList.AddRange(monoType.GetEvents(bf));
			Block_4:
			IL_008E:
			EventInfo[] array = new EventInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013B0 RID: 5040 RVA: 0x0004E774 File Offset: 0x0004C974
		private EventInfo[] GetEventsInternal(BindingFlags bf, MonoGenericClass reftype)
		{
			if (this.generic_type.events == null)
			{
				return new EventInfo[0];
			}
			this.initialize();
			ArrayList arrayList = new ArrayList();
			for (int i = 0; i < this.event_count; i++)
			{
				EventBuilder eventBuilder = this.generic_type.events[i];
				bool flag = false;
				MethodInfo methodInfo = eventBuilder.add_method;
				if (methodInfo == null)
				{
					methodInfo = eventBuilder.remove_method;
				}
				if (methodInfo != null)
				{
					MethodAttributes attributes = methodInfo.Attributes;
					if ((attributes & MethodAttributes.MemberAccessMask) == MethodAttributes.Public)
					{
						if ((bf & BindingFlags.Public) != BindingFlags.Default)
						{
							flag = true;
						}
					}
					else if ((bf & BindingFlags.NonPublic) != BindingFlags.Default)
					{
						flag = true;
					}
					if (flag)
					{
						flag = false;
						if ((attributes & MethodAttributes.Static) != MethodAttributes.PrivateScope)
						{
							if ((bf & BindingFlags.Static) != BindingFlags.Default)
							{
								flag = true;
							}
						}
						else if ((bf & BindingFlags.Instance) != BindingFlags.Default)
						{
							flag = true;
						}
						if (flag)
						{
							arrayList.Add(new EventOnTypeBuilderInst(this, eventBuilder));
						}
					}
				}
			}
			EventInfo[] array = new EventInfo[arrayList.Count];
			arrayList.CopyTo(array);
			return array;
		}

		// Token: 0x060013B1 RID: 5041 RVA: 0x0004E880 File Offset: 0x0004CA80
		public override Type[] GetNestedTypes(BindingFlags bf)
		{
			return this.generic_type.GetNestedTypes(bf);
		}

		// Token: 0x060013B2 RID: 5042 RVA: 0x0004E890 File Offset: 0x0004CA90
		public override bool IsAssignableFrom(Type c)
		{
			if (c == this)
			{
				return true;
			}
			Type[] interfacesInternal = this.GetInterfacesInternal();
			if (c.IsInterface)
			{
				if (interfacesInternal == null)
				{
					return false;
				}
				foreach (Type type in interfacesInternal)
				{
					if (c.IsAssignableFrom(type))
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				Type parentType = this.GetParentType();
				if (parentType == null)
				{
					return c == typeof(object);
				}
				return c.IsAssignableFrom(parentType);
			}
		}

		// Token: 0x1700034D RID: 845
		// (get) Token: 0x060013B3 RID: 5043 RVA: 0x0004E910 File Offset: 0x0004CB10
		public override Type UnderlyingSystemType
		{
			get
			{
				return this;
			}
		}

		// Token: 0x1700034E RID: 846
		// (get) Token: 0x060013B4 RID: 5044 RVA: 0x0004E914 File Offset: 0x0004CB14
		public override string Name
		{
			get
			{
				return this.generic_type.Name;
			}
		}

		// Token: 0x1700034F RID: 847
		// (get) Token: 0x060013B5 RID: 5045 RVA: 0x0004E924 File Offset: 0x0004CB24
		public override string Namespace
		{
			get
			{
				return this.generic_type.Namespace;
			}
		}

		// Token: 0x17000350 RID: 848
		// (get) Token: 0x060013B6 RID: 5046 RVA: 0x0004E934 File Offset: 0x0004CB34
		public override string FullName
		{
			get
			{
				return this.format_name(true, false);
			}
		}

		// Token: 0x17000351 RID: 849
		// (get) Token: 0x060013B7 RID: 5047 RVA: 0x0004E940 File Offset: 0x0004CB40
		public override string AssemblyQualifiedName
		{
			get
			{
				return this.format_name(true, true);
			}
		}

		// Token: 0x17000352 RID: 850
		// (get) Token: 0x060013B8 RID: 5048 RVA: 0x0004E94C File Offset: 0x0004CB4C
		public override Guid GUID
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x060013B9 RID: 5049 RVA: 0x0004E954 File Offset: 0x0004CB54
		private string format_name(bool full_name, bool assembly_qualified)
		{
			StringBuilder stringBuilder = new StringBuilder(this.generic_type.FullName);
			bool isCompilerContext = this.generic_type.IsCompilerContext;
			stringBuilder.Append("[");
			for (int i = 0; i < this.type_arguments.Length; i++)
			{
				if (i > 0)
				{
					stringBuilder.Append(",");
				}
				string text = ((!full_name) ? this.type_arguments[i].ToString() : this.type_arguments[i].AssemblyQualifiedName);
				if (text == null)
				{
					if (!isCompilerContext || !this.type_arguments[i].IsGenericParameter)
					{
						return null;
					}
					text = this.type_arguments[i].Name;
				}
				if (full_name)
				{
					stringBuilder.Append("[");
				}
				stringBuilder.Append(text);
				if (full_name)
				{
					stringBuilder.Append("]");
				}
			}
			stringBuilder.Append("]");
			if (assembly_qualified)
			{
				stringBuilder.Append(", ");
				stringBuilder.Append(this.generic_type.Assembly.FullName);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060013BA RID: 5050 RVA: 0x0004EA78 File Offset: 0x0004CC78
		public override string ToString()
		{
			return this.format_name(false, false);
		}

		// Token: 0x060013BB RID: 5051 RVA: 0x0004EA84 File Offset: 0x0004CC84
		public override Type MakeArrayType()
		{
			return new ArrayType(this, 0);
		}

		// Token: 0x060013BC RID: 5052 RVA: 0x0004EA90 File Offset: 0x0004CC90
		public override Type MakeArrayType(int rank)
		{
			if (rank < 1)
			{
				throw new IndexOutOfRangeException();
			}
			return new ArrayType(this, rank);
		}

		// Token: 0x060013BD RID: 5053 RVA: 0x0004EAA8 File Offset: 0x0004CCA8
		public override Type MakeByRefType()
		{
			return new ByRefType(this);
		}

		// Token: 0x060013BE RID: 5054 RVA: 0x0004EAB0 File Offset: 0x0004CCB0
		public override Type MakePointerType()
		{
			return new PointerType(this);
		}

		// Token: 0x060013BF RID: 5055 RVA: 0x0004EAB8 File Offset: 0x0004CCB8
		protected override bool IsPrimitiveImpl()
		{
			return false;
		}

		// Token: 0x060013C0 RID: 5056 RVA: 0x0004EABC File Offset: 0x0004CCBC
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			return this.generic_type.Attributes;
		}

		// Token: 0x060013C1 RID: 5057 RVA: 0x0004EACC File Offset: 0x0004CCCC
		public override EventInfo GetEvent(string name, BindingFlags bindingAttr)
		{
			if (!this.generic_type.IsCompilerContext)
			{
				throw new NotSupportedException();
			}
			foreach (EventInfo eventInfo in this.GetEvents(bindingAttr))
			{
				if (eventInfo.Name == name)
				{
					return eventInfo;
				}
			}
			return null;
		}

		// Token: 0x060013C2 RID: 5058 RVA: 0x0004EB24 File Offset: 0x0004CD24
		public override FieldInfo GetField(string name, BindingFlags bindingAttr)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060013C3 RID: 5059 RVA: 0x0004EB2C File Offset: 0x0004CD2C
		public override object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060013C4 RID: 5060 RVA: 0x0004EB34 File Offset: 0x0004CD34
		protected override MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060013C5 RID: 5061 RVA: 0x0004EB3C File Offset: 0x0004CD3C
		protected override PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060013C6 RID: 5062 RVA: 0x0004EB44 File Offset: 0x0004CD44
		protected override ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060013C7 RID: 5063 RVA: 0x0004EB4C File Offset: 0x0004CD4C
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060013C8 RID: 5064 RVA: 0x0004EB54 File Offset: 0x0004CD54
		public override object[] GetCustomAttributes(bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060013C9 RID: 5065 RVA: 0x0004EB5C File Offset: 0x0004CD5C
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			throw new NotSupportedException();
		}

		// Token: 0x040009D7 RID: 2519
		private const BindingFlags flags = BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

		// Token: 0x040009D8 RID: 2520
		internal TypeBuilder generic_type;

		// Token: 0x040009D9 RID: 2521
		private Type[] type_arguments;

		// Token: 0x040009DA RID: 2522
		private bool initialized;

		// Token: 0x040009DB RID: 2523
		private Hashtable fields;

		// Token: 0x040009DC RID: 2524
		private Hashtable ctors;

		// Token: 0x040009DD RID: 2525
		private Hashtable methods;

		// Token: 0x040009DE RID: 2526
		private int event_count;
	}
}
