﻿using System;
using System.Runtime.CompilerServices;

namespace System.Reflection
{
	// Token: 0x0200020E RID: 526
	[Serializable]
	internal class MonoGenericMethod : MonoMethod
	{
		// Token: 0x060013CC RID: 5068 RVA: 0x0004EB74 File Offset: 0x0004CD74
		internal MonoGenericMethod()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x17000354 RID: 852
		// (get) Token: 0x060013CD RID: 5069
		public override extern Type ReflectedType
		{
			[MethodImpl(4096)]
			get;
		}
	}
}
