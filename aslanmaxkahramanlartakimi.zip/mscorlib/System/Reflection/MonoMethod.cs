﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;

namespace System.Reflection
{
	// Token: 0x0200020F RID: 527
	[Serializable]
	internal class MonoMethod : MethodInfo, ISerializable
	{
		// Token: 0x060013CE RID: 5070 RVA: 0x0004EB84 File Offset: 0x0004CD84
		internal MonoMethod()
		{
		}

		// Token: 0x060013CF RID: 5071 RVA: 0x0004EB8C File Offset: 0x0004CD8C
		internal MonoMethod(RuntimeMethodHandle mhandle)
		{
			this.mhandle = mhandle.Value;
		}

		// Token: 0x060013D0 RID: 5072
		[MethodImpl(4096)]
		internal static extern string get_name(MethodBase method);

		// Token: 0x060013D1 RID: 5073
		[MethodImpl(4096)]
		internal static extern MonoMethod get_base_definition(MonoMethod method);

		// Token: 0x060013D2 RID: 5074 RVA: 0x0004EBA4 File Offset: 0x0004CDA4
		public override MethodInfo GetBaseDefinition()
		{
			return MonoMethod.get_base_definition(this);
		}

		// Token: 0x17000355 RID: 853
		// (get) Token: 0x060013D3 RID: 5075 RVA: 0x0004EBAC File Offset: 0x0004CDAC
		public override Type ReturnType
		{
			get
			{
				return MonoMethodInfo.GetReturnType(this.mhandle);
			}
		}

		// Token: 0x060013D4 RID: 5076 RVA: 0x0004EBBC File Offset: 0x0004CDBC
		public override MethodImplAttributes GetMethodImplementationFlags()
		{
			return MonoMethodInfo.GetMethodImplementationFlags(this.mhandle);
		}

		// Token: 0x060013D5 RID: 5077 RVA: 0x0004EBCC File Offset: 0x0004CDCC
		public override ParameterInfo[] GetParameters()
		{
			ParameterInfo[] parametersInfo = MonoMethodInfo.GetParametersInfo(this.mhandle, this);
			ParameterInfo[] array = new ParameterInfo[parametersInfo.Length];
			parametersInfo.CopyTo(array, 0);
			return array;
		}

		// Token: 0x060013D6 RID: 5078
		[MethodImpl(4096)]
		internal extern object InternalInvoke(object obj, object[] parameters, out Exception exc);

		// Token: 0x060013D7 RID: 5079 RVA: 0x0004EBF8 File Offset: 0x0004CDF8
		public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
		{
			if (binder == null)
			{
				binder = Binder.DefaultBinder;
			}
			ParameterInfo[] parametersInfo = MonoMethodInfo.GetParametersInfo(this.mhandle, this);
			if ((parameters == null && parametersInfo.Length != 0) || (parameters != null && parameters.Length != parametersInfo.Length))
			{
				throw new TargetParameterCountException("parameters do not match signature");
			}
			if ((invokeAttr & BindingFlags.ExactBinding) == BindingFlags.Default)
			{
				if (!Binder.ConvertArgs(binder, parameters, parametersInfo, culture))
				{
					throw new ArgumentException("failed to convert parameters");
				}
			}
			else
			{
				for (int i = 0; i < parametersInfo.Length; i++)
				{
					if (parameters[i].GetType() != parametersInfo[i].ParameterType)
					{
						throw new ArgumentException("parameters do not match signature");
					}
				}
			}
			if (this.ContainsGenericParameters)
			{
				throw new InvalidOperationException("Late bound operations cannot be performed on types or methods for which ContainsGenericParameters is true.");
			}
			object obj2 = null;
			Exception ex;
			try
			{
				obj2 = this.InternalInvoke(obj, parameters, out ex);
			}
			catch (ThreadAbortException)
			{
				throw;
			}
			catch (MethodAccessException)
			{
				throw;
			}
			catch (Exception ex2)
			{
				throw new TargetInvocationException(ex2);
			}
			if (ex != null)
			{
				throw ex;
			}
			return obj2;
		}

		// Token: 0x17000356 RID: 854
		// (get) Token: 0x060013D8 RID: 5080 RVA: 0x0004ED28 File Offset: 0x0004CF28
		public override RuntimeMethodHandle MethodHandle
		{
			get
			{
				return new RuntimeMethodHandle(this.mhandle);
			}
		}

		// Token: 0x17000357 RID: 855
		// (get) Token: 0x060013D9 RID: 5081 RVA: 0x0004ED38 File Offset: 0x0004CF38
		public override MethodAttributes Attributes
		{
			get
			{
				return MonoMethodInfo.GetAttributes(this.mhandle);
			}
		}

		// Token: 0x17000358 RID: 856
		// (get) Token: 0x060013DA RID: 5082 RVA: 0x0004ED48 File Offset: 0x0004CF48
		public override CallingConventions CallingConvention
		{
			get
			{
				return MonoMethodInfo.GetCallingConvention(this.mhandle);
			}
		}

		// Token: 0x17000359 RID: 857
		// (get) Token: 0x060013DB RID: 5083 RVA: 0x0004ED58 File Offset: 0x0004CF58
		public override Type ReflectedType
		{
			get
			{
				return this.reftype;
			}
		}

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x060013DC RID: 5084 RVA: 0x0004ED60 File Offset: 0x0004CF60
		public override Type DeclaringType
		{
			get
			{
				return MonoMethodInfo.GetDeclaringType(this.mhandle);
			}
		}

		// Token: 0x1700035B RID: 859
		// (get) Token: 0x060013DD RID: 5085 RVA: 0x0004ED70 File Offset: 0x0004CF70
		public override string Name
		{
			get
			{
				if (this.name != null)
				{
					return this.name;
				}
				return MonoMethod.get_name(this);
			}
		}

		// Token: 0x060013DE RID: 5086 RVA: 0x0004ED8C File Offset: 0x0004CF8C
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x060013DF RID: 5087 RVA: 0x0004ED98 File Offset: 0x0004CF98
		public override object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x060013E0 RID: 5088 RVA: 0x0004EDA4 File Offset: 0x0004CFA4
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x060013E1 RID: 5089
		[MethodImpl(4096)]
		internal static extern DllImportAttribute GetDllImportAttribute(IntPtr mhandle);

		// Token: 0x060013E2 RID: 5090 RVA: 0x0004EDB0 File Offset: 0x0004CFB0
		internal object[] GetPseudoCustomAttributes()
		{
			int num = 0;
			MonoMethodInfo methodInfo = MonoMethodInfo.GetMethodInfo(this.mhandle);
			if ((methodInfo.iattrs & MethodImplAttributes.PreserveSig) != MethodImplAttributes.IL)
			{
				num++;
			}
			if ((methodInfo.attrs & MethodAttributes.PinvokeImpl) != MethodAttributes.PrivateScope)
			{
				num++;
			}
			if (num == 0)
			{
				return null;
			}
			object[] array = new object[num];
			num = 0;
			if ((methodInfo.iattrs & MethodImplAttributes.PreserveSig) != MethodImplAttributes.IL)
			{
				array[num++] = new PreserveSigAttribute();
			}
			if ((methodInfo.attrs & MethodAttributes.PinvokeImpl) != MethodAttributes.PrivateScope)
			{
				DllImportAttribute dllImportAttribute = MonoMethod.GetDllImportAttribute(this.mhandle);
				if ((methodInfo.iattrs & MethodImplAttributes.PreserveSig) != MethodImplAttributes.IL)
				{
					dllImportAttribute.PreserveSig = true;
				}
				array[num++] = dllImportAttribute;
			}
			return array;
		}

		// Token: 0x060013E3 RID: 5091 RVA: 0x0004EE68 File Offset: 0x0004D068
		private static bool ShouldPrintFullName(Type type)
		{
			return type.IsClass && (!type.IsPointer || (!type.GetElementType().IsPrimitive && !type.GetElementType().IsNested));
		}

		// Token: 0x060013E4 RID: 5092 RVA: 0x0004EEA8 File Offset: 0x0004D0A8
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			Type returnType = this.ReturnType;
			if (MonoMethod.ShouldPrintFullName(returnType))
			{
				stringBuilder.Append(returnType.ToString());
			}
			else
			{
				stringBuilder.Append(returnType.Name);
			}
			stringBuilder.Append(" ");
			stringBuilder.Append(this.Name);
			if (this.IsGenericMethod)
			{
				Type[] genericArguments = this.GetGenericArguments();
				stringBuilder.Append("[");
				for (int i = 0; i < genericArguments.Length; i++)
				{
					if (i > 0)
					{
						stringBuilder.Append(",");
					}
					stringBuilder.Append(genericArguments[i].Name);
				}
				stringBuilder.Append("]");
			}
			stringBuilder.Append("(");
			ParameterInfo[] parameters = this.GetParameters();
			for (int j = 0; j < parameters.Length; j++)
			{
				if (j > 0)
				{
					stringBuilder.Append(", ");
				}
				Type type = parameters[j].ParameterType;
				bool isByRef = type.IsByRef;
				if (isByRef)
				{
					type = type.GetElementType();
				}
				if (MonoMethod.ShouldPrintFullName(type))
				{
					stringBuilder.Append(type.ToString());
				}
				else
				{
					stringBuilder.Append(type.Name);
				}
				if (isByRef)
				{
					stringBuilder.Append(" ByRef");
				}
			}
			if ((this.CallingConvention & CallingConventions.VarArgs) != (CallingConventions)0)
			{
				if (parameters.Length > 0)
				{
					stringBuilder.Append(", ");
				}
				stringBuilder.Append("...");
			}
			stringBuilder.Append(")");
			return stringBuilder.ToString();
		}

		// Token: 0x060013E5 RID: 5093 RVA: 0x0004F04C File Offset: 0x0004D24C
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			Type[] array = ((!this.IsGenericMethod || this.IsGenericMethodDefinition) ? null : this.GetGenericArguments());
			MemberInfoSerializationHolder.Serialize(info, this.Name, this.ReflectedType, this.ToString(), MemberTypes.Method, array);
		}

		// Token: 0x060013E6 RID: 5094 RVA: 0x0004F098 File Offset: 0x0004D298
		public override MethodInfo MakeGenericMethod(Type[] methodInstantiation)
		{
			if (methodInstantiation == null)
			{
				throw new ArgumentNullException("methodInstantiation");
			}
			for (int i = 0; i < methodInstantiation.Length; i++)
			{
				if (methodInstantiation[i] == null)
				{
					throw new ArgumentNullException();
				}
			}
			MethodInfo methodInfo = this.MakeGenericMethod_impl(methodInstantiation);
			if (methodInfo == null)
			{
				throw new ArgumentException(string.Format("The method has {0} generic parameter(s) but {1} generic argument(s) were provided.", this.GetGenericArguments().Length, methodInstantiation.Length));
			}
			return methodInfo;
		}

		// Token: 0x060013E7 RID: 5095
		[MethodImpl(4096)]
		private extern MethodInfo MakeGenericMethod_impl(Type[] types);

		// Token: 0x060013E8 RID: 5096
		[MethodImpl(4096)]
		public override extern Type[] GetGenericArguments();

		// Token: 0x060013E9 RID: 5097
		[MethodImpl(4096)]
		private extern MethodInfo GetGenericMethodDefinition_impl();

		// Token: 0x060013EA RID: 5098 RVA: 0x0004F110 File Offset: 0x0004D310
		public override MethodInfo GetGenericMethodDefinition()
		{
			MethodInfo genericMethodDefinition_impl = this.GetGenericMethodDefinition_impl();
			if (genericMethodDefinition_impl == null)
			{
				throw new InvalidOperationException();
			}
			return genericMethodDefinition_impl;
		}

		// Token: 0x1700035C RID: 860
		// (get) Token: 0x060013EB RID: 5099
		public override extern bool IsGenericMethodDefinition
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700035D RID: 861
		// (get) Token: 0x060013EC RID: 5100
		public override extern bool IsGenericMethod
		{
			[MethodImpl(4096)]
			get;
		}

		// Token: 0x1700035E RID: 862
		// (get) Token: 0x060013ED RID: 5101 RVA: 0x0004F134 File Offset: 0x0004D334
		public override bool ContainsGenericParameters
		{
			get
			{
				if (this.IsGenericMethod)
				{
					foreach (Type type in this.GetGenericArguments())
					{
						if (type.ContainsGenericParameters)
						{
							return true;
						}
					}
				}
				return this.DeclaringType.ContainsGenericParameters;
			}
		}

		// Token: 0x040009DF RID: 2527
		internal IntPtr mhandle;

		// Token: 0x040009E0 RID: 2528
		private string name;

		// Token: 0x040009E1 RID: 2529
		private Type reftype;
	}
}
