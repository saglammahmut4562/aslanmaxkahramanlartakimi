﻿using System;
using System.Runtime.CompilerServices;

namespace System.Reflection
{
	// Token: 0x02000210 RID: 528
	internal struct MonoMethodInfo
	{
		// Token: 0x060013EE RID: 5102
		[MethodImpl(4096)]
		private static extern void get_method_info(IntPtr handle, out MonoMethodInfo info);

		// Token: 0x060013EF RID: 5103 RVA: 0x0004F184 File Offset: 0x0004D384
		internal static MonoMethodInfo GetMethodInfo(IntPtr handle)
		{
			MonoMethodInfo monoMethodInfo;
			MonoMethodInfo.get_method_info(handle, out monoMethodInfo);
			return monoMethodInfo;
		}

		// Token: 0x060013F0 RID: 5104 RVA: 0x0004F19C File Offset: 0x0004D39C
		internal static Type GetDeclaringType(IntPtr handle)
		{
			return MonoMethodInfo.GetMethodInfo(handle).parent;
		}

		// Token: 0x060013F1 RID: 5105 RVA: 0x0004F1B8 File Offset: 0x0004D3B8
		internal static Type GetReturnType(IntPtr handle)
		{
			return MonoMethodInfo.GetMethodInfo(handle).ret;
		}

		// Token: 0x060013F2 RID: 5106 RVA: 0x0004F1D4 File Offset: 0x0004D3D4
		internal static MethodAttributes GetAttributes(IntPtr handle)
		{
			return MonoMethodInfo.GetMethodInfo(handle).attrs;
		}

		// Token: 0x060013F3 RID: 5107 RVA: 0x0004F1F0 File Offset: 0x0004D3F0
		internal static CallingConventions GetCallingConvention(IntPtr handle)
		{
			return MonoMethodInfo.GetMethodInfo(handle).callconv;
		}

		// Token: 0x060013F4 RID: 5108 RVA: 0x0004F20C File Offset: 0x0004D40C
		internal static MethodImplAttributes GetMethodImplementationFlags(IntPtr handle)
		{
			return MonoMethodInfo.GetMethodInfo(handle).iattrs;
		}

		// Token: 0x060013F5 RID: 5109
		[MethodImpl(4096)]
		private static extern ParameterInfo[] get_parameter_info(IntPtr handle, MemberInfo member);

		// Token: 0x060013F6 RID: 5110 RVA: 0x0004F228 File Offset: 0x0004D428
		internal static ParameterInfo[] GetParametersInfo(IntPtr handle, MemberInfo member)
		{
			return MonoMethodInfo.get_parameter_info(handle, member);
		}

		// Token: 0x040009E2 RID: 2530
		private Type parent;

		// Token: 0x040009E3 RID: 2531
		private Type ret;

		// Token: 0x040009E4 RID: 2532
		internal MethodAttributes attrs;

		// Token: 0x040009E5 RID: 2533
		internal MethodImplAttributes iattrs;

		// Token: 0x040009E6 RID: 2534
		private CallingConventions callconv;
	}
}
