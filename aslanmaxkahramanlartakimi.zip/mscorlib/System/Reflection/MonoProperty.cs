﻿using System;
using System.Globalization;
using System.Runtime.Serialization;
using System.Security;

namespace System.Reflection
{
	// Token: 0x02000211 RID: 529
	[Serializable]
	internal class MonoProperty : PropertyInfo, ISerializable
	{
		// Token: 0x060013F8 RID: 5112 RVA: 0x0004F23C File Offset: 0x0004D43C
		private void CachePropertyInfo(PInfo flags)
		{
			if ((this.cached & flags) != flags)
			{
				MonoPropertyInfo.get_property_info(this, ref this.info, flags);
				this.cached |= flags;
			}
		}

		// Token: 0x1700035F RID: 863
		// (get) Token: 0x060013F9 RID: 5113 RVA: 0x0004F268 File Offset: 0x0004D468
		public override PropertyAttributes Attributes
		{
			get
			{
				this.CachePropertyInfo(PInfo.Attributes);
				return this.info.attrs;
			}
		}

		// Token: 0x17000360 RID: 864
		// (get) Token: 0x060013FA RID: 5114 RVA: 0x0004F27C File Offset: 0x0004D47C
		public override bool CanRead
		{
			get
			{
				this.CachePropertyInfo(PInfo.GetMethod);
				return this.info.get_method != null;
			}
		}

		// Token: 0x17000361 RID: 865
		// (get) Token: 0x060013FB RID: 5115 RVA: 0x0004F298 File Offset: 0x0004D498
		public override bool CanWrite
		{
			get
			{
				this.CachePropertyInfo(PInfo.SetMethod);
				return this.info.set_method != null;
			}
		}

		// Token: 0x17000362 RID: 866
		// (get) Token: 0x060013FC RID: 5116 RVA: 0x0004F2B4 File Offset: 0x0004D4B4
		public override Type PropertyType
		{
			get
			{
				this.CachePropertyInfo(PInfo.GetMethod | PInfo.SetMethod);
				if (this.info.get_method != null)
				{
					return this.info.get_method.ReturnType;
				}
				ParameterInfo[] parameters = this.info.set_method.GetParameters();
				return parameters[parameters.Length - 1].ParameterType;
			}
		}

		// Token: 0x17000363 RID: 867
		// (get) Token: 0x060013FD RID: 5117 RVA: 0x0004F308 File Offset: 0x0004D508
		public override Type ReflectedType
		{
			get
			{
				this.CachePropertyInfo(PInfo.ReflectedType);
				return this.info.parent;
			}
		}

		// Token: 0x17000364 RID: 868
		// (get) Token: 0x060013FE RID: 5118 RVA: 0x0004F31C File Offset: 0x0004D51C
		public override Type DeclaringType
		{
			get
			{
				this.CachePropertyInfo(PInfo.DeclaringType);
				return this.info.parent;
			}
		}

		// Token: 0x17000365 RID: 869
		// (get) Token: 0x060013FF RID: 5119 RVA: 0x0004F334 File Offset: 0x0004D534
		public override string Name
		{
			get
			{
				this.CachePropertyInfo(PInfo.Name);
				return this.info.name;
			}
		}

		// Token: 0x06001400 RID: 5120 RVA: 0x0004F34C File Offset: 0x0004D54C
		public override MethodInfo GetGetMethod(bool nonPublic)
		{
			this.CachePropertyInfo(PInfo.GetMethod);
			if (this.info.get_method != null && (nonPublic || this.info.get_method.IsPublic))
			{
				return this.info.get_method;
			}
			return null;
		}

		// Token: 0x06001401 RID: 5121 RVA: 0x0004F398 File Offset: 0x0004D598
		public override ParameterInfo[] GetIndexParameters()
		{
			this.CachePropertyInfo(PInfo.GetMethod | PInfo.SetMethod);
			ParameterInfo[] array;
			if (this.info.get_method != null)
			{
				array = this.info.get_method.GetParameters();
			}
			else
			{
				if (this.info.set_method == null)
				{
					return new ParameterInfo[0];
				}
				ParameterInfo[] parameters = this.info.set_method.GetParameters();
				array = new ParameterInfo[parameters.Length - 1];
				Array.Copy(parameters, array, array.Length);
			}
			for (int i = 0; i < array.Length; i++)
			{
				ParameterInfo parameterInfo = array[i];
				array[i] = new ParameterInfo(parameterInfo, this);
			}
			return array;
		}

		// Token: 0x06001402 RID: 5122 RVA: 0x0004F438 File Offset: 0x0004D638
		public override MethodInfo GetSetMethod(bool nonPublic)
		{
			this.CachePropertyInfo(PInfo.SetMethod);
			if (this.info.set_method != null && (nonPublic || this.info.set_method.IsPublic))
			{
				return this.info.set_method;
			}
			return null;
		}

		// Token: 0x06001403 RID: 5123 RVA: 0x0004F484 File Offset: 0x0004D684
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, false);
		}

		// Token: 0x06001404 RID: 5124 RVA: 0x0004F490 File Offset: 0x0004D690
		public override object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, false);
		}

		// Token: 0x06001405 RID: 5125 RVA: 0x0004F49C File Offset: 0x0004D69C
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, false);
		}

		// Token: 0x06001406 RID: 5126 RVA: 0x0004F4A8 File Offset: 0x0004D6A8
		public override object GetValue(object obj, object[] index)
		{
			if (index == null || index.Length == 0)
			{
			}
			return this.GetValue(obj, BindingFlags.Default, null, index, null);
		}

		// Token: 0x06001407 RID: 5127 RVA: 0x0004F4C4 File Offset: 0x0004D6C4
		public override object GetValue(object obj, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
		{
			object obj2 = null;
			MethodInfo getMethod = this.GetGetMethod(true);
			if (getMethod == null)
			{
				throw new ArgumentException("Get Method not found for '" + this.Name + "'");
			}
			try
			{
				if (index == null || index.Length == 0)
				{
					obj2 = getMethod.Invoke(obj, invokeAttr, binder, null, culture);
				}
				else
				{
					obj2 = getMethod.Invoke(obj, invokeAttr, binder, index, culture);
				}
			}
			catch (SecurityException ex)
			{
				throw new TargetInvocationException(ex);
			}
			return obj2;
		}

		// Token: 0x06001408 RID: 5128 RVA: 0x0004F550 File Offset: 0x0004D750
		public override void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
		{
			MethodInfo setMethod = this.GetSetMethod(true);
			if (setMethod == null)
			{
				throw new ArgumentException("Set Method not found for '" + this.Name + "'");
			}
			object[] array;
			if (index == null || index.Length == 0)
			{
				array = new object[] { value };
			}
			else
			{
				int num = index.Length;
				array = new object[num + 1];
				index.CopyTo(array, 0);
				array[num] = value;
			}
			setMethod.Invoke(obj, invokeAttr, binder, array, culture);
		}

		// Token: 0x06001409 RID: 5129 RVA: 0x0004F5D0 File Offset: 0x0004D7D0
		public override string ToString()
		{
			return this.PropertyType.ToString() + " " + this.Name;
		}

		// Token: 0x0600140A RID: 5130 RVA: 0x0004F5F0 File Offset: 0x0004D7F0
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			MemberInfoSerializationHolder.Serialize(info, this.Name, this.ReflectedType, this.ToString(), MemberTypes.Property);
		}

		// Token: 0x040009E7 RID: 2535
		internal IntPtr klass;

		// Token: 0x040009E8 RID: 2536
		internal IntPtr prop;

		// Token: 0x040009E9 RID: 2537
		private MonoPropertyInfo info;

		// Token: 0x040009EA RID: 2538
		private PInfo cached;

		// Token: 0x040009EB RID: 2539
		private MonoProperty.GetterAdapter cached_getter;

		// Token: 0x02000212 RID: 530
		// (Invoke) Token: 0x0600140C RID: 5132
		private delegate object GetterAdapter(object _this);
	}
}
