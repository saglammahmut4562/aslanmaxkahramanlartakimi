﻿using System;
using System.Runtime.CompilerServices;

namespace System.Reflection
{
	// Token: 0x02000213 RID: 531
	internal struct MonoPropertyInfo
	{
		// Token: 0x0600140F RID: 5135
		[MethodImpl(4096)]
		internal static extern void get_property_info(MonoProperty prop, ref MonoPropertyInfo info, PInfo req_info);

		// Token: 0x040009EC RID: 2540
		public Type parent;

		// Token: 0x040009ED RID: 2541
		public string name;

		// Token: 0x040009EE RID: 2542
		public MethodInfo get_method;

		// Token: 0x040009EF RID: 2543
		public MethodInfo set_method;

		// Token: 0x040009F0 RID: 2544
		public PropertyAttributes attrs;
	}
}
