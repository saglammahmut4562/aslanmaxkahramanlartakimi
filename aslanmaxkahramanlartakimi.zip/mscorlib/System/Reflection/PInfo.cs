﻿using System;

namespace System.Reflection
{
	// Token: 0x02000217 RID: 535
	[Flags]
	internal enum PInfo
	{
		// Token: 0x04000A06 RID: 2566
		Attributes = 1,
		// Token: 0x04000A07 RID: 2567
		GetMethod = 2,
		// Token: 0x04000A08 RID: 2568
		SetMethod = 4,
		// Token: 0x04000A09 RID: 2569
		ReflectedType = 8,
		// Token: 0x04000A0A RID: 2570
		DeclaringType = 16,
		// Token: 0x04000A0B RID: 2571
		Name = 32
	}
}
