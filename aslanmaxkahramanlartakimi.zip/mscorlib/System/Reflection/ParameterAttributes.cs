﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000214 RID: 532
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum ParameterAttributes
	{
		// Token: 0x040009F2 RID: 2546
		None = 0,
		// Token: 0x040009F3 RID: 2547
		In = 1,
		// Token: 0x040009F4 RID: 2548
		Out = 2,
		// Token: 0x040009F5 RID: 2549
		Lcid = 4,
		// Token: 0x040009F6 RID: 2550
		Retval = 8,
		// Token: 0x040009F7 RID: 2551
		Optional = 16,
		// Token: 0x040009F8 RID: 2552
		ReservedMask = 61440,
		// Token: 0x040009F9 RID: 2553
		HasDefault = 4096,
		// Token: 0x040009FA RID: 2554
		HasFieldMarshal = 8192,
		// Token: 0x040009FB RID: 2555
		Reserved3 = 16384,
		// Token: 0x040009FC RID: 2556
		Reserved4 = 32768
	}
}
