﻿using System;
using System.Reflection.Emit;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000215 RID: 533
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_ParameterInfo))]
	[Serializable]
	public class ParameterInfo : ICustomAttributeProvider, _ParameterInfo
	{
		// Token: 0x06001410 RID: 5136 RVA: 0x0004F60C File Offset: 0x0004D80C
		protected ParameterInfo()
		{
		}

		// Token: 0x06001411 RID: 5137 RVA: 0x0004F614 File Offset: 0x0004D814
		internal ParameterInfo(ParameterBuilder pb, Type type, MemberInfo member, int position)
		{
			this.ClassImpl = type;
			this.MemberImpl = member;
			if (pb != null)
			{
				this.NameImpl = pb.Name;
				this.PositionImpl = pb.Position - 1;
				this.AttrsImpl = (ParameterAttributes)pb.Attributes;
			}
			else
			{
				this.NameImpl = null;
				this.PositionImpl = position - 1;
				this.AttrsImpl = ParameterAttributes.None;
			}
		}

		// Token: 0x06001412 RID: 5138 RVA: 0x0004F680 File Offset: 0x0004D880
		internal ParameterInfo(ParameterInfo pinfo, MemberInfo member)
		{
			this.ClassImpl = pinfo.ParameterType;
			this.MemberImpl = member;
			this.NameImpl = pinfo.Name;
			this.PositionImpl = pinfo.Position;
			this.AttrsImpl = pinfo.Attributes;
		}

		// Token: 0x06001413 RID: 5139 RVA: 0x0004F6C0 File Offset: 0x0004D8C0
		public override string ToString()
		{
			Type type = this.ClassImpl;
			while (type.HasElementType)
			{
				type = type.GetElementType();
			}
			bool flag = type.IsPrimitive || this.ClassImpl == typeof(void) || this.ClassImpl.Namespace == this.MemberImpl.DeclaringType.Namespace;
			string text = ((!flag) ? this.ClassImpl.FullName : this.ClassImpl.Name);
			if (!this.IsRetval)
			{
				text += ' ';
				text += this.NameImpl;
			}
			return text;
		}

		// Token: 0x17000366 RID: 870
		// (get) Token: 0x06001414 RID: 5140 RVA: 0x0004F778 File Offset: 0x0004D978
		public virtual Type ParameterType
		{
			get
			{
				return this.ClassImpl;
			}
		}

		// Token: 0x17000367 RID: 871
		// (get) Token: 0x06001415 RID: 5141 RVA: 0x0004F780 File Offset: 0x0004D980
		public virtual ParameterAttributes Attributes
		{
			get
			{
				return this.AttrsImpl;
			}
		}

		// Token: 0x17000368 RID: 872
		// (get) Token: 0x06001416 RID: 5142 RVA: 0x0004F788 File Offset: 0x0004D988
		public bool IsIn
		{
			get
			{
				return (this.Attributes & ParameterAttributes.In) != ParameterAttributes.None;
			}
		}

		// Token: 0x17000369 RID: 873
		// (get) Token: 0x06001417 RID: 5143 RVA: 0x0004F798 File Offset: 0x0004D998
		public bool IsOptional
		{
			get
			{
				return (this.Attributes & ParameterAttributes.Optional) != ParameterAttributes.None;
			}
		}

		// Token: 0x1700036A RID: 874
		// (get) Token: 0x06001418 RID: 5144 RVA: 0x0004F7AC File Offset: 0x0004D9AC
		public bool IsOut
		{
			get
			{
				return (this.Attributes & ParameterAttributes.Out) != ParameterAttributes.None;
			}
		}

		// Token: 0x1700036B RID: 875
		// (get) Token: 0x06001419 RID: 5145 RVA: 0x0004F7BC File Offset: 0x0004D9BC
		public bool IsRetval
		{
			get
			{
				return (this.Attributes & ParameterAttributes.Retval) != ParameterAttributes.None;
			}
		}

		// Token: 0x1700036C RID: 876
		// (get) Token: 0x0600141A RID: 5146 RVA: 0x0004F7CC File Offset: 0x0004D9CC
		public virtual MemberInfo Member
		{
			get
			{
				return this.MemberImpl;
			}
		}

		// Token: 0x1700036D RID: 877
		// (get) Token: 0x0600141B RID: 5147 RVA: 0x0004F7D4 File Offset: 0x0004D9D4
		public virtual string Name
		{
			get
			{
				return this.NameImpl;
			}
		}

		// Token: 0x1700036E RID: 878
		// (get) Token: 0x0600141C RID: 5148 RVA: 0x0004F7DC File Offset: 0x0004D9DC
		public virtual int Position
		{
			get
			{
				return this.PositionImpl;
			}
		}

		// Token: 0x0600141D RID: 5149 RVA: 0x0004F7E4 File Offset: 0x0004D9E4
		public virtual object[] GetCustomAttributes(bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, inherit);
		}

		// Token: 0x0600141E RID: 5150 RVA: 0x0004F7F0 File Offset: 0x0004D9F0
		public virtual object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.GetCustomAttributes(this, attributeType, inherit);
		}

		// Token: 0x0600141F RID: 5151 RVA: 0x0004F7FC File Offset: 0x0004D9FC
		public virtual bool IsDefined(Type attributeType, bool inherit)
		{
			return MonoCustomAttrs.IsDefined(this, attributeType, inherit);
		}

		// Token: 0x06001420 RID: 5152 RVA: 0x0004F808 File Offset: 0x0004DA08
		internal object[] GetPseudoCustomAttributes()
		{
			int num = 0;
			if (this.IsIn)
			{
				num++;
			}
			if (this.IsOut)
			{
				num++;
			}
			if (this.IsOptional)
			{
				num++;
			}
			if (this.marshalAs != null)
			{
				num++;
			}
			if (num == 0)
			{
				return null;
			}
			object[] array = new object[num];
			num = 0;
			if (this.IsIn)
			{
				array[num++] = new InAttribute();
			}
			if (this.IsOptional)
			{
				array[num++] = new OptionalAttribute();
			}
			if (this.IsOut)
			{
				array[num++] = new OutAttribute();
			}
			if (this.marshalAs != null)
			{
				array[num++] = this.marshalAs.ToMarshalAsAttribute();
			}
			return array;
		}

		// Token: 0x040009FD RID: 2557
		protected Type ClassImpl;

		// Token: 0x040009FE RID: 2558
		protected object DefaultValueImpl;

		// Token: 0x040009FF RID: 2559
		protected MemberInfo MemberImpl;

		// Token: 0x04000A00 RID: 2560
		protected string NameImpl;

		// Token: 0x04000A01 RID: 2561
		protected int PositionImpl;

		// Token: 0x04000A02 RID: 2562
		protected ParameterAttributes AttrsImpl;

		// Token: 0x04000A03 RID: 2563
		private UnmanagedMarshal marshalAs;
	}
}
