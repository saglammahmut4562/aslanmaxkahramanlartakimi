﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000216 RID: 534
	[ComVisible(true)]
	[DefaultMember("Item")]
	[Serializable]
	public struct ParameterModifier
	{
		// Token: 0x04000A04 RID: 2564
		private bool[] _byref;
	}
}
