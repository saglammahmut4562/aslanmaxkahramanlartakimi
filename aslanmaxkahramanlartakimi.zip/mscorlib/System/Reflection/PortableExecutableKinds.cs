﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000218 RID: 536
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum PortableExecutableKinds
	{
		// Token: 0x04000A0D RID: 2573
		NotAPortableExecutableImage = 0,
		// Token: 0x04000A0E RID: 2574
		ILOnly = 1,
		// Token: 0x04000A0F RID: 2575
		Required32Bit = 2,
		// Token: 0x04000A10 RID: 2576
		PE32Plus = 4,
		// Token: 0x04000A11 RID: 2577
		Unmanaged32Bit = 8
	}
}
