﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000219 RID: 537
	[ComVisible(true)]
	[Serializable]
	public enum ProcessorArchitecture
	{
		// Token: 0x04000A13 RID: 2579
		None,
		// Token: 0x04000A14 RID: 2580
		MSIL,
		// Token: 0x04000A15 RID: 2581
		X86,
		// Token: 0x04000A16 RID: 2582
		IA64,
		// Token: 0x04000A17 RID: 2583
		Amd64
	}
}
