﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x0200021A RID: 538
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum PropertyAttributes
	{
		// Token: 0x04000A19 RID: 2585
		None = 0,
		// Token: 0x04000A1A RID: 2586
		SpecialName = 512,
		// Token: 0x04000A1B RID: 2587
		ReservedMask = 62464,
		// Token: 0x04000A1C RID: 2588
		RTSpecialName = 1024,
		// Token: 0x04000A1D RID: 2589
		HasDefault = 4096,
		// Token: 0x04000A1E RID: 2590
		Reserved2 = 8192,
		// Token: 0x04000A1F RID: 2591
		Reserved3 = 16384,
		// Token: 0x04000A20 RID: 2592
		Reserved4 = 32768
	}
}
