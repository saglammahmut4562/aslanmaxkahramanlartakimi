﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x0200021B RID: 539
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(_PropertyInfo))]
	[ComVisible(true)]
	[Serializable]
	public abstract class PropertyInfo : MemberInfo, _PropertyInfo
	{
		// Token: 0x1700036F RID: 879
		// (get) Token: 0x06001422 RID: 5154
		public abstract PropertyAttributes Attributes { get; }

		// Token: 0x17000370 RID: 880
		// (get) Token: 0x06001423 RID: 5155
		public abstract bool CanRead { get; }

		// Token: 0x17000371 RID: 881
		// (get) Token: 0x06001424 RID: 5156
		public abstract bool CanWrite { get; }

		// Token: 0x17000372 RID: 882
		// (get) Token: 0x06001425 RID: 5157 RVA: 0x0004F8D0 File Offset: 0x0004DAD0
		public override MemberTypes MemberType
		{
			get
			{
				return MemberTypes.Property;
			}
		}

		// Token: 0x17000373 RID: 883
		// (get) Token: 0x06001426 RID: 5158
		public abstract Type PropertyType { get; }

		// Token: 0x06001427 RID: 5159 RVA: 0x0004F8D4 File Offset: 0x0004DAD4
		public MethodInfo GetGetMethod()
		{
			return this.GetGetMethod(false);
		}

		// Token: 0x06001428 RID: 5160
		public abstract MethodInfo GetGetMethod(bool nonPublic);

		// Token: 0x06001429 RID: 5161
		public abstract ParameterInfo[] GetIndexParameters();

		// Token: 0x0600142A RID: 5162 RVA: 0x0004F8E0 File Offset: 0x0004DAE0
		public MethodInfo GetSetMethod()
		{
			return this.GetSetMethod(false);
		}

		// Token: 0x0600142B RID: 5163
		public abstract MethodInfo GetSetMethod(bool nonPublic);

		// Token: 0x0600142C RID: 5164 RVA: 0x0004F8EC File Offset: 0x0004DAEC
		[DebuggerHidden]
		[DebuggerStepThrough]
		public virtual object GetValue(object obj, object[] index)
		{
			return this.GetValue(obj, BindingFlags.Default, null, index, null);
		}

		// Token: 0x0600142D RID: 5165
		public abstract object GetValue(object obj, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture);

		// Token: 0x0600142E RID: 5166 RVA: 0x0004F8FC File Offset: 0x0004DAFC
		[DebuggerStepThrough]
		[DebuggerHidden]
		public virtual void SetValue(object obj, object value, object[] index)
		{
			this.SetValue(obj, value, BindingFlags.Default, null, index, null);
		}

		// Token: 0x0600142F RID: 5167
		public abstract void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture);
	}
}
