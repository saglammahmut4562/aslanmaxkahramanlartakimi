﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x0200021C RID: 540
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum ResourceAttributes
	{
		// Token: 0x04000A22 RID: 2594
		Public = 1,
		// Token: 0x04000A23 RID: 2595
		Private = 2
	}
}
