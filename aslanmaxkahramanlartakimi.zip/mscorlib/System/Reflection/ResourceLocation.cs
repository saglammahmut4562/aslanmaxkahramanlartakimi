﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x0200021D RID: 541
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum ResourceLocation
	{
		// Token: 0x04000A25 RID: 2597
		Embedded = 1,
		// Token: 0x04000A26 RID: 2598
		ContainedInAnotherAssembly = 2,
		// Token: 0x04000A27 RID: 2599
		ContainedInManifestFile = 4
	}
}
