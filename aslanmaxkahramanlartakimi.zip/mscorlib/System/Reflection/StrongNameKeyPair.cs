﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using Mono.Security;
using Mono.Security.Cryptography;

namespace System.Reflection
{
	// Token: 0x0200021E RID: 542
	[ComVisible(true)]
	[Serializable]
	public class StrongNameKeyPair : IDeserializationCallback, ISerializable
	{
		// Token: 0x06001430 RID: 5168 RVA: 0x0004F90C File Offset: 0x0004DB0C
		protected StrongNameKeyPair(SerializationInfo info, StreamingContext context)
		{
			this._publicKey = (byte[])info.GetValue("_publicKey", typeof(byte[]));
			this._keyPairContainer = info.GetString("_keyPairContainer");
			this._keyPairExported = info.GetBoolean("_keyPairExported");
			this._keyPairArray = (byte[])info.GetValue("_keyPairArray", typeof(byte[]));
		}

		// Token: 0x06001431 RID: 5169 RVA: 0x0004F984 File Offset: 0x0004DB84
		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("_publicKey", this._publicKey, typeof(byte[]));
			info.AddValue("_keyPairContainer", this._keyPairContainer);
			info.AddValue("_keyPairExported", this._keyPairExported);
			info.AddValue("_keyPairArray", this._keyPairArray, typeof(byte[]));
		}

		// Token: 0x06001432 RID: 5170 RVA: 0x0004F9EC File Offset: 0x0004DBEC
		void IDeserializationCallback.OnDeserialization(object sender)
		{
		}

		// Token: 0x06001433 RID: 5171 RVA: 0x0004F9F0 File Offset: 0x0004DBF0
		private RSA GetRSA()
		{
			if (this._rsa != null)
			{
				return this._rsa;
			}
			if (this._keyPairArray != null)
			{
				try
				{
					this._rsa = CryptoConvert.FromCapiKeyBlob(this._keyPairArray);
				}
				catch
				{
					this._keyPairArray = null;
				}
			}
			return this._rsa;
		}

		// Token: 0x06001434 RID: 5172 RVA: 0x0004FA54 File Offset: 0x0004DC54
		internal StrongName StrongName()
		{
			RSA rsa = this.GetRSA();
			if (rsa != null)
			{
				return new StrongName(rsa);
			}
			if (this._publicKey != null)
			{
				return new StrongName(this._publicKey);
			}
			return null;
		}

		// Token: 0x04000A28 RID: 2600
		private byte[] _publicKey;

		// Token: 0x04000A29 RID: 2601
		private string _keyPairContainer;

		// Token: 0x04000A2A RID: 2602
		private bool _keyPairExported;

		// Token: 0x04000A2B RID: 2603
		private byte[] _keyPairArray;

		// Token: 0x04000A2C RID: 2604
		[NonSerialized]
		private RSA _rsa;
	}
}
