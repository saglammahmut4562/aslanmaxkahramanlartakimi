﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x0200021F RID: 543
	[ComVisible(true)]
	[Serializable]
	public class TargetException : Exception
	{
		// Token: 0x06001435 RID: 5173 RVA: 0x0004FA90 File Offset: 0x0004DC90
		public TargetException()
			: base(Locale.GetText("Unable to invoke an invalid target."))
		{
		}

		// Token: 0x06001436 RID: 5174 RVA: 0x0004FAA4 File Offset: 0x0004DCA4
		public TargetException(string message)
			: base(message)
		{
		}

		// Token: 0x06001437 RID: 5175 RVA: 0x0004FAB0 File Offset: 0x0004DCB0
		protected TargetException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
