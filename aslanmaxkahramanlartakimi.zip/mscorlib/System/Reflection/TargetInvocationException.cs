﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x02000220 RID: 544
	[ComVisible(true)]
	[Serializable]
	public sealed class TargetInvocationException : Exception
	{
		// Token: 0x06001438 RID: 5176 RVA: 0x0004FABC File Offset: 0x0004DCBC
		public TargetInvocationException(Exception inner)
			: base("Exception has been thrown by the target of an invocation.", inner)
		{
		}

		// Token: 0x06001439 RID: 5177 RVA: 0x0004FACC File Offset: 0x0004DCCC
		public TargetInvocationException(string message, Exception inner)
			: base(message, inner)
		{
		}

		// Token: 0x0600143A RID: 5178 RVA: 0x0004FAD8 File Offset: 0x0004DCD8
		internal TargetInvocationException(SerializationInfo info, StreamingContext sc)
			: base(info, sc)
		{
		}
	}
}
