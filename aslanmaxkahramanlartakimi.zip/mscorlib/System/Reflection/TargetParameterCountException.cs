﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace System.Reflection
{
	// Token: 0x02000221 RID: 545
	[ComVisible(true)]
	[Serializable]
	public sealed class TargetParameterCountException : Exception
	{
		// Token: 0x0600143B RID: 5179 RVA: 0x0004FAE4 File Offset: 0x0004DCE4
		public TargetParameterCountException()
			: base(Locale.GetText("Number of parameter does not match expected count."))
		{
		}

		// Token: 0x0600143C RID: 5180 RVA: 0x0004FAF8 File Offset: 0x0004DCF8
		public TargetParameterCountException(string message)
			: base(message)
		{
		}

		// Token: 0x0600143D RID: 5181 RVA: 0x0004FB04 File Offset: 0x0004DD04
		internal TargetParameterCountException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
