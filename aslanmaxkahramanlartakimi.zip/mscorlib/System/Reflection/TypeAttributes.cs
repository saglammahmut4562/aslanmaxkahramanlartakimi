﻿using System;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000222 RID: 546
	[ComVisible(true)]
	[Flags]
	[Serializable]
	public enum TypeAttributes
	{
		// Token: 0x04000A2E RID: 2606
		VisibilityMask = 7,
		// Token: 0x04000A2F RID: 2607
		NotPublic = 0,
		// Token: 0x04000A30 RID: 2608
		Public = 1,
		// Token: 0x04000A31 RID: 2609
		NestedPublic = 2,
		// Token: 0x04000A32 RID: 2610
		NestedPrivate = 3,
		// Token: 0x04000A33 RID: 2611
		NestedFamily = 4,
		// Token: 0x04000A34 RID: 2612
		NestedAssembly = 5,
		// Token: 0x04000A35 RID: 2613
		NestedFamANDAssem = 6,
		// Token: 0x04000A36 RID: 2614
		NestedFamORAssem = 7,
		// Token: 0x04000A37 RID: 2615
		LayoutMask = 24,
		// Token: 0x04000A38 RID: 2616
		AutoLayout = 0,
		// Token: 0x04000A39 RID: 2617
		SequentialLayout = 8,
		// Token: 0x04000A3A RID: 2618
		ExplicitLayout = 16,
		// Token: 0x04000A3B RID: 2619
		ClassSemanticsMask = 32,
		// Token: 0x04000A3C RID: 2620
		Class = 0,
		// Token: 0x04000A3D RID: 2621
		Interface = 32,
		// Token: 0x04000A3E RID: 2622
		Abstract = 128,
		// Token: 0x04000A3F RID: 2623
		Sealed = 256,
		// Token: 0x04000A40 RID: 2624
		SpecialName = 1024,
		// Token: 0x04000A41 RID: 2625
		Import = 4096,
		// Token: 0x04000A42 RID: 2626
		Serializable = 8192,
		// Token: 0x04000A43 RID: 2627
		StringFormatMask = 196608,
		// Token: 0x04000A44 RID: 2628
		AnsiClass = 0,
		// Token: 0x04000A45 RID: 2629
		UnicodeClass = 65536,
		// Token: 0x04000A46 RID: 2630
		AutoClass = 131072,
		// Token: 0x04000A47 RID: 2631
		BeforeFieldInit = 1048576,
		// Token: 0x04000A48 RID: 2632
		ReservedMask = 264192,
		// Token: 0x04000A49 RID: 2633
		RTSpecialName = 2048,
		// Token: 0x04000A4A RID: 2634
		HasSecurity = 262144,
		// Token: 0x04000A4B RID: 2635
		CustomFormatClass = 196608,
		// Token: 0x04000A4C RID: 2636
		CustomFormatMask = 12582912
	}
}
