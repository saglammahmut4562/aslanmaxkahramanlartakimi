﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace System.Reflection
{
	// Token: 0x02000223 RID: 547
	[ComVisible(true)]
	[Serializable]
	public class TypeDelegator : Type
	{
		// Token: 0x0600143E RID: 5182 RVA: 0x0004FB10 File Offset: 0x0004DD10
		protected TypeDelegator()
		{
		}

		// Token: 0x17000374 RID: 884
		// (get) Token: 0x0600143F RID: 5183 RVA: 0x0004FB18 File Offset: 0x0004DD18
		public override Assembly Assembly
		{
			get
			{
				return this.typeImpl.Assembly;
			}
		}

		// Token: 0x17000375 RID: 885
		// (get) Token: 0x06001440 RID: 5184 RVA: 0x0004FB28 File Offset: 0x0004DD28
		public override string AssemblyQualifiedName
		{
			get
			{
				return this.typeImpl.AssemblyQualifiedName;
			}
		}

		// Token: 0x17000376 RID: 886
		// (get) Token: 0x06001441 RID: 5185 RVA: 0x0004FB38 File Offset: 0x0004DD38
		public override Type BaseType
		{
			get
			{
				return this.typeImpl.BaseType;
			}
		}

		// Token: 0x17000377 RID: 887
		// (get) Token: 0x06001442 RID: 5186 RVA: 0x0004FB48 File Offset: 0x0004DD48
		public override string FullName
		{
			get
			{
				return this.typeImpl.FullName;
			}
		}

		// Token: 0x17000378 RID: 888
		// (get) Token: 0x06001443 RID: 5187 RVA: 0x0004FB58 File Offset: 0x0004DD58
		public override Guid GUID
		{
			get
			{
				return this.typeImpl.GUID;
			}
		}

		// Token: 0x17000379 RID: 889
		// (get) Token: 0x06001444 RID: 5188 RVA: 0x0004FB68 File Offset: 0x0004DD68
		public override Module Module
		{
			get
			{
				return this.typeImpl.Module;
			}
		}

		// Token: 0x1700037A RID: 890
		// (get) Token: 0x06001445 RID: 5189 RVA: 0x0004FB78 File Offset: 0x0004DD78
		public override string Name
		{
			get
			{
				return this.typeImpl.Name;
			}
		}

		// Token: 0x1700037B RID: 891
		// (get) Token: 0x06001446 RID: 5190 RVA: 0x0004FB88 File Offset: 0x0004DD88
		public override string Namespace
		{
			get
			{
				return this.typeImpl.Namespace;
			}
		}

		// Token: 0x1700037C RID: 892
		// (get) Token: 0x06001447 RID: 5191 RVA: 0x0004FB98 File Offset: 0x0004DD98
		public override RuntimeTypeHandle TypeHandle
		{
			get
			{
				return this.typeImpl.TypeHandle;
			}
		}

		// Token: 0x1700037D RID: 893
		// (get) Token: 0x06001448 RID: 5192 RVA: 0x0004FBA8 File Offset: 0x0004DDA8
		public override Type UnderlyingSystemType
		{
			get
			{
				return this.typeImpl.UnderlyingSystemType;
			}
		}

		// Token: 0x06001449 RID: 5193 RVA: 0x0004FBB8 File Offset: 0x0004DDB8
		protected override TypeAttributes GetAttributeFlagsImpl()
		{
			return this.typeImpl.Attributes;
		}

		// Token: 0x0600144A RID: 5194 RVA: 0x0004FBC8 File Offset: 0x0004DDC8
		protected override ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			return this.typeImpl.GetConstructor(bindingAttr, binder, callConvention, types, modifiers);
		}

		// Token: 0x0600144B RID: 5195 RVA: 0x0004FBDC File Offset: 0x0004DDDC
		[ComVisible(true)]
		public override ConstructorInfo[] GetConstructors(BindingFlags bindingAttr)
		{
			return this.typeImpl.GetConstructors(bindingAttr);
		}

		// Token: 0x0600144C RID: 5196 RVA: 0x0004FBEC File Offset: 0x0004DDEC
		public override object[] GetCustomAttributes(bool inherit)
		{
			return this.typeImpl.GetCustomAttributes(inherit);
		}

		// Token: 0x0600144D RID: 5197 RVA: 0x0004FBFC File Offset: 0x0004DDFC
		public override object[] GetCustomAttributes(Type attributeType, bool inherit)
		{
			return this.typeImpl.GetCustomAttributes(attributeType, inherit);
		}

		// Token: 0x0600144E RID: 5198 RVA: 0x0004FC0C File Offset: 0x0004DE0C
		public override Type GetElementType()
		{
			return this.typeImpl.GetElementType();
		}

		// Token: 0x0600144F RID: 5199 RVA: 0x0004FC1C File Offset: 0x0004DE1C
		public override EventInfo GetEvent(string name, BindingFlags bindingAttr)
		{
			return this.typeImpl.GetEvent(name, bindingAttr);
		}

		// Token: 0x06001450 RID: 5200 RVA: 0x0004FC2C File Offset: 0x0004DE2C
		public override EventInfo[] GetEvents(BindingFlags bindingAttr)
		{
			return this.typeImpl.GetEvents(bindingAttr);
		}

		// Token: 0x06001451 RID: 5201 RVA: 0x0004FC3C File Offset: 0x0004DE3C
		public override FieldInfo GetField(string name, BindingFlags bindingAttr)
		{
			return this.typeImpl.GetField(name, bindingAttr);
		}

		// Token: 0x06001452 RID: 5202 RVA: 0x0004FC4C File Offset: 0x0004DE4C
		public override FieldInfo[] GetFields(BindingFlags bindingAttr)
		{
			return this.typeImpl.GetFields(bindingAttr);
		}

		// Token: 0x06001453 RID: 5203 RVA: 0x0004FC5C File Offset: 0x0004DE5C
		public override Type[] GetInterfaces()
		{
			return this.typeImpl.GetInterfaces();
		}

		// Token: 0x06001454 RID: 5204 RVA: 0x0004FC6C File Offset: 0x0004DE6C
		public override MemberInfo[] GetMember(string name, MemberTypes type, BindingFlags bindingAttr)
		{
			return this.typeImpl.GetMember(name, type, bindingAttr);
		}

		// Token: 0x06001455 RID: 5205 RVA: 0x0004FC7C File Offset: 0x0004DE7C
		protected override MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers)
		{
			return this.typeImpl.GetMethodImplInternal(name, bindingAttr, binder, callConvention, types, modifiers);
		}

		// Token: 0x06001456 RID: 5206 RVA: 0x0004FC94 File Offset: 0x0004DE94
		public override MethodInfo[] GetMethods(BindingFlags bindingAttr)
		{
			return this.typeImpl.GetMethods(bindingAttr);
		}

		// Token: 0x06001457 RID: 5207 RVA: 0x0004FCA4 File Offset: 0x0004DEA4
		public override Type[] GetNestedTypes(BindingFlags bindingAttr)
		{
			return this.typeImpl.GetNestedTypes(bindingAttr);
		}

		// Token: 0x06001458 RID: 5208 RVA: 0x0004FCB4 File Offset: 0x0004DEB4
		public override PropertyInfo[] GetProperties(BindingFlags bindingAttr)
		{
			return this.typeImpl.GetProperties(bindingAttr);
		}

		// Token: 0x06001459 RID: 5209 RVA: 0x0004FCC4 File Offset: 0x0004DEC4
		protected override PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
		{
			return this.typeImpl.GetPropertyImplInternal(name, bindingAttr, binder, returnType, types, modifiers);
		}

		// Token: 0x0600145A RID: 5210 RVA: 0x0004FCDC File Offset: 0x0004DEDC
		protected override bool HasElementTypeImpl()
		{
			return this.typeImpl.HasElementType;
		}

		// Token: 0x0600145B RID: 5211 RVA: 0x0004FCEC File Offset: 0x0004DEEC
		public override object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] namedParameters)
		{
			return this.typeImpl.InvokeMember(name, invokeAttr, binder, target, args, modifiers, culture, namedParameters);
		}

		// Token: 0x0600145C RID: 5212 RVA: 0x0004FD14 File Offset: 0x0004DF14
		protected override bool IsArrayImpl()
		{
			return this.typeImpl.IsArray;
		}

		// Token: 0x0600145D RID: 5213 RVA: 0x0004FD24 File Offset: 0x0004DF24
		protected override bool IsByRefImpl()
		{
			return this.typeImpl.IsByRef;
		}

		// Token: 0x0600145E RID: 5214 RVA: 0x0004FD34 File Offset: 0x0004DF34
		public override bool IsDefined(Type attributeType, bool inherit)
		{
			return this.typeImpl.IsDefined(attributeType, inherit);
		}

		// Token: 0x0600145F RID: 5215 RVA: 0x0004FD44 File Offset: 0x0004DF44
		protected override bool IsPointerImpl()
		{
			return this.typeImpl.IsPointer;
		}

		// Token: 0x06001460 RID: 5216 RVA: 0x0004FD54 File Offset: 0x0004DF54
		protected override bool IsPrimitiveImpl()
		{
			return this.typeImpl.IsPrimitive;
		}

		// Token: 0x06001461 RID: 5217 RVA: 0x0004FD64 File Offset: 0x0004DF64
		protected override bool IsValueTypeImpl()
		{
			return this.typeImpl.IsValueType;
		}

		// Token: 0x04000A4D RID: 2637
		protected Type typeImpl;
	}
}
