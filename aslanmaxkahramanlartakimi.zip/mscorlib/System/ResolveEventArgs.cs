﻿using System;
using System.Runtime.InteropServices;

namespace System
{
	// Token: 0x02000225 RID: 549
	[ComVisible(true)]
	public class ResolveEventArgs : EventArgs
	{
		// Token: 0x06001466 RID: 5222 RVA: 0x0004FD74 File Offset: 0x0004DF74
		public ResolveEventArgs(string name)
		{
			this.m_Name = name;
		}

		// Token: 0x04000A4E RID: 2638
		private string m_Name;
	}
}
