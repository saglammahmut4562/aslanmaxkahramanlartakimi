﻿using System;

namespace System.Resources
{
	// Token: 0x02000227 RID: 551
	internal class NameOrId
	{
		// Token: 0x1700037E RID: 894
		// (get) Token: 0x0600146B RID: 5227 RVA: 0x0004FD84 File Offset: 0x0004DF84
		public bool IsName
		{
			get
			{
				return this.name != null;
			}
		}

		// Token: 0x1700037F RID: 895
		// (get) Token: 0x0600146C RID: 5228 RVA: 0x0004FD94 File Offset: 0x0004DF94
		public int Id
		{
			get
			{
				return this.id;
			}
		}

		// Token: 0x0600146D RID: 5229 RVA: 0x0004FD9C File Offset: 0x0004DF9C
		public override string ToString()
		{
			if (this.name != null)
			{
				return "Name(" + this.name + ")";
			}
			return "Id(" + this.id + ")";
		}

		// Token: 0x04000A4F RID: 2639
		private string name;

		// Token: 0x04000A50 RID: 2640
		private int id;
	}
}
