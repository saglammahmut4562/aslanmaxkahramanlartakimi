﻿using System;
using System.Runtime.InteropServices;

namespace System.Resources
{
	// Token: 0x02000228 RID: 552
	[AttributeUsage(AttributeTargets.Assembly)]
	[ComVisible(true)]
	public sealed class NeutralResourcesLanguageAttribute : Attribute
	{
		// Token: 0x0600146E RID: 5230 RVA: 0x0004FDDC File Offset: 0x0004DFDC
		public NeutralResourcesLanguageAttribute(string cultureName)
		{
			if (cultureName == null)
			{
				throw new ArgumentNullException("culture is null");
			}
			this.culture = cultureName;
		}

		// Token: 0x04000A51 RID: 2641
		private string culture;

		// Token: 0x04000A52 RID: 2642
		private UltimateResourceFallbackLocation loc;
	}
}
