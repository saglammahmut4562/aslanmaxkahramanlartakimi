﻿using System;
using System.Runtime.InteropServices;

namespace System.Resources
{
	// Token: 0x02000229 RID: 553
	[ComVisible(true)]
	[AttributeUsage(AttributeTargets.Assembly)]
	public sealed class SatelliteContractVersionAttribute : Attribute
	{
		// Token: 0x0600146F RID: 5231 RVA: 0x0004FDFC File Offset: 0x0004DFFC
		public SatelliteContractVersionAttribute(string version)
		{
			this.ver = new Version(version);
		}

		// Token: 0x04000A53 RID: 2643
		private Version ver;
	}
}
