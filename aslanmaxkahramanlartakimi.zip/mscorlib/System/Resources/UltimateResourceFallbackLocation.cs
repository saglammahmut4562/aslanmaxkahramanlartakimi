﻿using System;
using System.Runtime.InteropServices;

namespace System.Resources
{
	// Token: 0x0200022A RID: 554
	[ComVisible(true)]
	[Serializable]
	public enum UltimateResourceFallbackLocation
	{
		// Token: 0x04000A55 RID: 2645
		MainAssembly,
		// Token: 0x04000A56 RID: 2646
		Satellite
	}
}
