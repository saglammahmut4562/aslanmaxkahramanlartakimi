﻿using System;

namespace System.Resources
{
	// Token: 0x0200022B RID: 555
	internal abstract class Win32Resource
	{
		// Token: 0x17000380 RID: 896
		// (get) Token: 0x06001470 RID: 5232 RVA: 0x0004FE10 File Offset: 0x0004E010
		public Win32ResourceType ResourceType
		{
			get
			{
				if (this.type.IsName)
				{
					return (Win32ResourceType)(-1);
				}
				return (Win32ResourceType)this.type.Id;
			}
		}

		// Token: 0x06001471 RID: 5233 RVA: 0x0004FE30 File Offset: 0x0004E030
		public override string ToString()
		{
			return string.Concat(new object[] { "Win32Resource (Kind=", this.ResourceType, ", Name=", this.name, ")" });
		}

		// Token: 0x04000A57 RID: 2647
		private NameOrId type;

		// Token: 0x04000A58 RID: 2648
		private NameOrId name;

		// Token: 0x04000A59 RID: 2649
		private int language;
	}
}
