﻿using System;

namespace System.Resources
{
	// Token: 0x0200022C RID: 556
	internal enum Win32ResourceType
	{
		// Token: 0x04000A5B RID: 2651
		RT_CURSOR = 1,
		// Token: 0x04000A5C RID: 2652
		RT_FONT = 8,
		// Token: 0x04000A5D RID: 2653
		RT_BITMAP = 2,
		// Token: 0x04000A5E RID: 2654
		RT_ICON,
		// Token: 0x04000A5F RID: 2655
		RT_MENU,
		// Token: 0x04000A60 RID: 2656
		RT_DIALOG,
		// Token: 0x04000A61 RID: 2657
		RT_STRING,
		// Token: 0x04000A62 RID: 2658
		RT_FONTDIR,
		// Token: 0x04000A63 RID: 2659
		RT_ACCELERATOR = 9,
		// Token: 0x04000A64 RID: 2660
		RT_RCDATA,
		// Token: 0x04000A65 RID: 2661
		RT_MESSAGETABLE,
		// Token: 0x04000A66 RID: 2662
		RT_GROUP_CURSOR,
		// Token: 0x04000A67 RID: 2663
		RT_GROUP_ICON = 14,
		// Token: 0x04000A68 RID: 2664
		RT_VERSION = 16,
		// Token: 0x04000A69 RID: 2665
		RT_DLGINCLUDE,
		// Token: 0x04000A6A RID: 2666
		RT_PLUGPLAY = 19,
		// Token: 0x04000A6B RID: 2667
		RT_VXD,
		// Token: 0x04000A6C RID: 2668
		RT_ANICURSOR,
		// Token: 0x04000A6D RID: 2669
		RT_ANIICON,
		// Token: 0x04000A6E RID: 2670
		RT_HTML
	}
}
