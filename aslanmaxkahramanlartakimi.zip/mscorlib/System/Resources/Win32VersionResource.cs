﻿using System;
using System.Collections;
using System.Reflection;

namespace System.Resources
{
	// Token: 0x0200022D RID: 557
	[DefaultMember("Item")]
	internal class Win32VersionResource : Win32Resource
	{
		// Token: 0x04000A6F RID: 2671
		public string[] WellKnownProperties;

		// Token: 0x04000A70 RID: 2672
		private long signature;

		// Token: 0x04000A71 RID: 2673
		private int struct_version;

		// Token: 0x04000A72 RID: 2674
		private long file_version;

		// Token: 0x04000A73 RID: 2675
		private long product_version;

		// Token: 0x04000A74 RID: 2676
		private int file_flags_mask;

		// Token: 0x04000A75 RID: 2677
		private int file_flags;

		// Token: 0x04000A76 RID: 2678
		private int file_os;

		// Token: 0x04000A77 RID: 2679
		private int file_type;

		// Token: 0x04000A78 RID: 2680
		private int file_subtype;

		// Token: 0x04000A79 RID: 2681
		private long file_date;

		// Token: 0x04000A7A RID: 2682
		private int file_lang;

		// Token: 0x04000A7B RID: 2683
		private int file_codepage;

		// Token: 0x04000A7C RID: 2684
		private Hashtable properties;
	}
}
