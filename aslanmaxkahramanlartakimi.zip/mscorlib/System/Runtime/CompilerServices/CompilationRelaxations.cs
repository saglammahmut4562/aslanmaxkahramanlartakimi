﻿using System;
using System.Runtime.InteropServices;

namespace System.Runtime.CompilerServices
{
	// Token: 0x0200022E RID: 558
	[Flags]
	[ComVisible(true)]
	[Serializable]
	public enum CompilationRelaxations
	{
		// Token: 0x04000A7E RID: 2686
		NoStringInterning = 8
	}
}
